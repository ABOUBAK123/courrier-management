# Guide d'Installation sur Serveur Personnel

## Prérequis

- Serveur web (Apache/Nginx)
- PHP 7.4 ou supérieur
- MySQL 5.7 ou supérieur
- Extensions PHP : pdo, pdo_mysql, json, mbstring

## Étapes d'Installation

### 1. Configuration de la Base de Données

```bash
# Se connecter à MySQL
mysql -u root -p

# Créer la base de données
CREATE DATABASE gestion_administrative CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Créer un utilisateur
CREATE USER 'admin_user'@'localhost' IDENTIFIED BY 'votre_mot_de_passe_securise';
GRANT ALL PRIVILEGES ON gestion_administrative.* TO 'admin_user'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Importer les Tables

```bash
# Importer la table des objets
mysql -u admin_user -p gestion_administrative < database/objects_table.sql

# Importer les autres tables
mysql -u admin_user -p gestion_administrative < database/mail_management.sql
mysql -u admin_user -p gestion_administrative < database/mail_management_part2.sql
mysql -u admin_user -p gestion_administrative < database/mail_management_part3.sql
mysql -u admin_user -p gestion_administrative < database/mail_management_part4.sql
```

### 3. Configuration de l'Application

Modifier le fichier `config/database.php` avec vos informations :

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'gestion_administrative');
define('DB_USER', 'admin_user');
define('DB_PASS', 'votre_mot_de_passe_securise');
```

### 4. Configuration Apache

```apache
<VirtualHost *:80>
    ServerName votre-domaine.com
    DocumentRoot /var/www/html/gestion-administrative
    
    <Directory /var/www/html/gestion-administrative>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
```

### 5. Permissions

```bash
# Définir les permissions appropriées
sudo chown -R www-data:www-data /var/www/html/gestion-administrative
sudo chmod -R 755 /var/www/html/gestion-administrative
```

### 6. Test de l'Installation

1. Accéder à `http://votre-domaine.com`
2. Vérifier que l'application se charge sans erreurs
3. Tester la connexion avec les identifiants par défaut

## Dépannage

### Erreur de connexion à la base de données
- Vérifier les identifiants dans `config/database.php`
- Vérifier que MySQL est démarré : `sudo systemctl status mysql`

### Erreur 404 sur les API
- Vérifier que le fichier `.htaccess` est présent
- Vérifier que `mod_rewrite` est activé : `sudo a2enmod rewrite`

### Erreurs de permissions
- Vérifier les permissions des fichiers et dossiers
- Vérifier que l'utilisateur www-data a accès aux fichiers

## Sécurité

1. Changer les mots de passe par défaut
2. Activer HTTPS avec Let's Encrypt
3. Configurer le firewall
4. Sauvegarder régulièrement la base de données

## Maintenance

### Sauvegarde de la base de données
```bash
mysqldump -u admin_user -p gestion_administrative > backup_$(date +%Y%m%d).sql
```

### Restauration
```bash
mysql -u admin_user -p gestion_administrative < backup_20250101.sql
```
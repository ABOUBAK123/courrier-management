<?php
// Script de diagnostic FTP détaillé
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

echo "<h1>Diagnostic FTP - Système de Gestion du Courrier</h1>";
echo "<hr>";

// Vérifier les extensions PHP
echo "<h2>1. Vérification des extensions PHP</h2>";
echo "Version PHP: " . PHP_VERSION . "<br>";
echo "Extension FTP: " . (extension_loaded('ftp') ? "✅ Disponible" : "❌ Non disponible") . "<br>";
echo "Extension cURL: " . (extension_loaded('curl') ? "✅ Disponible" : "❌ Non disponible") . "<br>";
echo "Extension OpenSSL: " . (extension_loaded('openssl') ? "✅ Disponible" : "❌ Non disponible") . "<br>";
echo "<br>";

// Vérifier les fonctions FTP
echo "<h2>2. Fonctions FTP disponibles</h2>";
$ftp_functions = ['ftp_connect', 'ftp_login', 'ftp_pasv', 'ftp_put', 'ftp_get', 'ftp_nlist'];
foreach ($ftp_functions as $func) {
    echo "$func: " . (function_exists($func) ? "✅ Disponible" : "❌ Non disponible") . "<br>";
}
echo "<br>";

// Test de connexion si des paramètres sont fournis
if (isset($_GET['test']) && $_GET['test'] == '1') {
    echo "<h2>3. Test de connexion FTP</h2>";
    
    $host = $_GET['host'] ?? '';
    $port = $_GET['port'] ?? 21;
    $username = $_GET['username'] ?? '';
    $password = $_GET['password'] ?? '';
    
    if ($host && $username && $password) {
        echo "Tentative de connexion à: $host:$port<br>";
        echo "Utilisateur: $username<br>";
        echo "Mot de passe: " . str_repeat('*', strlen($password)) . "<br><br>";
        
        // Test de résolution DNS
        echo "<strong>Résolution DNS:</strong><br>";
        $ip = gethostbyname($host);
        if ($ip != $host) {
            echo "✅ $host résolu vers $ip<br>";
        } else {
            echo "❌ Impossible de résoudre $host<br>";
        }
        echo "<br>";
        
        // Test de connexion TCP
        echo "<strong>Test de connexion TCP:</strong><br>";
        $socket = @fsockopen($host, $port, $errno, $errstr, 10);
        if ($socket) {
            echo "✅ Connexion TCP réussie sur $host:$port<br>";
            fclose($socket);
        } else {
            echo "❌ Connexion TCP échouée: $errstr ($errno)<br>";
        }
        echo "<br>";
        
        // Test de connexion FTP
        echo "<strong>Test de connexion FTP:</strong><br>";
        $ftp = @ftp_connect($host, $port, 30);
        if ($ftp) {
            echo "✅ Connexion FTP établie<br>";
            
            // Test de login
            $login = @ftp_login($ftp, $username, $password);
            if ($login) {
                echo "✅ Authentification réussie<br>";
                
                // Test du mode passif
                echo "<strong>Test du mode passif:</strong><br>";
                $pasv = ftp_pasv($ftp, true);
                echo ($pasv ? "✅" : "❌") . " Mode passif activé<br>";
                
                // Test de listing
                echo "<strong>Test de listing:</strong><br>";
                $list = @ftp_nlist($ftp, '.');
                if ($list !== false) {
                    echo "✅ Listing réussi (" . count($list) . " éléments)<br>";
                    if (count($list) > 0) {
                        echo "Premiers éléments: " . implode(', ', array_slice($list, 0, 5)) . "<br>";
                    }
                } else {
                    echo "❌ Listing échoué<br>";
                }
                
                // Test du répertoire de travail
                echo "<strong>Répertoire de travail:</strong><br>";
                $pwd = @ftp_pwd($ftp);
                if ($pwd) {
                    echo "✅ Répertoire actuel: $pwd<br>";
                } else {
                    echo "❌ Impossible de déterminer le répertoire<br>";
                }
                
            } else {
                echo "❌ Authentification échouée<br>";
            }
            
            ftp_close($ftp);
        } else {
            echo "❌ Connexion FTP échouée<br>";
        }
    } else {
        echo "❌ Paramètres manquants pour le test<br>";
    }
}

// Formulaire de test
echo "<hr>";
echo "<h2>Test Manuel</h2>";
echo "<form method='GET'>";
echo "<input type='hidden' name='test' value='1'>";
echo "<table>";
echo "<tr><td>Serveur FTP:</td><td><input type='text' name='host' placeholder='ftp.example.com' required></td></tr>";
echo "<tr><td>Port:</td><td><input type='number' name='port' value='21' required></td></tr>";
echo "<tr><td>Utilisateur:</td><td><input type='text' name='username' required></td></tr>";
echo "<tr><td>Mot de passe:</td><td><input type='password' name='password' required></td></tr>";
echo "<tr><td colspan='2'><input type='submit' value='Tester la connexion'></td></tr>";
echo "</table>";
echo "</form>";

echo "<hr>";
echo "<p><small>Script généré le " . date('Y-m-d H:i:s') . "</small></p>";
?>
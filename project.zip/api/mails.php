<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['direction'])) {
                getMails($db, $_GET['direction']);
            } else {
                jsonResponse(['error' => 'Direction requise'], 400);
            }
            break;
            
        case 'POST':
            createMail($db, $input);
            break;
            
        case 'PUT':
            if (isset($_GET['id'])) {
                updateMail($db, $_GET['id'], $input);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        case 'DELETE':
            if (isset($_GET['id'])) {
                deleteMail($db, $_GET['id']);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        default:
            jsonResponse(['error' => 'Méthode non autorisée'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function getMails($db, $direction) {
    $stmt = $db->prepare("SELECT * FROM mails WHERE direction = ? ORDER BY created_at DESC");
    $stmt->execute([$direction]);
    $mails = $stmt->fetchAll();
    
    jsonResponse(['items' => $mails]);
}

function createMail($db, $data) {
    $required = ['numero', 'type', 'objet', 'direction'];
    $errors = validateInput($data, $required);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("INSERT INTO mails (numero, type, priority, date_emission, objet, expediteur, destinateur, numero_emission, numero_reference, direction, created_by, files) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->execute([
        sanitizeInput($data['numero']),
        sanitizeInput($data['type']),
        isset($data['priority']) ? sanitizeInput($data['priority']) : 'normale',
        $data['date'],
        sanitizeInput($data['objet']),
        isset($data['expediteur']) ? sanitizeInput($data['expediteur']) : null,
        isset($data['destinateur']) ? sanitizeInput($data['destinateur']) : null,
        isset($data['numeroEmission']) ? sanitizeInput($data['numeroEmission']) : null,
        isset($data['numeroReference']) ? sanitizeInput($data['numeroReference']) : null,
        sanitizeInput($data['direction']),
        isset($data['createdBy']) ? $data['createdBy'] : null,
        isset($data['files']) ? json_encode($data['files']) : null
    ]);
    
    $mailId = $db->lastInsertId();
    jsonResponse(['success' => true, 'id' => $mailId, 'message' => 'Courrier créé']);
}

function updateMail($db, $id, $data) {
    $stmt = $db->prepare("UPDATE mails SET status = ?, treatment_name = ?, response_file = ? WHERE id = ?");
    $stmt->execute([
        isset($data['status']) ? sanitizeInput($data['status']) : null,
        isset($data['treatmentName']) ? sanitizeInput($data['treatmentName']) : null,
        isset($data['responseFile']) ? sanitizeInput($data['responseFile']) : null,
        $id
    ]);
    
    jsonResponse(['success' => true, 'message' => 'Courrier mis à jour']);
}

function deleteMail($db, $id) {
    $stmt = $db->prepare("DELETE FROM mails WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['success' => true, 'message' => 'Courrier supprimé']);
}
?>

<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'POST':
            if (isset($_GET['action']) && $_GET['action'] === 'login') {
                login($db, $input);
            } elseif (isset($_GET['action']) && $_GET['action'] === 'register') {
                register($db, $input);
            } else {
                jsonResponse(['error' => 'Action non valide'], 400);
            }
            break;
        
        case 'PUT':
            if (isset($_GET['action']) && $_GET['action'] === 'update_password') {
                updatePassword($db, $input);
            } elseif (isset($_GET['action']) && $_GET['action'] === 'update_photo') {
                updatePhoto($db, $input);
            } else {
                jsonResponse(['error' => 'Action non valide'], 400);
            }
            break;
            
        default:
            jsonResponse(['error' => 'Méthode non autorisée'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function login($db, $data) {
    $errors = validateInput($data, ['email', 'password']);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([sanitizeInput($data['email'])]);
    $user = $stmt->fetch();

    if ($user && $user['password'] === $data['password']) {
        unset($user['password']);
        jsonResponse(['success' => true, 'user' => $user]);
    } else {
        jsonResponse(['error' => 'Email ou mot de passe incorrect'], 401);
    }
}

function register($db, $data) {
    $required = ['name', 'email', 'password', 'role', 'direction'];
    $errors = validateInput($data, $required);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    try {
        $stmt = $db->prepare("INSERT INTO users (name, email, password, role, direction, superieur_hierarchique) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            sanitizeInput($data['name']),
            sanitizeInput($data['email']),
            $data['password'],
            sanitizeInput($data['role']),
            sanitizeInput($data['direction']),
            isset($data['superieur_hierarchique']) ? sanitizeInput($data['superieur_hierarchique']) : null
        ]);
        
        jsonResponse(['success' => true, 'message' => 'Utilisateur créé avec succès']);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            jsonResponse(['error' => 'Cet email existe déjà'], 409);
        }
        throw $e;
    }
}

function updatePassword($db, $data) {
    $errors = validateInput($data, ['email', 'current_password', 'new_password']);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("SELECT password FROM users WHERE email = ?");
    $stmt->execute([sanitizeInput($data['email'])]);
    $user = $stmt->fetch();

    if (!$user || $user['password'] !== $data['current_password']) {
        jsonResponse(['error' => 'Mot de passe actuel incorrect'], 401);
    }

    $stmt = $db->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->execute([$data['new_password'], sanitizeInput($data['email'])]);
    
    jsonResponse(['success' => true, 'message' => 'Mot de passe mis à jour']);
}

function updatePhoto($db, $data) {
    $errors = validateInput($data, ['email', 'photo']);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("UPDATE users SET photo = ? WHERE email = ?");
    $stmt->execute([$data['photo'], sanitizeInput($data['email'])]);
    
    jsonResponse(['success' => true, 'message' => 'Photo mise à jour']);
}
?>

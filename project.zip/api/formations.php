<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['direction'])) {
                getFormations($db, $_GET['direction']);
            } else {
                jsonResponse(['error' => 'Direction requise'], 400);
            }
            break;
            
        case 'POST':
            createFormation($db, $input);
            break;
            
        case 'PUT':
            if (isset($_GET['id'])) {
                updateFormation($db, $_GET['id'], $input);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        case 'DELETE':
            if (isset($_GET['id'])) {
                deleteFormation($db, $_GET['id']);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        default:
            jsonResponse(['error' => 'Méthode non autorisée'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function getFormations($db, $direction) {
    $stmt = $db->prepare("SELECT * FROM formations WHERE direction = ? ORDER BY created_at DESC");
    $stmt->execute([$direction]);
    $formations = $stmt->fetchAll();
    
    jsonResponse(['items' => $formations]);
}

function createFormation($db, $data) {
    $required = ['titre', 'dateDebut', 'dateFin', 'formateur', 'direction'];
    $errors = validateInput($data, $required);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("INSERT INTO formations (titre, description, date_debut, date_fin, formateur, participants, direction, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        sanitizeInput($data['titre']),
        isset($data['description']) ? sanitizeInput($data['description']) : null,
        $data['dateDebut'],
        $data['dateFin'],
        sanitizeInput($data['formateur']),
        isset($data['participants']) ? sanitizeInput($data['participants']) : null,
        sanitizeInput($data['direction']),
        isset($data['createdBy']) ? sanitizeInput($data['createdBy']) : null
    ]);
    
    $formationId = $db->lastInsertId();
    jsonResponse(['success' => true, 'id' => $formationId, 'message' => 'Formation créée']);
}

function updateFormation($db, $id, $data) {
    $stmt = $db->prepare("UPDATE formations SET status = ? WHERE id = ?");
    $stmt->execute([
        isset($data['status']) ? sanitizeInput($data['status']) : null,
        $id
    ]);
    
    jsonResponse(['success' => true, 'message' => 'Formation mise à jour']);
}

function deleteFormation($db, $id) {
    $stmt = $db->prepare("DELETE FROM formations WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['success' => true, 'message' => 'Formation supprimée']);
}
?>

<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['direction'])) {
                getConges($db, $_GET['direction']);
            } else {
                jsonResponse(['error' => 'Direction requise'], 400);
            }
            break;
            
        case 'POST':
            createConge($db, $input);
            break;
            
        case 'PUT':
            if (isset($_GET['id'])) {
                updateConge($db, $_GET['id'], $input);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        default:
            jsonResponse(['error' => 'Méthode non autorisée'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function getConges($db, $direction) {
    $stmt = $db->prepare("SELECT * FROM conges WHERE direction = ? ORDER BY created_at DESC");
    $stmt->execute([$direction]);
    $conges = $stmt->fetchAll();
    
    jsonResponse(['items' => $conges]);
}

function createConge($db, $data) {
    $required = ['employe', 'typeConge', 'dateDebut', 'dateFin', 'direction'];
    $errors = validateInput($data, $required);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("INSERT INTO conges (employe, type_conge, date_debut, date_fin, motif, direction, demande_par) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        sanitizeInput($data['employe']),
        sanitizeInput($data['typeConge']),
        $data['dateDebut'],
        $data['dateFin'],
        isset($data['motif']) ? sanitizeInput($data['motif']) : null,
        sanitizeInput($data['direction']),
        isset($data['demandePar']) ? sanitizeInput($data['demandePar']) : null
    ]);
    
    $congeId = $db->lastInsertId();
    jsonResponse(['success' => true, 'id' => $congeId, 'message' => 'Demande de congé créée']);
}

function updateConge($db, $id, $data) {
    $stmt = $db->prepare("UPDATE conges SET status = ?, approuve_par = ? WHERE id = ?");
    $stmt->execute([
        isset($data['status']) ? sanitizeInput($data['status']) : null,
        isset($data['approuvePar']) ? sanitizeInput($data['approuvePar']) : null,
        $id
    ]);
    
    jsonResponse(['success' => true, 'message' => 'Congé mis à jour']);
}
?>

<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['user1']) && isset($_GET['user2'])) {
                getChatMessages($db, $_GET['user1'], $_GET['user2']);
            } else {
                jsonResponse(['error' => 'Utilisateurs requis'], 400);
            }
            break;
            
        case 'POST':
            sendMessage($db, $input);
            break;
            
        default:
            jsonResponse(['error' => 'Méthode non autorisée'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function getChatMessages($db, $user1, $user2) {
    $stmt = $db->prepare("SELECT * FROM chat_messages WHERE (sender_email = ? AND receiver_email = ?) OR (sender_email = ? AND receiver_email = ?) ORDER BY timestamp ASC LIMIT 50");
    $stmt->execute([$user1, $user2, $user2, $user1]);
    $messages = $stmt->fetchAll();
    
    // Formater les données pour correspondre à l'interface
    foreach ($messages as &$msg) {
        $msg['sender'] = $msg['sender_email'];
        $msg['senderName'] = $msg['sender_name'];
        $msg['receiver'] = $msg['receiver_email'];
        $msg['message'] = $msg['message'];
    }
    
    jsonResponse(['items' => $messages]);
}

function sendMessage($db, $data) {
    $required = ['sender_email', 'sender_name', 'receiver_email', 'message'];
    $errors = validateInput($data, $required);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("INSERT INTO chat_messages (sender_email, sender_name, receiver_email, message) VALUES (?, ?, ?, ?)");
    $stmt->execute([
        sanitizeInput($data['sender_email']),
        sanitizeInput($data['sender_name']),
        sanitizeInput($data['receiver_email']),
        sanitizeInput($data['message'])
    ]);
    
    jsonResponse(['success' => true, 'message' => 'Message envoyé']);
}
?>

<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['direction'])) {
                getPersonnel($db, $_GET['direction']);
            } else {
                jsonResponse(['error' => 'Direction requise'], 400);
            }
            break;
            
        case 'POST':
            createPersonnel($db, $input);
            break;
            
        case 'PUT':
            if (isset($_GET['id'])) {
                updatePersonnel($db, $_GET['id'], $input);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        case 'DELETE':
            if (isset($_GET['id'])) {
                deletePersonnel($db, $_GET['id']);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        default:
            jsonResponse(['error' => 'Méthode non autorisée'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function getPersonnel($db, $direction) {
    $stmt = $db->prepare("SELECT * FROM personnel WHERE direction = ? ORDER BY created_at DESC");
    $stmt->execute([$direction]);
    $personnel = $stmt->fetchAll();
    
    jsonResponse(['items' => $personnel]);
}

function createPersonnel($db, $data) {
    $required = ['nom', 'prenom', 'email', 'poste', 'direction'];
    $errors = validateInput($data, $required);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    try {
        $stmt = $db->prepare("INSERT INTO personnel (nom, prenom, email, poste, telephone, date_embauche, direction, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            sanitizeInput($data['nom']),
            sanitizeInput($data['prenom']),
            sanitizeInput($data['email']),
            sanitizeInput($data['poste']),
            isset($data['telephone']) ? sanitizeInput($data['telephone']) : null,
            $data['dateEmbauche'],
            sanitizeInput($data['direction']),
            isset($data['createdBy']) ? sanitizeInput($data['createdBy']) : null
        ]);
        
        $personnelId = $db->lastInsertId();
        jsonResponse(['success' => true, 'id' => $personnelId, 'message' => 'Personnel ajouté']);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            jsonResponse(['error' => 'Cet email existe déjà'], 409);
        }
        throw $e;
    }
}

function updatePersonnel($db, $id, $data) {
    $stmt = $db->prepare("UPDATE personnel SET nom = ?, prenom = ?, email = ?, poste = ?, telephone = ? WHERE id = ?");
    $stmt->execute([
        sanitizeInput($data['nom']),
        sanitizeInput($data['prenom']),
        sanitizeInput($data['email']),
        sanitizeInput($data['poste']),
        isset($data['telephone']) ? sanitizeInput($data['telephone']) : null,
        $id
    ]);
    
    jsonResponse(['success' => true, 'message' => 'Personnel mis à jour']);
}

function deletePersonnel($db, $id) {
    $stmt = $db->prepare("DELETE FROM personnel WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['success' => true, 'message' => 'Personnel supprimé']);
}
?>

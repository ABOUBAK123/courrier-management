<?php
header('Content-Type: application/pdf');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Gérer les requêtes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    $url = $_GET['url'] ?? '';
    $username = $_GET['user'] ?? '';
    $password = $_GET['pass'] ?? '';
    
    if (empty($url)) {
        throw new Exception('URL manquante');
    }
    
    $decodedUrl = urldecode($url);
    $parsedUrl = parse_url($decodedUrl);
    
    if (!$parsedUrl) {
        throw new Exception('URL invalide');
    }
    
    $scheme = $parsedUrl['scheme'] ?? '';
    $host = $parsedUrl['host'] ?? '';
    $port = $parsedUrl['port'] ?? null;
    $path = $parsedUrl['path'] ?? '';
    
    switch ($scheme) {
        case 'ftp':
            $content = fetchFtpDocument($host, $port ?: 21, $path, $username, $password);
            break;
            
        case 'http':
        case 'https':
            $content = fetchHttpDocument($decodedUrl, $username, $password);
            break;
            
        default:
            throw new Exception('Protocole non supporté: ' . $scheme);
    }
    
    if ($content === false) {
        throw new Exception('Impossible de récupérer le document');
    }
    
    echo $content;
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

function fetchFtpDocument($host, $port, $path, $username, $password) {
    $ftpConnection = ftp_connect($host, $port);
    
    if (!$ftpConnection) {
        return false;
    }
    
    if (!ftp_login($ftpConnection, $username, $password)) {
        ftp_close($ftpConnection);
        return false;
    }
    
    ftp_pasv($ftpConnection, true);
    
    $tempFile = tempnam(sys_get_temp_dir(), 'ftp_doc');
    
    if (ftp_get($ftpConnection, $tempFile, $path, FTP_BINARY)) {
        $content = file_get_contents($tempFile);
        unlink($tempFile);
        ftp_close($ftpConnection);
        return $content;
    }
    
    unlink($tempFile);
    ftp_close($ftpConnection);
    return false;
}

function fetchHttpDocument($url, $username = '', $password = '') {
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 30,
            'header' => [
                'User-Agent: Mozilla/5.0 (compatible; DocumentProxy/1.0)',
                'Accept: application/pdf,*/*'
            ]
        ]
    ]);
    
    if (!empty($username) && !empty($password)) {
        $auth = base64_encode($username . ':' . $password);
        $context['http']['header'][] = 'Authorization: Basic ' . $auth;
    }
    
    return file_get_contents($url, false, $context);
}
?>
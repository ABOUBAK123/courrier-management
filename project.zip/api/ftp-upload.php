<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    // Vérifier si un fichier a été uploadé
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Aucun fichier reçu ou erreur upload');
    }

    // Récupérer les paramètres
    $fileName = $_POST['fileName'] ?? $_FILES['file']['name'];
    $ftpConfigJson = $_POST['ftpConfig'] ?? '';
    
    if (!$ftpConfigJson) {
        throw new Exception('Configuration FTP manquante');
    }

    $ftpConfig = json_decode($ftpConfigJson, true);
    if (!$ftpConfig) {
        throw new Exception('Configuration FTP invalide');
    }

    // Paramètres FTP
    $host = $ftpConfig['server'] ?? '';
    $port = isset($ftpConfig['port']) ? (int)$ftpConfig['port'] : 21;
    $username = $ftpConfig['username'] ?? '';
    $password = $ftpConfig['password'] ?? '';
    $directory = $ftpConfig['directory'] ?? '/';

    if (!$host || !$username) {
        throw new Exception('Paramètres FTP incomplets');
    }

    // Connexion FTP
    $connection = ftp_connect($host, $port, 30);
    if (!$connection) {
        throw new Exception("Impossible de se connecter à $host:$port");
    }

    $login = ftp_login($connection, $username, $password);
    if (!$login) {
        ftp_close($connection);
        throw new Exception("Échec authentification FTP");
    }

    // Mode passif pour éviter les problèmes de firewall
    ftp_pasv($connection, true);

    // Changer de répertoire si spécifié
    if ($directory !== '/') {
        if (!ftp_chdir($connection, $directory)) {
            ftp_close($connection);
            throw new Exception("Impossible d'accéder au répertoire: $directory");
        }
    }

    // Upload du fichier
    $tempFile = $_FILES['file']['tmp_name'];
    $remotePath = $fileName;

    $upload = ftp_put($connection, $remotePath, $tempFile, FTP_BINARY);
    
    if (!$upload) {
        ftp_close($connection);
        throw new Exception("Échec de l'upload FTP");
    }

    // Vérifier que le fichier a été uploadé
    $fileSize = ftp_size($connection, $remotePath);
    ftp_close($connection);

    if ($fileSize === -1) {
        throw new Exception("Fichier uploadé mais non trouvé sur le serveur");
    }

    // Construire le chemin complet
    $fullPath = rtrim($directory, '/') . '/' . $fileName;

    echo json_encode([
        'success' => true,
        'message' => 'Upload réussi',
        'fileName' => $fileName,
        'ftpPath' => $fullPath,
        'size' => $fileSize,
        'uploadDate' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
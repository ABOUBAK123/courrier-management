<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Test simple pour vérifier que PHP fonctionne
echo json_encode([
    'success' => true,
    'message' => 'PHP fonctionne correctement',
    'php_version' => PHP_VERSION,
    'ftp_extension' => extension_loaded('ftp'),
    'timestamp' => date('Y-m-d H:i:s')
]);
?>
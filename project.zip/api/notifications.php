<?php
require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['user_email'])) {
                getNotifications($db, $_GET['user_email']);
            } else {
                jsonResponse(['error' => 'Email utilisateur requis'], 400);
            }
            break;
            
        case 'POST':
            createNotification($db, $input);
            break;
            
        case 'PUT':
            if (isset($_GET['id'])) {
                markAsRead($db, $_GET['id']);
            } else {
                jsonResponse(['error' => 'ID requis'], 400);
            }
            break;
            
        default:
            jsonResponse(['error' => 'Méthode non autorisée'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function getNotifications($db, $userEmail) {
    $stmt = $db->prepare("SELECT * FROM notifications WHERE user_email = ? ORDER BY created_at DESC LIMIT 20");
    $stmt->execute([$userEmail]);
    $notifications = $stmt->fetchAll();
    
    // Convertir is_read en boolean
    foreach ($notifications as &$notif) {
        $notif['read'] = (bool)$notif['is_read'];
        $notif['createdAt'] = $notif['created_at'];
    }
    
    jsonResponse(['items' => $notifications]);
}

function createNotification($db, $data) {
    $required = ['user_email', 'message'];
    $errors = validateInput($data, $required);
    if (!empty($errors)) {
        jsonResponse(['error' => implode(', ', $errors)], 400);
    }

    $stmt = $db->prepare("INSERT INTO notifications (user_email, message, type) VALUES (?, ?, ?)");
    $stmt->execute([
        sanitizeInput($data['user_email']),
        sanitizeInput($data['message']),
        isset($data['type']) ? sanitizeInput($data['type']) : 'general'
    ]);
    
    jsonResponse(['success' => true, 'message' => 'Notification créée']);
}

function markAsRead($db, $id) {
    $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['success' => true, 'message' => 'Notification marquée comme lue']);
}
?>

<?php
// Test PHP configuration
header('Content-Type: text/html; charset=utf-8');
echo "<!DOCTYPE html>";
echo "<html><head><title>PHP Info</title></head><body>";
echo "<h1>PHP is working!</h1>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Server: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
echo "<h2>PHP Configuration</h2>";
phpinfo();
echo "</body></html>";
?>
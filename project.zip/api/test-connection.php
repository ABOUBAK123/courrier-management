<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config/database.php';

try {
    $pdo = getDBConnection();
    echo json_encode([
        'success' => true,
        'message' => 'Connexion à la base de données réussie',
        'database' => DB_NAME,
        'host' => DB_HOST
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/database.php';

$action = $_GET['action'] ?? ($_POST['action'] ?? null);

if (!$action) {
    echo json_encode(['success' => false, 'error' => 'Action non spécifiée']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    switch ($action) {
        case 'create':
            $input = json_decode(file_get_contents('php://input'), true);
            $objectType = $input['objectType'] ?? null;
            $objectData = $input['objectData'] ?? null;
            
            if (!$objectType || !$objectData) {
                throw new Exception('Type ou données manquants');
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO objects (object_type, object_data, created_at, updated_at)
                VALUES (:type, :data, NOW(), NOW())
            ");
            
            $stmt->execute([
                'type' => $objectType,
                'data' => json_encode($objectData)
            ]);
            
            $objectId = $pdo->lastInsertId();
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'objectId' => (string)$objectId,
                    'objectType' => $objectType,
                    'objectData' => $objectData,
                    'createdAt' => date('c'),
                    'updatedAt' => date('c')
                ]
            ]);
            break;
            
        case 'update':
            $input = json_decode(file_get_contents('php://input'), true);
            $objectType = $input['objectType'] ?? null;
            $objectId = $input['objectId'] ?? null;
            $objectData = $input['objectData'] ?? null;
            
            if (!$objectType || !$objectId || !$objectData) {
                throw new Exception('Paramètres manquants');
            }
            
            $stmt = $pdo->prepare("
                UPDATE objects 
                SET object_data = :data, updated_at = NOW()
                WHERE id = :id AND object_type = :type
            ");
            
            $stmt->execute([
                'id' => $objectId,
                'type' => $objectType,
                'data' => json_encode($objectData)
            ]);
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'objectId' => $objectId,
                    'objectType' => $objectType,
                    'objectData' => $objectData,
                    'updatedAt' => date('c')
                ]
            ]);
            break;
            
        case 'get':
            $objectType = $_GET['objectType'] ?? null;
            $objectId = $_GET['objectId'] ?? null;
            
            if (!$objectType || !$objectId) {
                throw new Exception('Paramètres manquants');
            }
            
            $stmt = $pdo->prepare("
                SELECT * FROM objects 
                WHERE id = :id AND object_type = :type
            ");
            
            $stmt->execute([
                'id' => $objectId,
                'type' => $objectType
            ]);
            
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$row) {
                throw new Exception('Objet non trouvé');
            }
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'objectId' => (string)$row['id'],
                    'objectType' => $row['object_type'],
                    'objectData' => json_decode($row['object_data'], true),
                    'createdAt' => $row['created_at'],
                    'updatedAt' => $row['updated_at']
                ]
            ]);
            break;
            
        case 'list':
            $objectType = $_GET['objectType'] ?? null;
            $limit = (int)($_GET['limit'] ?? 100);
            $descent = filter_var($_GET['descent'] ?? 'true', FILTER_VALIDATE_BOOLEAN);
            
            if (!$objectType) {
                throw new Exception('Type d\'objet manquant');
            }
            
            $order = $descent ? 'DESC' : 'ASC';
            
            $stmt = $pdo->prepare("
                SELECT * FROM objects 
                WHERE object_type = :type 
                ORDER BY id $order 
                LIMIT :limit
            ");
            
            $stmt->bindValue('type', $objectType);
            $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            $items = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $items[] = [
                    'objectId' => (string)$row['id'],
                    'objectType' => $row['object_type'],
                    'objectData' => json_decode($row['object_data'], true),
                    'createdAt' => $row['created_at'],
                    'updatedAt' => $row['updated_at']
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $items,
                'nextPageToken' => null
            ]);
            break;
            
        case 'delete':
            $input = json_decode(file_get_contents('php://input'), true);
            $objectType = $input['objectType'] ?? null;
            $objectId = $input['objectId'] ?? null;
            
            if (!$objectType || !$objectId) {
                throw new Exception('Paramètres manquants');
            }
            
            $stmt = $pdo->prepare("
                DELETE FROM objects 
                WHERE id = :id AND object_type = :type
            ");
            
            $stmt->execute([
                'id' => $objectId,
                'type' => $objectType
            ]);
            
            echo json_encode(['success' => true]);
            break;
            
        default:
            throw new Exception('Action non reconnue');
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Données JSON invalides');
    }

    $host = $input['server'] ?? $input['host'] ?? '';
    $port = isset($input['port']) ? (int)$input['port'] : 21;
    $username = $input['username'] ?? '';
    $password = $input['password'] ?? '';
    $directory = $input['directory'] ?? '/';

    if (!$host || !$username) {
        throw new Exception('Paramètres manquants');
    }

    // Test de connexion FTP
    $connection = ftp_connect($host, $port, 10);
    
    if (!$connection) {
        throw new Exception("Impossible de se connecter à $host:$port");
    }

    $login = ftp_login($connection, $username, $password);
    
    if (!$login) {
        ftp_close($connection);
        throw new Exception("Échec authentification");
    }

    // Test du répertoire
    if ($directory !== '/') {
        $currentDir = ftp_pwd($connection);
        if (!ftp_chdir($connection, $directory)) {
            ftp_close($connection);
            throw new Exception("Répertoire inaccessible: $directory");
        }
        ftp_chdir($connection, $currentDir);
    }

    ftp_close($connection);

    echo json_encode([
        'success' => true,
        'message' => 'Connexion FTP réussie',
        'details' => [
            'server' => $host,
            'port' => $port,
            'directory' => $directory
        ]
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
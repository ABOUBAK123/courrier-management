# Guide de Déploiement - Système de Gestion du Courrier
## Serveur Ubuntu 22.04 + Webmin + Apache + MariaDB

### Prérequis
- Serveur Ubuntu 22.04 LTS
- Accès root ou sudo
- Connexion Internet stable
- Nom de domaine (optionnel)

## 1. Mise à jour du système

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install curl wget unzip software-properties-common -y
```

## 2. Installation d'Apache

```bash
# Installation d'Apache
sudo apt install apache2 -y

# Démarrage et activation d'Apache
sudo systemctl start apache2
sudo systemctl enable apache2

# Vérification du statut
sudo systemctl status apache2

# Configuration du firewall
sudo ufw allow 'Apache Full'
sudo ufw allow OpenSSH
sudo ufw enable
```

## 3. Installation de PHP

```bash
# Installation de PHP et modules nécessaires
sudo apt install php libapache2-mod-php php-mysql php-curl php-gd php-mbstring php-xml php-zip php-json -y

# Redémarrage d'Apache
sudo systemctl restart apache2

# Vérification de PHP
php -v
```

## 4. Installation de MariaDB

```bash
# Installation de MariaDB
sudo apt install mariadb-server mariadb-client -y

# Démarrage et activation de MariaDB
sudo systemctl start mariadb
sudo systemctl enable mariadb

# Sécurisation de MariaDB
sudo mysql_secure_installation
```

**Configuration de sécurité MariaDB :**
- Mot de passe root : OUI (choisir un mot de passe fort)
- Supprimer utilisateurs anonymes : OUI
- Interdire connexion root distante : OUI
- Supprimer base de test : OUI
- Recharger privilèges : OUI

## 5. Installation de Webmin

```bash
# Ajout du dépôt Webmin
curl -o setup-repos.sh https://raw.githubusercontent.com/webmin/webmin/master/setup-repos.sh
sudo sh setup-repos.sh

# Installation de Webmin
sudo apt install webmin -y

# Démarrage de Webmin
sudo systemctl start webmin
sudo systemctl enable webmin

# Autoriser le port Webmin dans le firewall
sudo ufw allow 10000
```

**Accès Webmin :** https://votre-ip:10000

## 6. Configuration de la base de données

```bash
# Connexion à MariaDB
sudo mysql -u root -p

# Création de la base de données et utilisateur
CREATE DATABASE mail_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'mail_user'@'localhost' IDENTIFIED BY 'VotreMotDePasseSecurise';
GRANT ALL PRIVILEGES ON mail_management.* TO 'mail_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 7. Préparation du répertoire web

```bash
# Création du répertoire de l'application
sudo mkdir -p /var/www/mail-system
sudo chown -R www-data:www-data /var/www/mail-system
sudo chmod -R 755 /var/www/mail-system

# Création du répertoire uploads
sudo mkdir -p /var/www/mail-system/uploads
sudo chmod -R 777 /var/www/mail-system/uploads
```

## 8. Configuration Apache Virtual Host

```bash
# Création du fichier de configuration
sudo nano /etc/apache2/sites-available/mail-system.conf
```

**Contenu du fichier mail-system.conf :**
```apache
<VirtualHost *:80>
    ServerAdmin admin@votre-domaine.com
    ServerName votre-domaine.com
    ServerAlias www.votre-domaine.com
    DocumentRoot /var/www/mail-system
    
    <Directory /var/www/mail-system>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/mail-system_error.log
    CustomLog ${APACHE_LOG_DIR}/mail-system_access.log combined
</VirtualHost>
```

```bash
# Activation du site et des modules nécessaires
sudo a2ensite mail-system.conf
sudo a2enmod rewrite
sudo a2dissite 000-default.conf
sudo systemctl restart apache2
```

## 9. Déploiement de l'application

### 9.1 Téléchargement des fichiers
```bash
# Aller dans le répertoire web
cd /var/www/mail-system

# Télécharger votre application (exemple avec git ou upload direct)
# Option 1: Avec git (si votre code est sur GitHub)
# sudo git clone https://github.com/votre-repo/mail-system.git .

# Option 2: Upload manuel via SCP/SFTP
# Uploadez tous vos fichiers dans /var/www/mail-system/
```

### 9.2 Configuration des permissions
```bash
sudo chown -R www-data:www-data /var/www/mail-system
sudo chmod -R 755 /var/www/mail-system
sudo chmod -R 777 /var/www/mail-system/uploads
```

## 10. Configuration de la base de données

### 10.1 Import du schéma de base
```bash
# Si vous avez un fichier SQL d'export
mysql -u mail_user -p mail_management < /var/www/mail-system/database/mail_management.sql
```

### 10.2 Configuration de connexion
**Créer le fichier :** `/var/www/mail-system/config/database.php`
```php
<?php
$host = 'localhost';
$dbname = 'mail_management';
$username = 'mail_user';
$password = 'VotreMotDePasseSecurise';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
?>
```

## 11. Configuration SSL (Optionnel mais recommandé)

```bash
# Installation de Certbot
sudo apt install snapd -y
sudo snap install core; sudo snap refresh core
sudo snap install --classic certbot

# Création du lien symbolique
sudo ln -s /snap/bin/certbot /usr/bin/certbot

# Obtention du certificat SSL
sudo certbot --apache -d votre-domaine.com -d www.votre-domaine.com

# Renouvellement automatique
sudo crontab -e
# Ajouter cette ligne :
# 0 12 * * * /usr/bin/certbot renew --quiet
```

## 12. Configuration de sécurité avancée

### 12.1 Configuration PHP
```bash
sudo nano /etc/php/8.1/apache2/php.ini
```

**Modifications recommandées :**
```ini
upload_max_filesize = 50M
post_max_size = 50M
max_execution_time = 300
memory_limit = 256M
display_errors = Off
log_errors = On
```

### 12.2 Sécurisation Apache
```bash
# Masquer la version d'Apache
sudo nano /etc/apache2/conf-enabled/security.conf
```

**Modifications :**
```apache
ServerTokens Prod
ServerSignature Off
```

### 12.3 Configuration .htaccess
**Créer :** `/var/www/mail-system/.htaccess`
```apache
# Sécurité générale
Options -Indexes
ServerSignature Off

# Protection des fichiers sensibles
<Files "*.sql">
    Deny from all
</Files>

<Files "*.log">
    Deny from all
</Files>

# Redirection HTTPS (si SSL configuré)
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

## 13. Sauvegarde automatique

### 13.1 Script de sauvegarde
**Créer :** `/home/backup-mail-system.sh`
```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/home/backups"
DB_NAME="mail_management"
DB_USER="mail_user"
DB_PASS="VotreMotDePasseSecurise"

# Création du répertoire de sauvegarde
mkdir -p $BACKUP_DIR

# Sauvegarde de la base de données
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/db_backup_$DATE.sql

# Sauvegarde des fichiers
tar -czf $BACKUP_DIR/files_backup_$DATE.tar.gz /var/www/mail-system

# Suppression des sauvegardes de plus de 7 jours
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
```

```bash
# Rendre le script exécutable
chmod +x /home/backup-mail-system.sh

# Programmer la sauvegarde quotidienne
sudo crontab -e
# Ajouter : 0 2 * * * /home/backup-mail-system.sh
```

## 14. Monitoring et logs

### 14.1 Surveillance des logs
```bash
# Logs Apache
sudo tail -f /var/log/apache2/mail-system_error.log
sudo tail -f /var/log/apache2/mail-system_access.log

# Logs MariaDB
sudo tail -f /var/log/mysql/error.log

# Logs système
sudo tail -f /var/log/syslog
```

### 14.2 Installation de monitoring (optionnel)
```bash
# Installation de htop pour monitoring système
sudo apt install htop -y

# Installation de monitoring MariaDB
sudo apt install mytop -y
```

## 15. Tests et vérifications

### 15.1 Test de l'application
1. Accédez à `http://votre-domaine.com` ou `http://votre-ip`
2. Vérifiez la page de connexion
3. Testez la connexion à la base de données
4. Vérifiez l'upload de fichiers

### 15.2 Vérifications de sécurité
```bash
# Test des permissions
ls -la /var/www/mail-system

# Test de la connexion base de données
mysql -u mail_user -p mail_management -e "SHOW TABLES;"

# Vérification des ports ouverts
sudo netstat -tulpn | grep LISTEN
```

## 16. Maintenance

### 16.1 Mises à jour régulières
```bash
# Script de mise à jour système
sudo apt update && sudo apt upgrade -y
sudo systemctl restart apache2
sudo systemctl restart mariadb
```

### 16.2 Nettoyage des logs
```bash
# Rotation des logs Apache
sudo logrotate /etc/logrotate.d/apache2

# Nettoyage manuel si nécessaire
sudo truncate -s 0 /var/log/apache2/*.log
```

## 17. Dépannage courant

### Problèmes fréquents :

**Apache ne démarre pas :**
```bash
sudo apache2ctl configtest
sudo systemctl status apache2
```

**Erreur de connexion base de données :**
```bash
sudo systemctl status mariadb
mysql -u mail_user -p
```

**Problèmes de permissions :**
```bash
sudo chown -R www-data:www-data /var/www/mail-system
sudo chmod -R 755 /var/www/mail-system
```

**Logs d'erreur :**
```bash
sudo tail -50 /var/log/apache2/mail-system_error.log
sudo tail -50 /var/log/mysql/error.log
```

## Support et contacts

- Documentation Webmin : https://webmin.com/docs/
- Documentation Apache : https://httpd.apache.org/docs/
- Documentation MariaDB : https://mariadb.org/documentation/

---

**Note importante :** Remplacez tous les exemples de mots de passe et noms de domaine par vos propres valeurs sécurisées avant le déploiement en production.
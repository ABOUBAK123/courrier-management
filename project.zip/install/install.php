<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation - Système de Gestion du Courrier</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .step { background: #f5f5f5; padding: 20px; margin: 20px 0; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        .btn { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1>Installation du Système de Gestion du Courrier</h1>
    
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $host = $_POST['host'] ?? 'localhost';
        $username = $_POST['username'] ?? 'root';
        $password = $_POST['password'] ?? '';
        $database = $_POST['database'] ?? 'mail_management';
        
        try {
            // Connexion à MySQL
            $pdo = new PDO("mysql:host=$host", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            echo '<div class="step success">✓ Connexion à MySQL réussie</div>';
            
            // Création de la base de données
            $pdo->exec("CREATE DATABASE IF NOT EXISTS $database CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE $database");
            
            echo '<div class="step success">✓ Base de données créée</div>';
            
            // Lecture et exécution du fichier SQL
            $sql = file_get_contents('../database/mail_management.sql');
            $statements = explode(';', $sql);
            
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if (!empty($statement)) {
                    $pdo->exec($statement);
                }
            }
            
            echo '<div class="step success">✓ Tables créées avec succès</div>';
            
            // Mise à jour du fichier de configuration
            $configContent = "<?php
class Database {
    private \$host = '$host';
    private \$db_name = '$database';
    private \$username = '$username';
    private \$password = '$password';
    private \$conn = null;

    public function getConnection() {
        try {
            \$this->conn = new PDO(
                \"mysql:host=\" . \$this->host . \";dbname=\" . \$this->db_name . \";charset=utf8mb4\",
                \$this->username,
                \$this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException \$e) {
            error_log(\"Erreur de connexion: \" . \$e->getMessage());
            throw new Exception(\"Erreur de connexion à la base de données\");
        }
        return \$this->conn;
    }

    public function closeConnection() {
        \$this->conn = null;
    }
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if (\$_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

function jsonResponse(\$data, \$status = 200) {
    http_response_code(\$status);
    echo json_encode(\$data, JSON_UNESCAPED_UNICODE);
    exit();
}

function validateInput(\$data, \$required_fields = []) {
    \$errors = [];
    foreach (\$required_fields as \$field) {
        if (!isset(\$data[\$field]) || empty(trim(\$data[\$field]))) {
            \$errors[] = \"Le champ '\$field' est requis\";
        }
    }
    return \$errors;
}

function sanitizeInput(\$data) {
    return htmlspecialchars(strip_tags(trim(\$data)));
}
?>";
            
            file_put_contents('../config/database.php', $configContent);
            
            echo '<div class="step success">✓ Configuration mise à jour</div>';
            echo '<div class="step success"><strong>Installation terminée avec succès!</strong><br>Vous pouvez maintenant utiliser l\'application.</div>';
            echo '<a href="../index.html" class="btn">Accéder à l\'application</a>';
            
        } catch (Exception $e) {
            echo '<div class="step error">Erreur: ' . $e->getMessage() . '</div>';
        }
    } else {
    ?>
    
    <form method="POST">
        <div class="step">
            <h3>Configuration de la base de données</h3>
            <p><label>Hôte: <input type="text" name="host" value="localhost" required></label></p>
            <p><label>Nom d'utilisateur: <input type="text" name="username" value="root" required></label></p>
            <p><label>Mot de passe: <input type="password" name="password"></label></p>
            <p><label>Nom de la base: <input type="text" name="database" value="mail_management" required></label></p>
        </div>
        
        <div class="step">
            <h3>Prérequis</h3>
            <ul>
                <li>WampServer installé et démarré</li>
                <li>PHP 7.4+ avec extension PDO</li>
                <li>MySQL 5.7+ ou MariaDB 10.2+</li>
            </ul>
        </div>
        
        <button type="submit" class="btn">Installer</button>
    </form>
    
    <?php } ?>
</body>
</html>

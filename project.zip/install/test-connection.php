<?php
// Script de test de connexion à la base de données

header('Content-Type: application/json');

try {
    // Paramètres de connexion par défaut
    $host = $_GET['host'] ?? 'localhost';
    $username = $_GET['username'] ?? 'root';
    $password = $_GET['password'] ?? '';
    $database = $_GET['database'] ?? 'mail_management';
    
    // Test de connexion MySQL
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $response = [
        'success' => true,
        'message' => 'Connexion MySQL réussie',
        'mysql_version' => $pdo->query('SELECT VERSION()')->fetchColumn(),
        'databases' => []
    ];
    
    // Lister les bases de données disponibles
    $stmt = $pdo->query('SHOW DATABASES');
    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        $response['databases'][] = $row[0];
    }
    
    // Tester la connexion à la base spécifique si elle existe
    if (in_array($database, $response['databases'])) {
        $pdo->exec("USE $database");
        $response['database_exists'] = true;
        $response['tables'] = [];
        
        // Lister les tables
        $stmt = $pdo->query('SHOW TABLES');
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $response['tables'][] = $row[0];
        }
    } else {
        $response['database_exists'] = false;
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'code' => $e->getCode()
    ], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ], JSON_PRETTY_PRINT);
}
?>

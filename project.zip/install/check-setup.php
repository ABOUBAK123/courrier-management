<?php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Vérification Installation</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        h2 { margin-top: 30px; }
    </style>
</head>
<body>
    <h1>Vérification de l'Installation</h1>
    
    <h2>1. Configuration PHP</h2>
    <?php
    echo "<p>Version PHP: " . phpversion() . "</p>";
    
    $required_extensions = ['pdo', 'pdo_mysql', 'json', 'mbstring'];
    foreach ($required_extensions as $ext) {
        if (extension_loaded($ext)) {
            echo "<p class='success'>✓ Extension $ext: installée</p>";
        } else {
            echo "<p class='error'>✗ Extension $ext: manquante</p>";
        }
    }
    ?>
    
    <h2>2. Connexion Base de Données</h2>
    <?php
    try {
        require_once '../config/database.php';
        $pdo = getDBConnection();
        echo "<p class='success'>✓ Connexion réussie à la base de données</p>";
        echo "<p>Base de données: " . DB_NAME . "</p>";
        echo "<p>Hôte: " . DB_HOST . "</p>";
        
        // Vérifier la table objects
        $stmt = $pdo->query("SHOW TABLES LIKE 'objects'");
        if ($stmt->rowCount() > 0) {
            echo "<p class='success'>✓ Table 'objects' existe</p>";
        } else {
            echo "<p class='error'>✗ Table 'objects' n'existe pas</p>";
            echo "<p class='warning'>Exécutez: mysql -u root -p " . DB_NAME . " < database/objects_table.sql</p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='error'>✗ Erreur: " . $e->getMessage() . "</p>";
    }
    ?>
    
    <h2>3. Permissions Fichiers</h2>
    <?php
    $paths_to_check = [
        '../api' => 'Dossier API',
        '../config' => 'Dossier Config',
        '../api/objects.php' => 'Fichier objects.php'
    ];
    
    foreach ($paths_to_check as $path => $desc) {
        if (file_exists($path)) {
            $perms = substr(sprintf('%o', fileperms($path)), -4);
            echo "<p class='success'>✓ $desc: existe (permissions: $perms)</p>";
        } else {
            echo "<p class='error'>✗ $desc: n'existe pas</p>";
        }
    }
    ?>
    
    <h2>4. Test API</h2>
    <p>Testez l'API en accédant à: <a href="../api/test-connection.php" target="_blank">test-connection.php</a></p>
    
    <h2>5. Accès Application</h2>
    <p>Accédez à l'application: <a href="../index.html">index.html</a></p>
</body>
</html>
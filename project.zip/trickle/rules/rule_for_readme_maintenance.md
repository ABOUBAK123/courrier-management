# Règle de Maintenance du README

## Quand le projet est mis à jour

- **Vérifier systématiquement** si le README.md dans `trickle/notes` doit être mis à jour
- Mettre à jour les sections suivantes selon les changements :
  - Architecture (si nouvelles technologies ajoutées)
  - Fonctionnalités (si nouvelles features implémentées)
  - Structure du projet (si organisation modifiée)
  - Instructions d'installation (si dépendances changées)
  - Prochaines étapes (selon l'avancement)

## Règles de contenu

- Garder le README concis et à jour
- Inclure uniquement les informations essentielles
- Marquer les fonctionnalités avec ✅ (terminé) ou ❌ (non implémenté)
- Documenter les changements majeurs d'architecture
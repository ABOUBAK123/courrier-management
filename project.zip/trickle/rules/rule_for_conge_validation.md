# Règle de Validation des Demandes de Congé

## Quand un agent fait une demande de congé

- **Étape 1** : La demande ne doit être visible QUE dans le profil de son supérieur hiérarchique DIRECT
- Aucun autre utilisateur ne doit voir cette demande à cette étape
- La validation doit se faire exclusivement dans l'onglet "Congés à valider" du supérieur

## Après validation du supérieur hiérarchique

- **Étape 2** : Si approuvée, la demande devient visible dans le profil DRH pour validation finale
- Le DRH peut approuver ou refuser la demande
- Seul le DRH voit les demandes à cette étape

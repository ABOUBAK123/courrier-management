# Système de Gestion Administrative - Migration React + Vite

## Vue d'ensemble

Application moderne de gestion administrative migrée de Babel Standalone vers React 18 + Vite + TailwindCSS.

## Architecture

- **Frontend**: React 18 avec Vite
- **Styling**: TailwindCSS (sans CDN)
- **Routing**: React Router DOM
- **Charts**: Chart.js + react-chartjs-2
- **Icons**: Lucide React

## Structure du projet

```
src/
├── components/     # Composants réutilisables
├── pages/          # Pages principales
├── context/        # Contextes React
├── main.jsx        # Point d'entrée
└── index.css       # Styles Tailwind
```

## Fonctionnalités

### Module Courrier (Terminé)
- ✅ Dashboard principal avec statistiques
- ✅ Création de courriers arrivés/départs avec numérotation automatique
- ✅ Liste des courriers avec filtres et recherche
- ✅ Système d'imputation hiérarchique
- ✅ Gestion des courriers en traitement
- ✅ Suivi et rapports statistiques
- ✅ Archives des courriers traités

### Autres modules
- ✅ Gestion du personnel
- ✅ E-parapheur
- ✅ Archives
- ✅ Administration
- ✅ Espace agent
- ✅ Système d'authentification
- ✅ Notifications toast

## Installation et démarrage

```bash
npm install
npm run dev
```

## Migration effectuée

- ✅ Conversion Babel Standalone → Vite
- ✅ Suppression des CDN
- ✅ Structure modulaire ES6
- ✅ Configuration Tailwind moderne
- ✅ Système de routing
- ✅ Composants optimisés

## Structure Module Courrier

### Pages
- `courrier.html` - Page principale du module
- `courrier-app.js` - Application React avec gestion d'état

### Composants principaux
- `CourrierHeader.js` - En-tête avec navigation
- `CourrierSidebar.js` - Menu latéral avec compteurs
- `CourrierDashboard.js` - Tableau de bord statistiques
- `NewMailForm.js` - Formulaire création courrier
- `MailListTable.js` - Liste avec filtres
- `ImputationPanel.js` - Imputation aux directions
- `TraitementPanel.js` - Validation/rejet
- `SuiviPanel.js` - Suivi et rapports
- `ArchivePanel.js` - Archives

### Services
- `mailService.js` - API courriers et workflow
- `numberGenerator.js` - Numérotation automatique

## Prochaines étapes

- [ ] Migration du module Personnel
- [ ] Migration du module E-parapheur
- [ ] Intégration base de données Trickle
- [ ] Tests et optimisations

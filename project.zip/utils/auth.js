const AuthContext = React.createContext();

function useAuth() {
    const context = React.useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within AuthProvider');
    }
    return context;
}

function AuthProvider({ children }) {
    try {
        const [user, setUser] = React.useState(null);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            const initializeAuth = async () => {
                try {
                    // Check for saved user first (offline capability)
                    const savedUser = localStorage.getItem('currentUser');
                    if (savedUser) {
                        try {
                            setUser(JSON.parse(savedUser));
                        } catch (parseError) {
                            console.error('Erreur de parsing utilisateur sauvegardé:', parseError);
                            localStorage.removeItem('currentUser');
                        }
                    }

                    // Try to initialize database with graceful error handling
                    try {
                        // Check if database functions are available
                        if (typeof trickleListObjects !== 'function') {
                            console.warn('Fonctions de base de données non disponibles, mode hors ligne activé');
                            return;
                        }

                        // Try to access database with timeout
                        const timeoutPromise = new Promise((_, reject) => 
                            setTimeout(() => reject(new Error('Timeout')), 3000)
                        );

                        const initPromise = (async () => {
                            const users = await trickleListObjects('user', 10, true);
                            if (users.items.length === 0) {
                                await trickleCreateObject('user', {
                                    name: 'Administrateur',
                                    email: 'admin@gov.com',
                                    password: 'admin123',
                                    role: 'ADMIN',
                                    direction: 'DIR001'
                                });
                            }
                        })();

                        await Promise.race([initPromise, timeoutPromise]);
                        console.log('Base de données initialisée avec succès');
                    } catch (dbError) {
                        console.warn('Initialisation base de données échouée:', dbError.message);
                        // Continue in offline mode
                    }
                } catch (error) {
                    console.error('Erreur d\'initialisation:', error);
                    // Don't block the app, continue with offline mode
                } finally {
                    setLoading(false);
                }
            };

            initializeAuth();
        }, []);

        const login = async (email, password) => {
            // Always allow default admin access in offline mode
            if (email === 'admin@gov.com' && password === 'admin123') {
                const defaultUser = {
                    name: 'Administrateur',
                    email: 'admin@gov.com',
                    role: 'ADMIN',
                    direction: 'DIR001',
                    isOfflineMode: true
                };
                setUser(defaultUser);
                localStorage.setItem('currentUser', JSON.stringify(defaultUser));
                return { success: true, user: defaultUser };
            }

            // Check if database functions are available
            if (typeof trickleListObjects !== 'function') {
                return { 
                    success: false, 
                    error: 'Base de données non disponible. Utilisez admin@gov.com / admin123 pour le mode hors ligne.' 
                };
            }

            try {
                // Try database authentication with shorter timeout
                const timeoutPromise = new Promise((_, reject) => 
                    setTimeout(() => reject(new Error('Timeout')), 5000)
                );

                const loginPromise = (async () => {
                    const users = await trickleListObjects('user', 100, true);
                    const foundUser = users.items.find(u => 
                        u.objectData.email === email && u.objectData.password === password
                    );
                    
                    if (foundUser) {
                        const userData = foundUser.objectData;
                        userData.isOfflineMode = false;
                        
                        // Try to get role URL but don't fail if it doesn't work
                        try {
                            const roles = await trickleListObjects('roles', 100, true);
                            const userRole = roles.items.find(r => r.objectData.nom === userData.role);
                            
                            if (userRole && userRole.objectData.urlConnexion) {
                                userData.urlConnexion = userRole.objectData.urlConnexion;
                            }
                        } catch (roleError) {
                            console.warn('Rôles non disponibles:', roleError.message);
                        }
                        
                        setUser(userData);
                        localStorage.setItem('currentUser', JSON.stringify(userData));
                        
                        // Démarrer surveillance email pour les managers
                        if ((userData.role === 'manager' || userData.role === 'chef_service' || userData.role === 'directeur') && window.EmailAlerts) {
                            setTimeout(() => {
                                window.EmailAlerts.startMonitoring();
                            }, 2000);
                        }
                        
                        return { success: true, user: userData };
                    }
                    return { success: false, error: 'Email ou mot de passe incorrect' };
                })();

                return await Promise.race([loginPromise, timeoutPromise]);
            } catch (error) {
                console.error('Erreur de connexion:', error);
                
                // Handle specific error types
                if (error.message.includes('NoPermission')) {
                    return { 
                        success: false, 
                        error: 'Permissions insuffisantes. Utilisez admin@gov.com / admin123 pour le mode hors ligne.' 
                    };
                }
                
                if (error.message === 'Timeout' || error.message.includes('fetch')) {
                    return { 
                        success: false, 
                        error: 'Connexion impossible. Utilisez admin@gov.com / admin123 pour le mode hors ligne.' 
                    };
                }
                
                return { 
                    success: false, 
                    error: 'Erreur de connexion. Utilisez admin@gov.com / admin123 pour le mode hors ligne.' 
                };
            }
        };

        const logout = () => {
            setUser(null);
            localStorage.removeItem('currentUser');
        };

        const value = { user, login, logout, loading };

        return React.createElement(AuthContext.Provider, { value }, children);
    } catch (error) {
        console.error('AuthProvider error:', error);
        reportError(error);
    }
}

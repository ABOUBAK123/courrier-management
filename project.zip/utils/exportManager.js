window.exportManager = {
    async exporterConges(format) {
        try {
            const response = await trickleListObjects('demande_conge', 500, true);
            const demandes = response.items;

            if (format === 'csv') {
                this.exporterCSV(demandes);
            } else if (format === 'pdf') {
                this.exporterPDF(demandes);
            }
        } catch (error) {
            console.error('Erreur export:', error);
        }
    },

    exporterCSV(demandes) {
        const headers = [
            'Agent',
            'Direction',
            'Type de congé',
            'Date début',
            'Date fin',
            'Durée (jours)',
            'Statut',
            'Date demande',
            'Validateur',
            'Commentaire'
        ];

        const rows = demandes.map(demande => [
            demande.objectData.agent_nom || '',
            demande.objectData.agent_direction || '',
            demande.objectData.type_conge || '',
            new Date(demande.objectData.date_debut).toLocaleDateString(),
            new Date(demande.objectData.date_fin).toLocaleDateString(),
            demande.objectData.duree_jours || '',
            demande.objectData.statut || '',
            new Date(demande.createdAt).toLocaleDateString(),
            demande.objectData.validateur_nom || '',
            demande.objectData.commentaire_validation || ''
        ]);

        const csvContent = [headers, ...rows]
            .map(row => row.map(field => `"${field}"`).join(','))
            .join('\n');

        this.telechargerFichier(csvContent, 'conges_export.csv', 'text/csv');
    },

    exporterPDF(demandes) {
        // Simulation d'export PDF
        const htmlContent = this.genererHTMLRapport(demandes);
        this.telechargerFichier(htmlContent, 'rapport_conges.html', 'text/html');
    },

    genererHTMLRapport(demandes) {
        const maintenant = new Date().toLocaleDateString();
        const stats = this.calculerStatsRapport(demandes);

        return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Rapport des Congés</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .stats { display: flex; justify-content: space-around; margin-bottom: 30px; }
        .stat-box { text-align: center; padding: 15px; background: #f5f5f5; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Rapport des Congés</h1>
        <p>Généré le ${maintenant}</p>
    </div>
    
    <div class="stats">
        <div class="stat-box">
            <h3>${stats.total}</h3>
            <p>Total demandes</p>
        </div>
        <div class="stat-box">
            <h3>${stats.approuvees}</h3>
            <p>Approuvées</p>
        </div>
        <div class="stat-box">
            <h3>${stats.refusees}</h3>
            <p>Refusées</p>
        </div>
        <div class="stat-box">
            <h3>${stats.enAttente}</h3>
            <p>En attente</p>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>Agent</th>
                <th>Type</th>
                <th>Période</th>
                <th>Durée</th>
                <th>Statut</th>
                <th>Date demande</th>
            </tr>
        </thead>
        <tbody>
            ${demandes.map(demande => `
                <tr>
                    <td>${demande.objectData.agent_nom || ''}</td>
                    <td>${demande.objectData.type_conge || ''}</td>
                    <td>${new Date(demande.objectData.date_debut).toLocaleDateString()} - ${new Date(demande.objectData.date_fin).toLocaleDateString()}</td>
                    <td>${demande.objectData.duree_jours || ''} jour(s)</td>
                    <td>${demande.objectData.statut || ''}</td>
                    <td>${new Date(demande.createdAt).toLocaleDateString()}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>
</body>
</html>`;
    },

    calculerStatsRapport(demandes) {
        return {
            total: demandes.length,
            approuvees: demandes.filter(d => d.objectData.statut === 'approuvee').length,
            refusees: demandes.filter(d => d.objectData.statut === 'refusee').length,
            enAttente: demandes.filter(d => d.objectData.statut === 'en_attente').length
        };
    },

    telechargerFichier(contenu, nomFichier, type) {
        const blob = new Blob([contenu], { type });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = nomFichier;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }
};

window.workflowCongesHierarchique = {
    
    async traiterDemandeConge(demandeData) {
        try {
            console.log('🔄 Traitement demande congé:', demandeData);
            
            const agentId = demandeData.agent_id;
            
            if (!agentId) {
                throw new Error('ID agent manquant dans les données de la demande');
            }
            
            // 1. Créer le workflow de validation hiérarchique séquentiel
            const workflow = await this.creerWorkflowSequentiel(agentId, demandeData);
            console.log('Workflow créé:', workflow);
            
            // 2. Créer la demande dans la base avec le workflow
            const nouvelleDemande = await trickleCreateObject('demande_conge', {
                ...demandeData,
                workflow: workflow,
                statut: 'en_cours',
                date_creation: new Date().toISOString(),
                etape_actuelle: 1
            });
            
            console.log('✅ Demande créée:', nouvelleDemande.objectId);
            
            // 3. Notifier le premier validateur
            if (workflow.length > 0) {
                await this.notifierNouvelledemande(
                    nouvelleDemande.objectId,
                    demandeData.agent_nom,
                    demandeData.type_conge,
                    workflow[0].validateur_id
                );
            }
            
            return { success: true, demandeId: nouvelleDemande.objectId, workflow };
            
        } catch (error) {
            console.error('❌ Erreur traitement demande:', error);
            throw new Error(`Erreur lors de la création de la demande: ${error.message}`);
        }
    },

    async creerWorkflowSequentiel(agentId, demandeData) {
        try {
            console.log('🔄 Création workflow pour agent ID:', agentId);
            
            const personnelResponse = await trickleListObjects('personnel', 200, true);
            console.log('📋 Personnel trouvé:', personnelResponse.items.length, 'agents');
            
            const agent = personnelResponse.items.find(p => 
                p.objectId === agentId || 
                p.objectData.matricule === agentId ||
                p.objectData.id === agentId
            );
            
            console.log('👤 Agent trouvé:', agent ? 'Oui' : 'Non');
            
            if (!agent) {
                throw new Error(`Agent non trouvé avec ID: ${agentId}`);
            }

            if (!agent.objectData.superieur_id) {
                // Créer un workflow minimal sans supérieur - directement vers DRH
                console.log('⚠️ Pas de supérieur défini, workflow direct vers DRH');
                return [
                    {
                        etape: 1,
                        type: 'validation_drh',
                        validateur_id: 'DRH',
                        validateur_nom: 'Direction des Ressources Humaines',
                        niveau_hierarchique: 1,
                        statut: 'en_attente',
                        decision: null,
                        commentaire: null,
                        date_decision: null
                    }
                ];
            }

            const superieur = personnelResponse.items.find(p => 
                p.objectId === agent.objectData.superieur_id
            );

            if (!superieur) {
                console.log('⚠️ Supérieur non trouvé, workflow direct vers DRH');
                return [
                    {
                        etape: 1,
                        type: 'validation_drh',
                        validateur_id: 'DRH',
                        validateur_nom: 'Direction des Ressources Humaines',
                        niveau_hierarchique: 1,
                        statut: 'en_attente',
                        decision: null,
                        commentaire: null,
                        date_decision: null
                    }
                ];
            }

            // Workflow en 2 étapes : 1) Supérieur direct, 2) DRH
            const workflow = [
                {
                    etape: 1,
                    type: 'validation_hierarchique',
                    validateur_id: superieur.objectId,
                    validateur_nom: `${superieur.objectData.prenom || ''} ${superieur.objectData.nom || ''}`.trim(),
                    niveau_hierarchique: 1,
                    statut: 'en_attente',
                    decision: null,
                    commentaire: null,
                    date_decision: null
                },
                {
                    etape: 2,
                    type: 'validation_drh',
                    validateur_id: 'DRH',
                    validateur_nom: 'Direction des Ressources Humaines',
                    niveau_hierarchique: 2,
                    statut: 'en_attente_precedent',
                    decision: null,
                    commentaire: null,
                    date_decision: null
                }
            ];
            
            console.log('✅ Workflow créé avec succès:', workflow.length, 'étapes');
            return workflow;
            
        } catch (error) {
            console.error('❌ Erreur création workflow:', error);
            throw new Error(`Impossible de créer le workflow: ${error.message}`);
        }
    },

    async getSuperieursHierarchiques(agentId) {
        try {
            const personnelResponse = await trickleListObjects('personnel', 200, true);
            const agent = personnelResponse.items.find(p => p.objectId === agentId);
            
            if (!agent) return [];
            
            const superieurs = [];
            
            // Niveau 1 - Supérieur direct
            if (agent.objectData.superieur_id) {
                const superieur1 = personnelResponse.items.find(p => 
                    p.objectId === agent.objectData.superieur_id
                );
                if (superieur1) {
                    superieurs.push({
                        id: superieur1.objectId,
                        nom: `${superieur1.objectData.prenom} ${superieur1.objectData.nom}`,
                        niveau_hierarchique: 1
                    });
                    
                    // Niveau 2 - Supérieur du supérieur
                    if (superieur1.objectData.superieur_id) {
                        const superieur2 = personnelResponse.items.find(p => 
                            p.objectId === superieur1.objectData.superieur_id
                        );
                        if (superieur2) {
                            superieurs.push({
                                id: superieur2.objectId,
                                nom: `${superieur2.objectData.prenom} ${superieur2.objectData.nom}`,
                                niveau_hierarchique: 2
                            });
                        }
                    }
                }
            }
            
            return superieurs;
        } catch (error) {
            console.error('Erreur récupération hiérarchie:', error);
            return [];
        }
    },

    async validerEtape(demandeId, validateurId, decision, commentaire) {
        try {
            const demande = await trickleGetObject('demande_conge', demandeId);
            const workflow = demande.objectData.workflow || [];
            const etapeActuelle = demande.objectData.etape_actuelle || 1;
            
            const etapeIndex = etapeActuelle - 1;
            const etapeEnCours = workflow[etapeIndex];
            
            if (!etapeEnCours || etapeEnCours.validateur_id !== validateurId) {
                throw new Error('Non autorisé à valider cette étape');
            }
            
            // Mettre à jour l'étape actuelle
            etapeEnCours.decision = decision;
            etapeEnCours.commentaire = commentaire;
            etapeEnCours.date_decision = new Date().toISOString();
            etapeEnCours.statut = decision === 'approuver' ? 'approuve' : 'refuse';
            
            let nouveauStatut = 'en_cours';
            let nouvelleEtape = etapeActuelle;
            
            if (decision === 'refuser') {
                nouveauStatut = 'refuse';
                // Marquer toutes les étapes suivantes comme annulées
                for (let i = etapeIndex + 1; i < workflow.length; i++) {
                    workflow[i].statut = 'annule';
                }
            } else if (decision === 'approuver') {
                if (etapeIndex === workflow.length - 1) {
                    // Dernière étape (DRH) = validation finale
                    nouveauStatut = 'approuve';
                    nouvelleEtape = workflow.length + 1;
                } else {
                    // Passer à l'étape DRH
                    nouvelleEtape = etapeActuelle + 1;
                    const etapeDRH = workflow[etapeIndex + 1];
                    if (etapeDRH) {
                        etapeDRH.statut = 'en_attente';
                        nouveauStatut = 'en_attente_drh';
                    }
                }
            }
            
            // Mettre à jour la demande
            await trickleUpdateObject('demande_conge', demandeId, {
                workflow: workflow,
                etape_actuelle: nouvelleEtape,
                statut: nouveauStatut
            });
            
            return { success: true, nouveauStatut, nouvelleEtape };
            
        } catch (error) {
            console.error('Erreur validation étape:', error);
            throw error;
        }
    },

    async notifierNouvelledemande(demandeId, agentNom, typeConge, validateurId) {
        try {
            await trickleCreateObject('notification_conge', {
                destinataire_id: validateurId,
                type: 'nouvelle_demande_conge',
                titre: '🔔 Nouvelle demande de congé',
                message: `${agentNom} a fait une demande de ${typeConge}`,
                demande_id: demandeId,
                lue: false,
                date_envoi: new Date().toISOString()
            });
        } catch (error) {
            console.error('Erreur notification:', error);
        }
    },

    async getDemandesParValidateur(validateurId) {
        try {
            const response = await trickleListObjects('demande_conge', 100, true);
            
            return response.items.filter(demande => {
                const workflow = demande.objectData.workflow || [];
                const etapeActuelle = demande.objectData.etape_actuelle || 1;
                
                if (workflow.length > 0 && etapeActuelle <= workflow.length) {
                    const etapeEnCours = workflow[etapeActuelle - 1];
                    return etapeEnCours && 
                           etapeEnCours.validateur_id === validateurId && 
                           etapeEnCours.statut === 'en_attente' &&
                           !etapeEnCours.decision;
                }
                return false;
            });
        } catch (error) {
            console.error('Erreur récupération demandes validateur:', error);
            return [];
        }
    }
};
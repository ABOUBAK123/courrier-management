window.hierarchyManager = {
    // Définition de la hiérarchie organisationnelle
    HIERARCHIE_POSTES: {
        'Agent': { niveau: 1, superieur: 'Chef de Service' },
        'Chef de Service': { niveau: 2, superieur: 'Sous-Directeur' },
        'Sous-Directeur': { niveau: 3, superieur: 'Directeur' },
        'Directeur': { niveau: 4, superieur: 'Directeur Général' },
        'Directeur Général': { niveau: 5, superieur: 'Directeur RH' },
        'Directeur RH': { niveau: 6, superieur: null }
    },

    async creerWorkflowValidation(agentId, demandeData) {
        try {
            console.log('Création workflow pour agent:', agentId);
            
            const agent = await trickleGetObject('personnel', agentId);
            if (!agent) {
                console.error('Agent non trouvé pour le workflow');
                return [];
            }

            const posteAgent = agent.objectData.grade || agent.objectData.poste || 'Agent';
            console.log('Poste agent:', posteAgent);
            
            const workflow = await this.construireChainValidation(posteAgent, agent.objectData.direction_id);
            console.log('Chaîne de validation:', workflow);

            return workflow.map((etape, index) => ({
                niveau: index + 1,
                validateur_id: etape.validateur_id,
                validateur_nom: etape.validateur_nom,
                poste: etape.poste,
                valide: false,
                decision: null,
                date_validation: null,
                commentaire: '',
                obligatoire: true,
                date_limite: this.calculerDateLimite(),
                signature_finale: etape.signature_finale || false
            }));
        } catch (error) {
            console.error('Erreur création workflow:', error);
            // Retourner un workflow minimal si erreur
            return [{
                niveau: 1,
                validateur_id: 'admin',
                validateur_nom: 'Administrateur',
                poste: 'Administrateur',
                valide: false,
                decision: null,
                date_validation: null,
                commentaire: '',
                obligatoire: true,
                date_limite: this.calculerDateLimite(),
                signature_finale: true
            }];
        }
    },

    async construireChainValidation(posteAgent, directionId) {
        try {
            const chaine = [];
            let posteActuel = posteAgent;

            // Construction de la chaîne hiérarchique
            while (posteActuel && this.HIERARCHIE_POSTES[posteActuel]?.superieur) {
                const posteSuperieur = this.HIERARCHIE_POSTES[posteActuel].superieur;
                const superieur = await this.trouverSuperieur(posteSuperieur, directionId);
                
                if (superieur) {
                    chaine.push({
                        validateur_id: superieur.objectId,
                        validateur_nom: `${superieur.objectData.nom} ${superieur.objectData.prenom}`,
                        poste: posteSuperieur,
                        direction_id: superieur.objectData.direction_id
                    });
                }
                
                posteActuel = posteSuperieur;
            }

            // Toujours finir par le Directeur RH (signature finale)
            const directeurRH = await this.trouverDirecteurRH();
            if (directeurRH && !chaine.find(etape => etape.poste === 'Directeur RH')) {
                chaine.push({
                    validateur_id: directeurRH.objectId,
                    validateur_nom: `${directeurRH.objectData.nom} ${directeurRH.objectData.prenom}`,
                    poste: 'Directeur RH',
                    direction_id: directeurRH.objectData.direction_id,
                    signature_finale: true
                });
            }

            return chaine;
        } catch (error) {
            console.error('Erreur construction chaîne:', error);
            return [];
        }
    },

    async trouverSuperieur(poste, directionId) {
        try {
            const response = await trickleListObjects('personnel', 100, true);
            
            // Recherche par poste et direction
            let superieur = response.items.find(item => 
                (item.objectData.grade === poste || item.objectData.poste === poste) &&
                item.objectData.direction_id === directionId &&
                item.objectData.statut === 'actif'
            );

            // Si pas trouvé dans la même direction, chercher au niveau global pour DG et DRH
            if (!superieur && (poste === 'Directeur Général' || poste === 'Directeur RH')) {
                superieur = response.items.find(item => 
                    (item.objectData.grade === poste || item.objectData.poste === poste) &&
                    item.objectData.statut === 'actif'
                );
            }

            return superieur;
        } catch (error) {
            console.error('Erreur recherche supérieur:', error);
            return null;
        }
    },

    async trouverDirecteurRH() {
        try {
            const response = await trickleListObjects('personnel', 100, true);
            return response.items.find(item => 
                (item.objectData.grade === 'Directeur RH' || 
                 item.objectData.poste === 'Directeur RH' ||
                 item.objectData.departement === 'Ressources Humaines') &&
                item.objectData.statut === 'actif'
            );
        } catch (error) {
            console.error('Erreur recherche DRH:', error);
            return null;
        }
    },

    calculerDateLimite() {
        const maintenant = new Date();
        maintenant.setDate(maintenant.getDate() + 3); // 3 jours pour validation
        return maintenant.toISOString();
    },

    async verifierAutorisationValidation(userId, demandeId) {
        try {
            const demande = await trickleGetObject('demande_conge', demandeId);
            if (!demande) return false;

            const workflow = demande.objectData.workflow || [];
            
            // Trouver l'étape actuelle (première non validée)
            const etapeActuelle = workflow.find(etape => !etape.valide);
            
            return etapeActuelle && etapeActuelle.validateur_id === userId;
        } catch (error) {
            console.error('Erreur vérification autorisation:', error);
            return false;
        }
    },

    async obtenirEtapeActuelle(demandeId) {
        try {
            const demande = await trickleGetObject('demande_conge', demandeId);
            if (!demande) return null;

            const workflow = demande.objectData.workflow || [];
            return workflow.find(etape => !etape.valide) || null;
        } catch (error) {
            console.error('Erreur obtention étape actuelle:', error);
            return null;
        }
    },

    async genererAttestationConge(demandeId) {
        try {
            const demande = await trickleGetObject('demande_conge', demandeId);
            if (!demande) return null;

            const agent = await trickleGetObject('personnel', demande.objectData.agent_id);
            if (!agent) return null;

            const attestation = {
                numero_attestation: `ATT-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
                agent_nom: `${agent.objectData.nom} ${agent.objectData.prenom}`,
                agent_matricule: agent.objectData.matricule,
                type_conge: demande.objectData.type_conge,
                date_debut: demande.objectData.date_debut,
                date_fin: demande.objectData.date_fin,
                duree_jours: demande.objectData.duree_jours,
                date_generation: new Date().toISOString(),
                statut: 'validee',
                signatures: demande.objectData.workflow.filter(etape => etape.valide)
            };

            await trickleCreateObject('attestation_conge', attestation);
            return attestation;
        } catch (error) {
            console.error('Erreur génération attestation:', error);
            return null;
        }
    }
};

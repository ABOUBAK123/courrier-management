const generateMailNumber = async (type, directionCode, year) => {
    try {
        const prefix = type === 'arrive' ? 'A' : 'D';
        
        // Rechercher tous les courriers existants pour cette direction
        const mails = await trickleListObjects(`mail:${directionCode}`, 1000, true);
        
        // Filtrer par type et année avec pattern exact
        const filteredMails = mails.items.filter(mail => {
            const mailData = mail.objectData;
            const numero = mailData.numero;
            
            if (!numero) return false;
            
            // Vérifier le format exact: A-XXXX-DIRECTION-YEAR ou D-XXXX-DIRECTION-YEAR
            const pattern = new RegExp(`^${prefix}-(\\d{4})-${directionCode}-${year}$`);
            return pattern.test(numero);
        });
        
        // Extraire les numéros séquentiels et trouver le maximum
        let maxNumber = 0;
        filteredMails.forEach(mail => {
            const numero = mail.objectData.numero;
            const match = numero.match(new RegExp(`^${prefix}-(\\d{4})-${directionCode}-${year}$`));
            if (match) {
                const sequentialNumber = parseInt(match[1], 10);
                if (sequentialNumber > maxNumber) {
                    maxNumber = sequentialNumber;
                }
            }
        });
        
        // Le prochain numéro est le maximum + 1
        const nextNumber = maxNumber + 1;
        
        // Vérifier la limite de 9999
        if (nextNumber > 9999) {
            throw new Error(`Limite de numérotation atteinte (9999) pour ${directionCode}-${year}`);
        }
        
        // Format: A-0007-DMOA-2025 (toujours 4 chiffres)
        return `${prefix}-${nextNumber.toString().padStart(4, '0')}-${directionCode}-${year}`;
        
    } catch (error) {
        console.error('Erreur génération numéro:', error);
        // Fallback sécurisé qui commence par 0001
        const prefix = type === 'arrive' ? 'A' : 'D';
        return `${prefix}-0001-${directionCode}-${year}`;
    }
};

const createMail = async (mailData) => {
    const loadingToastId = window.toastManager?.loading('Création du courrier en cours...');
    
    try {
        const result = await trickleCreateObject(`mail:${mailData.direction}`, mailData);
        
        window.toastManager?.remove(loadingToastId);
        window.toastManager?.success('Courrier créé avec succès');
        
        return result;
    } catch (error) {
        window.toastManager?.remove(loadingToastId);
        window.toastManager?.error(`Erreur lors de la création: ${error.message}`);
        throw error;
    }
};

const updateMail = async (mailId, direction, updateData) => {
    const loadingToastId = window.toastManager?.loading('Mise à jour en cours...');
    
    try {
        const result = await trickleUpdateObject(`mail:${direction}`, mailId, updateData);
        
        window.toastManager?.remove(loadingToastId);
        window.toastManager?.success('Courrier mis à jour avec succès');
        
        return result;
    } catch (error) {
        window.toastManager?.remove(loadingToastId);
        window.toastManager?.error(`Erreur de mise à jour: ${error.message}`);
        throw error;
    }
};

const generateFileNumber = () => {
    const now = new Date();
    const counter = Math.floor(Math.random() * 9999) + 1;
    const timestamp = now.toISOString().replace(/[-:T.]/g, '').slice(0, 14);
    return `J-${counter.toString().padStart(4, '0')}-${timestamp}`;
};

const PRIORITIES = [
    { value: 'faible', label: 'Faible', color: 'text-green-600' },
    { value: 'normale', label: 'Normale', color: 'text-blue-600' },
    { value: 'elevee', label: 'Élevée', color: 'text-orange-600' },
    { value: 'urgente', label: 'Urgente', color: 'text-red-600' }
];

const STATUSES = [
    { value: 'attente', label: 'En attente', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'traitement', label: 'En traitement', color: 'bg-blue-100 text-blue-800' },
    { value: 'traite', label: 'Traité', color: 'bg-green-100 text-green-800' },
    { value: 'valide', label: 'Validé', color: 'bg-purple-100 text-purple-800' }
];

// Configuration pour stockage externe des documents
const EXTERNAL_STORAGE_CONFIG = {
    enabled: true,
    types: [
        { value: 'azure', label: 'Azure Government Cloud', icon: 'fab fa-microsoft' },
        { value: 'aws', label: 'AWS GovCloud', icon: 'fab fa-aws' },
        { value: 'google', label: 'Google Cloud Government', icon: 'fab fa-google' },
        { value: 'ftp', label: 'Serveur FTP/SFTP Interne', icon: 'fas fa-server' },
        { value: 'sharepoint', label: 'SharePoint Gouvernemental', icon: 'fas fa-share-alt' },
        { value: 'other', label: 'Autre stockage sécurisé', icon: 'fas fa-cloud' }
    ]
};

// Validation des URLs de documents
const validateDocumentUrl = (url) => {
    if (!url || url.trim() === '') return false;
    
    try {
        const urlObj = new URL(url);
        // Vérifier que c'est un protocole sécurisé
        return urlObj.protocol === 'https:' || urlObj.protocol === 'ftp:' || urlObj.protocol === 'sftp:';
    } catch (error) {
        return false;
    }
};

// Extraire le nom de fichier depuis une URL
const extractFileNameFromUrl = (url) => {
    try {
        const urlObj = new URL(url);
        const pathname = urlObj.pathname;
        return pathname.split('/').pop() || 'document';
    } catch (error) {
        return 'document';
    }
};

// Générer les métadonnées pour un document externe
const createDocumentMetadata = (url, name, type, size = null) => {
    return {
        id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        name: name || extractFileNameFromUrl(url),
        url: url,
        type: type || 'application/octet-stream',
        size: size,
        uploadDate: new Date().toISOString(),
        isExternal: true,
        verified: validateDocumentUrl(url)
    };
};

const ROLES = {
    ADMIN: 'ADMIN',
    MINISTRE: 'MINISTRE',
    DIR_CAB: 'DIR CAB',
    DIRECTEUR_GENERAL: 'DIRECTEUR GENERAL',
    DIRECTEUR: 'DIRECTEUR',
    SOUS_DIRECTEUR: 'SOUS-DIRECTEUR',
    ASSISTANT: 'ASSISTANT',
    CHEF_SERVICE: 'CHEF DE SERVICE',
    AGENT: 'AGENT'
};

const canViewImputation = (role) => {
    return ['ADMIN', 'MINISTRE', 'DIR CAB', 'DIRECTEUR GENERAL', 'DIRECTEUR'].includes(role);
};

const canReimpute = (role) => {
    return ['DIR CAB', 'DIRECTEUR GENERAL', 'DIRECTEUR', 'SOUS-DIRECTEUR'].includes(role);
};

// Fonction pour valider le format d'un numéro de courrier
const validateMailNumber = (numero) => {
    const pattern = /^[AD]-\d{4}-[A-Z]+\d*-\d{4}$/;
    return pattern.test(numero);
};

// Fonction pour supprimer tous les courriers numérotés
const deleteAllNumberedMails = async () => {
    try {
        // Récupérer toutes les directions
        const directions = await trickleListObjects('directions', 100, true);
        let totalDeleted = 0;
        
        for (const direction of directions.items) {
            const directionCode = direction.objectData.code;
            
            // Récupérer tous les courriers de cette direction
            const mails = await trickleListObjects(`mail:${directionCode}`, 1000, true);
            
            for (const mail of mails.items) {
                const mailData = mail.objectData;
                
                // Vérifier si le courrier a un numéro (format A-XXXX ou D-XXXX)
                if (mailData.numero && validateMailNumber(mailData.numero)) {
                    try {
                        await trickleDeleteObject(`mail:${directionCode}`, mail.objectId);
                        totalDeleted++;
                        console.log(`Supprimé: ${mailData.numero}`);
                    } catch (deleteError) {
                        console.error(`Erreur suppression ${mailData.numero}:`, deleteError);
                    }
                }
            }
        }
        
        return {
            success: true,
            deletedCount: totalDeleted,
            message: `${totalDeleted} courriers numérotés supprimés avec succès`
        };
        
    } catch (error) {
        console.error('Erreur suppression courriers:', error);
        return {
            success: false,
            error: error.message,
            message: 'Erreur lors de la suppression des courriers'
        };
    }
};

window.congeCalculator = {
    calculerSoldeAcquis(dateEmbauche, typeConge) {
        const maintenant = new Date();
        const embauche = new Date(dateEmbauche);
        const moisTravailles = this.calculerMoisTravailles(embauche, maintenant);
        
        return Math.floor((moisTravailles / 12) * typeConge.soldeParAn);
    },

    calculerMoisTravailles(dateDebut, dateFin) {
        const debut = new Date(dateDebut);
        const fin = new Date(dateFin);
        
        let mois = (fin.getFullYear() - debut.getFullYear()) * 12;
        mois += fin.getMonth() - debut.getMonth();
        
        return mois;
    },

    calculerDureeEnJours(dateDebut, dateFin) {
        const debut = new Date(dateDebut);
        const fin = new Date(dateFin);
        let jours = 0;
        
        const current = new Date(debut);
        while (current <= fin) {
            if (current.getDay() !== 0 && current.getDay() !== 6) {
                jours++;
            }
            current.setDate(current.getDate() + 1);
        }
        
        return jours;
    },

    verifierSoldeDisponible(soldeActuel, dureedemandee) {
        return soldeActuel >= dureedemandee;
    },

    calculerDateRetour(dateDebut, dureeJours) {
        const debut = new Date(dateDebut);
        let joursAjoutes = 0;
        
        while (joursAjoutes < dureeJours) {
            debut.setDate(debut.getDate() + 1);
            if (debut.getDay() !== 0 && debut.getDay() !== 6) {
                joursAjoutes++;
            }
        }
        
        return debut;
    }
};
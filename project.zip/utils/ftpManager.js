// Gestionnaire de connexions FTP pour les documents
const FTPManager = {
    config: null,

    // Charger la configuration FTP
    async loadConfig() {
        try {
            const settings = await trickleListObjects('ftp-config', 10, true);
            if (settings.items.length > 0) {
                this.config = settings.items[0].objectData;
                return this.config;
            }
            return null;
        } catch (error) {
            console.error('Erreur chargement config FTP:', error);
            return null;
        }
    },

    // Upload réel d'un fichier vers le serveur FTP
    async uploadFile(file, fileName = null) {
        try {
            await this.loadConfig();
            
            if (!this.config) {
                throw new Error('Configuration FTP manquante');
            }

            const finalFileName = fileName || `${Date.now()}_${file.name}`;
            window.toastManager?.info(`🔄 Upload de ${file.name}...`);
            
            try {
                // Créer FormData pour l'upload
                const formData = new FormData();
                formData.append('file', file);
                formData.append('fileName', finalFileName);
                formData.append('ftpConfig', JSON.stringify(this.config));

                // Envoyer vers l'API proxy d'upload
                const response = await fetch('./api/ftp-upload.php', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error(`Erreur HTTP: ${response.status}`);
                }

                const result = await response.json();
                
                if (result.success) {
                    window.toastManager?.success(`✅ Fichier ${file.name} uploadé`);
                    
                    return {
                        fileName: finalFileName,
                        ftpPath: result.ftpPath,
                        size: file.size,
                        type: file.type,
                        uploadDate: new Date().toISOString(),
                        ftpUrl: this.buildDocumentUrl(finalFileName)
                    };
                } else {
                    throw new Error(result.message || 'Erreur upload FTP');
                }
            } catch (error) {
                window.toastManager?.error(`❌ Échec upload: ${error.message}`);
                throw error;
            }
        } catch (error) {
            console.error('Erreur upload FTP:', error);
            throw error;
        }
    },

    // Construire l'URL complète du document
    buildDocumentUrl(fileName) {
        if (!this.config) {
            return fileName;
        }

        const protocol = this.config.server.startsWith('ftp://') ? '' : 'ftp://';
        const auth = this.config.username && this.config.password ? 
            `${this.config.username}:${this.config.password}@` : '';
        const port = this.config.port && this.config.port !== '21' ? `:${this.config.port}` : '';
        
        return `${protocol}${auth}${this.config.server}${port}/${fileName}`;
    },

    // Tester la connexion FTP
    async testConnection() {
        await this.loadConfig();
        
        if (!this.config) {
            throw new Error('Configuration FTP manquante');
        }

        try {
            const response = await fetch('/api/ftp-test.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(this.config)
            });

            const result = await response.json();
            return result;
        } catch (error) {
            throw new Error(`Erreur test connexion: ${error.message}`);
        }
    }
};

window.FTPManager = FTPManager;

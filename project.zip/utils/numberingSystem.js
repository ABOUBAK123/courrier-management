// Système de numérotation basé sur le dernier numéro enregistré
const getNextMailNumber = async (type, directionCode, year) => {
    try {
        const prefix = type === 'arrive' ? 'A' : 'D';
        
        // Rechercher tous les courriers existants pour cette direction/type/année
        const existingMails = await trickleListObjects('mails', 1000, true);
        
        // Filtrer par direction, type et année
        const relevantMails = existingMails.items.filter(mail => {
            const mailData = mail.objectData;
            const mailNumber = mailData.numero;
            
            if (!mailNumber) return false;
            
            // Vérifier le format: A-XXXX-DIRECTION-YEAR ou D-XXXX-DIRECTION-YEAR
            const pattern = new RegExp(`^${prefix}-(\\d{4})-${directionCode}-${year}$`);
            return pattern.test(mailNumber);
        });
        
        // Extraire les numéros séquentiels et trouver le maximum
        let maxNumber = 0;
        relevantMails.forEach(mail => {
            const mailNumber = mail.objectData.numero;
            const match = mailNumber.match(new RegExp(`^${prefix}-(\\d{4})-${directionCode}-${year}$`));
            if (match) {
                const sequentialNumber = parseInt(match[1], 10);
                if (sequentialNumber > maxNumber) {
                    maxNumber = sequentialNumber;
                }
            }
        });
        
        // Le prochain numéro est le maximum + 1
        const nextNumber = maxNumber + 1;
        
        // Vérifier la limite de 9999
        if (nextNumber > 9999) {
            throw new Error(`Limite de numérotation atteinte (9999) pour ${directionCode}-${year}`);
        }
        
        // Générer le numéro final avec padding à 4 chiffres
        return `${prefix}-${nextNumber.toString().padStart(4, '0')}-${directionCode}-${year}`;
        
    } catch (error) {
        console.error('Erreur système numérotation:', error);
        throw error;
    }
};

// Fonction pour obtenir le prochain numéro sans l'incrémenter (preview)
const previewNextNumber = async (type, directionCode, year) => {
    try {
        const prefix = type === 'arrive' ? 'A' : 'D';
        
        // Rechercher tous les courriers existants pour cette direction/type/année
        const existingMails = await trickleListObjects('mails', 1000, true);
        
        // Filtrer par direction, type et année
        const relevantMails = existingMails.items.filter(mail => {
            const mailData = mail.objectData;
            const mailNumber = mailData.numero;
            
            if (!mailNumber) return false;
            
            // Vérifier le format: A-XXXX-DIRECTION-YEAR ou D-XXXX-DIRECTION-YEAR
            const pattern = new RegExp(`^${prefix}-(\\d{4})-${directionCode}-${year}$`);
            return pattern.test(mailNumber);
        });
        
        // Extraire les numéros séquentiels et trouver le maximum
        let maxNumber = 0;
        relevantMails.forEach(mail => {
            const mailNumber = mail.objectData.numero;
            const match = mailNumber.match(new RegExp(`^${prefix}-(\\d{4})-${directionCode}-${year}$`));
            if (match) {
                const sequentialNumber = parseInt(match[1], 10);
                if (sequentialNumber > maxNumber) {
                    maxNumber = sequentialNumber;
                }
            }
        });
        
        // Le prochain numéro est le maximum + 1
        const nextNumber = maxNumber + 1;
        return `${prefix}-${nextNumber.toString().padStart(4, '0')}-${directionCode}-${year}`;
    } catch (error) {
        console.error('Erreur preview numéro:', error);
        return `${prefix}-0001-${directionCode}-${year}`;
    }
};

// Fonction pour obtenir les statistiques de numérotation par direction
const getNumberingStats = async (directionCode, year) => {
    try {
        const existingMails = await trickleListObjects('mails', 1000, true);
        
        // Compter les courriers arrivés
        const arriveMails = existingMails.items.filter(mail => {
            const mailNumber = mail.objectData.numero;
            if (!mailNumber) return false;
            const pattern = new RegExp(`^A-\\d{4}-${directionCode}-${year}$`);
            return pattern.test(mailNumber);
        });
        
        // Compter les courriers départ
        const departMails = existingMails.items.filter(mail => {
            const mailNumber = mail.objectData.numero;
            if (!mailNumber) return false;
            const pattern = new RegExp(`^D-\\d{4}-${directionCode}-${year}$`);
            return pattern.test(mailNumber);
        });
        
        return {
            arrive: arriveMails.length,
            depart: departMails.length,
            total: arriveMails.length + departMails.length
        };
    } catch (error) {
        console.error('Erreur stats numérotation:', error);
        return { arrive: 0, depart: 0, total: 0 };
    }
};

// Fonction pour réinitialiser les compteurs (admin seulement)
const resetCountersForYear = async (year) => {
    try {
        const counters = await trickleListObjects('mail-counters', 1000, true);
        const yearCounters = counters.items.filter(item => 
            item.objectData.year === year
        );
        
        for (const counter of yearCounters) {
            await trickleUpdateObject('mail-counters', counter.objectId, {
                ...counter.objectData,
                currentNumber: 0,
                lastUpdated: new Date().toISOString()
            });
        }
        
        return `${yearCounters.length} compteurs réinitialisés pour l'année ${year}`;
    } catch (error) {
        console.error('Erreur réinitialisation compteurs:', error);
        throw error;
    }
};

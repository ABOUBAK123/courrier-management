// Système de validation pour l'import de données Excel

const ValidationRules = {
    matricule: {
        required: true,
        pattern: /^[A-Z0-9]{3,10}$/,
        message: 'Le matricule doit contenir 3-10 caractères alphanumériques'
    },
    nom: {
        required: true,
        minLength: 2,
        maxLength: 100,
        pattern: /^[a-zA-ZÀ-ÿ\s\-']+$/,
        message: 'Le nom doit contenir uniquement des lettres, espaces, tirets et apostrophes'
    },
    email: {
        required: true,
        pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        message: 'Format d\'email invalide'
    },
    poste: {
        required: true,
        minLength: 2,
        maxLength: 50,
        message: 'Le poste doit contenir 2-50 caractères'
    },
    grade: {
        required: true,
        allowedValues: ['Échelle 6', 'Échelle 7', 'Échelle 8', 'Échelle 9', 'Échelle 10', 'Échelle 11', 'Échelle 12', 'Hors échelle'],
        message: 'Grade non reconnu'
    }
};

function validateField(field, value, rule) {
    const errors = [];
    
    // Vérifier si requis
    if (rule.required && (!value || value.toString().trim() === '')) {
        errors.push(`${field} est obligatoire`);
        return errors;
    }
    
    if (!value) return errors;
    
    const stringValue = value.toString().trim();
    
    // Vérifier la longueur minimale
    if (rule.minLength && stringValue.length < rule.minLength) {
        errors.push(`${field} doit contenir au moins ${rule.minLength} caractères`);
    }
    
    // Vérifier la longueur maximale
    if (rule.maxLength && stringValue.length > rule.maxLength) {
        errors.push(`${field} ne peut pas dépasser ${rule.maxLength} caractères`);
    }
    
    // Vérifier le pattern
    if (rule.pattern && !rule.pattern.test(stringValue)) {
        errors.push(rule.message);
    }
    
    // Vérifier les valeurs autorisées
    if (rule.allowedValues && !rule.allowedValues.includes(stringValue)) {
        errors.push(`${field}: ${rule.message}. Valeurs autorisées: ${rule.allowedValues.join(', ')}`);
    }
    
    return errors;
}

function validateRow(rowData, rowIndex, existingData = []) {
    const errors = [];
    const warnings = [];
    
    // Validation des champs individuels
    Object.keys(ValidationRules).forEach(field => {
        const fieldErrors = validateField(field, rowData[field], ValidationRules[field]);
        errors.push(...fieldErrors.map(err => ({ field, message: err, line: rowIndex })));
    });
    
    // Validation de l'unicité du matricule
    if (rowData.matricule) {
        const duplicateMatricule = existingData.find(item => 
            item.matricule === rowData.matricule.toString().trim()
        );
        if (duplicateMatricule) {
            errors.push({
                field: 'matricule',
                message: 'Matricule déjà existant dans la base de données',
                line: rowIndex
            });
        }
    }
    
    // Validation de l'unicité de l'email
    if (rowData.email) {
        const duplicateEmail = existingData.find(item => 
            item.email === rowData.email.toString().trim().toLowerCase()
        );
        if (duplicateEmail) {
            errors.push({
                field: 'email',
                message: 'Email déjà utilisé par un autre agent',
                line: rowIndex
            });
        }
    }
    
    // Avertissements pour les données suspectes
    if (rowData.nom && rowData.nom.toString().length < 3) {
        warnings.push({
            field: 'nom',
            message: 'Nom très court, vérifiez la saisie',
            line: rowIndex
        });
    }
    
    return { errors, warnings };
}

function validateImportData(data) {
    const results = {
        totalRows: data.length,
        validRows: 0,
        invalidRows: 0,
        errors: [],
        warnings: [],
        summary: {}
    };
    
    // Mock existing data for demonstration
    const existingData = [
        { matricule: 'EMP001', email: 'existing@ministere.gov.ma' }
    ];
    
    data.forEach((row, index) => {
        const validation = validateRow(row, index + 2, existingData); // +2 car ligne 1 = headers
        
        if (validation.errors.length > 0) {
            results.invalidRows++;
            results.errors.push(...validation.errors);
        } else {
            results.validRows++;
        }
        
        results.warnings.push(...validation.warnings);
    });
    
    // Générer le résumé
    results.summary = {
        successRate: ((results.validRows / results.totalRows) * 100).toFixed(1),
        errorsByField: results.errors.reduce((acc, error) => {
            acc[error.field] = (acc[error.field] || 0) + 1;
            return acc;
        }, {})
    };
    
    return results;
}
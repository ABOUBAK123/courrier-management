// Client API pour remplacer les fonctions Trickle
// Test de plusieurs configurations de chemins

// Liste des chemins possibles à tester
const possiblePaths = [
    '/api',            // Chemin absolu depuis la racine
    './api',           // Chemin relatif
    'api',             // Sans point
];

let API_BASE_URL = '/api'; // Défaut - absolu depuis racine
let apiPathTested = false;

// Fonction pour tester et trouver le bon chemin API
async function findWorkingApiPath() {
    if (apiPathTested) return;
    
    console.log('[API Client] Test des chemins API...');
    
    for (const path of possiblePaths) {
        try {
            const testUrl = `${path}/test-simple.php`;
            console.log(`[API Client] Test: ${testUrl}`);
            
            const response = await fetch(testUrl);
            if (response.ok) {
                API_BASE_URL = path;
                apiPathTested = true;
                console.log(`[API Client] ✓ Chemin trouvé: ${API_BASE_URL}`);
                return;
            }
        } catch (error) {
            console.log(`[API Client] ✗ Échec: ${path}`);
        }
    }
    
    console.error('[API Client] Aucun chemin API valide trouvé!');
    apiPathTested = true;
}

// Tester au chargement
findWorkingApiPath().catch(console.error);

// Fonction pour créer un objet
async function trickleCreateObject(objectType, objectData) {
    await findWorkingApiPath();
    
    try {
        const url = `${API_BASE_URL}/objects.php`;
        
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'create',
                objectType,
                objectData
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const result = await response.json();
        if (result.success) return result.data;
        throw new Error(result.error);
    } catch (error) {
        console.error('Erreur trickleCreateObject:', error);
        throw error;
    }
}

// Fonction pour mettre à jour un objet
async function trickleUpdateObject(objectType, objectId, objectData) {
    await findWorkingApiPath();
    
    try {
        const response = await fetch(`${API_BASE_URL}/objects.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'update',
                objectType,
                objectId,
                objectData
            })
        });
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const result = await response.json();
        if (result.success) return result.data;
        throw new Error(result.error);
    } catch (error) {
        console.error('Erreur trickleUpdateObject:', error);
        throw error;
    }
}

// Fonction pour récupérer un objet
async function trickleGetObject(objectType, objectId) {
    await findWorkingApiPath();
    
    try {
        const url = `${API_BASE_URL}/objects.php?action=get&objectType=${encodeURIComponent(objectType)}&objectId=${encodeURIComponent(objectId)}`;
        const response = await fetch(url);
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const result = await response.json();
        if (result.success) return result.data;
        throw new Error(result.error);
    } catch (error) {
        console.error('Erreur trickleGetObject:', error);
        throw error;
    }
}

// Fonction pour lister des objets
async function trickleListObjects(objectType, limit = 100, descent = true, nextPageToken = null) {
    await findWorkingApiPath();
    
    try {
        let url = `${API_BASE_URL}/objects.php?action=list&objectType=${encodeURIComponent(objectType)}&limit=${limit}&descent=${descent}`;
        if (nextPageToken) url += `&nextPageToken=${encodeURIComponent(nextPageToken)}`;
        
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const result = await response.json();
        if (result.success) {
            return {
                items: result.data || [],
                nextPageToken: result.nextPageToken || null
            };
        }
        throw new Error(result.error);
    } catch (error) {
        console.error('Erreur trickleListObjects:', error);
        throw error;
    }
}

// Fonction pour supprimer un objet
async function trickleDeleteObject(objectType, objectId) {
    await findWorkingApiPath();
    
    try {
        const response = await fetch(`${API_BASE_URL}/objects.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'delete',
                objectType,
                objectId
            })
        });
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const result = await response.json();
        if (!result.success) throw new Error(result.error);
    } catch (error) {
        console.error('Erreur trickleDeleteObject:', error);
        throw error;
    }
}

// Exposer les fonctions
window.trickleCreateObject = trickleCreateObject;
window.trickleUpdateObject = trickleUpdateObject;
window.trickleGetObject = trickleGetObject;
window.trickleListObjects = trickleListObjects;
window.trickleDeleteObject = trickleDeleteObject;
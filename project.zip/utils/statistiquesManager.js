window.statistiquesManager = {
    async genererStatistiques(periode = 'mois') {
        try {
            const dateDebut = this.calculerDateDebut(periode);
            const dateFin = new Date();

            // Récupérer toutes les demandes de congés
            const demandesResponse = await trickleListObjects('demande_conge', 1000, true);
            const demandes = demandesResponse.items.filter(item => {
                const dateCreation = new Date(item.createdAt);
                return dateCreation >= dateDebut && dateCreation <= dateFin;
            });

            // Récupérer les directions
            const directionsResponse = await trickleListObjects('direction', 100, true);
            const directions = directionsResponse.items;

            return {
                totalDemandes: demandes.length,
                demandesApprouvees: demandes.filter(d => d.objectData.statut === 'approuve').length,
                demandesEnAttente: demandes.filter(d => d.objectData.statut === 'en_attente').length,
                demandesRejetees: demandes.filter(d => d.objectData.statut === 'rejete').length,
                parDirection: this.calculerStatistiquesParDirection(demandes, directions),
                evolution: this.calculerEvolution(demandes, periode),
                topDirections: this.calculerTopDirections(demandes, directions),
                alertes: this.genererAlertes(demandes)
            };
        } catch (error) {
            console.error('Erreur génération statistiques:', error);
            return this.statistiquesParDefaut();
        }
    },

    calculerDateDebut(periode) {
        const maintenant = new Date();
        switch (periode) {
            case 'semaine':
                const debutSemaine = new Date(maintenant);
                debutSemaine.setDate(maintenant.getDate() - 7);
                return debutSemaine;
            case 'mois':
                return new Date(maintenant.getFullYear(), maintenant.getMonth(), 1);
            case 'trimestre':
                const moisTrimestre = Math.floor(maintenant.getMonth() / 3) * 3;
                return new Date(maintenant.getFullYear(), moisTrimestre, 1);
            case 'annee':
                return new Date(maintenant.getFullYear(), 0, 1);
            default:
                return new Date(maintenant.getFullYear(), maintenant.getMonth(), 1);
        }
    },

    calculerStatistiquesParDirection(demandes, directions) {
        const stats = {};
        
        directions.forEach(dir => {
            const directionId = dir.objectData.code || dir.objectId;
            const demandesDirection = demandes.filter(d => 
                d.objectData.agent_direction === directionId ||
                d.objectData.agent_direction === dir.objectData.nom
            );
            
            const totalJours = demandesDirection.reduce((total, d) => 
                total + (parseInt(d.objectData.duree_jours) || 0), 0
            );
            
            if (totalJours > 0) {
                stats[dir.objectData.nom || directionId] = totalJours;
            }
        });

        return stats;
    },

    calculerEvolution(demandes, periode) {
        const evolution = { labels: [], data: [] };
        const maintenant = new Date();
        
        if (periode === 'mois') {
            // Evolution par semaine du mois
            for (let i = 3; i >= 0; i--) {
                const dateDebut = new Date(maintenant);
                dateDebut.setDate(maintenant.getDate() - (i + 1) * 7);
                const dateFin = new Date(maintenant);
                dateFin.setDate(maintenant.getDate() - i * 7);
                
                const demandesPeriode = demandes.filter(d => {
                    const dateCreation = new Date(d.createdAt);
                    return dateCreation >= dateDebut && dateCreation < dateFin;
                });
                
                evolution.labels.push(`S${4-i}`);
                evolution.data.push(demandesPeriode.length);
            }
        } else {
            // Evolution par mois
            for (let i = 5; i >= 0; i--) {
                const date = new Date(maintenant);
                date.setMonth(maintenant.getMonth() - i);
                
                const demandesMois = demandes.filter(d => {
                    const dateCreation = new Date(d.createdAt);
                    return dateCreation.getMonth() === date.getMonth() && 
                           dateCreation.getFullYear() === date.getFullYear();
                });
                
                evolution.labels.push(date.toLocaleDateString('fr-FR', { month: 'short' }));
                evolution.data.push(demandesMois.length);
            }
        }
        
        return evolution;
    },

    calculerTopDirections(demandes, directions) {
        const stats = this.calculerStatistiquesParDirection(demandes, directions);
        return Object.entries(stats)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 5)
            .map(([nom, total]) => ({ nom, total }));
    },

    genererAlertes(demandes) {
        const alertes = [];
        
        // Demandes en attente depuis plus de 48h
        const demandesEnRetard = demandes.filter(d => {
            if (d.objectData.statut !== 'en_attente') return false;
            const dateCreation = new Date(d.createdAt);
            const maintenant = new Date();
            const heuresEcoulees = (maintenant - dateCreation) / (1000 * 60 * 60);
            return heuresEcoulees > 48;
        });

        if (demandesEnRetard.length > 0) {
            alertes.push({
                type: 'warning',
                message: `${demandesEnRetard.length} demande(s) en attente depuis plus de 48h`
            });
        }

        // Pic de demandes
        const moyenneDemandes = demandes.length / 30; // par jour
        const demandesAujourdhui = demandes.filter(d => {
            const dateCreation = new Date(d.createdAt);
            const aujourdhui = new Date();
            return dateCreation.toDateString() === aujourdhui.toDateString();
        }).length;

        if (demandesAujourdhui > moyenneDemandes * 2) {
            alertes.push({
                type: 'info',
                message: `Pic de demandes aujourd'hui: ${demandesAujourdhui} demandes`
            });
        }

        return alertes;
    },

    statistiquesParDefaut() {
        return {
            totalDemandes: 0,
            demandesApprouvees: 0,
            demandesEnAttente: 0,
            demandesRejetees: 0,
            parDirection: {},
            evolution: { labels: [], data: [] },
            topDirections: [],
            alertes: []
        };
    }
};
// Utilitaire pour valider et tracer le workflow des courriers
const validateWorkflowChain = async (mailNumber) => {
    try {
        const allDirections = await trickleListObjects('directions', 100, true);
        const directionCodes = allDirections.items.map(d => d.objectData.code);
        
        const workflowChain = [];
        
        // Rechercher le courrier dans toutes les directions
        for (const dirCode of directionCodes) {
            const mails = await trickleListObjects(`mail:${dirCode}`, 100, true);
            const mail = mails.items.find(m => m.objectData.numero === mailNumber);
            
            if (mail) {
                workflowChain.push({
                    direction: dirCode,
                    mail: mail.objectData,
                    step: getWorkflowStep(mail.objectData)
                });
            }
        }
        
        // Trier par ordre chronologique
        workflowChain.sort((a, b) => {
            const dateA = new Date(a.mail.imputationDate || a.mail.createdAt);
            const dateB = new Date(b.mail.imputationDate || b.mail.createdAt);
            return dateA - dateB;
        });
        
        return workflowChain;
    } catch (error) {
        console.error('Erreur validation workflow:', error);
        return [];
    }
};

const getWorkflowStep = (mail) => {
    if (mail.status === 'attente') return 'En attente d\'imputation';
    if (mail.status === 'traitement') return 'En cours de traitement';
    if (mail.status === 'traite') return 'Traité avec réponse';
    if (mail.status === 'valide') return 'Validé';
    if (mail.status === 'reimpute') return 'Réimputé';
    return 'Statut inconnu';
};

// Fonction pour vérifier l'intégrité du workflow
const checkWorkflowIntegrity = async (mailNumber) => {
    try {
        const chain = await validateWorkflowChain(mailNumber);
        const issues = [];
        
        // Vérifier qu'il y a au moins un courrier traité avec fichier
        const treatedWithFile = chain.find(step => 
            step.mail.status === 'traite' && step.mail.responseFile
        );
        
        if (!treatedWithFile) {
            issues.push('Aucun courrier traité avec fichier réponse trouvé');
        }
        
        // Vérifier la chaîne de validation
        const validations = chain.filter(step => step.mail.status === 'valide');
        if (validations.length === 0) {
            issues.push('Aucune validation trouvée dans la chaîne');
        }
        
        return {
            isValid: issues.length === 0,
            issues,
            chain
        };
    } catch (error) {
        console.error('Erreur vérification intégrité:', error);
        return { isValid: false, issues: ['Erreur système'], chain: [] };
    }
};

// Fonction pour nettoyer les courriers orphelins
const cleanOrphanedMails = async (direction) => {
    try {
        const mails = await trickleListObjects(`mail:${direction}`, 100, true);
        const orphaned = [];
        
        for (const mailItem of mails.items) {
            const mail = mailItem.objectData;
            
            // Vérifier si c'est un courrier réimputé sans suivi
            if (mail.status === 'reimpute' && !mail.responseFile) {
                const hasTracking = await trickleListObjects(`imputation:${direction}`, 100, true);
                const tracking = hasTracking.items.find(t => 
                    t.objectData.mailNumber === mail.numero
                );
                
                if (!tracking) {
                    orphaned.push(mailItem.objectId);
                }
            }
        }
        
        // Supprimer les courriers orphelins
        for (const orphanId of orphaned) {
            await trickleDeleteObject(`mail:${direction}`, orphanId);
        }
        
        return orphaned.length;
    } catch (error) {
        console.error('Erreur nettoyage orphelins:', error);
        return 0;
    }
};

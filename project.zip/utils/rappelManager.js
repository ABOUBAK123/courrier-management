window.rappelManager = {
    async obtenirRappelsEnAttente() {
        try {
            // Récupérer toutes les demandes en attente
            const demandesResponse = await trickleListObjects('demande_conge', 1000, true);
            const demandesEnAttente = demandesResponse.items.filter(item => 
                item.objectData.statut === 'en_attente'
            );

            const rappels = [];
            const maintenant = new Date();

            for (const demande of demandesEnAttente) {
                const dateCreation = new Date(demande.createdAt);
                const heuresEcoulees = (maintenant - dateCreation) / (1000 * 60 * 60);
                
                // Vérifier si un rappel est nécessaire
                if (heuresEcoulees > 24) {
                    const workflow = demande.objectData.workflow || [];
                    const etapeActuelle = workflow.find(etape => 
                        etape.niveau === demande.objectData.etape_actuelle && !etape.valide
                    );

                    if (etapeActuelle) {
                        rappels.push({
                            id: `rappel_${demande.objectId}`,
                            demandeId: demande.objectId,
                            titre: `Demande de congé en attente - ${demande.objectData.agent_nom}`,
                            description: `Demande de ${demande.objectData.type_conge} du ${demande.objectData.date_debut} au ${demande.objectData.date_fin}`,
                            validateurId: etapeActuelle.validateur_id,
                            validateurNom: etapeActuelle.validateur_nom,
                            dateEcheance: new Date(dateCreation.getTime() + 72 * 60 * 60 * 1000), // 72h après création
                            priorite: this.calculerPriorite(heuresEcoulees),
                            dernierRappel: await this.obtenirDernierRappel(demande.objectId)
                        });
                    }
                }
            }

            return rappels.sort((a, b) => new Date(a.dateEcheance) - new Date(b.dateEcheance));
        } catch (error) {
            console.error('Erreur obtention rappels:', error);
            return [];
        }
    },

    calculerPriorite(heuresEcoulees) {
        if (heuresEcoulees > 72) return 'haute';
        if (heuresEcoulees > 48) return 'moyenne';
        return 'basse';
    },

    async obtenirDernierRappel(demandeId) {
        try {
            const rappelsResponse = await trickleListObjects('rappel_log', 10, true);
            const rappelsDemande = rappelsResponse.items.filter(item => 
                item.objectData.demande_id === demandeId
            );
            
            if (rappelsDemande.length > 0) {
                return new Date(rappelsDemande[0].createdAt);
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    async envoyerRappel(rappelId) {
        try {
            const demandeId = rappelId.replace('rappel_', '');
            const demande = await trickleGetObject('demande_conge', demandeId);
            
            if (!demande) {
                throw new Error('Demande non trouvée');
            }

            // Enregistrer le rappel
            await trickleCreateObject('rappel_log', {
                demande_id: demandeId,
                type: 'rappel_validation',
                destinataire: demande.objectData.workflow[demande.objectData.etape_actuelle - 1]?.validateur_id,
                message: `Rappel: Demande de congé de ${demande.objectData.agent_nom} en attente de validation`,
                statut: 'envoye',
                date_envoi: new Date().toISOString()
            });

            // Simuler l'envoi d'email (dans un vrai système, intégrer avec un service d'email)
            console.log('Rappel envoyé pour la demande:', demandeId);
            
            return true;
        } catch (error) {
            console.error('Erreur envoi rappel:', error);
            throw error;
        }
    },

    async marquerCommeTraite(rappelId) {
        try {
            const demandeId = rappelId.replace('rappel_', '');
            
            await trickleCreateObject('rappel_log', {
                demande_id: demandeId,
                type: 'rappel_traite',
                message: 'Rappel marqué comme traité manuellement',
                statut: 'traite',
                date_traitement: new Date().toISOString()
            });

            return true;
        } catch (error) {
            console.error('Erreur marquage rappel:', error);
            throw error;
        }
    },

    async obtenirConfiguration() {
        try {
            const configResponse = await trickleListObjects('config_rappels', 1, true);
            if (configResponse.items.length > 0) {
                return configResponse.items[0].objectData;
            }
            return null;
        } catch (error) {
            return null;
        }
    },

    async sauvegarderConfiguration(config) {
        try {
            // Vérifier si une configuration existe
            const configExistante = await this.obtenirConfiguration();
            
            if (configExistante) {
                const configResponse = await trickleListObjects('config_rappels', 1, true);
                await trickleUpdateObject('config_rappels', configResponse.items[0].objectId, config);
            } else {
                await trickleCreateObject('config_rappels', config);
            }
            
            return true;
        } catch (error) {
            console.error('Erreur sauvegarde configuration:', error);
            throw error;
        }
    }
};

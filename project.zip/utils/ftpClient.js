// Client FTP côté navigateur pour test de connexion
const FTPClient = {
    // Test de connexion FTP via WebSocket ou fetch avec proxy
    testConnection: async (config) => {
        try {
            // Méthode 1: Test via telnet simulation
            const result = await FTPClient.testTelnet(config);
            return result;
        } catch (error) {
            console.error('Erreur test FTP:', error);
            return {
                success: false,
                message: error.message
            };
        }
    },

    // Simulation test telnet pour vérifier connectivité
    testTelnet: async (config) => {
        return new Promise((resolve) => {
            const timeout = setTimeout(() => {
                resolve({
                    success: false,
                    message: 'Timeout de connexion'
                });
            }, 10000);

            // Créer une image pour tester la connectivité
            const img = new Image();
            const startTime = Date.now();
            
            img.onload = () => {
                clearTimeout(timeout);
                resolve({
                    success: true,
                    message: 'Serveur accessible',
                    responseTime: Date.now() - startTime
                });
            };
            
            img.onerror = () => {
                clearTimeout(timeout);
                // Test alternatif avec fetch
                FTPClient.testWithFetch(config).then(resolve);
            };
            
            // Tenter connexion via image (contournement CORS)
            img.src = `http://${config.host}:${config.port || 21}/favicon.ico?t=${Date.now()}`;
        });
    },

    // Test avec fetch et gestion CORS
    testWithFetch: async (config) => {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);
            
            const response = await fetch(`http://${config.host}:${config.port || 21}`, {
                method: 'HEAD',
                mode: 'no-cors',
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            return {
                success: true,
                message: 'Serveur FTP accessible',
                details: 'Test de connectivité réussi'
            };
        } catch (error) {
            if (error.name === 'AbortError') {
                return {
                    success: false,
                    message: 'Timeout - Serveur non accessible'
                };
            }
            return {
                success: true, // En mode no-cors, l'erreur peut indiquer que le serveur existe
                message: 'Serveur probablement accessible (CORS bloqué)',
                details: 'Le serveur semble répondre mais CORS bloque la requête'
            };
        }
    },

    // Validation des paramètres FTP
    validateConfig: (config) => {
        const errors = [];
        
        // Utiliser 'server' au lieu de 'host' pour correspondre au formulaire
        const host = config.host || config.server;
        if (!host || host.trim() === '') {
            errors.push('Adresse serveur requise');
        }
        
        if (!config.username || config.username.trim() === '') {
            errors.push('Nom d\'utilisateur requis');
        }
        
        if (!config.password || config.password.trim() === '') {
            errors.push('Mot de passe requis');
        }
        
        const port = parseInt(config.port);
        if (isNaN(port) || port < 1 || port > 65535) {
            errors.push('Port invalide (1-65535)');
        }
        
        return {
            valid: errors.length === 0,
            errors: errors
        };
    }
};
const EmailNotifications = {
    // Configuration email
    config: {
        smtpServer: 'localhost',
        smtpPort: 587,
        username: 'admin@entreprise.com',
        password: 'password'
    },

    // Envoyer notification d'approbation
    async sendApprovalNotification(conge, manager) {
        try {
            const employee = await trickleGetObject('personnel', conge.objectData.employeId);
            
            const emailData = {
                to: employee.objectData.email,
                subject: '✅ Demande de congé approuvée',
                body: this.generateApprovalEmail(conge, manager, employee)
            };

            await this.sendEmail(emailData);
            
            // Enregistrer la notification
            await trickleCreateObject('notification_email', {
                type: 'conge_approuve',
                destinataire: employee.objectData.email,
                congeId: conge.objectId,
                datEnvoi: new Date().toISOString(),
                status: 'envoye'
            });

        } catch (error) {
            console.error('Erreur envoi email approbation:', error);
        }
    },

    // Envoyer notification de refus
    async sendRejectionNotification(conge, manager, motif) {
        try {
            const employee = await trickleGetObject('personnel', conge.objectData.employeId);
            
            const emailData = {
                to: employee.objectData.email,
                subject: '❌ Demande de congé refusée',
                body: this.generateRejectionEmail(conge, manager, employee, motif)
            };

            await this.sendEmail(emailData);
            
            await trickleCreateObject('notification_email', {
                type: 'conge_refuse',
                destinataire: employee.objectData.email,
                congeId: conge.objectId,
                motifRefus: motif,
                datEnvoi: new Date().toISOString(),
                status: 'envoye'
            });

        } catch (error) {
            console.error('Erreur envoi email refus:', error);
        }
    },

    // Envoyer notification nouvelle demande aux managers
    async sendNewRequestNotification(conge) {
        try {
            const managersResult = await trickleListObjects('personnel', 100, true);
            const managers = managersResult.items.filter(p => 
                p.objectData.role === 'manager' && 
                p.objectData.departement === conge.objectData.departement
            );

            for (const manager of managers) {
                const emailData = {
                    to: manager.objectData.email,
                    subject: '📋 Nouvelle demande de congé',
                    body: this.generateNewRequestEmail(conge, manager)
                };

                await this.sendEmail(emailData);
            }

        } catch (error) {
            console.error('Erreur notification managers:', error);
        }
    },

    // Générer email d'approbation
    generateApprovalEmail(conge, manager, employee) {
        return `
Bonjour ${employee.objectData.prenom},

Votre demande de congé a été approuvée par ${manager.nom}.

Détails de la demande :
- Type : ${conge.objectData.type}
- Période : du ${conge.objectData.dateDebut} au ${conge.objectData.dateFin}
- Nombre de jours : ${conge.objectData.nombreJours}

Bon congé !

L'équipe RH
        `.trim();
    },

    // Générer email de refus
    generateRejectionEmail(conge, manager, employee, motif) {
        return `
Bonjour ${employee.objectData.prenom},

Votre demande de congé a été refusée par ${manager.nom}.

Détails de la demande :
- Type : ${conge.objectData.type}
- Période : du ${conge.objectData.dateDebut} au ${conge.objectData.dateFin}
- Motif du refus : ${motif}

N'hésitez pas à contacter votre manager pour plus d'informations.

L'équipe RH
        `.trim();
    },

    // Générer email nouvelle demande
    generateNewRequestEmail(conge, manager) {
        return `
Bonjour ${manager.objectData.prenom},

Une nouvelle demande de congé nécessite votre attention.

Employé : ${conge.objectData.prenom} ${conge.objectData.nom}
Type : ${conge.objectData.type}
Période : du ${conge.objectData.dateDebut} au ${conge.objectData.dateFin}

Connectez-vous au système pour traiter cette demande.

Le système RH
        `.trim();
    },

    // Notification remplaçant
    async sendReplacementNotification(conge, remplacant, taches) {
        try {
            const emailData = {
                to: remplacant.objectData.email,
                subject: '🔄 Assignation de remplacement',
                body: this.generateReplacementEmail(conge, remplacant, taches)
            };

            await this.sendEmail(emailData);
            
        } catch (error) {
            console.error('Erreur notification remplacement:', error);
        }
    },

    // Générer email remplacement
    generateReplacementEmail(conge, remplacant, taches) {
        return `
Bonjour ${remplacant.objectData.prenom},

Vous avez été assigné(e) comme remplaçant(e) pour ${conge.objectData.prenom} ${conge.objectData.nom}.

Période de remplacement : du ${conge.objectData.dateDebut} au ${conge.objectData.dateFin}

Tâches à effectuer :
${taches}

Merci de votre collaboration.

L'équipe RH
        `.trim();
    },

    // Envoyer email via API
    async sendEmail(emailData) {
        try {
            const response = await fetch('/api/send-email.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(emailData)
            });

            if (!response.ok) {
                throw new Error('Erreur envoi email');
            }

            return await response.json();
        } catch (error) {
            console.error('Erreur API email:', error);
            throw error;
        }
    }
};

window.EmailNotifications = EmailNotifications;
const EmailAlerts = {
    // Vérifier les demandes urgentes et en retard
    async checkUrgentRequests() {
        try {
            const result = await trickleListObjects('conge', 200, true);
            const demandesEnAttente = result.items.filter(d => 
                d.objectData.status === 'en_attente'
            );

            for (const demande of demandesEnAttente) {
                if (this.isUrgent(demande)) {
                    await this.sendUrgentAlert(demande);
                }
                if (this.isOverdue(demande)) {
                    await this.sendOverdueAlert(demande);
                }
            }
        } catch (error) {
            console.error('Erreur vérification demandes urgentes:', error);
        }
    },

    isUrgent(demande) {
        const dateDebut = new Date(demande.objectData.dateDebut);
        const maintenant = new Date();
        const joursAvantDebut = Math.ceil((dateDebut - maintenant) / (1000 * 60 * 60 * 24));
        return joursAvantDebut <= 3 && joursAvantDebut > 0;
    },

    isOverdue(demande) {
        const dateCreation = new Date(demande.objectData.dateCreation);
        const maintenant = new Date();
        const joursDepuisCreation = Math.ceil((maintenant - dateCreation) / (1000 * 60 * 60 * 24));
        return joursDepuisCreation > 5;
    },

    async sendUrgentAlert(demande) {
        try {
            const superieur = await trickleGetObject('personnel', demande.objectData.superieurId);
            
            const emailData = {
                to: superieur.objectData.email,
                subject: `URGENT: Demande de congé à valider - ${demande.objectData.prenom} ${demande.objectData.nom}`,
                body: `
                    Bonjour ${superieur.objectData.prenom},
                    
                    Une demande de congé urgente nécessite votre validation:
                    
                    Employé: ${demande.objectData.prenom} ${demande.objectData.nom}
                    Type: ${demande.objectData.type}
                    Période: Du ${demande.objectData.dateDebut} au ${demande.objectData.dateFin}
                    Début dans: ${Math.ceil((new Date(demande.objectData.dateDebut) - new Date()) / (1000 * 60 * 60 * 24))} jours
                    
                    Veuillez vous connecter au système pour traiter cette demande.
                    
                    Cordialement,
                    Système de Gestion Administrative
                `
            };

            await this.sendEmail(emailData);
        } catch (error) {
            console.error('Erreur envoi alerte urgente:', error);
        }
    },

    async sendOverdueAlert(demande) {
        try {
            const superieur = await trickleGetObject('personnel', demande.objectData.superieurId);
            
            const emailData = {
                to: superieur.objectData.email,
                subject: `RAPPEL: Demande de congé en retard - ${demande.objectData.prenom} ${demande.objectData.nom}`,
                body: `
                    Bonjour ${superieur.objectData.prenom},
                    
                    Une demande de congé est en attente depuis plus de 5 jours:
                    
                    Employé: ${demande.objectData.prenom} ${demande.objectData.nom}
                    Type: ${demande.objectData.type}
                    Période: Du ${demande.objectData.dateDebut} au ${demande.objectData.dateFin}
                    Soumise le: ${new Date(demande.objectData.dateCreation).toLocaleDateString()}
                    
                    Veuillez traiter cette demande dans les plus brefs délais.
                    
                    Cordialement,
                    Système de Gestion Administrative
                `
            };

            await this.sendEmail(emailData);
        } catch (error) {
            console.error('Erreur envoi alerte retard:', error);
        }
    },

    async sendEmail(emailData) {
        // Simulation d'envoi d'email - à remplacer par vraie API
        console.log('Envoi email:', emailData);
        
        // Créer notification système
        await trickleCreateObject('email_log', {
            destinataire: emailData.to,
            sujet: emailData.subject,
            contenu: emailData.body,
            dateEnvoi: new Date().toISOString(),
            statut: 'envoye'
        });
    },

    // Démarrer la surveillance automatique
    startMonitoring() {
        if (this.monitoringStarted) return; // Éviter les doublons
        this.monitoringStarted = true;
        
        console.log('Démarrage du système de surveillance des alertes email');
        
        // Vérifier toutes les 30 minutes (pour les tests)
        this.intervalId = setInterval(() => {
            this.checkUrgentRequests();
        }, 30 * 60 * 1000);
        
        // Première vérification après 5 secondes
        setTimeout(() => {
            this.checkUrgentRequests();
        }, 5000);
    },

    // Arrêter la surveillance
    stopMonitoring() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
            this.monitoringStarted = false;
            console.log('Arrêt du système de surveillance des alertes email');
        }
    }
};

window.EmailAlerts = EmailAlerts;
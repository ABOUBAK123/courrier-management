// Gestionnaire de cache local pour les documents PDF
class CacheManager {
    constructor() {
        this.cache = new Map();
        this.maxCacheSize = 50 * 1024 * 1024; // 50MB
        this.currentCacheSize = 0;
        this.cacheStats = {
            hits: 0,
            misses: 0,
            evictions: 0
        };
    }

    // Générer une clé de cache basée sur l'URL du document
    generateCacheKey(documentUrl) {
        return btoa(documentUrl).replace(/[^a-zA-Z0-9]/g, '');
    }

    // Vérifier si un document est en cache
    has(documentUrl) {
        const key = this.generateCacheKey(documentUrl);
        return this.cache.has(key);
    }

    // Récupérer un document du cache
    get(documentUrl) {
        const key = this.generateCacheKey(documentUrl);
        if (this.cache.has(key)) {
            const item = this.cache.get(key);
            // Vérifier l'expiration (24h par défaut)
            if (Date.now() - item.timestamp < 24 * 60 * 60 * 1000) {
                this.cacheStats.hits++;
                item.lastAccess = Date.now();
                return item.data;
            } else {
                this.cache.delete(key);
                this.currentCacheSize -= item.size;
            }
        }
        this.cacheStats.misses++;
        return null;
    }

    // Ajouter un document au cache
    set(documentUrl, data) {
        const key = this.generateCacheKey(documentUrl);
        const size = this.calculateSize(data);
        
        // Vérifier si on peut ajouter au cache
        if (size > this.maxCacheSize) {
            console.warn('Document trop volumineux pour le cache:', documentUrl);
            return false;
        }

        // Libérer de l'espace si nécessaire
        this.ensureSpace(size);

        const item = {
            data: data,
            size: size,
            timestamp: Date.now(),
            lastAccess: Date.now(),
            url: documentUrl
        };

        this.cache.set(key, item);
        this.currentCacheSize += size;
        return true;
    }

    // Calculer la taille approximative des données
    calculateSize(data) {
        if (typeof data === 'string') {
            return data.length * 2; // UTF-16
        }
        return JSON.stringify(data).length * 2;
    }

    // Libérer de l'espace dans le cache
    ensureSpace(neededSize) {
        while (this.currentCacheSize + neededSize > this.maxCacheSize && this.cache.size > 0) {
            // Supprimer l'élément le moins récemment utilisé
            let oldestKey = null;
            let oldestTime = Date.now();

            for (const [key, item] of this.cache.entries()) {
                if (item.lastAccess < oldestTime) {
                    oldestTime = item.lastAccess;
                    oldestKey = key;
                }
            }

            if (oldestKey) {
                const item = this.cache.get(oldestKey);
                this.cache.delete(oldestKey);
                this.currentCacheSize -= item.size;
                this.cacheStats.evictions++;
            }
        }
    }

    // Vider le cache
    clear() {
        this.cache.clear();
        this.currentCacheSize = 0;
        this.cacheStats = { hits: 0, misses: 0, evictions: 0 };
    }

    // Obtenir les statistiques du cache
    getStats() {
        return {
            ...this.cacheStats,
            size: this.cache.size,
            currentCacheSize: this.currentCacheSize,
            maxCacheSize: this.maxCacheSize,
            hitRate: this.cacheStats.hits / (this.cacheStats.hits + this.cacheStats.misses) || 0
        };
    }

    // Nettoyer les éléments expirés
    cleanup() {
        const now = Date.now();
        const maxAge = 24 * 60 * 60 * 1000; // 24h

        for (const [key, item] of this.cache.entries()) {
            if (now - item.timestamp > maxAge) {
                this.cache.delete(key);
                this.currentCacheSize -= item.size;
            }
        }
    }
}

// Instance globale du gestionnaire de cache
window.cacheManager = new CacheManager();

// Nettoyage automatique toutes les heures
setInterval(() => {
    window.cacheManager.cleanup();
}, 60 * 60 * 1000);
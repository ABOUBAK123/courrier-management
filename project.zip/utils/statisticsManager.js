// Gestionnaire de statistiques et rapports
const StatisticsManager = {
    // Calcul des statistiques générales
    calculateGeneralStats: function(mails) {
        try {
            const now = new Date();
            const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const thisWeek = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
            const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);

            const stats = {
                total: mails.length,
                today: 0,
                thisWeek: 0,
                thisMonth: 0,
                enAttente: 0,
                enTraitement: 0,
                traites: 0,
                enRetard: 0,
                urgent: 0,
                normal: 0,
                faible: 0
            };

            mails.forEach(mail => {
                const mailDate = new Date(mail.dateReception);
                
                // Statistiques par période
                if (mailDate >= today) stats.today++;
                if (mailDate >= thisWeek) stats.thisWeek++;
                if (mailDate >= thisMonth) stats.thisMonth++;

                // Statistiques par statut
                switch (mail.statut) {
                    case 'en_attente': stats.enAttente++; break;
                    case 'en_traitement': stats.enTraitement++; break;
                    case 'traite': stats.traites++; break;
                }

                // Statistiques par priorité
                switch (mail.priorite) {
                    case 'urgent': stats.urgent++; break;
                    case 'normal': stats.normal++; break;
                    case 'faible': stats.faible++; break;
                }

                // Courriers en retard
                if (mail.dateLimite && new Date(mail.dateLimite) < now && mail.statut !== 'traite') {
                    stats.enRetard++;
                }
            });

            return stats;
        } catch (error) {
            console.error('Erreur calcul statistiques générales:', error);
            return {};
        }
    },

    // Statistiques par direction
    calculateDirectionStats: function(mails, directions) {
        try {
            const directionStats = {};
            
            directions.forEach(direction => {
                directionStats[direction.id] = {
                    nom: direction.nom,
                    total: 0,
                    enAttente: 0,
                    enTraitement: 0,
                    traites: 0,
                    enRetard: 0,
                    tempsTraitementMoyen: 0
                };
            });

            mails.forEach(mail => {
                if (mail.directionId && directionStats[mail.directionId]) {
                    const stat = directionStats[mail.directionId];
                    stat.total++;
                    
                    switch (mail.statut) {
                        case 'en_attente': stat.enAttente++; break;
                        case 'en_traitement': stat.enTraitement++; break;
                        case 'traite': stat.traites++; break;
                    }

                    if (mail.dateLimite && new Date(mail.dateLimite) < new Date() && mail.statut !== 'traite') {
                        stat.enRetard++;
                    }
                }
            });

            return directionStats;
        } catch (error) {
            console.error('Erreur calcul statistiques directions:', error);
            return {};
        }
    },

    // Statistiques de performance du personnel
    calculatePersonnelStats: function(mails, personnel) {
        try {
            const personnelStats = {};
            
            personnel.forEach(person => {
                personnelStats[person.id] = {
                    nom: `${person.prenom} ${person.nom}`,
                    total: 0,
                    traites: 0,
                    enCours: 0,
                    enRetard: 0,
                    tempsTraitementMoyen: 0,
                    tauxTraitement: 0
                };
            });

            mails.forEach(mail => {
                if (mail.assigneId && personnelStats[mail.assigneId]) {
                    const stat = personnelStats[mail.assigneId];
                    stat.total++;
                    
                    if (mail.statut === 'traite') {
                        stat.traites++;
                    } else {
                        stat.enCours++;
                    }

                    if (mail.dateLimite && new Date(mail.dateLimite) < new Date() && mail.statut !== 'traite') {
                        stat.enRetard++;
                    }
                }
            });

            // Calcul du taux de traitement
            Object.keys(personnelStats).forEach(id => {
                const stat = personnelStats[id];
                stat.tauxTraitement = stat.total > 0 ? Math.round((stat.traites / stat.total) * 100) : 0;
            });

            return personnelStats;
        } catch (error) {
            console.error('Erreur calcul statistiques personnel:', error);
            return {};
        }
    },

    // Données pour graphiques temporels
    getTimeSeriesData: function(mails, period = 'month') {
        try {
            const data = {};
            const now = new Date();
            
            // Définir la plage de dates selon la période
            let startDate, dateFormat;
            switch (period) {
                case 'week':
                    startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    dateFormat = 'DD/MM';
                    break;
                case 'month':
                    startDate = new Date(now.getFullYear(), now.getMonth(), 1);
                    dateFormat = 'DD/MM';
                    break;
                case 'year':
                    startDate = new Date(now.getFullYear(), 0, 1);
                    dateFormat = 'MM/YYYY';
                    break;
                default:
                    startDate = new Date(now.getFullYear(), now.getMonth(), 1);
                    dateFormat = 'DD/MM';
            }

            mails.forEach(mail => {
                const mailDate = new Date(mail.dateReception);
                if (mailDate >= startDate) {
                    const dateKey = this.formatDate(mailDate, dateFormat);
                    
                    if (!data[dateKey]) {
                        data[dateKey] = {
                            date: dateKey,
                            recus: 0,
                            traites: 0,
                            enRetard: 0
                        };
                    }
                    
                    data[dateKey].recus++;
                    if (mail.statut === 'traite') data[dateKey].traites++;
                    if (mail.dateLimite && new Date(mail.dateLimite) < now && mail.statut !== 'traite') {
                        data[dateKey].enRetard++;
                    }
                }
            });

            return Object.values(data).sort((a, b) => new Date(a.date) - new Date(b.date));
        } catch (error) {
            console.error('Erreur génération données temporelles:', error);
            return [];
        }
    },

    // Formatage de date
    formatDate: function(date, format) {
        try {
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const year = date.getFullYear();
            
            switch (format) {
                case 'DD/MM': return `${day}/${month}`;
                case 'MM/YYYY': return `${month}/${year}`;
                default: return `${day}/${month}/${year}`;
            }
        } catch (error) {
            console.error('Erreur formatage date:', error);
            return '';
        }
    },

    // Génération de rapport complet
    generateReport: function(mails, directions, personnel, period = 'month') {
        try {
            return {
                generatedAt: new Date().toISOString(),
                period: period,
                generalStats: this.calculateGeneralStats(mails),
                directionStats: this.calculateDirectionStats(mails, directions),
                personnelStats: this.calculatePersonnelStats(mails, personnel),
                timeSeriesData: this.getTimeSeriesData(mails, period),
                summary: {
                    totalMails: mails.length,
                    activeDirections: Object.keys(this.calculateDirectionStats(mails, directions)).length,
                    activePersonnel: Object.keys(this.calculatePersonnelStats(mails, personnel)).length
                }
            };
        } catch (error) {
            console.error('Erreur génération rapport:', error);
            return null;
        }
    }
};
// Utilitaires pour le scanner OCR

function getFieldLabel(fieldKey, mailType) {
    const labels = {
        arrive: {
            objet: 'Objet du courrier',
            expediteur: 'Expéditeur',
            reference: 'Numéro d\'émission',
            type: 'Type de document',
            priorite: 'Priorité'
        },
        depart: {
            objet: 'Objet du courrier',
            destinataire: 'Destinataire',
            reference: 'Numéro de référence',
            type: 'Type de document',
            priorite: 'Priorité'
        }
    };
    
    return labels[mailType]?.[fieldKey] || fieldKey.charAt(0).toUpperCase() + fieldKey.slice(1);
}

function extractMetadataFromText(text, mailType) {
    // Simulation d'extraction OCR intelligente
    const lines = text.split('\n');
    const extracted = {};
    
    // Recherche de patterns communs
    lines.forEach(line => {
        const lowerLine = line.toLowerCase();
        
        // Objet
        if (lowerLine.includes('objet:') || lowerLine.includes('sujet:')) {
            extracted.objet = line.split(':')[1]?.trim();
        }
        
        // Expéditeur/Destinataire
        if (mailType === 'arrive') {
            if (lowerLine.includes('expéditeur:') || lowerLine.includes('de:')) {
                extracted.expediteur = line.split(':')[1]?.trim();
            }
        } else {
            if (lowerLine.includes('destinataire:') || lowerLine.includes('à:')) {
                extracted.destinataire = line.split(':')[1]?.trim();
            }
        }
        
        // Référence
        if (lowerLine.includes('référence:') || lowerLine.includes('ref:') || lowerLine.includes('n°:')) {
            extracted.reference = line.split(':')[1]?.trim();
        }
        
        // Priorité
        if (lowerLine.includes('urgent')) {
            extracted.priorite = 'Urgent';
        } else if (lowerLine.includes('normal')) {
            extracted.priorite = 'Normal';
        }
    });
    
    return extracted;
}

function generateMockOCRText(mailType) {
    if (mailType === 'arrive') {
        return `MINISTÈRE DE L'INTÉRIEUR
Direction Générale des Collectivités Locales

Expéditeur: Commune de Casablanca
Objet: Demande d'autorisation de travaux
Date: ${new Date().toLocaleDateString()}
Référence: DGC-2024-001
Priorité: Normal

Monsieur le Directeur,

J'ai l'honneur de vous demander l'autorisation pour les travaux de rénovation...`;
    } else {
        return `MINISTÈRE DE L'INTÉRIEUR
Direction Générale des Collectivités Locales

Destinataire: Commune de Casablanca
Objet: Réponse à votre demande d'autorisation
Date: ${new Date().toLocaleDateString()}
Référence: REP-DGC-2024-001
Priorité: Normal

Monsieur le Maire,

Suite à votre courrier en date du... nous avons l'honneur de vous informer...`;
    }
}
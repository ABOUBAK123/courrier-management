// Gestionnaire de chargement de documents avec cache et stockage local
window.documentLoader = {
    cache: new Map(),
    maxCacheSize: 50,
    cacheHits: 0,
    cacheMisses: 0,

    // Initialiser le gestionnaire
    init: function() {
        console.log('📄 DocumentLoader initialisé');
        this.cleanupCache();
    },

    // Charger un document depuis localStorage ou URL
    loadDocument: async function(documentUrl) {
        try {
            if (!documentUrl) {
                throw new Error('URL du document manquante');
            }

            // Si c'est un fichier local (ID de fichier)
            if (documentUrl.startsWith('file_')) {
                return this.loadLocalFile(documentUrl);
            }

            return await this.fetchDocument(documentUrl);

        } catch (error) {
            console.error('❌ Erreur chargement document:', error);
            throw error;
        }
    },

    // Charger un fichier depuis localStorage
    loadLocalFile: function(fileId) {
        try {
            const fileData = localStorage.getItem(`mail_file_${fileId}`);
            if (!fileData) {
                throw new Error('Fichier non trouvé');
            }

            const parsedData = JSON.parse(fileData);
            console.log('📄 Fichier local chargé:', parsedData.name);
            return parsedData.data;

        } catch (error) {
            console.error('❌ Erreur fichier local:', error);
            throw error;
        }
    },

    // Récupérer document depuis serveur
    fetchDocument: async function(documentUrl) {
        if (documentUrl.startsWith('data:')) {
            return documentUrl;
        }

        try {
            const response = await fetch(documentUrl, {
                method: 'GET',
                mode: 'cors',
                credentials: 'include'
            });

            if (response.ok) {
                const blob = await response.blob();
                return URL.createObjectURL(blob);
            }

            throw new Error(`Erreur HTTP ${response.status}`);

        } catch (error) {
            console.warn('Erreur fetch:', error);
            throw error;
        }
    },

    // Nettoyer le cache
    cleanupCache: function() {
        if (this.cache.size > this.maxCacheSize) {
            const entries = Array.from(this.cache.entries());
            entries.sort((a, b) => a[1].timestamp - b[1].timestamp);
            
            for (let i = 0; i < 10; i++) {
                const [key, value] = entries[i];
                if (value.url && value.url.startsWith('blob:')) {
                    URL.revokeObjectURL(value.url);
                }
                this.cache.delete(key);
            }
        }
    }
};

// Initialiser au chargement
if (typeof window !== 'undefined') {
    window.documentLoader.init();
}
window.workflowConges = {
    async determinerValidateurs(demandeId, typeConge, dureeJours, utilisateurId) {
        const validateurs = [];
        
        // Récupérer la hiérarchie de l'utilisateur
        const hierarchie = await this.obtenirHierarchie(utilisateurId);
        
        // N+1 (supérieur direct)
        if (typeConge.validationN1 && hierarchie.n1) {
            validateurs.push({ niveau: 1, userId: hierarchie.n1, type: 'N1' });
        }
        
        // N+2 si durée dépasse le seuil
        if (typeConge.validationN2 && dureeJours >= typeConge.seuilValidationN2 && hierarchie.n2) {
            validateurs.push({ niveau: 2, userId: hierarchie.n2, type: 'N2' });
        }
        
        // DRH pour certains types
        if (typeConge.validationDRH) {
            const drh = await this.obtenirDRH();
            if (drh) {
                validateurs.push({ niveau: 3, userId: drh.id, type: 'DRH' });
            }
        }
        
        return validateurs;
    },

    async obtenirHierarchie(utilisateurId) {
        try {
            const response = await fetch(`api/personnel.php?action=getHierarchie&userId=${utilisateurId}`);
            return response.ok ? await response.json() : {};
        } catch (error) {
            console.error('Erreur hiérarchie:', error);
            return {};
        }
    },

    async obtenirDRH() {
        try {
            const response = await fetch('api/personnel.php?action=getDRH');
            return response.ok ? await response.json() : null;
        } catch (error) {
            console.error('Erreur DRH:', error);
            return null;
        }
    },

    async verifierConflits(dateDebut, dateFin, equipeId) {
        try {
            const response = await fetch('api/conges.php?action=verifierConflits', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ dateDebut, dateFin, equipeId })
            });
            return response.ok ? await response.json() : [];
        } catch (error) {
            console.error('Erreur vérification conflits:', error);
            return [];
        }
    }
};
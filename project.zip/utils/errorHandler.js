// Gestionnaire d'erreurs global
let errorCount = 0;
const maxErrors = 10;
const errorCooldown = 60000; // 1 minute
let lastErrorTime = 0;

function reportError(error, context = '') {
    const now = Date.now();
    
    // Éviter le spam d'erreurs
    if (now - lastErrorTime < 1000) return;
    lastErrorTime = now;
    
    errorCount++;
    
    // Log simplifié
    if (errorCount <= maxErrors) {
        console.error(`[${context}] Erreur:`, error.message || error);
    }
    
    // Reset du compteur après cooldown
    if (errorCount === 1) {
        setTimeout(() => {
            errorCount = 0;
        }, errorCooldown);
    }
}

// Gestionnaire pour les erreurs de rate limit
function handleRateLimit(error, fallbackData = null) {
    if (error.message && error.message.includes('Rate limit')) {
        console.warn('Rate limit atteint, utilisation des données de fallback');
        return fallbackData;
    }
    throw error;
}

// Cache simple pour éviter les appels répétés
const cache = new Map();

function getCachedData(key, ttl = 30000) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < ttl) {
        return cached.data;
    }
    return null;
}

function setCachedData(key, data) {
    cache.set(key, {
        data: data,
        timestamp: Date.now()
    });
}

// Nettoyage périodique du cache
setInterval(() => {
    const now = Date.now();
    for (const [key, value] of cache.entries()) {
        if (now - value.timestamp > 300000) { // 5 minutes
            cache.delete(key);
        }
    }
}, 60000); // Nettoyage chaque minute
const WorkflowManager = {
    // Configuration des niveaux de validation selon le type de congé
    getValidationLevels: (typeConge, duree) => {
        const config = {
            'annuel': duree > 5 ? ['superviseur', 'directeur', 'rh'] : ['superviseur', 'rh'],
            'maladie': duree > 3 ? ['superviseur', 'rh'] : ['superviseur'],
            'maternite': ['superviseur', 'directeur', 'rh'],
            'paternite': ['superviseur', 'rh'],
            'exceptionnel': ['superviseur', 'directeur', 'rh']
        };
        return config[typeConge] || ['superviseur'];
    },

    // Calculer la durée en jours
    calculateDuration: (dateDebut, dateFin) => {
        const debut = new Date(dateDebut);
        const fin = new Date(dateFin);
        return Math.ceil((fin - debut) / (1000 * 60 * 60 * 24)) + 1;
    },

    // Initier le processus de validation
    initiateValidation: async (demandeId, demandeData) => {
        try {
            const duree = WorkflowManager.calculateDuration(demandeData.dateDebut, demandeData.dateFin);
            const levels = WorkflowManager.getValidationLevels(demandeData.typeConge, duree);
            
            const workflow = {
                demandeId: demandeId,
                currentLevel: 0,
                levels: levels,
                validations: [],
                status: 'en_validation',
                createdAt: new Date().toISOString()
            };

            await trickleCreateObject('workflow-validation', workflow);
            
            // Envoyer notification au premier validateur
            await WorkflowManager.notifyNextValidator(workflow, demandeData);
            
            return workflow;
        } catch (error) {
            console.error('Erreur initiation workflow:', error);
            throw error;
        }
    },

    // Traiter une validation
    processValidation: async (workflowId, decision, validatorId, commentaire = '') => {
        try {
            const workflow = await trickleGetObject('workflow-validation', workflowId);
            const currentLevel = workflow.objectData.levels[workflow.objectData.currentLevel];
            
            const validation = {
                level: currentLevel,
                validatorId: validatorId,
                decision: decision,
                commentaire: commentaire,
                date: new Date().toISOString()
            };

            workflow.objectData.validations.push(validation);

            if (decision === 'rejete') {
                workflow.objectData.status = 'rejete';
                await trickleUpdateObject('workflow-validation', workflowId, workflow.objectData);
                await WorkflowManager.notifyRejection(workflow.objectData);
            } else if (workflow.objectData.currentLevel + 1 >= workflow.objectData.levels.length) {
                workflow.objectData.status = 'approuve';
                await trickleUpdateObject('workflow-validation', workflowId, workflow.objectData);
                await WorkflowManager.notifyApproval(workflow.objectData);
            } else {
                workflow.objectData.currentLevel++;
                await trickleUpdateObject('workflow-validation', workflowId, workflow.objectData);
                await WorkflowManager.notifyNextValidator(workflow.objectData);
            }

            return workflow.objectData;
        } catch (error) {
            console.error('Erreur traitement validation:', error);
            throw error;
        }
    },

    // Notifier le prochain validateur
    notifyNextValidator: async (workflow, demandeData = null) => {
        try {
            if (!demandeData) {
                const demande = await trickleGetObject('conge', workflow.demandeId);
                demandeData = demande.objectData;
            }

            const currentLevel = workflow.levels[workflow.currentLevel];
            const validators = await WorkflowManager.getValidators(currentLevel, demandeData.direction);
            
            for (const validator of validators) {
                await window.EmailNotifications.sendValidationRequest(validator, demandeData, workflow);
            }
        } catch (error) {
            console.error('Erreur notification validateur:', error);
        }
    },

    // Récupérer les validateurs selon le niveau
    getValidators: async (level, direction) => {
        try {
            const roleMap = {
                'superviseur': 'CHEF_SERVICE',
                'directeur': 'DIRECTEUR',
                'rh': 'RH'
            };

            const users = await trickleListObjects('utilisateur', 100, true);
            return users.items.filter(user => 
                user.objectData.role === roleMap[level] && 
                (!direction || user.objectData.direction === direction)
            ).map(user => user.objectData);
        } catch (error) {
            console.error('Erreur récupération validateurs:', error);
            return [];
        }
    },

    // Notifier l'approbation
    notifyApproval: async (workflow) => {
        try {
            const demande = await trickleGetObject('conge', workflow.demandeId);
            await window.EmailNotifications.sendApprovalNotification(demande.objectData, workflow);
        } catch (error) {
            console.error('Erreur notification approbation:', error);
        }
    },

    // Notifier le rejet
    notifyRejection: async (workflow) => {
        try {
            const demande = await trickleGetObject('conge', workflow.demandeId);
            await window.EmailNotifications.sendRejectionNotification(demande.objectData, workflow);
        } catch (error) {
            console.error('Erreur notification rejet:', error);
        }
    }
};

window.WorkflowManager = WorkflowManager;
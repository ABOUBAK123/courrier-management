function PlanificateurConges({ directionId }) {
    const [congesDirection, setCongesDirection] = React.useState([]);
    const [conflits, setConflits] = React.useState([]);
    const [suggestions, setSuggestions] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedPeriod, setSelectedPeriod] = React.useState('mois');

    React.useEffect(() => {
        chargerDonneesDirection();
    }, [directionId, selectedPeriod]);

    const chargerDonneesDirection = async () => {
        try {
            setLoading(true);
            
            // Récupérer tous les employés de la direction
            const personnelResult = await trickleListObjects('personnel', 100, true);
            const employes = personnelResult.items.filter(p => 
                p.objectData.direction === directionId
            );

            // Récupérer tous les congés de la direction
            const congesResult = await trickleListObjects('demande_conge', 200, true);
            const congesDir = congesResult.items.filter(c => {
                const employe = employes.find(e => e.objectId === c.objectData.employeId);
                return employe && (c.objectData.etat === 'en_attente' || c.objectData.etat === 'approuve_final');
            });

            // Enrichir avec les infos employés
            const congesEnrichis = congesDir.map(conge => {
                const employe = employes.find(e => e.objectId === conge.objectData.employeId);
                return {
                    ...conge,
                    employeInfo: employe.objectData
                };
            });

            setCongesDirection(congesEnrichis);
            analyserConflits(congesEnrichis);
            
        } catch (error) {
            console.error('Erreur chargement données direction:', error);
        } finally {
            setLoading(false);
        }
    };

    const analyserConflits = (conges) => {
        const conflitsDetectes = [];
        const suggestionsList = [];

        // Grouper par service/équipe
        const parService = conges.reduce((acc, conge) => {
            const service = conge.employeInfo.service || 'Non défini';
            if (!acc[service]) acc[service] = [];
            acc[service].push(conge);
            return acc;
        }, {});

        Object.entries(parService).forEach(([service, congesService]) => {
            // Détecter les chevauchements
            for (let i = 0; i < congesService.length; i++) {
                for (let j = i + 1; j < congesService.length; j++) {
                    const conge1 = congesService[i];
                    const conge2 = congesService[j];
                    
                    if (detecterChevauchement(conge1, conge2)) {
                        const conflit = {
                            id: `${conge1.objectId}-${conge2.objectId}`,
                            service: service,
                            employe1: conge1.employeInfo,
                            employe2: conge2.employeInfo,
                            conge1: conge1.objectData,
                            conge2: conge2.objectData,
                            type: 'chevauchement',
                            gravite: calculerGravite(conge1, conge2)
                        };
                        conflitsDetectes.push(conflit);
                        
                        // Générer suggestions
                        const suggestion = genererSuggestions(conflit);
                        if (suggestion) {
                            suggestionsList.push(suggestion);
                        }
                    }
                }
            }

            // Détecter surcharge d'équipe
            const surcharge = detecterSurcharge(congesService, service);
            if (surcharge) {
                conflitsDetectes.push(surcharge);
            }
        });

        setConflits(conflitsDetectes);
        setSuggestions(suggestionsList);
    };

    const detecterChevauchement = (conge1, conge2) => {
        const debut1 = new Date(conge1.objectData.dateDebut);
        const fin1 = new Date(conge1.objectData.dateFin);
        const debut2 = new Date(conge2.objectData.dateDebut);
        const fin2 = new Date(conge2.objectData.dateFin);

        return (debut1 <= fin2 && fin1 >= debut2);
    };

    const calculerGravite = (conge1, conge2) => {
        const totalJours = conge1.objectData.nombreJours + conge2.objectData.nombreJours;
        if (totalJours > 20) return 'critique';
        if (totalJours > 10) return 'haute';
        return 'moyenne';
    };

    const detecterSurcharge = (congesService, service) => {
        const totalEmployes = new Set(congesService.map(c => c.objectData.employeId)).size;
        const employesEnConge = congesService.filter(c => {
            const maintenant = new Date();
            const debut = new Date(c.objectData.dateDebut);
            const fin = new Date(c.objectData.dateFin);
            return debut <= maintenant && fin >= maintenant;
        }).length;

        const pourcentageAbsence = (employesEnConge / totalEmployes) * 100;
        
        if (pourcentageAbsence > 50) {
            return {
                id: `surcharge-${service}`,
                service: service,
                type: 'surcharge',
                pourcentage: pourcentageAbsence,
                gravite: pourcentageAbsence > 75 ? 'critique' : 'haute'
            };
        }
        return null;
    };

    const genererSuggestions = (conflit) => {
        return {
            id: conflit.id,
            type: 'decalage',
            description: 'Décaler l\'une des demandes de congé',
            actions: [
                {
                    label: `Décaler ${conflit.employe1.prenom} de 1 semaine`,
                    impact: 'Faible impact sur la planification'
                },
                {
                    label: `Décaler ${conflit.employe2.prenom} de 1 semaine`,
                    impact: 'Faible impact sur la planification'
                }
            ]
        };
    };

    if (loading) {
        return React.createElement('div', {
            className: 'flex justify-center items-center h-48'
        }, 'Chargement de la planification...');
    }

    return React.createElement('div', {
        className: 'bg-white rounded-lg shadow-md p-6',
        'data-name': 'planificateur-conges',
        'data-file': 'components/PlanificateurConges.js'
    }, [
        React.createElement('h3', {
            key: 'title',
            className: 'text-xl font-bold mb-4 flex items-center'
        }, [
            React.createElement('i', {
                key: 'icon',
                className: 'fas fa-calendar-alt mr-2 text-blue-600'
            }),
            'Planificateur de Congés - Détection de Conflits'
        ]),

        // Statistiques rapides
        React.createElement('div', {
            key: 'stats',
            className: 'grid grid-cols-3 gap-4 mb-6'
        }, [
            React.createElement('div', {
                key: 'total',
                className: 'bg-blue-50 p-4 rounded-lg text-center'
            }, [
                React.createElement('div', {
                    key: 'number',
                    className: 'text-2xl font-bold text-blue-600'
                }, congesDirection.length),
                React.createElement('div', {
                    key: 'label',
                    className: 'text-sm text-gray-600'
                }, 'Congés planifiés')
            ]),
            React.createElement('div', {
                key: 'conflicts',
                className: 'bg-red-50 p-4 rounded-lg text-center'
            }, [
                React.createElement('div', {
                    key: 'number',
                    className: 'text-2xl font-bold text-red-600'
                }, conflits.length),
                React.createElement('div', {
                    key: 'label',
                    className: 'text-sm text-gray-600'
                }, 'Conflits détectés')
            ]),
            React.createElement('div', {
                key: 'suggestions',
                className: 'bg-green-50 p-4 rounded-lg text-center'
            }, [
                React.createElement('div', {
                    key: 'number',
                    className: 'text-2xl font-bold text-green-600'
                }, suggestions.length),
                React.createElement('div', {
                    key: 'label',
                    className: 'text-sm text-gray-600'
                }, 'Suggestions')
            ])
        ]),

        // Liste des conflits
        conflits.length > 0 && React.createElement('div', {
            key: 'conflicts-section',
            className: 'mb-6'
        }, [
            React.createElement('h4', {
                key: 'conflicts-title',
                className: 'text-lg font-semibold mb-3 text-red-600'
            }, '⚠️ Conflits Détectés'),
            React.createElement('div', {
                key: 'conflicts-list',
                className: 'space-y-3'
            }, conflits.map(conflit => 
                React.createElement('div', {
                    key: conflit.id,
                    className: `border-l-4 ${
                        conflit.gravite === 'critique' ? 'border-red-500 bg-red-50' :
                        conflit.gravite === 'haute' ? 'border-orange-500 bg-orange-50' :
                        'border-yellow-500 bg-yellow-50'
                    } p-4 rounded`
                }, [
                    React.createElement('div', {
                        key: 'conflict-header',
                        className: 'flex justify-between items-start'
                    }, [
                        React.createElement('div', {
                            key: 'info'
                        }, [
                            React.createElement('h5', {
                                key: 'service',
                                className: 'font-semibold'
                            }, `Service: ${conflit.service}`),
                            conflit.type === 'chevauchement' ? 
                                React.createElement('p', {
                                    key: 'description',
                                    className: 'text-sm text-gray-600'
                                }, `Conflit entre ${conflit.employe1.prenom} ${conflit.employe1.nom} et ${conflit.employe2.prenom} ${conflit.employe2.nom}`) :
                                React.createElement('p', {
                                    key: 'description',
                                    className: 'text-sm text-gray-600'
                                }, `Surcharge d'équipe: ${conflit.pourcentage.toFixed(1)}% d'absences`)
                        ]),
                        React.createElement('span', {
                            key: 'severity',
                            className: `px-2 py-1 rounded text-xs font-medium ${
                                conflit.gravite === 'critique' ? 'bg-red-100 text-red-800' :
                                conflit.gravite === 'haute' ? 'bg-orange-100 text-orange-800' :
                                'bg-yellow-100 text-yellow-800'
                            }`
                        }, conflit.gravite.toUpperCase())
                    ])
                ])
            ))
        ]),

        // Suggestions
        suggestions.length > 0 && React.createElement('div', {
            key: 'suggestions-section'
        }, [
            React.createElement('h4', {
                key: 'suggestions-title',
                className: 'text-lg font-semibold mb-3 text-green-600'
            }, '💡 Suggestions de Résolution'),
            React.createElement('div', {
                key: 'suggestions-list',
                className: 'space-y-3'
            }, suggestions.map(suggestion => 
                React.createElement('div', {
                    key: suggestion.id,
                    className: 'border border-green-200 bg-green-50 p-4 rounded'
                }, [
                    React.createElement('h5', {
                        key: 'suggestion-title',
                        className: 'font-semibold mb-2'
                    }, suggestion.description),
                    React.createElement('div', {
                        key: 'actions',
                        className: 'space-y-2'
                    }, suggestion.actions.map((action, index) => 
                        React.createElement('div', {
                            key: index,
                            className: 'flex justify-between items-center'
                        }, [
                            React.createElement('span', {
                                key: 'action-label',
                                className: 'text-sm'
                            }, action.label),
                            React.createElement('button', {
                                key: 'apply-btn',
                                className: 'bg-green-600 text-white px-3 py-1 rounded text-xs hover:bg-green-700'
                            }, 'Appliquer')
                        ])
                    ))
                ])
            ))
        ])
    ]);
}

window.PlanificateurConges = PlanificateurConges;
function ValidationPanel({ demande, onValidate, onReject }) {
    const [showRejectModal, setShowRejectModal] = React.useState(false);
    const [rejectReason, setRejectReason] = React.useState('');
    const [comment, setComment] = React.useState('');

    const handleApprove = () => {
        onValidate(demande.objectId, 'approuve', comment);
    };

    const handleReject = () => {
        if (rejectReason.trim()) {
            onReject(demande.objectId, 'refuse', rejectReason);
            setShowRejectModal(false);
            setRejectReason('');
        }
    };

    return React.createElement('div', {
        className: 'bg-white border rounded-lg p-4 shadow-sm',
        'data-name': 'validation-panel',
        'data-file': 'components/ValidationPanel.js'
    }, [
        React.createElement('div', {
            key: 'header',
            className: 'flex justify-between items-start mb-4'
        }, [
            React.createElement('div', { key: 'info' }, [
                React.createElement('h4', {
                    key: 'title',
                    className: 'font-semibold text-lg'
                }, `${demande.objectData.prenom} ${demande.objectData.nom}`),
                React.createElement('p', {
                    key: 'type',
                    className: 'text-gray-600'
                }, demande.objectData.type),
                React.createElement('p', {
                    key: 'dates',
                    className: 'text-sm text-gray-500'
                }, `Du ${demande.objectData.dateDebut} au ${demande.objectData.dateFin}`)
            ]),
            React.createElement('span', {
                key: 'status',
                className: 'bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-sm'
            }, 'En attente')
        ]),

        React.createElement('div', {
            key: 'comment-section',
            className: 'mb-4'
        }, [
            React.createElement('label', {
                key: 'label',
                className: 'block text-sm font-medium text-gray-700 mb-1'
            }, 'Commentaire (optionnel)'),
            React.createElement('textarea', {
                key: 'textarea',
                value: comment,
                onChange: (e) => setComment(e.target.value),
                className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                rows: 2,
                placeholder: 'Ajoutez un commentaire...'
            })
        ]),

        React.createElement('div', {
            key: 'actions',
            className: 'flex space-x-2'
        }, [
            React.createElement('button', {
                key: 'approve',
                onClick: handleApprove,
                className: 'bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700'
            }, 'Approuver'),
            React.createElement('button', {
                key: 'reject',
                onClick: () => setShowRejectModal(true),
                className: 'bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700'
            }, 'Refuser')
        ]),

        showRejectModal && React.createElement('div', {
            key: 'modal',
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
        }, React.createElement('div', {
            className: 'bg-white rounded-lg p-6 w-full max-w-md'
        }, [
            React.createElement('h3', {
                key: 'modal-title',
                className: 'text-lg font-semibold mb-4'
            }, 'Motif de refus'),
            React.createElement('textarea', {
                key: 'reason',
                value: rejectReason,
                onChange: (e) => setRejectReason(e.target.value),
                className: 'w-full px-3 py-2 border border-gray-300 rounded-md mb-4',
                rows: 3,
                placeholder: 'Expliquez le motif du refus...',
                required: true
            }),
            React.createElement('div', {
                key: 'modal-actions',
                className: 'flex justify-end space-x-2'
            }, [
                React.createElement('button', {
                    key: 'cancel',
                    onClick: () => setShowRejectModal(false),
                    className: 'px-4 py-2 text-gray-600 border border-gray-300 rounded'
                }, 'Annuler'),
                React.createElement('button', {
                    key: 'confirm',
                    onClick: handleReject,
                    className: 'px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700'
                }, 'Confirmer le refus')
            ])
        ]))
    ]);
}

window.ValidationPanel = ValidationPanel;
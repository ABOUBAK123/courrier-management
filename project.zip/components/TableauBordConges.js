function TableauBordConges({ user }) {
    const [stats, setStats] = React.useState({
        soldes: [], demandesEnCours: 0, prochainConge: null, equipeAbsente: []
    });

    React.useEffect(() => {
        chargerStatistiques();
    }, []);

    const chargerStatistiques = async () => {
        try {
            const response = await fetch(`api/conges.php?action=getTableauBord&userId=${user.id}`);
            if (response.ok) {
                const data = await response.json();
                setStats(data);
            }
        } catch (error) {
            console.error('Erreur chargement statistiques:', error);
        }
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Soldes */}
            <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-semibold mb-3">Mes Soldes</h3>
                <div className="space-y-2">
                    {stats.soldes.slice(0, 3).map((solde, index) => (
                        <div key={index} className="flex justify-between">
                            <span className="text-sm">{solde.type}</span>
                            <span className="font-medium">{solde.restant}j</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Demandes en cours */}
            <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-semibold mb-3">Demandes en cours</h3>
                <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{stats.demandesEnCours}</div>
                    <div className="text-sm text-gray-600">demande(s)</div>
                </div>
            </div>

            {/* Prochain congé */}
            <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-semibold mb-3">Prochain congé</h3>
                {stats.prochainConge ? (
                    <div>
                        <div className="font-medium">{stats.prochainConge.type}</div>
                        <div className="text-sm text-gray-600">{stats.prochainConge.date}</div>
                    </div>
                ) : (
                    <div className="text-gray-500 text-sm">Aucun congé prévu</div>
                )}
            </div>

            {/* Équipe absente */}
            <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-semibold mb-3">Équipe absente</h3>
                <div className="space-y-1">
                    {stats.equipeAbsente.slice(0, 3).map((absent, index) => (
                        <div key={index} className="text-sm">
                            {absent.nom} ({absent.type})
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

window.TableauBordConges = TableauBordConges;
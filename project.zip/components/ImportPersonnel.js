function ImportPersonnel({ user }) {
    try {
        const [uploading, setUploading] = React.useState(false);
        const [uploadResult, setUploadResult] = React.useState(null);
        const fileInputRef = React.useRef(null);

        const downloadTemplate = () => {
            // Créer un fichier CSV qui peut être ouvert dans Excel
            const headers = ['Matricule', 'Nom & Prénoms', 'Email', 'Poste', 'Grade'];
            const sampleData = [
                ['EMP001', 'ALAMI Mohammed', 'alami@ministere.gov.ma', 'Secrétaire', 'Échelle 10'],
                ['EMP002', 'BENNANI Fatima', 'bennani@ministere.gov.ma', 'Technicien', 'Échelle 9'],
                ['EMP003', 'CHRAIBI Ahmed', 'chraibi@ministere.gov.ma', 'Administrateur', 'Échelle 11']
            ];
            
            const csvContent = [headers, ...sampleData]
                .map(row => row.join(','))
                .join('\n');
            
            const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'modele_personnel.csv';
            link.click();
        };

        const parseCSVData = (text) => {
            const lines = text.split('\n').filter(line => line.trim());
            if (lines.length < 2) return [];
            
            const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
            const data = [];
            
            for (let i = 1; i < lines.length; i++) {
                const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
                if (values.length >= headers.length) {
                    data.push({
                        matricule: values[0],
                        nom: values[1],
                        email: values[2],
                        poste: values[3],
                        grade: values[4]
                    });
                }
            }
            return data;
        };

        const handleFileUpload = async (event) => {
            const file = event.target.files[0];
            if (!file) return;

            setUploading(true);
            setUploadResult(null);

            try {
                const text = await file.text();
                const parsedData = parseCSVData(text);
                
                // Validation des données
                const validationResults = validateImportData(parsedData);
                
                setUploadResult({
                    total: validationResults.totalRows,
                    success: validationResults.validRows,
                    errors: validationResults.invalidRows,
                    warnings: validationResults.warnings.length,
                    details: validationResults.errors,
                    warningDetails: validationResults.warnings,
                    summary: validationResults.summary,
                    fileName: file.name
                });
                
            } catch (error) {
                setUploadResult({
                    total: 0,
                    success: 0,
                    errors: 1,
                    details: [{ line: 0, message: 'Erreur de lecture du fichier: ' + error.message }]
                });
            }
            
            setUploading(false);
            
            // Réinitialiser l'input file
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
        };

        return React.createElement('div', {
            className: 'p-6',
            'data-name': 'import-personnel',
            'data-file': 'components/ImportPersonnel.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'mb-6'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-xl font-bold text-gray-800 mb-2'
                }, 'Import en Masse du Personnel'),
                React.createElement('p', {
                    key: 'description',
                    className: 'text-gray-600'
                }, 'Téléchargez le modèle Excel, remplissez-le avec les informations du personnel et importez-le pour créer les comptes agents automatiquement.')
            ]),

            React.createElement('div', {
                key: 'download-section',
                className: 'bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6'
            }, [
                React.createElement('h4', {
                    key: 'download-title',
                    className: 'text-lg font-semibold text-blue-800 mb-3'
                }, '📥 Étape 1: Télécharger le modèle'),
                React.createElement('p', {
                    key: 'download-desc',
                    className: 'text-blue-700 mb-4'
                }, 'Téléchargez le fichier modèle Excel avec les colonnes prédéfinies'),
                React.createElement('button', {
                    key: 'download-btn',
                    onClick: downloadTemplate,
                    className: 'bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 flex items-center'
                }, [
                    React.createElement('i', { key: 'download-icon', className: 'fas fa-download mr-2' }),
                    'Télécharger le modèle Excel'
                ])
            ]),

            React.createElement('div', {
                key: 'upload-section',
                className: 'bg-green-50 border border-green-200 rounded-lg p-6 mb-6'
            }, [
                React.createElement('h4', {
                    key: 'upload-title',
                    className: 'text-lg font-semibold text-green-800 mb-3'
                }, '📤 Étape 2: Importer le fichier rempli'),
                React.createElement('p', {
                    key: 'upload-desc',
                    className: 'text-green-700 mb-4'
                }, 'Sélectionnez votre fichier Excel rempli pour créer automatiquement les comptes agents'),
                
                React.createElement('input', {
                    key: 'file-input',
                    ref: fileInputRef,
                    type: 'file',
                    accept: '.csv,.xlsx,.xls',
                    onChange: handleFileUpload,
                    className: 'hidden'
                }),
                
                React.createElement('button', {
                    key: 'upload-btn',
                    onClick: () => fileInputRef.current?.click(),
                    disabled: uploading,
                    className: `px-6 py-3 rounded-lg flex items-center ${
                        uploading 
                            ? 'bg-gray-400 cursor-not-allowed text-white' 
                            : 'bg-green-600 hover:bg-green-700 text-white'
                    }`
                }, uploading ? [
                    React.createElement('i', { key: 'spinner', className: 'fas fa-spinner fa-spin mr-2' }),
                    'Import en cours...'
                ] : [
                    React.createElement('i', { key: 'upload-icon', className: 'fas fa-upload mr-2' }),
                    'Sélectionner et importer le fichier'
                ])
            ]),

            uploadResult && React.createElement('div', {
                key: 'results',
                className: 'bg-white border rounded-lg p-6'
            }, [
                React.createElement('h4', {
                    key: 'results-title',
                    className: 'text-lg font-semibold text-gray-800 mb-4'
                }, '📊 Résultats de l\'import'),
                
                React.createElement('div', {
                    key: 'file-info',
                    className: 'mb-4 p-3 bg-gray-50 rounded'
                }, [
                    React.createElement('span', {
                        key: 'file-name',
                        className: 'text-sm text-gray-600'
                    }, `📄 Fichier: ${uploadResult.fileName || 'N/A'}`),
                    uploadResult.summary && React.createElement('span', {
                        key: 'success-rate',
                        className: 'ml-4 text-sm font-medium text-blue-600'
                    }, `Taux de réussite: ${uploadResult.summary.successRate}%`)
                ]),

                React.createElement('div', {
                    key: 'summary',
                    className: 'grid grid-cols-4 gap-4 mb-4'
                }, [
                    React.createElement('div', {
                        key: 'total',
                        className: 'bg-blue-100 p-4 rounded text-center'
                    }, [
                        React.createElement('div', {
                            key: 'total-number',
                            className: 'text-2xl font-bold text-blue-600'
                        }, uploadResult.total),
                        React.createElement('div', {
                            key: 'total-label',
                            className: 'text-blue-800 text-sm'
                        }, 'Total lignes')
                    ]),
                    React.createElement('div', {
                        key: 'success',
                        className: 'bg-green-100 p-4 rounded text-center'
                    }, [
                        React.createElement('div', {
                            key: 'success-number',
                            className: 'text-2xl font-bold text-green-600'
                        }, uploadResult.success),
                        React.createElement('div', {
                            key: 'success-label',
                            className: 'text-green-800 text-sm'
                        }, 'Valides')
                    ]),
                    React.createElement('div', {
                        key: 'errors',
                        className: 'bg-red-100 p-4 rounded text-center'
                    }, [
                        React.createElement('div', {
                            key: 'errors-number',
                            className: 'text-2xl font-bold text-red-600'
                        }, uploadResult.errors),
                        React.createElement('div', {
                            key: 'errors-label',
                            className: 'text-red-800 text-sm'
                        }, 'Erreurs')
                    ]),
                    React.createElement('div', {
                        key: 'warnings',
                        className: 'bg-yellow-100 p-4 rounded text-center'
                    }, [
                        React.createElement('div', {
                            key: 'warnings-number',
                            className: 'text-2xl font-bold text-yellow-600'
                        }, uploadResult.warnings || 0),
                        React.createElement('div', {
                            key: 'warnings-label',
                            className: 'text-yellow-800 text-sm'
                        }, 'Avertissements')
                    ])
                ]),

                uploadResult.errors > 0 && React.createElement('div', {
                    key: 'error-details',
                    className: 'bg-red-50 border border-red-200 rounded p-4 mb-4'
                }, [
                    React.createElement('h5', {
                        key: 'errors-title',
                        className: 'font-semibold text-red-800 mb-3 flex items-center'
                    }, [
                        React.createElement('i', { key: 'error-icon', className: 'fas fa-exclamation-circle mr-2' }),
                        `Erreurs détectées (${uploadResult.details.length})`
                    ]),
                    React.createElement('div', {
                        key: 'errors-list',
                        className: 'max-h-40 overflow-y-auto space-y-2'
                    }, uploadResult.details.map((error, index) =>
                        React.createElement('div', {
                            key: index,
                            className: 'text-sm bg-white p-2 rounded border-l-4 border-red-400'
                        }, [
                            React.createElement('div', {
                                key: 'error-line',
                                className: 'font-medium text-red-800'
                            }, `Ligne ${error.line} - Champ: ${error.field}`),
                            React.createElement('div', {
                                key: 'error-msg',
                                className: 'text-red-600'
                            }, error.message)
                        ])
                    ))
                ]),

                (uploadResult.warnings > 0) && React.createElement('div', {
                    key: 'warning-details',
                    className: 'bg-yellow-50 border border-yellow-200 rounded p-4 mb-4'
                }, [
                    React.createElement('h5', {
                        key: 'warnings-title',
                        className: 'font-semibold text-yellow-800 mb-3 flex items-center'
                    }, [
                        React.createElement('i', { key: 'warning-icon', className: 'fas fa-exclamation-triangle mr-2' }),
                        `Avertissements (${uploadResult.warnings})`
                    ]),
                    React.createElement('div', {
                        key: 'warnings-list',
                        className: 'max-h-32 overflow-y-auto space-y-1'
                    }, uploadResult.warningDetails.map((warning, index) =>
                        React.createElement('div', {
                            key: index,
                            className: 'text-sm text-yellow-700'
                        }, `Ligne ${warning.line}: ${warning.message}`)
                    ))
                ]),

                uploadResult.success > 0 && React.createElement('div', {
                    key: 'success-actions',
                    className: 'bg-green-50 border border-green-200 rounded p-4'
                }, [
                    React.createElement('h5', {
                        key: 'success-title',
                        className: 'font-semibold text-green-800 mb-3'
                    }, '✅ Actions disponibles'),
                    React.createElement('div', {
                        key: 'action-buttons',
                        className: 'flex space-x-3'
                    }, [
                        React.createElement('button', {
                            key: 'confirm-import',
                            className: 'px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700'
                        }, `Confirmer l'import (${uploadResult.success} agents)`),
                        React.createElement('button', {
                            key: 'preview',
                            className: 'px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
                        }, 'Prévisualiser les données')
                    ])
                ])
            ]),

            React.createElement('div', {
                key: 'info',
                className: 'bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-6'
            }, [
                React.createElement('h5', {
                    key: 'info-title',
                    className: 'font-semibold text-yellow-800 mb-2'
                }, '💡 Informations importantes:'),
                React.createElement('ul', {
                    key: 'info-list',
                    className: 'text-yellow-700 text-sm space-y-1'
                }, [
                    React.createElement('li', { key: 'info1' }, '• Tous les agents importés auront automatiquement le rôle "AGENT"'),
                    React.createElement('li', { key: 'info2' }, '• Les matricules doivent être uniques'),
                    React.createElement('li', { key: 'info3' }, '• Les adresses email doivent être valides et uniques'),
                    React.createElement('li', { key: 'info4' }, '• Formats acceptés: CSV, Excel (.xlsx, .xls)')
                ])
            ])
        ]);
    } catch (error) {
        console.error('ImportPersonnel component error:', error);
        return React.createElement('div', {
            className: 'p-6 text-red-600'
        }, 'Erreur lors du chargement du composant d\'import');
    }
}
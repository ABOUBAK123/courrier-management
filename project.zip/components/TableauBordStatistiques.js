function TableauBordStatistiques({ onClose }) {
    const [statistiques, setStatistiques] = React.useState(null);
    const [loading, setLoading] = React.useState(true);
    const [periodeSelectionnee, setPeriodeSelectionnee] = React.useState('mois');

    React.useEffect(() => {
        chargerStatistiques();
    }, [periodeSelectionnee]);

    const chargerStatistiques = async () => {
        try {
            setLoading(true);
            const stats = await window.statistiquesManager.genererStatistiques(periodeSelectionnee);
            setStatistiques(stats);
        } catch (error) {
            console.error('Erreur chargement statistiques:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg p-6">
                    <div className="text-center">Chargement des statistiques...</div>
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg max-w-6xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center p-6 border-b">
                    <h2 className="text-xl font-bold">Statistiques Congés</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
                        <i className="fas fa-times"></i>
                    </button>
                </div>
                <div className="p-6">
                    <div className="mb-6">
                        <select value={periodeSelectionnee} onChange={(e) => setPeriodeSelectionnee(e.target.value)} className="border rounded px-3 py-2">
                            <option value="semaine">Cette semaine</option>
                            <option value="mois">Ce mois</option>
                            <option value="trimestre">Ce trimestre</option>
                            <option value="annee">Cette année</option>
                        </select>
                    </div>
                    {statistiques && (
                        <div className="space-y-6">
                            <div className="grid grid-cols-4 gap-4">
                                <div className="bg-blue-50 p-4 rounded text-center">
                                    <div className="text-2xl font-bold text-blue-600">{statistiques.totalDemandes}</div>
                                    <div className="text-sm text-gray-600">Total</div>
                                </div>
                                <div className="bg-green-50 p-4 rounded text-center">
                                    <div className="text-2xl font-bold text-green-600">{statistiques.demandesApprouvees}</div>
                                    <div className="text-sm text-gray-600">Approuvées</div>
                                </div>
                                <div className="bg-yellow-50 p-4 rounded text-center">
                                    <div className="text-2xl font-bold text-yellow-600">{statistiques.demandesEnAttente}</div>
                                    <div className="text-sm text-gray-600">En attente</div>
                                </div>
                                <div className="bg-red-50 p-4 rounded text-center">
                                    <div className="text-2xl font-bold text-red-600">{statistiques.demandesRejetees}</div>
                                    <div className="text-sm text-gray-600">Rejetées</div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

window.TableauBordStatistiques = TableauBordStatistiques;
function Utilisateurs({ user }) {
    try {
        const [users, setUsers] = React.useState([]);
        const [directions, setDirections] = React.useState([]);
        const [roles, setRoles] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [editingUser, setEditingUser] = React.useState(null);
        const [formData, setFormData] = React.useState({
            name: '',
            email: '',
            password: '',
            confirmPassword: '',
            role: '',
            direction: '',
            superieurHierarchique: '',
            matricule: ''
        });

        React.useEffect(() => {
            loadUsers();
            loadDirections();
            loadRoles();
        }, []);

        const resetForm = () => {
            setFormData({
                name: '',
                email: '',
                password: '',
                confirmPassword: '',
                role: '',
                direction: '',
                superieurHierarchique: '',
                matricule: ''
            });
            setEditingUser(null);
            setShowForm(false);
        };

        const loadUsers = async () => {
            try {
                const response = await trickleListObjects('user', 100, true);
                const userData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setUsers(userData);
            } catch (error) {
                console.error('Erreur lors du chargement des utilisateurs:', error);
            }
        };

        const loadDirections = async () => {
            try {
                const response = await trickleListObjects('directions', 100, true);
                const directionData = response.items.map(item => item.objectData);
                setDirections(directionData);
            } catch (error) {
                console.error('Erreur lors du chargement des directions:', error);
            }
        };

        const loadRoles = async () => {
            try {
                const response = await trickleListObjects('roles', 100, true);
                const roleData = response.items.map(item => item.objectData);
                setRoles(roleData);
            } catch (error) {
                console.error('Erreur lors du chargement des rôles:', error);
            }
        };

        const handleEdit = (userToEdit) => {
            setEditingUser(userToEdit);
            setFormData({
                name: userToEdit.name || '',
                email: userToEdit.email || '',
                password: '',
                confirmPassword: '',
                role: userToEdit.role || '',
                direction: userToEdit.direction || '',
                superieurHierarchique: userToEdit.superieurHierarchique || '',
                matricule: userToEdit.matricule || ''
            });
            setShowForm(true);
        };

        const handleSave = async () => {
            try {
                if (formData.password && formData.password !== formData.confirmPassword) {
                    alert('Les mots de passe ne correspondent pas');
                    return;
                }

                const userData = {
                    name: formData.name,
                    email: formData.email,
                    role: formData.role,
                    direction: formData.direction,
                    superieurHierarchique: formData.superieurHierarchique,
                    updatedAt: new Date().toISOString()
                };

                // Ajouter le mot de passe seulement s'il est renseigné
                if (formData.password) {
                    userData.password = formData.password;
                }

                // Ajouter le matricule si le rôle est AGENT
                if (formData.role === 'AGENT' && formData.matricule) {
                    userData.matricule = formData.matricule;
                }

                if (editingUser) {
                    // Mode édition
                    await trickleUpdateObject('user', editingUser.id, {
                        ...editingUser,
                        ...userData
                    });
                    alert('Utilisateur modifié avec succès!');
                } else {
                    // Mode création
                    userData.createdBy = user.name;
                    userData.createdAt = new Date().toISOString();
                    userData.password = formData.password; // Obligatoire en création
                    
                    await trickleCreateObject('user', userData);
                    alert('Utilisateur créé avec succès!');
                }
                
                resetForm();
                loadUsers();
            } catch (error) {
                alert(editingUser ? 'Erreur lors de la modification' : 'Erreur lors de la création');
            }
        };

        const handleDelete = async (userId) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur?')) {
                try {
                    await trickleDeleteObject('user', userId);
                    alert('Utilisateur supprimé avec succès');
                    loadUsers();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'utilisateurs',
            'data-file': 'components/Utilisateurs.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Gestion des Utilisateurs'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouvel Utilisateur')
            ]),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden table-responsive'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Nom', 'Email', 'Rôle', 'Direction', 'Matricule', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, users.map(userItem =>
                        React.createElement('tr', {
                            key: userItem.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'name',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, userItem.name),
                            React.createElement('td', {
                                key: 'email',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, userItem.email),
                            React.createElement('td', {
                                key: 'role',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, userItem.role),
                            React.createElement('td', {
                                key: 'direction',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, userItem.direction),
                            React.createElement('td', {
                                key: 'matricule',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, userItem.matricule || '-'),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'edit',
                                    onClick: () => handleEdit(userItem),
                                    className: 'text-blue-600 hover:text-blue-900 mr-2'
                                }, [
                                    React.createElement('i', {
                                        key: 'edit-icon',
                                        className: 'fas fa-edit'
                                    })
                                ]),
                                React.createElement('button', {
                                    key: 'delete',
                                    onClick: () => handleDelete(userItem.id),
                                    className: 'text-red-600 hover:text-red-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'delete-icon',
                                        className: 'fas fa-trash'
                                    })
                                ])
                            ])
                        ])
                    ))
                ])
            ]),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-lg max-h-screen overflow-y-auto modal-responsive'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, editingUser ? 'Modifier l\'Utilisateur' : 'Nouvel Utilisateur'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'grid grid-cols-1 md:grid-cols-2 gap-4 form-responsive'
                    }, [
                        React.createElement('input', {
                            key: 'name-input',
                            type: 'text',
                            placeholder: 'Nom complet',
                            value: formData.name,
                            onChange: (e) => setFormData(prev => ({ ...prev, name: e.target.value })),
                            className: 'col-span-2 px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('input', {
                            key: 'email-input',
                            type: 'email',
                            placeholder: 'Email',
                            value: formData.email,
                            onChange: (e) => setFormData(prev => ({ ...prev, email: e.target.value })),
                            className: 'col-span-2 px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('input', {
                            key: 'password-input',
                            type: 'password',
                            placeholder: editingUser ? 'Nouveau mot de passe (optionnel)' : 'Mot de passe',
                            value: formData.password,
                            onChange: (e) => setFormData(prev => ({ ...prev, password: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('input', {
                            key: 'confirm-password-input',
                            type: 'password',
                            placeholder: 'Confirmer mot de passe',
                            value: formData.confirmPassword,
                            onChange: (e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('select', {
                            key: 'role-select',
                            value: formData.role,
                            onChange: (e) => setFormData(prev => ({ ...prev, role: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default-role', value: '' }, 'Choisir un rôle'),
                            ...roles.map(role => 
                                React.createElement('option', { key: role.nom, value: role.nom }, role.nom)
                            )
                        ]),
                        React.createElement('select', {
                            key: 'direction-select',
                            value: formData.direction,
                            onChange: (e) => setFormData(prev => ({ ...prev, direction: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default-direction', value: '' }, 'Choisir une direction'),
                            ...directions.map(dir => 
                                React.createElement('option', { key: dir.code, value: dir.code }, `${dir.code} - ${dir.nomDirection}`)
                            )
                        ]),
                        formData.role === 'AGENT' && React.createElement('input', {
                            key: 'matricule-input',
                            type: 'text',
                            placeholder: 'Matricule (ex: AG-1001)',
                            value: formData.matricule,
                            onChange: (e) => setFormData(prev => ({ ...prev, matricule: e.target.value })),
                            className: 'col-span-2 px-3 py-2 border border-gray-300 rounded-md bg-blue-50'
                        }),
                        React.createElement('div', {
                            key: 'superieur-container',
                            className: 'col-span-2'
                        }, [
                            React.createElement('label', {
                                key: 'superieur-label',
                                className: 'block text-sm font-medium text-gray-700 mb-1'
                            }, 'Supérieur hiérarchique direct'),
                            React.createElement(SuperieurSelector, {
                                key: 'superieur-selector',
                                value: formData.superieurHierarchique,
                                onChange: (value) => setFormData(prev => ({ ...prev, superieurHierarchique: value })),
                                currentEmployeeId: editingUser?.id,
                                users: users.filter(u => u.id !== editingUser?.id)
                            })
                        ])
                    ]),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save-btn',
                            onClick: handleSave,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, editingUser ? 'Modifier' : 'Créer'),
                        React.createElement('button', {
                            key: 'cancel-btn',
                            onClick: resetForm,
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Utilisateurs component error:', error);
        reportError(error);
    }
}

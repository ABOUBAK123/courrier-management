// Composant pour visualiser les statistiques du cache
function CacheViewer() {
    try {
        const [stats, setStats] = React.useState(null);
        const [showDetails, setShowDetails] = React.useState(false);

        const refreshStats = () => {
            setStats(window.cacheManager.getStats());
        };

        React.useEffect(() => {
            refreshStats();
            const interval = setInterval(refreshStats, 5000);
            return () => clearInterval(interval);
        }, []);

        const clearCache = () => {
            if (confirm('Êtes-vous sûr de vouloir vider le cache ?')) {
                window.cacheManager.clear();
                refreshStats();
                alert('Cache vidé avec succès');
            }
        };

        const formatSize = (bytes) => {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        };

        if (!stats) {
            return React.createElement('div', {
                className: 'text-center py-4'
            }, 'Chargement des statistiques...');
        }

        return React.createElement('div', {
            className: 'bg-white p-6 rounded-lg shadow-md',
            'data-name': 'cache-viewer',
            'data-file': 'components/CacheViewer.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-4'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold text-gray-800'
                }, 'Cache Documents PDF'),
                React.createElement('div', {
                    key: 'actions',
                    className: 'space-x-2'
                }, [
                    React.createElement('button', {
                        key: 'refresh',
                        onClick: refreshStats,
                        className: 'px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600'
                    }, 'Actualiser'),
                    React.createElement('button', {
                        key: 'clear',
                        onClick: clearCache,
                        className: 'px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600'
                    }, 'Vider')
                ])
            ]),

            React.createElement('div', {
                key: 'stats-grid',
                className: 'grid grid-cols-2 md:grid-cols-4 gap-4 mb-4'
            }, [
                React.createElement('div', {
                    key: 'hits',
                    className: 'text-center p-3 bg-green-50 rounded'
                }, [
                    React.createElement('div', {
                        key: 'hits-value',
                        className: 'text-2xl font-bold text-green-600'
                    }, stats.hits),
                    React.createElement('div', {
                        key: 'hits-label',
                        className: 'text-sm text-gray-600'
                    }, 'Cache Hits')
                ]),
                React.createElement('div', {
                    key: 'misses',
                    className: 'text-center p-3 bg-yellow-50 rounded'
                }, [
                    React.createElement('div', {
                        key: 'misses-value',
                        className: 'text-2xl font-bold text-yellow-600'
                    }, stats.misses),
                    React.createElement('div', {
                        key: 'misses-label',
                        className: 'text-sm text-gray-600'
                    }, 'Cache Misses')
                ]),
                React.createElement('div', {
                    key: 'hit-rate',
                    className: 'text-center p-3 bg-blue-50 rounded'
                }, [
                    React.createElement('div', {
                        key: 'hit-rate-value',
                        className: 'text-2xl font-bold text-blue-600'
                    }, Math.round(stats.hitRate * 100) + '%'),
                    React.createElement('div', {
                        key: 'hit-rate-label',
                        className: 'text-sm text-gray-600'
                    }, 'Taux de réussite')
                ]),
                React.createElement('div', {
                    key: 'size',
                    className: 'text-center p-3 bg-purple-50 rounded'
                }, [
                    React.createElement('div', {
                        key: 'size-value',
                        className: 'text-2xl font-bold text-purple-600'
                    }, stats.size),
                    React.createElement('div', {
                        key: 'size-label',
                        className: 'text-sm text-gray-600'
                    }, 'Documents')
                ])
            ]),

            React.createElement('div', {
                key: 'usage-bar',
                className: 'mb-4'
            }, [
                React.createElement('div', {
                    key: 'usage-label',
                    className: 'flex justify-between text-sm text-gray-600 mb-1'
                }, [
                    React.createElement('span', { key: 'current' }, `Utilisé: ${formatSize(stats.currentCacheSize)}`),
                    React.createElement('span', { key: 'max' }, `Max: ${formatSize(stats.maxCacheSize)}`)
                ]),
                React.createElement('div', {
                    key: 'progress-bg',
                    className: 'w-full bg-gray-200 rounded-full h-2'
                }, [
                    React.createElement('div', {
                        key: 'progress-bar',
                        className: 'bg-blue-600 h-2 rounded-full transition-all',
                        style: { width: `${(stats.currentCacheSize / stats.maxCacheSize) * 100}%` }
                    })
                ])
            ])
        ]);

    } catch (error) {
        console.error('CacheViewer component error:', error);
        return React.createElement('div', {
            className: 'text-red-500 p-4'
        }, 'Erreur affichage cache');
    }
}
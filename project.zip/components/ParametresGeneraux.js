function ParametresGeneraux() {
    try {
        const [activeSection, setActiveSection] = React.useState('general');
        const [showConfigModal, setShowConfigModal] = React.useState(null);
        const [showDeleteModal, setShowDeleteModal] = React.useState(false);
        const [isDeleting, setIsDeleting] = React.useState(false);
        const [settings, setSettings] = React.useState({
            nomOrganisation: 'Ministère de l\'Intérieur',
            documentViewer: 'pdf',
            smtpServer: '',
            smtpPort: 587,
            smtpUsername: '',
            smtpPassword: '',
            smsApiUrl: '',
            smsApiKey: '',
            onlyofficeServer: '',
            onlyofficeSecret: '',
            loginBackgroundImage: ''
        });

        const sections = [
            { id: 'general', label: 'Général', icon: 'fas fa-cog' },
            { id: 'email', label: 'Email & SMS', icon: 'fas fa-envelope' },
            { id: 'personnalisation', label: 'Personnalisation', icon: 'fas fa-palette' },
            { id: 'documents', label: 'Gestion Documentaire', icon: 'fas fa-file-alt' },
            { id: 'stockage', label: 'Paramètres de stockage', icon: 'fas fa-server' },
            { id: 'conges', label: 'Types de congé', icon: 'fas fa-calendar' },
            { id: 'grades', label: 'Grades', icon: 'fas fa-star' }
        ];

        const handleSave = async () => {
            try {
                await trickleCreateObject('settings', settings);
                alert('Paramètres sauvegardés avec succès');
            } catch (error) {
                console.error('Erreur lors de la sauvegarde:', error);
                alert('Erreur lors de la sauvegarde');
            }
        };

        const handleDeleteAllMails = async () => {
            setIsDeleting(true);
            try {
                const result = await deleteAllNumberedMails();
                if (result.success) {
                    alert(result.message);
                    setShowDeleteModal(false);
                } else {
                    alert(`Erreur: ${result.message}`);
                }
            } catch (error) {
                console.error('Erreur suppression:', error);
                alert('Erreur lors de la suppression des courriers');
            } finally {
                setIsDeleting(false);
            }
        };

        return React.createElement('div', {
            'data-name': 'parametres-generaux',
            'data-file': 'components/ParametresGeneraux.js',
            className: 'p-6'
        }, [
            React.createElement('div', { key: 'header', className: 'mb-6' }, [
                React.createElement('h2', { className: 'text-2xl font-bold text-gray-800' }, 'Paramètres Généraux'),
                React.createElement('p', { className: 'text-gray-600 mt-2' }, 'Configuration générale du système')
            ]),

            React.createElement('div', { key: 'navigation', className: 'flex space-x-1 bg-gray-100 p-1 rounded-lg mb-6' },
                sections.map(section =>
                    React.createElement('button', {
                        key: section.id,
                        onClick: () => setActiveSection(section.id),
                        className: `flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                            activeSection === section.id
                                ? 'bg-white text-blue-600 shadow'
                                : 'text-gray-600 hover:text-gray-800'
                        }`
                    }, [
                        React.createElement('i', { key: 'icon', className: `${section.icon} mr-2` }),
                        section.label
                    ])
                )
            ),

            React.createElement('div', { key: 'content', className: 'bg-white rounded-lg shadow p-6' }, [
                activeSection === 'general' && React.createElement('div', { key: 'general-section', className: 'space-y-6' }, [
                    React.createElement('div', { key: 'org-name' }, [
                        React.createElement('label', { key: 'org-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Nom de l\'organisation'),
                        React.createElement('input', {
                            key: 'org-input',
                            type: 'text',
                            value: settings.nomOrganisation,
                            onChange: (e) => setSettings(prev => ({ ...prev, nomOrganisation: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        })
                    ]),
                    React.createElement('div', {
                        key: 'cache-section',
                        className: 'bg-gray-50 p-4 rounded-lg'
                    }, [
                        React.createElement('h4', {
                            key: 'cache-title',
                            className: 'font-semibold mb-4'
                        }, 'Gestion du Cache Documents'),
                        React.createElement(CacheViewer, { key: 'cache-viewer' }),
                        React.createElement('div', {
                            key: 'cache-actions',
                            className: 'mt-4 pt-4 border-t'
                        }, [
                            React.createElement('button', {
                                key: 'clear-browser-cache',
                                onClick: () => {
                                    localStorage.clear();
                                    sessionStorage.clear();
                                    alert('Cache navigateur vidé avec succès');
                                },
                                className: 'px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600 mr-2'
                            }, 'Vider cache navigateur')
                        ])
                    ]),
                    React.createElement('div', { key: 'import-template', className: 'bg-gray-50 p-4 rounded-lg' }, [
                        React.createElement('h4', { key: 'template-title', className: 'font-medium text-gray-800 mb-3' }, 'Modèle d\'Import du Personnel'),
                        React.createElement('p', { key: 'template-desc', className: 'text-sm text-gray-600 mb-4' }, 'Configurez le fichier modèle Excel pour l\'import en masse du personnel'),
                        React.createElement('div', { key: 'template-config', className: 'space-y-3' }, [
                            React.createElement('div', { key: 'file-upload' }, [
                                React.createElement('label', { key: 'file-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Fichier modèle personnalisé'),
                                React.createElement('input', {
                                    key: 'file-input',
                                    type: 'file',
                                    accept: '.xlsx,.xls,.csv',
                                    onChange: (e) => {
                                        const file = e.target.files[0];
                                        if (file) {
                                            alert(`Fichier modèle "${file.name}" uploadé avec succès`);
                                        }
                                    },
                                    className: 'w-full px-3 py-2 border border-gray-300 rounded-md text-sm'
                                })
                            ]),
                            React.createElement('div', { key: 'format-settings', className: 'grid grid-cols-1 md:grid-cols-2 gap-4' }, [
                                React.createElement('div', { key: 'format-select' }, [
                                    React.createElement('label', { key: 'format-label', className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Format par défaut'),
                                    React.createElement('select', {
                                        key: 'format-dropdown',
                                        defaultValue: 'csv',
                                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md text-sm'
                                    }, [
                                        React.createElement('option', { key: 'csv-option', value: 'csv' }, 'CSV (Excel compatible)'),
                                        React.createElement('option', { key: 'xlsx-option', value: 'xlsx' }, 'Excel (.xlsx)')
                                    ])
                                ]),
                                React.createElement('div', { key: 'encoding-select' }, [
                                    React.createElement('label', { key: 'encoding-label', className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Encodage'),
                                    React.createElement('select', {
                                        key: 'encoding-dropdown',
                                        defaultValue: 'utf8',
                                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md text-sm'
                                    }, [
                                        React.createElement('option', { key: 'utf8-option', value: 'utf8' }, 'UTF-8'),
                                        React.createElement('option', { key: 'iso-option', value: 'iso' }, 'ISO-8859-1')
                                    ])
                                ])
                            ]),
                            React.createElement('div', { key: 'columns-info', className: 'bg-blue-50 p-3 rounded' }, [
                                React.createElement('h5', { key: 'columns-title', className: 'text-sm font-medium text-blue-800 mb-2' }, 'Colonnes du modèle:'),
                                React.createElement('div', { key: 'columns-list', className: 'text-xs text-blue-700 grid grid-cols-2 gap-2' }, [
                                    React.createElement('span', { key: 'col1' }, '• Matricule'),
                                    React.createElement('span', { key: 'col2' }, '• Nom & Prénoms'),
                                    React.createElement('span', { key: 'col3' }, '• Email'),
                                    React.createElement('span', { key: 'col4' }, '• Poste'),
                                    React.createElement('span', { key: 'col5' }, '• Grade')
                                ])
                            ])
                        ])
                    ])
                ]),

                activeSection === 'email' && React.createElement('div', { key: 'email-section', className: 'space-y-6' }, [
                    React.createElement('h3', { key: 'smtp-title', className: 'text-lg font-medium text-gray-800 mb-4' }, 'Configuration SMTP'),
                    React.createElement('div', { key: 'smtp-server-group', className: 'grid grid-cols-1 md:grid-cols-2 gap-4' }, [
                        React.createElement('div', { key: 'smtp-server' }, [
                            React.createElement('label', { key: 'smtp-server-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Serveur SMTP'),
                            React.createElement('input', {
                                key: 'smtp-server-input',
                                type: 'text',
                                value: settings.smtpServer,
                                onChange: (e) => setSettings(prev => ({ ...prev, smtpServer: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                                placeholder: 'smtp.gmail.com'
                            })
                        ]),
                        React.createElement('div', { key: 'smtp-port' }, [
                            React.createElement('label', { key: 'smtp-port-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Port SMTP'),
                            React.createElement('input', {
                                key: 'smtp-port-input',
                                type: 'number',
                                value: settings.smtpPort,
                                onChange: (e) => setSettings(prev => ({ ...prev, smtpPort: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ])
                    ]),
                    React.createElement('div', { key: 'smtp-auth-group', className: 'grid grid-cols-1 md:grid-cols-2 gap-4' }, [
                        React.createElement('div', { key: 'smtp-username' }, [
                            React.createElement('label', { key: 'smtp-username-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Nom d\'utilisateur'),
                            React.createElement('input', {
                                key: 'smtp-username-input',
                                type: 'text',
                                value: settings.smtpUsername,
                                onChange: (e) => setSettings(prev => ({ ...prev, smtpUsername: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ]),
                        React.createElement('div', { key: 'smtp-password' }, [
                            React.createElement('label', { key: 'smtp-password-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Mot de passe'),
                            React.createElement('input', {
                                key: 'smtp-password-input',
                                type: 'password',
                                value: settings.smtpPassword,
                                onChange: (e) => setSettings(prev => ({ ...prev, smtpPassword: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ])
                    ]),
                    React.createElement('h3', { key: 'sms-title', className: 'text-lg font-medium text-gray-800 mb-4 mt-8' }, 'Configuration SMS'),
                    React.createElement('div', { key: 'sms-group', className: 'grid grid-cols-1 md:grid-cols-2 gap-4' }, [
                        React.createElement('div', { key: 'sms-url' }, [
                            React.createElement('label', { key: 'sms-url-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'URL API SMS'),
                            React.createElement('input', {
                                key: 'sms-url-input',
                                type: 'url',
                                value: settings.smsApiUrl,
                                onChange: (e) => setSettings(prev => ({ ...prev, smsApiUrl: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ]),
                        React.createElement('div', { key: 'sms-key' }, [
                            React.createElement('label', { key: 'sms-key-label', className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Clé API SMS'),
                            React.createElement('input', {
                                key: 'sms-key-input',
                                type: 'password',
                                value: settings.smsApiKey,
                                onChange: (e) => setSettings(prev => ({ ...prev, smsApiKey: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ])
                    ])
                ]),

                activeSection === 'personnalisation' && React.createElement('div', { className: 'space-y-6' }, [
                    React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Visionneuse de documents'),
                        React.createElement('select', {
                            value: settings.documentViewer,
                            onChange: (e) => setSettings(prev => ({ ...prev, documentViewer: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { value: 'pdf' }, 'PDF natif'),
                            React.createElement('option', { value: 'onlyoffice' }, 'OnlyOffice')
                        ])
                    ]),
                    React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Serveur OnlyOffice'),
                        React.createElement('input', {
                            type: 'url',
                            value: settings.onlyofficeServer,
                            onChange: (e) => setSettings(prev => ({ ...prev, onlyofficeServer: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            placeholder: 'https://onlyoffice.votre-domaine.com'
                        })
                    ]),
                    React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Clé secrète OnlyOffice'),
                        React.createElement('input', {
                            type: 'password',
                            value: settings.onlyofficeSecret,
                            onChange: (e) => setSettings(prev => ({ ...prev, onlyofficeSecret: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        })
                    ])
                ]),

                activeSection === 'documents' && React.createElement('div', { className: 'space-y-6' }, [
                    React.createElement('h3', { className: 'text-lg font-medium text-gray-800 mb-4' }, 'Politiques de Gestion Documentaire'),
                    
                    React.createElement('div', { className: 'bg-gray-50 p-4 rounded-lg' }, [
                        React.createElement('h4', { className: 'font-medium text-gray-800 mb-3' }, 'Règles de Nommage'),
                        React.createElement('div', { className: 'grid grid-cols-1 md:grid-cols-2 gap-4' }, [
                            React.createElement('div', {}, [
                                React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Modèle'),
                                React.createElement('input', {
                                    type: 'text',
                                    defaultValue: 'YYYY-MM-DD_[SERVICE]_[TYPE]',
                                    className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                                })
                            ]),
                            React.createElement('div', {}, [
                                React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Séparateur'),
                                React.createElement('select', {
                                    defaultValue: '_',
                                    className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                                }, [
                                    React.createElement('option', { value: '_' }, 'Underscore (_)'),
                                    React.createElement('option', { value: '-' }, 'Tiret (-)')
                                ])
                            ])
                        ])
                    ]),

                    React.createElement('div', { className: 'bg-gray-50 p-4 rounded-lg' }, [
                        React.createElement('h4', { className: 'font-medium text-gray-800 mb-3' }, 'Durées de Rétention'),
                        React.createElement('div', { className: 'grid grid-cols-2 md:grid-cols-4 gap-4' }, [
                            React.createElement('div', {}, [
                                React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Public'),
                                React.createElement('select', {
                                    defaultValue: '2',
                                    className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                                }, [
                                    React.createElement('option', { value: '2' }, '2 ans'),
                                    React.createElement('option', { value: '5' }, '5 ans')
                                ])
                            ]),
                            React.createElement('div', {}, [
                                React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Confidentiel'),
                                React.createElement('select', {
                                    defaultValue: '10',
                                    className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                                }, [
                                    React.createElement('option', { value: '10' }, '10 ans'),
                                    React.createElement('option', { value: '15' }, '15 ans')
                                ])
                            ])
                        ])
                    ])
                ]),

                activeSection === 'stockage' && React.createElement('div', { className: 'space-y-6' }, [
                    React.createElement('h3', { className: 'text-lg font-medium text-gray-800 mb-4' }, 'Paramètres de Stockage'),
                    
                    React.createElement('div', { className: 'grid grid-cols-1 lg:grid-cols-2 gap-6' }, [
                        React.createElement(FTPConfig, {}),
                        React.createElement(FTPUploadTest, {})
                    ]),
                    
                    React.createElement('div', { className: 'grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6' }, [
                        React.createElement(FTPStatus, {}),
                        React.createElement(FTPDebugPanel, {}),
                        React.createElement(CacheViewer, {})
                    ]),

                    React.createElement('div', { className: 'bg-blue-50 p-4 rounded-lg mt-6' }, [
                        React.createElement('h4', { className: 'font-medium text-gray-800 mb-3' }, 'Autres Serveurs'),
                        React.createElement('div', { className: 'grid grid-cols-1 md:grid-cols-2 gap-4' }, [
                            React.createElement('div', { className: 'bg-white p-4 rounded border' }, [
                                React.createElement('h5', { className: 'font-medium mb-2' }, 'Serveur SFTP'),
                                React.createElement('p', { className: 'text-sm text-gray-600 mb-3' }, 'Configuration sécurisée avec clés SSH'),
                                React.createElement('button', { 
                                    onClick: () => setShowConfigModal('sftp'),
                                    className: 'px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700' 
                                }, 'Configurer')
                            ]),
                            React.createElement('div', { className: 'bg-white p-4 rounded border' }, [
                                React.createElement('h5', { className: 'font-medium mb-2' }, 'Partage SMB'),
                                React.createElement('p', { className: 'text-sm text-gray-600 mb-3' }, 'Accès aux partages réseau Windows'),
                                React.createElement('button', { 
                                    onClick: () => setShowConfigModal('smb'),
                                    className: 'px-3 py-1 bg-yellow-600 text-white text-sm rounded hover:bg-yellow-700' 
                                }, 'Configurer')
                            ])
                        ])
                    ])
                ]),

                activeSection === 'conges' && React.createElement(TypeConges, {
                    key: 'type-conges-component'
                }),

                activeSection === 'grades' && React.createElement(Grades, {
                    key: 'grades-component'
                })
            ]),

            React.createElement('div', { key: 'danger-zone', className: 'bg-red-50 border border-red-200 rounded-lg p-4 mb-6' }, [
                React.createElement('h3', { key: 'danger-title', className: 'text-lg font-semibold text-red-800 mb-2' }, 'Zone de Danger'),
                React.createElement('p', { key: 'danger-desc', className: 'text-red-600 mb-4' }, 'Ces actions sont irréversibles. Utilisez avec précaution.'),
                React.createElement('button', {
                    key: 'delete-btn',
                    onClick: () => setShowDeleteModal(true),
                    disabled: isDeleting,
                    className: 'bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors disabled:opacity-50'
                }, [
                    React.createElement('i', { key: 'icon', className: 'fas fa-trash mr-2' }),
                    isDeleting ? 'Suppression...' : 'Supprimer tous les courriers numérotés'
                ])
            ]),

            React.createElement('div', { key: 'actions', className: 'mt-6 flex justify-end' }, [
                React.createElement('button', {
                    onClick: handleSave,
                    className: 'bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700'
                }, 'Sauvegarder')
            ]),

            // Modales de configuration
            showConfigModal && React.createElement(ConfigServerModal, {
                type: showConfigModal,
                onClose: () => setShowConfigModal(null),
                onSave: (config) => {
                    console.log('Configuration sauvée:', config);
                    alert(`Configuration ${showConfigModal.toUpperCase()} sauvegardée`);
                    setShowConfigModal(null);
                }
            }),

            // Modale de suppression
            showDeleteModal && React.createElement(DeleteMailsModal, {
                isOpen: showDeleteModal,
                onClose: () => setShowDeleteModal(false),
                onConfirm: handleDeleteAllMails,
                isDeleting: isDeleting
            })
        ]);

    } catch (error) {
        console.error('Erreur ParametresGeneraux:', error);
        return React.createElement('div', { className: 'p-6 text-red-600' }, 'Erreur lors du chargement');
    }
}
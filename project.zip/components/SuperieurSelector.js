function SuperieurSelector({ value, onChange, currentEmployeeId, users: propUsers }) {
    const [users, setUsers] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [searchTerm, setSearchTerm] = React.useState('');
    const [isOpen, setIsOpen] = React.useState(false);

    React.useEffect(() => {
        if (propUsers && propUsers.length > 0) {
            // Utiliser les utilisateurs fournis en props (pour Gestion des Utilisateurs)
            const sortedUsers = propUsers.sort((a, b) => 
                `${a.name}`.localeCompare(`${b.name}`)
            );
            setUsers(sortedUsers);
            setLoading(false);
        } else {
            // Charger les utilisateurs depuis la table 'user' (pour formulaire employé)
            loadUsersFromUserTable();
        }
    }, [propUsers, currentEmployeeId]);

    const loadUsersFromUserTable = async () => {
        try {
            const response = await trickleListObjects('user', 100, true);
            const userData = response.items.map(item => ({
                ...item.objectData,
                id: item.objectId
            })).filter(user => 
                user.id !== currentEmployeeId && 
                user.name && 
                user.email
            ).sort((a, b) => 
                `${a.name}`.localeCompare(`${b.name}`)
            );
            
            setUsers(userData);
        } catch (error) {
            console.error('Erreur chargement utilisateurs:', error);
        } finally {
            setLoading(false);
        }
    };

    const getSelectedUser = () => {
        if (propUsers && propUsers.length > 0) {
            // Mode Gestion des Utilisateurs
            return users.find(u => u.name === value || u.id === value);
        } else {
            // Mode formulaire employé
            return users.find(u => u.id === value);
        }
    };

    const filteredUsers = users.filter(user => {
        let fullName, poste, dept;
        
        if (propUsers && propUsers.length > 0) {
            // Mode Gestion des Utilisateurs
            fullName = `${user.name}`.toLowerCase();
            poste = (user.role || '').toLowerCase();
            dept = (user.direction || '').toLowerCase();
        } else {
            // Mode formulaire employé - utilise les données de la table 'user'
            fullName = `${user.name}`.toLowerCase();
            poste = (user.role || '').toLowerCase();
            dept = (user.direction || '').toLowerCase();
        }
        
        const search = searchTerm.toLowerCase();
        return fullName.includes(search) || poste.includes(search) || dept.includes(search);
    });

    if (loading) {
        return React.createElement('div', {
            className: 'text-gray-500 px-3 py-2 border border-gray-300 rounded-md bg-gray-50'
        }, 'Chargement des utilisateurs...');
    }

    const selectedUser = getSelectedUser();

    return React.createElement('div', {
        className: 'relative',
        'data-name': 'superieur-selector',
        'data-file': 'components/SuperieurSelector.js'
    }, [
        // Champ d'affichage/recherche
        React.createElement('div', {
            key: 'input-container',
            className: 'relative'
        }, [
            React.createElement('input', {
                key: 'input',
                type: 'text',
                value: isOpen ? searchTerm : (selectedUser ? 
                    `${selectedUser.name} - ${selectedUser.role || 'Rôle non défini'}` : ''),
                onChange: (e) => setSearchTerm(e.target.value),
                onFocus: () => {
                    setIsOpen(true);
                    setSearchTerm('');
                },
                placeholder: 'Rechercher et sélectionner un supérieur hiérarchique...',
                className: 'w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500'
            }),
            React.createElement('button', {
                key: 'toggle',
                type: 'button',
                onClick: () => setIsOpen(!isOpen),
                className: 'absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600'
            }, React.createElement('i', {
                className: `fas fa-chevron-${isOpen ? 'up' : 'down'}`
            }))
        ]),

        // Liste déroulante
        isOpen && React.createElement('div', {
            key: 'dropdown',
            className: 'absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto'
        }, [
            filteredUsers.length === 0 ? 
                React.createElement('div', {
                    key: 'no-results',
                    className: 'px-3 py-2 text-gray-500 text-sm'
                }, searchTerm ? 'Aucun utilisateur trouvé' : 'Aucun utilisateur disponible') :
                filteredUsers.map(user => {
                    const userId = propUsers ? (user.id || user.name) : user.id;
                    const userName = user.name;
                    const userRole = user.role;
                    const userDept = user.direction;
                    
                    return React.createElement('div', {
                        key: userId,
                        onClick: (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            const selectedValue = propUsers ? user.name : user.id;
                            onChange(selectedValue);
                            setIsOpen(false);
                            setSearchTerm('');
                        },
                        className: `px-3 py-2 hover:bg-blue-50 cursor-pointer border-b border-gray-100 last:border-b-0 ${
                            value === userId ? 'bg-blue-100 text-blue-800' : ''
                        }`
                    }, [
                        React.createElement('div', {
                            key: 'name',
                            className: 'font-medium'
                        }, userName),
                        React.createElement('div', {
                            key: 'details',
                            className: 'text-sm text-gray-600'
                        }, `${userRole || 'N/A'} • ${userDept || 'Département non défini'}`)
                    ]);
                })
        ]),

        // Overlay pour fermer
        isOpen && React.createElement('div', {
            key: 'overlay',
            className: 'fixed inset-0 z-40',
            onClick: (e) => {
                e.preventDefault();
                setIsOpen(false);
            }
        })
    ]);
}

window.SuperieurSelector = SuperieurSelector;
function EparapheurAccueil({ user }) {
    try {
        const [stats, setStats] = React.useState({
            aSigner: 0,
            brouillon: 0,
            demarres: 0,
            arretes: 0,
            archives: 0
        });
        const [showSettings, setShowSettings] = React.useState(false);
        const [showPDFViewer, setShowPDFViewer] = React.useState(false);
        const [selectedDocument, setSelectedDocument] = React.useState(null);
        const [recentParapheurs, setRecentParapheurs] = React.useState([]);
        const [visibleCards, setVisibleCards] = React.useState({
            aSigner: true,
            brouillon: true,
            demarres: true,
            arretes: true,
            archives: true
        });

        React.useEffect(() => {
            loadStats();
            loadRecentParapheurs();
        }, [user]);

        const loadStats = async () => {
            try {
                const parapheurs = await trickleListObjects('parapheurs', 100, true);
                const userParapheurs = parapheurs.items
                    .map(item => item.objectData)
                    .filter(p => 
                        p.createdBy === user.email || 
                        p.proprietaireEmail === user.email ||
                        p.validations?.some(v => v.utilisateur === user.email) ||
                        p.signatures?.some(s => s.utilisateur === user.email)
                    );
                
                setStats({
                    aSigner: userParapheurs.filter(p => p.status === 'signature' || p.status === 'validation').length,
                    brouillon: userParapheurs.filter(p => p.status === 'brouillon').length,
                    demarres: userParapheurs.filter(p => p.status === 'demarre').length,
                    arretes: userParapheurs.filter(p => p.status === 'arrete').length,
                    archives: userParapheurs.filter(p => p.status === 'archive').length
                });
            } catch (error) {
                console.error('Erreur lors du chargement des statistiques:', error);
            }
        };

        const loadRecentParapheurs = async () => {
            try {
                const parapheurs = await trickleListObjects('parapheurs', 5, true);
                const userParapheurs = parapheurs.items
                    .map(item => ({ ...item.objectData, id: item.objectId }))
                    .filter(p => 
                        p.createdBy === user.email || 
                        p.proprietaireEmail === user.email ||
                        p.validations?.some(v => v.utilisateur === user.email) ||
                        p.signatures?.some(s => s.utilisateur === user.email)
                    );
                
                setRecentParapheurs(userParapheurs);
            } catch (error) {
                console.error('Erreur chargement parapheurs récents:', error);
            }
        };

        const handleViewDocument = (parapheur) => {
            setSelectedDocument({
                ...parapheur,
                documentUrl: parapheur.documents?.[0]?.url || 'data:application/pdf;base64,',
                signaturesCount: parapheur.signatures?.length || 0
            });
            setShowPDFViewer(true);
        };

        const statCards = [
            { key: 'aSigner', title: 'À Signer / Valider', value: stats.aSigner, icon: 'fas fa-pen', color: 'bg-orange-500' },
            { key: 'brouillon', title: 'Brouillon', value: stats.brouillon, icon: 'fas fa-edit', color: 'bg-gray-500' },
            { key: 'demarres', title: 'Démarrés', value: stats.demarres, icon: 'fas fa-play', color: 'bg-blue-500' },
            { key: 'arretes', title: 'Arrêtés', value: stats.arretes, icon: 'fas fa-stop', color: 'bg-red-500' },
            { key: 'archives', title: 'Archivés', value: stats.archives, icon: 'fas fa-archive', color: 'bg-green-500' }
        ];

        const handleToggleCard = (cardKey) => {
            setVisibleCards(prev => ({
                ...prev,
                [cardKey]: !prev[cardKey]
            }));
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'eparapheur-accueil',
            'data-file': 'components/EparapheurAccueil.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-8'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'E-parapheur - Accueil'),
                React.createElement('button', {
                    key: 'settings-btn',
                    onClick: () => setShowSettings(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, [
                    React.createElement('i', {
                        key: 'settings-icon',
                        className: 'fas fa-cog mr-2'
                    }),
                    'Paramètres'
                ])
            ]),
            React.createElement('div', {
                key: 'stats-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8'
            }, statCards.filter(card => visibleCards[card.key]).map(card =>
                React.createElement('div', {
                    key: card.key,
                    className: 'bg-white rounded-xl shadow-md p-6 card-hover'
                }, [
                    React.createElement('div', {
                        key: 'card-content',
                        className: 'flex items-center'
                    }, [
                        React.createElement('div', {
                            key: 'icon-container',
                            className: `${card.color} p-3 rounded-lg`
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: `${card.icon} text-white text-xl`
                            })
                        ]),
                        React.createElement('div', {
                            key: 'card-info',
                            className: 'ml-4'
                        }, [
                            React.createElement('p', {
                                key: 'card-title',
                                className: 'text-sm font-medium text-gray-600'
                            }, card.title),
                            React.createElement('p', {
                                key: 'card-value',
                                className: 'text-2xl font-bold text-gray-900'
                            }, card.value)
                        ])
                    ])
                ])
            )),
            React.createElement('div', {
                key: 'recent-parapheurs',
                className: 'bg-white rounded-xl shadow-md p-6'
            }, [
                React.createElement('h3', {
                    key: 'recent-title',
                    className: 'text-lg font-semibold text-gray-800 mb-4'
                }, 'Parapheurs Récents'),
                recentParapheurs.length > 0 ? React.createElement('div', {
                    key: 'parapheurs-list',
                    className: 'space-y-3'
                }, recentParapheurs.map(parapheur =>
                    React.createElement('div', {
                        key: parapheur.id,
                        className: 'flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors'
                    }, [
                        React.createElement('div', {
                            key: 'parapheur-info',
                            className: 'flex-1'
                        }, [
                            React.createElement('p', {
                                key: 'parapheur-name',
                                className: 'font-medium text-gray-800'
                            }, parapheur.nom),
                            React.createElement('p', {
                                key: 'parapheur-status',
                                className: 'text-sm text-gray-600'
                            }, `${parapheur.signatures?.length || 0} signataire(s) • ${parapheur.status}`)
                        ]),
                        React.createElement('button', {
                            key: 'view-btn',
                            onClick: () => handleViewDocument(parapheur),
                            className: 'bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700'
                        }, [
                            React.createElement('i', {
                                key: 'eye-icon',
                                className: 'fas fa-eye mr-1'
                            }),
                            'Voir'
                        ])
                    ])
                )) : React.createElement('p', {
                    key: 'no-recent',
                    className: 'text-gray-500 text-center py-4'
                }, 'Aucun parapheur récent')
            ]),
            showSettings && React.createElement('div', {
                key: 'settings-modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Paramètres des vignettes'),
                    React.createElement('div', {
                        key: 'checkboxes',
                        className: 'space-y-3'
                    }, statCards.map(card =>
                        React.createElement('label', {
                            key: card.key,
                            className: 'flex items-center'
                        }, [
                            React.createElement('input', {
                                key: 'checkbox',
                                type: 'checkbox',
                                checked: visibleCards[card.key],
                                onChange: () => handleToggleCard(card.key),
                                className: 'mr-3'
                            }),
                            React.createElement('span', {
                                key: 'label'
                            }, card.title)
                        ])
                    )),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'close-btn',
                            onClick: () => setShowSettings(false),
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Fermer')
                    ])
                ])
            ]),
            showPDFViewer && selectedDocument && React.createElement(PDFViewer, {
                key: 'pdf-viewer',
                documentUrl: selectedDocument.documentUrl,
                onClose: () => setShowPDFViewer(false),
                signaturesCount: selectedDocument.signaturesCount,
                showSignatureZones: true
            })
        ]);
    } catch (error) {
        console.error('EparapheurAccueil component error:', error);
        reportError(error);
    }
}

function OfflineIndicator({ user }) {
    // Composant désactivé - plus de mode hors ligne
    return null;
}

window.OfflineIndicator = OfflineIndicator;

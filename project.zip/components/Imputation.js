function Imputation({ user }) {
    try {
        const [mails, setMails] = React.useState([]);
        const [directions, setDirections] = React.useState([]);
        const [instructions, setInstructions] = React.useState([]);
        const [showModal, setShowModal] = React.useState(false);
        const [selectedMail, setSelectedMail] = React.useState(null);
        const [imputationData, setImputationData] = React.useState({
            direction: '',
            instruction: '',
            instructionParticuliere: '',
            delai: ''
        });

        React.useEffect(() => {
            loadPendingMails();
            loadChildDirections();
            loadInstructions();
        }, [user]);

        const canViewMailForImputation = (mail, userRole) => {
            const authorizedRoles = ['MINISTRE', 'DIR CAB', 'DIRECTEUR GENERAL', 'DIRECTEUR'];
            return authorizedRoles.includes(userRole);
        };

        const loadPendingMails = async () => {
            try {
                if (!canViewImputation(user.role)) return;
                
                const response = await trickleListObjects(`mail:${user.direction}`, 100, true);
                const allPendingMails = response.items
                    .map(item => ({ ...item.objectData, id: item.objectId }))
                    .filter(mail => mail.status === 'attente');
                
                const visibleMails = allPendingMails.filter(mail => 
                    canViewMailForImputation(mail, user.role)
                );
                
                setMails(visibleMails);
            } catch (error) {
                console.error('Erreur lors du chargement:', error);
            }
        };

        const loadChildDirections = async () => {
            try {
                const response = await trickleListObjects('directions', 100, true);
                const allDirections = response.items.map(item => item.objectData);
                const childDirections = allDirections.filter(dir => 
                    dir.directionParent === user.direction
                );
                setDirections(childDirections);
            } catch (error) {
                console.error('Erreur chargement directions:', error);
            }
        };

        const loadInstructions = async () => {
            try {
                const response = await trickleListObjects('instructions', 100, true);
                const instructionData = response.items.map(item => item.objectData);
                setInstructions(instructionData);
            } catch (error) {
                console.error('Erreur chargement instructions:', error);
            }
        };

        const handleImpute = async () => {
            try {
                // Update original mail status
                await trickleUpdateObject(`mail:${user.direction}`, selectedMail.id, {
                    ...selectedMail,
                    status: 'traitement',
                    imputedTo: imputationData.direction,
                    imputedBy: user.direction,
                    instruction: imputationData.instruction,
                    instructionParticuliere: imputationData.instructionParticuliere,
                    delai: imputationData.delai,
                    imputationDate: new Date().toISOString()
                });

                // Create mail copy in target direction
                await trickleCreateObject(`mail:${imputationData.direction}`, {
                    ...selectedMail,
                    status: 'traitement',
                    direction: imputationData.direction,
                    imputedTo: imputationData.direction,
                    imputedBy: user.direction,
                    instruction: imputationData.instruction,
                    instructionParticuliere: imputationData.instructionParticuliere,
                    delai: imputationData.delai,
                    imputationDate: new Date().toISOString(),
                    originalMailId: selectedMail.id
                });

                // Create tracking record for original direction
                await trickleCreateObject(`imputation:${user.direction}`, {
                    mailId: selectedMail.id,
                    mailNumber: selectedMail.numero,
                    mailObject: selectedMail.objet,
                    imputedTo: imputationData.direction,
                    imputedBy: user.direction,
                    status: 'en_traitement',
                    date: new Date().toISOString()
                });

                alert('Courrier imputé avec succès');
                setShowModal(false);
                loadPendingMails();
                
                setImputationData({
                    direction: '',
                    instruction: '',
                    instructionParticuliere: '',
                    delai: ''
                });
            } catch (error) {
                alert('Erreur lors de l\'imputation');
            }
        };

        if (!canViewImputation(user.role)) {
            return React.createElement('div', {
                className: 'p-6 text-center text-red-600',
                'data-name': 'access-denied',
                'data-file': 'components/Imputation.js'
            }, 'Accès non autorisé pour ce rôle');
        }

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'imputation',
            'data-file': 'components/Imputation.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Imputation des Courriers'),
            mails.length === 0 ? React.createElement('div', {
                key: 'no-mails',
                className: 'bg-white rounded-lg shadow-md p-8 text-center text-gray-500'
            }, 'Aucun courrier en attente d\'imputation') : React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Numéro', 'Objet', 'Expéditeur', 'Priorité', 'Agent', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, mails.map(mail =>
                        React.createElement('tr', {
                            key: mail.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'numero',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, mail.numero),
                            React.createElement('td', {
                                key: 'objet',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.objet),
                            React.createElement('td', {
                                key: 'expediteur',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.expediteur),
                            React.createElement('td', {
                                key: 'priority',
                                className: `px-6 py-4 whitespace-nowrap text-sm font-medium ${PRIORITIES.find(p => p.value === mail.priority)?.color}`
                            }, PRIORITIES.find(p => p.value === mail.priority)?.label),
                            React.createElement('td', {
                                key: 'agent',
                                className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                            }, mail.createdByName || 'Non défini'),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'view',
                                    className: 'text-blue-600 hover:text-blue-900 mr-2'
                                }, [
                                    React.createElement('i', {
                                        key: 'eye-icon',
                                        className: 'fas fa-eye'
                                    })
                                ]),
                                React.createElement('button', {
                                    key: 'impute',
                                    onClick: () => {
                                        setSelectedMail(mail);
                                        setShowModal(true);
                                    },
                                    className: 'bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700'
                                }, 'Imputer')
                            ])
                        ])
                    ))
                ])
            ]),
            showModal && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Formulaire d\'Imputation'),
                    React.createElement('div', {
                        key: 'mail-info',
                        className: 'mb-4 p-3 bg-gray-50 rounded'
                    }, [
                        React.createElement('p', { key: 'numero' }, `Numéro: ${selectedMail?.numero}`),
                        React.createElement('p', { key: 'objet' }, `Objet: ${selectedMail?.objet}`),
                        React.createElement('p', { key: 'expediteur' }, `Expéditeur: ${selectedMail?.expediteur}`)
                    ]),
                    React.createElement('div', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('select', {
                            key: 'direction',
                            value: imputationData.direction,
                            onChange: (e) => setImputationData(prev => ({ ...prev, direction: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            required: true
                        }, [
                            React.createElement('option', { key: 'default', value: '' }, 'Choisir une direction'),
                            ...directions.map(dir => 
                                React.createElement('option', { key: dir.code, value: dir.code }, `${dir.code} - ${dir.nomDirection}`)
                            )
                        ]),
                        React.createElement('select', {
                            key: 'instruction',
                            value: imputationData.instruction,
                            onChange: (e) => setImputationData(prev => ({ ...prev, instruction: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default', value: '' }, 'Choisir une instruction'),
                            ...instructions.map(inst => 
                                React.createElement('option', { key: inst.nom, value: inst.nom }, inst.nom)
                            )
                        ]),
                        React.createElement('textarea', {
                            key: 'instruction-particuliere',
                            placeholder: 'Instruction particulière...',
                            value: imputationData.instructionParticuliere,
                            onChange: (e) => setImputationData(prev => ({ ...prev, instructionParticuliere: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            rows: 3
                        }),
                        React.createElement('input', {
                            key: 'delai',
                            type: 'date',
                            value: imputationData.delai,
                            onChange: (e) => setImputationData(prev => ({ ...prev, delai: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        })
                    ]),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'impute-btn',
                            onClick: handleImpute,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, 'Imputer'),
                        React.createElement('button', {
                            key: 'cancel-btn',
                            onClick: () => setShowModal(false),
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Imputation component error:', error);
        reportError(error);
    }
}

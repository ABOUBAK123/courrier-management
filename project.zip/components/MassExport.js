function MassExport({ onClose }) {
    try {
        const [filters, setFilters] = React.useState({
            dateDebut: '',
            dateFin: '',
            statut: '',
            service: '',
            priorite: '',
            type: ''
        });
        const [exportFormat, setExportFormat] = React.useState('excel');
        const [exporting, setExporting] = React.useState(false);
        const [results, setResults] = React.useState(null);

        const handleFilterChange = (field, value) => {
            setFilters(prev => ({...prev, [field]: value}));
        };

        const previewResults = () => {
            // Simulation de prévisualisation
            const mockResults = [
                {
                    reference: 'DGC-2024-001',
                    objet: 'Demande de subvention',
                    expediteur: 'Commune de Rabat',
                    dateReception: '2024-01-15',
                    statut: 'En traitement',
                    service: 'Direction Générale',
                    priorite: 'Urgent'
                },
                {
                    reference: 'RPT-2024-002',
                    objet: 'Rapport mensuel',
                    expediteur: 'Province de Kenitra',
                    dateReception: '2024-01-18',
                    statut: 'Traité',
                    service: 'Service Administratif',
                    priorite: 'Normal'
                }
            ];
            setResults(mockResults);
        };

        const exportData = () => {
            setExporting(true);
            
            setTimeout(() => {
                const data = results || [];
                const filename = `export_courriers_${new Date().toISOString().split('T')[0]}.${exportFormat}`;
                
                if (exportFormat === 'excel') {
                    // Simulation export Excel
                    const csvContent = [
                        ['Référence', 'Objet', 'Expéditeur', 'Date Réception', 'Statut', 'Service', 'Priorité'],
                        ...data.map(row => [
                            row.reference, row.objet, row.expediteur, 
                            row.dateReception, row.statut, row.service, row.priorite
                        ])
                    ].map(row => row.join(',')).join('\n');
                    
                    const blob = new Blob([csvContent], { type: 'text/csv' });
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = filename;
                    a.click();
                }
                
                setExporting(false);
                alert(`Export réussi ! ${data.length} courriers exportés.`);
                onClose();
            }, 2000);
        };

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4'
        }, [
            React.createElement('div', {
                key: 'modal',
                className: 'bg-white rounded-lg shadow-2xl max-w-5xl w-full max-h-[95vh] overflow-auto'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'bg-green-600 text-white p-4 rounded-t-lg flex justify-between items-center'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-bold flex items-center'
                    }, [
                        React.createElement('i', { key: 'icon', className: 'fas fa-download mr-3' }),
                        'Export Massif de Courriers'
                    ]),
                    React.createElement('button', {
                        key: 'close',
                        onClick: onClose,
                        className: 'text-white hover:text-gray-300'
                    }, React.createElement('i', { className: 'fas fa-times text-xl' }))
                ]),

                React.createElement('div', {
                    key: 'content',
                    className: 'p-6'
                }, [
                    React.createElement('div', {
                        key: 'filters-section',
                        className: 'mb-6'
                    }, [
                        React.createElement('h4', {
                            key: 'filters-title',
                            className: 'font-bold text-gray-800 mb-4'
                        }, 'Filtres de sélection'),
                        React.createElement('div', {
                            key: 'filters-grid',
                            className: 'grid grid-cols-2 md:grid-cols-3 gap-4'
                        }, [
                            React.createElement('div', {
                                key: 'date-debut'
                            }, [
                                React.createElement('label', {
                                    key: 'label-debut',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Date début'),
                                React.createElement('input', {
                                    key: 'input-debut',
                                    type: 'date',
                                    value: filters.dateDebut,
                                    onChange: (e) => handleFilterChange('dateDebut', e.target.value),
                                    className: 'w-full border rounded-md px-3 py-2'
                                })
                            ]),
                            React.createElement('div', {
                                key: 'date-fin'
                            }, [
                                React.createElement('label', {
                                    key: 'label-fin',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Date fin'),
                                React.createElement('input', {
                                    key: 'input-fin',
                                    type: 'date',
                                    value: filters.dateFin,
                                    onChange: (e) => handleFilterChange('dateFin', e.target.value),
                                    className: 'w-full border rounded-md px-3 py-2'
                                })
                            ]),
                            React.createElement('div', {
                                key: 'statut'
                            }, [
                                React.createElement('label', {
                                    key: 'label-statut',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Statut'),
                                React.createElement('select', {
                                    key: 'select-statut',
                                    value: filters.statut,
                                    onChange: (e) => handleFilterChange('statut', e.target.value),
                                    className: 'w-full border rounded-md px-3 py-2'
                                }, [
                                    React.createElement('option', { key: 'all-statut', value: '' }, 'Tous les statuts'),
                                    React.createElement('option', { key: 'nouveau', value: 'nouveau' }, 'Nouveau'),
                                    React.createElement('option', { key: 'traitement', value: 'traitement' }, 'En traitement'),
                                    React.createElement('option', { key: 'traite', value: 'traite' }, 'Traité')
                                ])
                            ]),
                            React.createElement('div', {
                                key: 'service'
                            }, [
                                React.createElement('label', {
                                    key: 'label-service',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Service'),
                                React.createElement('select', {
                                    key: 'select-service',
                                    value: filters.service,
                                    onChange: (e) => handleFilterChange('service', e.target.value),
                                    className: 'w-full border rounded-md px-3 py-2'
                                }, [
                                    React.createElement('option', { key: 'all-service', value: '' }, 'Tous les services'),
                                    React.createElement('option', { key: 'dg', value: 'dg' }, 'Direction Générale'),
                                    React.createElement('option', { key: 'admin', value: 'admin' }, 'Service Administratif'),
                                    React.createElement('option', { key: 'tech', value: 'tech' }, 'Service Technique')
                                ])
                            ]),
                            React.createElement('div', {
                                key: 'priorite'
                            }, [
                                React.createElement('label', {
                                    key: 'label-priorite',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Priorité'),
                                React.createElement('select', {
                                    key: 'select-priorite',
                                    value: filters.priorite,
                                    onChange: (e) => handleFilterChange('priorite', e.target.value),
                                    className: 'w-full border rounded-md px-3 py-2'
                                }, [
                                    React.createElement('option', { key: 'all-priorite', value: '' }, 'Toutes les priorités'),
                                    React.createElement('option', { key: 'urgent', value: 'urgent' }, 'Urgent'),
                                    React.createElement('option', { key: 'normal', value: 'normal' }, 'Normal'),
                                    React.createElement('option', { key: 'routine', value: 'routine' }, 'Routine')
                                ])
                            ]),
                            React.createElement('div', {
                                key: 'type'
                            }, [
                                React.createElement('label', {
                                    key: 'label-type',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Type de courrier'),
                                React.createElement('select', {
                                    key: 'select-type',
                                    value: filters.type,
                                    onChange: (e) => handleFilterChange('type', e.target.value),
                                    className: 'w-full border rounded-md px-3 py-2'
                                }, [
                                    React.createElement('option', { key: 'all-type', value: '' }, 'Tous les types'),
                                    React.createElement('option', { key: 'demande', value: 'demande' }, 'Demande'),
                                    React.createElement('option', { key: 'rapport', value: 'rapport' }, 'Rapport'),
                                    React.createElement('option', { key: 'notification', value: 'notification' }, 'Notification')
                                ])
                            ])
                        ]),
                        
                        React.createElement('div', {
                            key: 'format-section',
                            className: 'mt-4'
                        }, [
                            React.createElement('label', {
                                key: 'format-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Format d\'export'),
                            React.createElement('div', {
                                key: 'format-options',
                                className: 'flex space-x-4'
                            }, [
                                React.createElement('label', {
                                    key: 'excel-option',
                                    className: 'flex items-center'
                                }, [
                                    React.createElement('input', {
                                        key: 'excel-radio',
                                        type: 'radio',
                                        value: 'excel',
                                        checked: exportFormat === 'excel',
                                        onChange: (e) => setExportFormat(e.target.value),
                                        className: 'mr-2'
                                    }),
                                    'Excel (.xlsx)'
                                ]),
                                React.createElement('label', {
                                    key: 'csv-option',
                                    className: 'flex items-center'
                                }, [
                                    React.createElement('input', {
                                        key: 'csv-radio',
                                        type: 'radio',
                                        value: 'csv',
                                        checked: exportFormat === 'csv',
                                        onChange: (e) => setExportFormat(e.target.value),
                                        className: 'mr-2'
                                    }),
                                    'CSV (.csv)'
                                ]),
                                React.createElement('label', {
                                    key: 'pdf-option',
                                    className: 'flex items-center'
                                }, [
                                    React.createElement('input', {
                                        key: 'pdf-radio',
                                        type: 'radio',
                                        value: 'pdf',
                                        checked: exportFormat === 'pdf',
                                        onChange: (e) => setExportFormat(e.target.value),
                                        className: 'mr-2'
                                    }),
                                    'PDF (.pdf)'
                                ])
                            ])
                        ]),

                        React.createElement('div', {
                            key: 'preview-actions',
                            className: 'mt-6 flex space-x-3'
                        }, [
                            React.createElement('button', {
                                key: 'preview-btn',
                                onClick: previewResults,
                                className: 'px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700'
                            }, [
                                React.createElement('i', { key: 'preview-icon', className: 'fas fa-eye mr-2' }),
                                'Prévisualiser'
                            ])
                        ])
                    ]),

                    results && React.createElement('div', {
                        key: 'results-section',
                        className: 'mb-6 border-t pt-6'
                    }, [
                        React.createElement('h4', {
                            key: 'results-title',
                            className: 'font-bold text-gray-800 mb-4'
                        }, `Résultats de la sélection (${results.length} courriers)`),
                        
                        React.createElement('div', {
                            key: 'results-table',
                            className: 'overflow-x-auto max-h-60'
                        }, [
                            React.createElement('table', {
                                key: 'table',
                                className: 'w-full border border-gray-300 rounded-lg text-sm'
                            }, [
                                React.createElement('thead', {
                                    key: 'thead',
                                    className: 'bg-gray-100 sticky top-0'
                                }, [
                                    React.createElement('tr', {
                                        key: 'header-row'
                                    }, ['Référence', 'Objet', 'Expéditeur', 'Date', 'Statut'].map(header => 
                                        React.createElement('th', {
                                            key: header,
                                            className: 'px-3 py-2 text-left font-medium text-gray-700'
                                        }, header)
                                    ))
                                ]),
                                React.createElement('tbody', {
                                    key: 'tbody'
                                }, results.map((item, index) => 
                                    React.createElement('tr', {
                                        key: index,
                                        className: 'hover:bg-gray-50'
                                    }, [
                                        React.createElement('td', {
                                            key: 'ref',
                                            className: 'px-3 py-2 border-b'
                                        }, item.reference),
                                        React.createElement('td', {
                                            key: 'obj',
                                            className: 'px-3 py-2 border-b max-w-xs truncate'
                                        }, item.objet),
                                        React.createElement('td', {
                                            key: 'exp',
                                            className: 'px-3 py-2 border-b'
                                        }, item.expediteur),
                                        React.createElement('td', {
                                            key: 'date',
                                            className: 'px-3 py-2 border-b'
                                        }, item.dateReception),
                                        React.createElement('td', {
                                            key: 'stat',
                                            className: 'px-3 py-2 border-b'
                                        }, React.createElement('span', {
                                            className: `px-2 py-1 rounded text-xs ${
                                                item.statut === 'Traité' ? 'bg-green-100 text-green-800' :
                                                item.statut === 'En traitement' ? 'bg-yellow-100 text-yellow-800' :
                                                'bg-gray-100 text-gray-800'
                                            }`
                                        }, item.statut))
                                    ])
                                ))
                            ])
                        ])
                    ]),

                    React.createElement('div', {
                        key: 'export-actions',
                        className: 'flex justify-between items-center pt-4 border-t'
                    }, [
                        React.createElement('div', {
                            key: 'export-info',
                            className: 'text-sm text-gray-600'
                        }, results ? `${results.length} courriers sélectionnés` : 'Aucune sélection'),
                        
                        React.createElement('div', {
                            key: 'action-buttons',
                            className: 'flex space-x-3'
                        }, [
                            React.createElement('button', {
                                key: 'cancel-btn',
                                onClick: onClose,
                                className: 'px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50'
                            }, 'Annuler'),
                            React.createElement('button', {
                                key: 'export-btn',
                                onClick: exportData,
                                disabled: !results || exporting,
                                className: `px-4 py-2 rounded-md text-white ${
                                    results && !exporting ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'
                                }`
                            }, exporting ? [
                                React.createElement('i', { key: 'loading-icon', className: 'fas fa-spinner fa-spin mr-2' }),
                                'Export en cours...'
                            ] : [
                                React.createElement('i', { key: 'export-icon', className: 'fas fa-download mr-2' }),
                                'Exporter'
                            ])
                        ])
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Erreur MassExport:', error);
        return null;
    }
}

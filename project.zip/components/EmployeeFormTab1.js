function EmployeeFormTab1({ formData, handleInputChange }) {
    try {
        const personalFields = [
            { key: 'matricule', label: 'Matricule', type: 'text', required: true },
            { key: 'nom', label: 'Nom', type: 'text', required: true },
            { key: 'prenom', label: 'Prénoms', type: 'text', required: true },
            { key: 'nomJeuneFille', label: 'Nom de Jeune Fille', type: 'text' },
            { key: 'dateNaissance', label: 'Date de Naissance', type: 'date', required: true },
            { key: 'lieuNaissance', label: 'Lieu de Naissance', type: 'text' },
            { key: 'nomPere', label: 'Nom du Père', type: 'text' },
            { key: 'nomMere', label: 'Nom de la Mère', type: 'text' },
            { key: 'numeroCNI', label: 'Numéro CNI', type: 'text' },
            { key: 'telephone', label: 'Téléphone', type: 'tel' },
            { key: 'email', label: 'Email', type: 'email', required: true },
            { key: 'nombreEnfants', label: 'Nombre d\'enfants', type: 'number' }
        ];

        const selectFields = [
            {
                key: 'sexe',
                label: 'Sexe',
                options: [
                    { value: '', label: 'Sélectionner' },
                    { value: 'M', label: 'Masculin' },
                    { value: 'F', label: 'Féminin' }
                ]
            },
            {
                key: 'situationFamiliale',
                label: 'Situation Familiale',
                options: [
                    { value: '', label: 'Sélectionner' },
                    { value: 'celibataire', label: 'Célibataire' },
                    { value: 'marie', label: 'Marié(e)' },
                    { value: 'divorce', label: 'Divorcé(e)' },
                    { value: 'veuf', label: 'Veuf(ve)' }
                ]
            }
        ];

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'employee-form-tab1',
            'data-file': 'components/EmployeeFormTab1.js'
        }, [
            React.createElement('h4', {
                key: 'title',
                className: 'text-lg font-medium text-gray-800 border-b pb-2'
            }, '👤 Informations Personnelles'),
            React.createElement('div', {
                key: 'fields-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
            }, [
                ...personalFields.map(field =>
                    React.createElement('div', {
                        key: field.key,
                        className: field.key === 'email' ? 'md:col-span-2' : ''
                    }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, [
                            field.label,
                            field.required && React.createElement('span', {
                                key: 'required',
                                className: 'text-red-500 ml-1'
                            }, '⭐')
                        ]),
                        React.createElement('input', {
                            key: 'input',
                            type: field.type,
                            value: formData[field.key] || '',
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                            required: field.required,
                            min: field.type === 'number' ? 0 : undefined
                        })
                    ])
                ),
                ...selectFields.map(field =>
                    React.createElement('div', {
                        key: field.key
                    }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, field.label),
                        React.createElement('select', {
                            key: 'select',
                            value: formData[field.key] || '',
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                        }, field.options.map(option =>
                            React.createElement('option', {
                                key: option.value,
                                value: option.value
                            }, option.label)
                        ))
                    ])
                )
            ]),
            React.createElement('div', {
                key: 'info',
                className: 'bg-blue-50 border border-blue-200 rounded-lg p-4'
            }, [
                React.createElement('p', {
                    key: 'info-text',
                    className: 'text-sm text-blue-700'
                }, '⭐ Les champs marqués d\'une étoile sont obligatoires')
            ])
        ]);
    } catch (error) {
        console.error('EmployeeFormTab1 component error:', error);
        reportError(error);
    }
}

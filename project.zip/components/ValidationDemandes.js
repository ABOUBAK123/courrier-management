function ValidationDemandes() {
    try {
        const [demandes, setDemandes] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [filter, setFilter] = React.useState('en_attente');

        React.useEffect(() => {
            loadDemandes();
        }, [filter]);

        const loadDemandes = async () => {
            try {
                setLoading(true);
                const response = await trickleListObjects('demande_conge', 100, true);
                const demandesData = response.items.filter(item => 
                    filter === 'all' || item.objectData.statut === filter
                );
                setDemandes(demandesData);
            } catch (error) {
                console.error('Erreur lors du chargement des demandes:', error);
            } finally {
                setLoading(false);
            }
        };

        const handleValidation = async (demandeId, action, commentaire = '') => {
            try {
                const demande = demandes.find(d => d.objectId === demandeId);
                if (!demande) return;
                
                const newStatut = action === 'approve' ? 'approuve' : 'refuse';
                
                await trickleUpdateObject('demande_conge', demandeId, {
                    ...demande.objectData,
                    statut: newStatut,
                    commentaire_validation: commentaire,
                    date_validation: new Date().toISOString(),
                    validateur: 'Responsable RH'
                });
                
                // Notification toast
                if (window.showToast) {
                    window.showToast(
                        `Demande ${newStatut === 'approuve' ? 'approuvée' : 'refusée'} avec succès`,
                        newStatut === 'approuve' ? 'success' : 'info'
                    );
                }
                
                loadDemandes();
            } catch (error) {
                console.error('Erreur lors de la validation:', error);
                if (window.showToast) {
                    window.showToast('Erreur lors de la validation', 'error');
                }
            }
        };

        const getStatutBadge = (statut) => {
            const styles = {
                en_attente: 'bg-yellow-100 text-yellow-800',
                approuve: 'bg-green-100 text-green-800',
                refuse: 'bg-red-100 text-red-800'
            };
            return `px-2 py-1 rounded-full text-xs font-medium ${styles[statut] || styles.en_attente}`;
        };

        return React.createElement('div', {
            className: 'p-6',
            'data-name': 'validation-demandes',
            'data-file': 'components/ValidationDemandes.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Validation des Demandes'),
                React.createElement('select', {
                    key: 'filter',
                    value: filter,
                    onChange: (e) => setFilter(e.target.value),
                    className: 'px-3 py-2 border border-gray-300 rounded-md'
                }, [
                    React.createElement('option', { key: 'en_attente', value: 'en_attente' }, 'En attente'),
                    React.createElement('option', { key: 'approuve', value: 'approuve' }, 'Approuvées'),
                    React.createElement('option', { key: 'refuse', value: 'refuse' }, 'Refusées'),
                    React.createElement('option', { key: 'all', value: 'all' }, 'Toutes')
                ])
            ]),

            loading ? React.createElement('div', {
                key: 'loading',
                className: 'text-center py-8'
            }, 'Chargement...') : React.createElement('div', {
                key: 'content',
                className: 'bg-white rounded-lg shadow'
            }, [
                React.createElement('div', {
                    key: 'table-container',
                    className: 'overflow-x-auto'
                }, React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, React.createElement('tr', {
                        key: 'header-row'
                    }, [
                        React.createElement('th', { key: 'agent', className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Agent'),
                        React.createElement('th', { key: 'type', className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Type'),
                        React.createElement('th', { key: 'periode', className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Période'),
                        React.createElement('th', { key: 'duree', className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Durée'),
                        React.createElement('th', { key: 'statut', className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Statut'),
                        React.createElement('th', { key: 'actions', className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Actions')
                    ])),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, demandes.map(demande => 
                        React.createElement('tr', {
                            key: demande.objectId
                        }, [
                            React.createElement('td', { key: 'agent', className: 'px-6 py-4 whitespace-nowrap' }, demande.objectData.nom_agent || 'Agent'),
                            React.createElement('td', { key: 'type', className: 'px-6 py-4 whitespace-nowrap' }, demande.objectData.type_conge || 'Congé'),
                            React.createElement('td', { key: 'periode', className: 'px-6 py-4 whitespace-nowrap text-sm' }, 
                                `${demande.objectData.date_debut} - ${demande.objectData.date_fin}`),
                            React.createElement('td', { key: 'duree', className: 'px-6 py-4 whitespace-nowrap' }, `${demande.objectData.duree || 0} jours`),
                            React.createElement('td', { key: 'statut', className: 'px-6 py-4 whitespace-nowrap' }, 
                                React.createElement('span', {
                                    className: getStatutBadge(demande.objectData.statut)
                                }, demande.objectData.statut === 'en_attente' ? 'En attente' : 
                                   demande.objectData.statut === 'approuve' ? 'Approuvée' : 'Refusée')),
                            React.createElement('td', { key: 'actions', className: 'px-6 py-4 whitespace-nowrap text-sm' }, 
                                demande.objectData.statut === 'en_attente' ? [
                                    React.createElement('button', {
                                        key: 'approve',
                                        onClick: () => handleValidation(demande.objectId, 'approve'),
                                        className: 'text-green-600 hover:text-green-900 mr-3'
                                    }, 'Approuver'),
                                    React.createElement('button', {
                                        key: 'reject',
                                        onClick: () => handleValidation(demande.objectId, 'reject'),
                                        className: 'text-red-600 hover:text-red-900'
                                    }, 'Refuser')
                                ] : React.createElement('span', { className: 'text-gray-400' }, 'Traitée'))
                        ])
                    ))
                ]))
            ])
        ]);
    } catch (error) {
        console.error('ValidationDemandes component error:', error);
        return React.createElement('div', { className: 'p-6 text-red-600' }, 'Erreur lors du chargement');
    }
}

window.ValidationDemandes = ValidationDemandes;
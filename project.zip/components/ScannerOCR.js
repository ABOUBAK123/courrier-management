function ScannerOCR({ onClose, onDocumentScanned, mailType }) {
    try {
        const [scanning, setScanning] = React.useState(false);
        const [ocrResult, setOcrResult] = React.useState(null);
        const [scannedImage, setScannedImage] = React.useState(null);
        const [extractedData, setExtractedData] = React.useState({});
        const fileInputRef = React.useRef(null);

        const handleFileSelect = async (event) => {
            const file = event.target.files[0];
            if (!file) return;

            setScanning(true);
            const reader = new FileReader();
            reader.onload = async (e) => {
                setScannedImage(e.target.result);
                
                // Simulation OCR
                setTimeout(() => {
                    const mockOcrText = generateMockOCRText(mailType);
                    setOcrResult(mockOcrText);
                    
                    // Extraction intelligente des métadonnées
                    const extractedFromText = extractMetadataFromText(mockOcrText, mailType);
                    setExtractedData(extractedFromText);
                    
                    setScanning(false);
                }, 2000);
            };
            reader.readAsDataURL(file);
        };

        const saveScannedDocument = () => {
            const documentData = {
                image: scannedImage,
                ocrText: ocrResult,
                extractedData: extractedData,
                scanDate: new Date().toISOString()
            };
            
            if (onDocumentScanned) {
                onDocumentScanned(documentData);
            }
            
            alert('Document numérisé et sauvegardé avec succès !');
            onClose();
        };

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4'
        }, [
            React.createElement('div', {
                key: 'modal',
                className: 'bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[95vh] overflow-auto'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'bg-blue-600 text-white p-4 rounded-t-lg flex justify-between items-center'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-bold flex items-center'
                    }, [
                        React.createElement('i', { key: 'icon', className: 'fas fa-scanner mr-3' }),
                        `Scanner & OCR - ${mailType === 'arrive' ? 'Courrier Arrivé' : 'Courrier Départ'}`
                    ]),
                    React.createElement('button', {
                        key: 'close',
                        onClick: onClose,
                        className: 'text-white hover:text-gray-300'
                    }, React.createElement('i', { className: 'fas fa-times text-xl' }))
                ]),

                React.createElement('div', {
                    key: 'content',
                    className: 'p-6'
                }, [
                    React.createElement('div', {
                        key: 'upload-section',
                        className: 'mb-6'
                    }, [
                        React.createElement('input', {
                            key: 'file-input',
                            ref: fileInputRef,
                            type: 'file',
                            accept: 'image/*,.pdf',
                            onChange: handleFileSelect,
                            className: 'hidden'
                        }),
                        
                        React.createElement('div', {
                            key: 'upload-area',
                            className: 'border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer',
                            onClick: () => fileInputRef.current.click()
                        }, [
                            React.createElement('i', {
                                key: 'upload-icon',
                                className: 'fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4'
                            }),
                            React.createElement('p', {
                                key: 'upload-text',
                                className: 'text-gray-600 mb-2'
                            }, 'Cliquez pour sélectionner un document à scanner'),
                            React.createElement('p', {
                                key: 'formats',
                                className: 'text-sm text-gray-500'
                            }, 'Formats supportés: JPG, PNG, PDF')
                        ])
                    ]),

                    scanning && React.createElement('div', {
                        key: 'scanning',
                        className: 'text-center py-8'
                    }, [
                        React.createElement('div', {
                            key: 'spinner',
                            className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4'
                        }),
                        React.createElement('p', {
                            key: 'scanning-text',
                            className: 'text-gray-600 font-medium'
                        }, 'Analyse OCR en cours...')
                    ]),

                    scannedImage && !scanning && React.createElement('div', {
                        key: 'results',
                        className: 'grid grid-cols-1 lg:grid-cols-2 gap-6'
                    }, [
                        React.createElement('div', {
                            key: 'image-preview',
                            className: 'space-y-4'
                        }, [
                            React.createElement('h4', {
                                key: 'image-title',
                                className: 'font-bold text-gray-800'
                            }, 'Document numérisé'),
                            React.createElement('img', {
                                key: 'image',
                                src: scannedImage,
                                alt: 'Document scanné',
                                className: 'w-full border rounded-lg shadow-sm max-h-64 object-contain'
                            })
                        ]),

                        React.createElement('div', {
                            key: 'extracted-info',
                            className: 'space-y-4'
                        }, [
                            React.createElement('h4', {
                                key: 'info-title',
                                className: 'font-bold text-gray-800'
                            }, 'Métadonnées extraites'),
                            React.createElement('div', {
                                key: 'help-text',
                                className: 'text-sm text-blue-600 bg-blue-50 p-2 rounded'
                            }, '💡 Ces informations seront automatiquement remplies dans le formulaire'),
                            React.createElement('div', {
                                key: 'metadata',
                                className: 'space-y-3'
                            }, Object.entries(extractedData).map(([key, value]) =>
                                React.createElement('div', {
                                    key: key,
                                    className: 'flex flex-col'
                                }, [
                                    React.createElement('label', {
                                        key: 'label',
                                        className: 'text-sm font-medium text-gray-700 mb-1'
                                    }, getFieldLabel(key, mailType)),
                                    React.createElement('input', {
                                        key: 'input',
                                        type: 'text',
                                        value: value,
                                        onChange: (e) => setExtractedData(prev => ({...prev, [key]: e.target.value})),
                                        className: 'border rounded-md px-3 py-2 text-sm'
                                    })
                                ])
                            ))
                        ])
                    ]),

                    ocrResult && React.createElement('div', {
                        key: 'ocr-result',
                        className: 'mt-6'
                    }, [
                        React.createElement('h4', {
                            key: 'ocr-title',
                            className: 'font-bold text-gray-800 mb-3'
                        }, 'Texte reconnu par OCR'),
                        React.createElement('textarea', {
                            key: 'ocr-text',
                            value: ocrResult,
                            onChange: (e) => setOcrResult(e.target.value),
                            className: 'w-full h-32 border rounded-md p-3 text-sm resize-none',
                            placeholder: 'Le texte reconnu apparaîtra ici...'
                        })
                    ]),

                    scannedImage && React.createElement('div', {
                        key: 'actions',
                        className: 'mt-6 flex justify-end space-x-3'
                    }, [
                        React.createElement('button', {
                            key: 'cancel',
                            onClick: onClose,
                            className: 'px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50'
                        }, 'Annuler'),
                        React.createElement('button', {
                            key: 'save',
                            onClick: saveScannedDocument,
                            className: 'px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700'
                        }, [
                            React.createElement('i', { key: 'save-icon', className: 'fas fa-check mr-2' }),
                            'Appliquer au formulaire'
                        ])
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Erreur ScannerOCR:', error);
        return null;
    }
}
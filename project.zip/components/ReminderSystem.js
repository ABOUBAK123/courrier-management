function ReminderSystem({ onClose }) {
    try {
        const [reminders, setReminders] = React.useState([]);
        const [settings, setSettings] = React.useState({
            urgent: 1,
            normal: 3,
            routine: 7
        });
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            // Simulation de chargement des rappels
            setTimeout(() => {
                const mockReminders = [
                    {
                        id: 1,
                        courrier: 'Demande de subvention - Commune Rabat',
                        reference: 'DGC-2024-001',
                        dateReception: '2024-01-15',
                        delaiEcoule: 5,
                        priorite: 'Urgent',
                        service: 'Direction Générale',
                        status: 'En retard'
                    },
                    {
                        id: 2,
                        courrier: 'Rapport mensuel - Province Kenitra',
                        reference: 'RPT-2024-002',
                        dateReception: '2024-01-18',
                        delaiEcoule: 2,
                        priorite: 'Normal',
                        service: 'Service Administratif',
                        status: 'Attention'
                    }
                ];
                setReminders(mockReminders);
                setLoading(false);
            }, 1000);
        }, []);

        const sendReminder = (reminderId) => {
            alert('Rappel envoyé avec succès !');
            setReminders(prev => 
                prev.map(r => r.id === reminderId ? {...r, lastReminder: new Date().toISOString()} : r)
            );
        };

        const updateSettings = () => {
            alert('Paramètres de rappel sauvegardés !');
        };

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4'
        }, [
            React.createElement('div', {
                key: 'modal',
                className: 'bg-white rounded-lg shadow-2xl max-w-6xl w-full max-h-[95vh] overflow-auto'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'bg-orange-600 text-white p-4 rounded-t-lg flex justify-between items-center'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-bold flex items-center'
                    }, [
                        React.createElement('i', { key: 'icon', className: 'fas fa-bell mr-3' }),
                        'Système de Rappels Intelligents'
                    ]),
                    React.createElement('button', {
                        key: 'close',
                        onClick: onClose,
                        className: 'text-white hover:text-gray-300'
                    }, React.createElement('i', { className: 'fas fa-times text-xl' }))
                ]),

                React.createElement('div', {
                    key: 'content',
                    className: 'p-6'
                }, [
                    React.createElement('div', {
                        key: 'settings-section',
                        className: 'mb-6 bg-gray-50 p-4 rounded-lg'
                    }, [
                        React.createElement('h4', {
                            key: 'settings-title',
                            className: 'font-bold text-gray-800 mb-4'
                        }, 'Paramètres des délais de rappel (en jours)'),
                        React.createElement('div', {
                            key: 'settings-grid',
                            className: 'grid grid-cols-3 gap-4'
                        }, [
                            React.createElement('div', {
                                key: 'urgent-setting'
                            }, [
                                React.createElement('label', {
                                    key: 'urgent-label',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Courrier Urgent'),
                                React.createElement('input', {
                                    key: 'urgent-input',
                                    type: 'number',
                                    value: settings.urgent,
                                    onChange: (e) => setSettings(prev => ({...prev, urgent: parseInt(e.target.value)})),
                                    className: 'w-full border rounded-md px-3 py-2'
                                })
                            ]),
                            React.createElement('div', {
                                key: 'normal-setting'
                            }, [
                                React.createElement('label', {
                                    key: 'normal-label',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Courrier Normal'),
                                React.createElement('input', {
                                    key: 'normal-input',
                                    type: 'number',
                                    value: settings.normal,
                                    onChange: (e) => setSettings(prev => ({...prev, normal: parseInt(e.target.value)})),
                                    className: 'w-full border rounded-md px-3 py-2'
                                })
                            ]),
                            React.createElement('div', {
                                key: 'routine-setting'
                            }, [
                                React.createElement('label', {
                                    key: 'routine-label',
                                    className: 'block text-sm font-medium text-gray-700 mb-1'
                                }, 'Courrier Routine'),
                                React.createElement('input', {
                                    key: 'routine-input',
                                    type: 'number',
                                    value: settings.routine,
                                    onChange: (e) => setSettings(prev => ({...prev, routine: parseInt(e.target.value)})),
                                    className: 'w-full border rounded-md px-3 py-2'
                                })
                            ])
                        ]),
                        React.createElement('button', {
                            key: 'save-settings',
                            onClick: updateSettings,
                            className: 'mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700'
                        }, 'Sauvegarder les paramètres')
                    ]),

                    loading ? React.createElement('div', {
                        key: 'loading',
                        className: 'text-center py-8'
                    }, [
                        React.createElement('div', {
                            key: 'spinner',
                            className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4'
                        }),
                        React.createElement('p', {
                            key: 'loading-text',
                            className: 'text-gray-600'
                        }, 'Chargement des rappels...')
                    ]) : React.createElement('div', {
                        key: 'reminders-section'
                    }, [
                        React.createElement('h4', {
                            key: 'reminders-title',
                            className: 'font-bold text-gray-800 mb-4'
                        }, `Courriers nécessitant un rappel (${reminders.length})`),
                        
                        reminders.length === 0 ? React.createElement('div', {
                            key: 'no-reminders',
                            className: 'text-center py-8 text-gray-500'
                        }, 'Aucun courrier en retard') : React.createElement('div', {
                            key: 'reminders-table',
                            className: 'overflow-x-auto'
                        }, [
                            React.createElement('table', {
                                key: 'table',
                                className: 'w-full border border-gray-300 rounded-lg overflow-hidden'
                            }, [
                                React.createElement('thead', {
                                    key: 'thead',
                                    className: 'bg-gray-100'
                                }, [
                                    React.createElement('tr', {
                                        key: 'header-row'
                                    }, [
                                        'Référence', 'Courrier', 'Service', 'Priorité', 'Délai écoulé', 'Statut', 'Actions'
                                    ].map(header => 
                                        React.createElement('th', {
                                            key: header,
                                            className: 'px-4 py-3 text-left text-sm font-medium text-gray-700 border-b'
                                        }, header)
                                    ))
                                ]),
                                React.createElement('tbody', {
                                    key: 'tbody'
                                }, reminders.map(reminder => 
                                    React.createElement('tr', {
                                        key: reminder.id,
                                        className: 'hover:bg-gray-50'
                                    }, [
                                        React.createElement('td', {
                                            key: 'reference',
                                            className: 'px-4 py-3 text-sm border-b'
                                        }, reminder.reference),
                                        React.createElement('td', {
                                            key: 'courrier',
                                            className: 'px-4 py-3 text-sm border-b max-w-xs truncate'
                                        }, reminder.courrier),
                                        React.createElement('td', {
                                            key: 'service',
                                            className: 'px-4 py-3 text-sm border-b'
                                        }, reminder.service),
                                        React.createElement('td', {
                                            key: 'priorite',
                                            className: 'px-4 py-3 text-sm border-b'
                                        }, React.createElement('span', {
                                            className: `px-2 py-1 rounded text-xs ${
                                                reminder.priorite === 'Urgent' ? 'bg-red-100 text-red-800' :
                                                reminder.priorite === 'Normal' ? 'bg-yellow-100 text-yellow-800' :
                                                'bg-green-100 text-green-800'
                                            }`
                                        }, reminder.priorite)),
                                        React.createElement('td', {
                                            key: 'delai',
                                            className: 'px-4 py-3 text-sm border-b'
                                        }, `${reminder.delaiEcoule} jours`),
                                        React.createElement('td', {
                                            key: 'status',
                                            className: 'px-4 py-3 text-sm border-b'
                                        }, React.createElement('span', {
                                            className: `px-2 py-1 rounded text-xs ${
                                                reminder.status === 'En retard' ? 'bg-red-100 text-red-800' :
                                                'bg-orange-100 text-orange-800'
                                            }`
                                        }, reminder.status)),
                                        React.createElement('td', {
                                            key: 'actions',
                                            className: 'px-4 py-3 text-sm border-b'
                                        }, React.createElement('button', {
                                            onClick: () => sendReminder(reminder.id),
                                            className: 'bg-orange-600 text-white px-3 py-1 rounded text-xs hover:bg-orange-700'
                                        }, [
                                            React.createElement('i', { key: 'send-icon', className: 'fas fa-paper-plane mr-1' }),
                                            'Envoyer rappel'
                                        ]))
                                    ])
                                ))
                            ])
                        ])
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Erreur ReminderSystem:', error);
        return null;
    }
}
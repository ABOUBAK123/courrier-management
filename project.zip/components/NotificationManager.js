const NotificationManager = ({ userRole, userId }) => {
    const [notifications, setNotifications] = React.useState([]);
    const [unreadCount, setUnreadCount] = React.useState(0);

    React.useEffect(() => {
        loadNotifications();
        const interval = setInterval(loadNotifications, 30000); // Check every 30s
        return () => clearInterval(interval);
    }, [userRole, userId]);

    const loadNotifications = async () => {
        try {
            if (userRole === 'manager' || userRole === 'admin') {
                const response = await trickleListObjects('notification', 50, true);
                const userNotifications = response.items?.filter(notif => 
                    notif.objectData.targetUserId === userId || 
                    notif.objectData.targetRole === userRole
                ) || [];
                
                setNotifications(userNotifications);
                setUnreadCount(userNotifications.filter(n => !n.objectData.isRead).length);
            }
        } catch (error) {
            console.error('Erreur chargement notifications:', error);
        }
    };

    const markAsRead = async (notificationId) => {
        try {
            await trickleUpdateObject('notification', notificationId, { isRead: true });
            loadNotifications();
        } catch (error) {
            console.error('Erreur marquage notification:', error);
        }
    };

    const createNotification = async (type, message, targetUserId, targetRole) => {
        try {
            await trickleCreateObject('notification', {
                type,
                message,
                targetUserId,
                targetRole,
                isRead: false,
                createdAt: new Date().toISOString()
            });
        } catch (error) {
            console.error('Erreur création notification:', error);
        }
    };

    // Expose function globally for other components
    React.useEffect(() => {
        window.createNotification = createNotification;
    }, []);

    return React.createElement('div', {
        className: 'relative',
        'data-name': 'notification-manager',
        'data-file': 'components/NotificationManager.js'
    }, [
        React.createElement('button', {
            key: 'bell',
            className: 'relative p-2 text-gray-600 hover:text-gray-800',
            onClick: () => setNotifications(prev => prev.map(n => ({ ...n, showDropdown: !n.showDropdown })))
        }, [
            React.createElement('i', {
                key: 'icon',
                className: 'fas fa-bell text-xl'
            }),
            unreadCount > 0 && React.createElement('span', {
                key: 'badge',
                className: 'absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center'
            }, unreadCount)
        ]),

        notifications.length > 0 && React.createElement('div', {
            key: 'dropdown',
            className: 'absolute right-0 top-full mt-2 w-80 bg-white rounded-lg shadow-lg border z-50'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'p-4 border-b'
            }, React.createElement('h3', {
                className: 'font-semibold text-gray-800'
            }, 'Notifications')),
            React.createElement('div', {
                key: 'list',
                className: 'max-h-64 overflow-y-auto'
            }, notifications.slice(0, 5).map((notif, index) =>
                React.createElement('div', {
                    key: notif.objectId || index,
                    className: `p-3 border-b hover:bg-gray-50 cursor-pointer ${!notif.objectData.isRead ? 'bg-blue-50' : ''}`,
                    onClick: () => markAsRead(notif.objectId)
                }, [
                    React.createElement('p', {
                        key: 'message',
                        className: 'text-sm text-gray-800'
                    }, notif.objectData.message),
                    React.createElement('p', {
                        key: 'time',
                        className: 'text-xs text-gray-500 mt-1'
                    }, new Date(notif.createdAt).toLocaleDateString())
                ])
            ))
        ])
    ]);
};

window.NotificationManager = NotificationManager;
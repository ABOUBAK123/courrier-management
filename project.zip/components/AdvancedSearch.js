function AdvancedSearch({ user }) {
    try {
        const [filters, setFilters] = React.useState({
            searchTerm: '',
            type: 'tous',
            status: 'tous',
            priority: 'tous',
            dateFrom: '',
            dateTo: ''
        });
        const [results, setResults] = React.useState([]);
        const [loading, setLoading] = React.useState(false);

        const handleSearch = async () => {
            setLoading(true);
            try {
                const mails = await trickleListObjects(`mail:${user.direction}`, 100, true);
                let filtered = mails.items.map(item => ({ ...item.objectData, id: item.objectId }));

                if (filters.searchTerm) {
                    filtered = filtered.filter(m => 
                        m.objet.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
                        m.numero.toLowerCase().includes(filters.searchTerm.toLowerCase())
                    );
                }
                if (filters.type !== 'tous') {
                    filtered = filtered.filter(m => m.type === filters.type);
                }
                if (filters.status !== 'tous') {
                    filtered = filtered.filter(m => m.status === filters.status);
                }
                if (filters.priority !== 'tous') {
                    filtered = filtered.filter(m => m.priority === filters.priority);
                }
                if (filters.dateFrom) {
                    filtered = filtered.filter(m => m.date >= filters.dateFrom);
                }
                if (filters.dateTo) {
                    filtered = filtered.filter(m => m.date <= filters.dateTo);
                }

                setResults(filtered);
            } catch (error) {
                console.error('Erreur de recherche:', error);
            } finally {
                setLoading(false);
            }
        };

        const handleReset = () => {
            setFilters({
                searchTerm: '',
                type: 'tous',
                status: 'tous',
                priority: 'tous',
                dateFrom: '',
                dateTo: ''
            });
            setResults([]);
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'advanced-search',
            'data-file': 'components/AdvancedSearch.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Recherche Avancée'),
            React.createElement('div', {
                key: 'search-form',
                className: 'bg-white rounded-lg shadow-md p-6 mb-6'
            }, [
                React.createElement('div', {
                    key: 'form-grid',
                    className: 'grid grid-cols-1 md:grid-cols-3 gap-4 mb-4'
                }, [
                    React.createElement('input', {
                        key: 'search-input',
                        type: 'text',
                        placeholder: 'Rechercher...',
                        value: filters.searchTerm,
                        onChange: (e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value })),
                        className: 'px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    }),
                    React.createElement('select', {
                        key: 'type-select',
                        value: filters.type,
                        onChange: (e) => setFilters(prev => ({ ...prev, type: e.target.value })),
                        className: 'px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    }, [
                        React.createElement('option', { key: 'tous-types', value: 'tous' }, 'Tous les types'),
                        React.createElement('option', { key: 'arrive', value: 'arrive' }, 'Arrivés'),
                        React.createElement('option', { key: 'depart', value: 'depart' }, 'Départ')
                    ]),
                    React.createElement('select', {
                        key: 'status-select',
                        value: filters.status,
                        onChange: (e) => setFilters(prev => ({ ...prev, status: e.target.value })),
                        className: 'px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    }, [
                        React.createElement('option', { key: 'tous-status', value: 'tous' }, 'Tous les statuts'),
                        ...STATUSES.map(s => React.createElement('option', { key: s.value, value: s.value }, s.label))
                    ])
                ]),
                React.createElement('div', {
                    key: 'second-row',
                    className: 'grid grid-cols-1 md:grid-cols-3 gap-4 mb-4'
                }, [
                    React.createElement('select', {
                        key: 'priority-select',
                        value: filters.priority,
                        onChange: (e) => setFilters(prev => ({ ...prev, priority: e.target.value })),
                        className: 'px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    }, [
                        React.createElement('option', { key: 'tous-priorities', value: 'tous' }, 'Toutes priorités'),
                        ...PRIORITIES.map(p => React.createElement('option', { key: p.value, value: p.value }, p.label))
                    ]),
                    React.createElement('input', {
                        key: 'date-from',
                        type: 'date',
                        placeholder: 'Date début',
                        value: filters.dateFrom,
                        onChange: (e) => setFilters(prev => ({ ...prev, dateFrom: e.target.value })),
                        className: 'px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    }),
                    React.createElement('input', {
                        key: 'date-to',
                        type: 'date',
                        placeholder: 'Date fin',
                        value: filters.dateTo,
                        onChange: (e) => setFilters(prev => ({ ...prev, dateTo: e.target.value })),
                        className: 'px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    })
                ]),
                React.createElement('div', {
                    key: 'buttons',
                    className: 'flex space-x-4'
                }, [
                    React.createElement('button', {
                        key: 'search-btn',
                        onClick: handleSearch,
                        disabled: loading,
                        className: 'btn-primary text-white px-6 py-2 rounded-md font-medium disabled:opacity-50'
                    }, loading ? 'Recherche...' : 'Rechercher'),
                    React.createElement('button', {
                        key: 'reset-btn',
                        onClick: handleReset,
                        className: 'bg-gray-500 text-white px-6 py-2 rounded-md font-medium hover:bg-gray-600'
                    }, 'Réinitialiser')
                ])
            ]),
            results.length > 0 && React.createElement('div', {
                key: 'results',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('div', {
                    key: 'results-header',
                    className: 'px-6 py-4 bg-gray-50 border-b'
                }, [
                    React.createElement('h3', {
                        key: 'results-title',
                        className: 'text-lg font-semibold text-gray-800'
                    }, `Résultats de recherche (${results.length})`)
                ]),
                React.createElement('div', {
                    key: 'results-table',
                    className: 'overflow-x-auto'
                }, [
                    React.createElement('table', {
                        key: 'table',
                        className: 'w-full'
                    }, [
                        React.createElement('thead', {
                            key: 'thead',
                            className: 'bg-gray-50'
                        }, [
                            React.createElement('tr', { key: 'header-row' }, [
                                'Numéro', 'Objet', 'Type', 'Priorité', 'Statut', 'Date'
                            ].map(header => 
                                React.createElement('th', {
                                    key: header,
                                    className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                                }, header)
                            ))
                        ]),
                        React.createElement('tbody', {
                            key: 'tbody',
                            className: 'bg-white divide-y divide-gray-200'
                        }, results.map(mail =>
                            React.createElement('tr', {
                                key: mail.id,
                                className: 'hover:bg-gray-50'
                            }, [
                                React.createElement('td', {
                                    key: 'numero',
                                    className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                                }, mail.numero),
                                React.createElement('td', {
                                    key: 'objet',
                                    className: 'px-6 py-4 text-sm text-gray-900'
                                }, mail.objet),
                                React.createElement('td', {
                                    key: 'type',
                                    className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                                }, mail.type === 'arrive' ? 'Arrivé' : 'Départ'),
                                React.createElement('td', {
                                    key: 'priority',
                                    className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                                }, PRIORITIES.find(p => p.value === mail.priority)?.label),
                                React.createElement('td', {
                                    key: 'status',
                                    className: 'px-6 py-4 whitespace-nowrap'
                                }, [
                                    React.createElement('span', {
                                        key: 'status-badge',
                                        className: `px-2 py-1 text-xs font-medium rounded-full ${STATUSES.find(s => s.value === mail.status)?.color}`
                                    }, STATUSES.find(s => s.value === mail.status)?.label)
                                ]),
                                React.createElement('td', {
                                    key: 'date',
                                    className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                                }, mail.date)
                            ])
                        ))
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('AdvancedSearch component error:', error);
        reportError(error);
    }
}

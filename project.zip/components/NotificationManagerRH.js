function NotificationManagerRH({ user }) {
    const [notifications, setNotifications] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        loadNotifications();
        const interval = setInterval(loadNotifications, 30000); // Refresh toutes les 30s
        return () => clearInterval(interval);
    }, []);

    const loadNotifications = async () => {
        try {
            const result = await trickleListObjects('conge', 100, true);
            const demandesEnAttente = result.items.filter(item => 
                item.objectData.status === 'en_attente'
            );
            setNotifications(demandesEnAttente);
        } catch (error) {
            console.error('Erreur chargement notifications:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleApprove = async (congeId) => {
        try {
            const conge = notifications.find(n => n.objectId === congeId);
            await trickleUpdateObject('conge', congeId, { 
                status: 'approuve',
                approuvePar: user.nom,
                dateApprobation: new Date().toISOString()
            });
            
            // Envoyer notification email
            await window.EmailNotifications.sendApprovalNotification(conge, user);
            
            loadNotifications();
        } catch (error) {
            console.error('Erreur approbation:', error);
        }
    };

    const handleReject = async (congeId, motif) => {
        try {
            const conge = notifications.find(n => n.objectId === congeId);
            await trickleUpdateObject('conge', congeId, { 
                status: 'refuse',
                refusePar: user.nom,
                motifRefus: motif,
                dateRefus: new Date().toISOString()
            });
            
            // Envoyer notification email
            await window.EmailNotifications.sendRejectionNotification(conge, user, motif);
            
            loadNotifications();
        } catch (error) {
            console.error('Erreur refus:', error);
        }
    };

    if (loading) {
        return React.createElement('div', { className: 'p-4 text-center' }, 'Chargement...');
    }

    return React.createElement('div', {
        className: 'bg-white rounded-lg shadow-md p-6',
        'data-name': 'notification-manager-rh',
        'data-file': 'components/NotificationManagerRH.js'
    }, [
        React.createElement('div', {
            key: 'header',
            className: 'flex items-center justify-between mb-6'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-xl font-bold text-gray-800 flex items-center'
            }, [
                React.createElement('i', { key: 'icon', className: 'fas fa-bell mr-2 text-blue-600' }),
                'Demandes en attente',
                React.createElement('span', {
                    key: 'count',
                    className: 'ml-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full'
                }, notifications.length)
            ])
        ]),

        notifications.length === 0 ? 
            React.createElement('div', {
                key: 'empty',
                className: 'text-center py-8 text-gray-500'
            }, [
                React.createElement('i', { key: 'icon', className: 'fas fa-check-circle text-4xl mb-4 text-green-400' }),
                React.createElement('p', { key: 'text' }, 'Aucune demande en attente')
            ]) :
            React.createElement('div', {
                key: 'list',
                className: 'space-y-4'
            }, notifications.map(notif => 
                React.createElement('div', {
                    key: notif.objectId,
                    className: 'border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow'
                }, [
                    React.createElement('div', {
                        key: 'info',
                        className: 'flex justify-between items-start mb-3'
                    }, [
                        React.createElement('div', { key: 'details' }, [
                            React.createElement('h3', {
                                key: 'name',
                                className: 'font-semibold text-gray-800'
                            }, `${notif.objectData.prenom} ${notif.objectData.nom}`),
                            React.createElement('p', {
                                key: 'type',
                                className: 'text-sm text-blue-600'
                            }, notif.objectData.type),
                            React.createElement('p', {
                                key: 'dates',
                                className: 'text-sm text-gray-600'
                            }, `Du ${notif.objectData.dateDebut} au ${notif.objectData.dateFin}`)
                        ]),
                        React.createElement('span', {
                            key: 'badge',
                            className: 'bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded'
                        }, 'En attente')
                    ]),
                    React.createElement('div', {
                        key: 'actions',
                        className: 'flex space-x-2'
                    }, [
                        React.createElement('button', {
                            key: 'approve',
                            onClick: () => handleApprove(notif.objectId),
                            className: 'bg-green-600 text-white px-3 py-1 text-sm rounded hover:bg-green-700'
                        }, '✓ Approuver'),
                        React.createElement('button', {
                            key: 'reject',
                            onClick: () => {
                                const motif = prompt('Motif du refus:');
                                if (motif) handleReject(notif.objectId, motif);
                            },
                            className: 'bg-red-600 text-white px-3 py-1 text-sm rounded hover:bg-red-700'
                        }, '✗ Refuser')
                    ])
                ])
            ))
    ]);
}

window.NotificationManagerRH = NotificationManagerRH;
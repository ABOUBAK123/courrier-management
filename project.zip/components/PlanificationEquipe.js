function PlanificationEquipe() {
    const [currentDate, setCurrentDate] = React.useState(new Date());
    const [absences, setAbsences] = React.useState([]);
    const [personnel, setPersonnel] = React.useState([]);
    const [conflicts, setConflicts] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        loadData();
    }, [currentDate]);

    const loadData = async () => {
        try {
            await Promise.all([
                loadAbsences(),
                loadPersonnel()
            ]);
            detectConflicts();
        } catch (error) {
            console.error('Erreur chargement données:', error);
        } finally {
            setLoading(false);
        }
    };

    const loadAbsences = async () => {
        try {
            const result = await trickleListObjects('conge', 300, true);
            const absencesApprouvees = result.items.filter(conge => 
                conge.objectData.status === 'approuve'
            );
            setAbsences(absencesApprouvees);
        } catch (error) {
            console.error('Erreur chargement absences:', error);
        }
    };

    const loadPersonnel = async () => {
        try {
            const result = await trickleListObjects('personnel', 200, true);
            setPersonnel(result.items);
        } catch (error) {
            console.error('Erreur chargement personnel:', error);
        }
    };

    const detectConflicts = () => {
        const conflictsFound = [];
        const departements = {};

        // Grouper par département
        personnel.forEach(emp => {
            const dept = emp.objectData.departement || 'Non défini';
            if (!departements[dept]) departements[dept] = [];
            departements[dept].push(emp);
        });

        // Vérifier les conflits par département
        Object.keys(departements).forEach(dept => {
            const empsDept = departements[dept];
            const absencesDept = absences.filter(abs => 
                empsDept.some(emp => emp.objectId === abs.objectData.employeId)
            );

            // Détecter les chevauchements
            absencesDept.forEach((abs1, i) => {
                absencesDept.slice(i + 1).forEach(abs2 => {
                    if (hasOverlap(abs1, abs2)) {
                        conflictsFound.push({
                            departement: dept,
                            absence1: abs1,
                            absence2: abs2
                        });
                    }
                });
            });
        });

        setConflicts(conflictsFound);
    };

    const hasOverlap = (abs1, abs2) => {
        const start1 = new Date(abs1.objectData.dateDebut);
        const end1 = new Date(abs1.objectData.dateFin);
        const start2 = new Date(abs2.objectData.dateDebut);
        const end2 = new Date(abs2.objectData.dateFin);

        return start1 <= end2 && start2 <= end1;
    };

    const getDaysInMonth = () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const days = [];
        
        // Ajouter les jours vides du début
        const startPadding = (firstDay.getDay() + 6) % 7; // Lundi = 0
        for (let i = 0; i < startPadding; i++) {
            const paddingDay = new Date(firstDay);
            paddingDay.setDate(firstDay.getDate() - startPadding + i);
            days.push({ date: paddingDay, isCurrentMonth: false });
        }

        // Ajouter les jours du mois
        for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
            days.push({ date: new Date(d), isCurrentMonth: true });
        }

        return days;
    };

    const getAbsencesForDay = (date) => {
        return absences.filter(abs => {
            const start = new Date(abs.objectData.dateDebut);
            const end = new Date(abs.objectData.dateFin);
            return date >= start && date <= end;
        });
    };

    if (loading) {
        return React.createElement('div', {
            className: 'flex items-center justify-center h-64'
        }, 'Chargement...');
    }

    return React.createElement('div', {
        className: 'space-y-6',
        'data-name': 'planification-equipe',
        'data-file': 'components/PlanificationEquipe.js'
    }, [
        // Header avec navigation
        React.createElement('div', {
            key: 'header',
            className: 'flex justify-between items-center'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-xl font-semibold'
            }, 'Planification d\'équipe'),
            React.createElement('div', {
                key: 'nav',
                className: 'flex items-center space-x-4'
            }, [
                React.createElement('button', {
                    key: 'prev',
                    onClick: () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1)),
                    className: 'px-3 py-1 bg-gray-200 rounded'
                }, '← Précédent'),
                React.createElement('span', {
                    key: 'current',
                    className: 'font-medium'
                }, currentDate.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })),
                React.createElement('button', {
                    key: 'next',
                    onClick: () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1)),
                    className: 'px-3 py-1 bg-gray-200 rounded'
                }, 'Suivant →')
            ])
        ]),

        // Alertes conflits
        conflicts.length > 0 && React.createElement('div', {
            key: 'conflicts',
            className: 'bg-red-50 border border-red-200 rounded-lg p-4'
        }, [
            React.createElement('h3', {
                key: 'title',
                className: 'text-red-800 font-semibold mb-2'
            }, `⚠️ ${conflicts.length} conflit(s) détecté(s)`),
            React.createElement('div', {
                key: 'list',
                className: 'space-y-2'
            }, conflicts.map((conflict, index) =>
                React.createElement('div', {
                    key: index,
                    className: 'text-sm text-red-700'
                }, `${conflict.departement}: Chevauchement entre ${conflict.absence1.objectData.prenom} et ${conflict.absence2.objectData.prenom}`)
            ))
        ]),

        // Calendrier
        React.createElement('div', {
            key: 'calendar',
            className: 'bg-white rounded-lg shadow overflow-hidden'
        }, [
            // En-tête jours
            React.createElement('div', {
                key: 'header-days',
                className: 'grid grid-cols-7 bg-gray-50'
            }, ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(day =>
                React.createElement('div', {
                    key: day,
                    className: 'p-3 text-center font-medium text-gray-700'
                }, day)
            )),

            // Grille calendrier
            React.createElement('div', {
                key: 'grid',
                className: 'grid grid-cols-7'
            }, getDaysInMonth().map(dayObj => {
                const day = dayObj.date;
                const dayAbsences = getAbsencesForDay(day);
                return React.createElement('div', {
                    key: day.toISOString(),
                    className: `min-h-24 p-2 border-b border-r border-gray-200 ${
                        !dayObj.isCurrentMonth ? 'bg-gray-50 text-gray-400' : ''
                    }`
                }, [
                    React.createElement('div', {
                        key: 'date',
                        className: 'text-sm font-medium mb-1'
                    }, day.getDate()),
                    React.createElement('div', {
                        key: 'absences',
                        className: 'space-y-1'
                    }, dayAbsences.slice(0, 3).map(abs =>
                        React.createElement('div', {
                            key: abs.objectId,
                            className: 'text-xs bg-blue-100 text-blue-800 px-1 py-0.5 rounded truncate',
                            title: `${abs.objectData.prenom} ${abs.objectData.nom} - ${abs.objectData.type}`
                        }, `${abs.objectData.prenom} ${abs.objectData.nom.charAt(0)}.`)
                    )),
                    dayAbsences.length > 3 && React.createElement('div', {
                        key: 'more',
                        className: 'text-xs text-gray-500'
                    }, `+${dayAbsences.length - 3} autres`)
                ]);
            }))
        ])
    ]);
}

window.PlanificationEquipe = PlanificationEquipe;
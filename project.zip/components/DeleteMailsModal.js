function DeleteMailsModal({ isOpen, onClose, onConfirm, isDeleting }) {
    try {
        if (!isOpen) return null;

        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" data-name="delete-mails-modal" data-file="components/DeleteMailsModal.js">
                <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                    <div className="flex items-center mb-4">
                        <i className="fas fa-exclamation-triangle text-red-500 text-2xl mr-3"></i>
                        <h3 className="text-lg font-semibold text-gray-900">Confirmation de suppression</h3>
                    </div>
                    
                    <div className="mb-6">
                        <p className="text-gray-700 mb-2">
                            <strong>Attention :</strong> Vous êtes sur le point de supprimer TOUS les courriers numérotés de toutes les directions.
                        </p>
                        <p className="text-red-600 font-medium">
                            Cette action est irréversible et supprimera définitivement tous les courriers ayant un numéro (format A-XXXX ou D-XXXX).
                        </p>
                    </div>
                    
                    <div className="flex justify-end space-x-3">
                        <button
                            onClick={onClose}
                            disabled={isDeleting}
                            className="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 transition-colors disabled:opacity-50"
                        >
                            Annuler
                        </button>
                        <button
                            onClick={onConfirm}
                            disabled={isDeleting}
                            className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors disabled:opacity-50"
                        >
                            {isDeleting ? (
                                <>
                                    <i className="fas fa-spinner fa-spin mr-2"></i>
                                    Suppression...
                                </>
                            ) : (
                                <>
                                    <i className="fas fa-trash mr-2"></i>
                                    Supprimer tous
                                </>
                            )}
                        </button>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('DeleteMailsModal error:', error);
        return null;
    }
}
function ProfilUtilisateur({ user }) {
    try {
        const [formData, setFormData] = React.useState({
            currentPassword: '',
            newPassword: '',
            confirmPassword: '',
            photo: null,
            photoPreview: user?.photo || null
        });
        const [loading, setLoading] = React.useState(false);
        const [activeTab, setActiveTab] = React.useState('info');

        const handlePhotoChange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    setFormData(prev => ({
                        ...prev,
                        photo: file,
                        photoPreview: event.target.result
                    }));
                };
                reader.readAsDataURL(file);
            }
        };

        const handlePasswordChange = async (e) => {
            e.preventDefault();
            if (formData.newPassword !== formData.confirmPassword) {
                alert('Les nouveaux mots de passe ne correspondent pas');
                return;
            }

            setLoading(true);
            try {
                const users = await trickleListObjects('user', 100, true);
                const currentUser = users.items.find(u => u.objectData.email === user.email);
                
                if (currentUser.objectData.password !== formData.currentPassword) {
                    alert('Mot de passe actuel incorrect');
                    return;
                }

                await trickleUpdateObject('user', currentUser.objectId, {
                    ...currentUser.objectData,
                    password: formData.newPassword,
                    updatedAt: new Date().toISOString()
                });

                alert('Mot de passe modifié avec succès!');
                setFormData(prev => ({
                    ...prev,
                    currentPassword: '',
                    newPassword: '',
                    confirmPassword: ''
                }));
            } catch (error) {
                alert('Erreur lors de la modification du mot de passe');
            } finally {
                setLoading(false);
            }
        };

        const handlePhotoSave = async () => {
            if (!formData.photo) return;

            setLoading(true);
            try {
                const users = await trickleListObjects('user', 100, true);
                const currentUser = users.items.find(u => u.objectData.email === user.email);

                await trickleUpdateObject('user', currentUser.objectId, {
                    ...currentUser.objectData,
                    photo: formData.photoPreview,
                    updatedAt: new Date().toISOString()
                });

                alert('Photo de profil mise à jour avec succès!');
                
                // Mettre à jour l'utilisateur dans le localStorage
                const updatedUser = { ...user, photo: formData.photoPreview };
                localStorage.setItem('currentUser', JSON.stringify(updatedUser));
                
                // Recharger la page pour mettre à jour l'avatar dans le header
                window.location.reload();
            } catch (error) {
                alert('Erreur lors de la mise à jour de la photo');
            } finally {
                setLoading(false);
            }
        };

        const tabs = [
            { id: 'info', label: 'Informations', icon: 'fas fa-info-circle' },
            { id: 'photo', label: 'Photo', icon: 'fas fa-camera' },
            { id: 'password', label: 'Mot de passe', icon: 'fas fa-lock' }
        ];

        return React.createElement('div', {
            className: 'p-6 fade-in max-w-4xl mx-auto',
            'data-name': 'profil-utilisateur',
            'data-file': 'components/ProfilUtilisateur.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Mon Profil'),
            React.createElement('div', {
                key: 'tabs',
                className: 'flex border-b border-gray-200 mb-6'
            }, tabs.map(tab =>
                React.createElement('button', {
                    key: tab.id,
                    onClick: () => setActiveTab(tab.id),
                    className: `flex items-center px-6 py-3 text-sm font-medium transition-colors ${
                        activeTab === tab.id
                            ? 'border-b-2 border-blue-600 text-blue-600'
                            : 'text-gray-600 hover:text-gray-800'
                    }`
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: `${tab.icon} mr-2`
                    }),
                    tab.label
                ])
            )),
            React.createElement('div', {
                key: 'content',
                className: 'bg-white rounded-lg shadow-md p-6'
            }, [
                activeTab === 'info' && React.createElement('div', {
                    key: 'info-content',
                    className: 'space-y-4'
                }, [
                    React.createElement('div', {
                        key: 'info-grid',
                        className: 'grid grid-cols-1 md:grid-cols-2 gap-6'
                    }, [
                        React.createElement('div', { key: 'name-field' }, [
                            React.createElement('label', {
                                key: 'name-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Nom complet'),
                            React.createElement('input', {
                                key: 'name-input',
                                type: 'text',
                                value: user?.name || '',
                                readOnly: true,
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50'
                            })
                        ]),
                        React.createElement('div', { key: 'email-field' }, [
                            React.createElement('label', {
                                key: 'email-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Email'),
                            React.createElement('input', {
                                key: 'email-input',
                                type: 'email',
                                value: user?.email || '',
                                readOnly: true,
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50'
                            })
                        ]),
                        React.createElement('div', { key: 'role-field' }, [
                            React.createElement('label', {
                                key: 'role-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Rôle'),
                            React.createElement('input', {
                                key: 'role-input',
                                type: 'text',
                                value: user?.role || '',
                                readOnly: true,
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50'
                            })
                        ]),
                        React.createElement('div', { key: 'direction-field' }, [
                            React.createElement('label', {
                                key: 'direction-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Direction'),
                            React.createElement('input', {
                                key: 'direction-input',
                                type: 'text',
                                value: user?.direction || '',
                                readOnly: true,
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50'
                            })
                        ])
                    ])
                ]),
                activeTab === 'photo' && React.createElement('div', {
                    key: 'photo-content',
                    className: 'flex flex-col items-center space-y-6'
                }, [
                    React.createElement('div', {
                        key: 'photo-preview',
                        className: 'w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden'
                    }, formData.photoPreview ? 
                        React.createElement('img', {
                            key: 'photo-img',
                            src: formData.photoPreview,
                            alt: 'Photo de profil',
                            className: 'w-full h-full object-cover'
                        }) :
                        React.createElement('i', {
                            key: 'photo-icon',
                            className: 'fas fa-user text-4xl text-gray-400'
                        })
                    ),
                    React.createElement('input', {
                        key: 'photo-input',
                        type: 'file',
                        accept: 'image/*',
                        onChange: handlePhotoChange,
                        className: 'hidden',
                        id: 'photo-upload'
                    }),
                    React.createElement('label', {
                        key: 'photo-label',
                        htmlFor: 'photo-upload',
                        className: 'bg-blue-600 text-white px-6 py-3 rounded-lg cursor-pointer hover:bg-blue-700 transition-colors'
                    }, 'Choisir une photo'),
                    formData.photo && React.createElement('button', {
                        key: 'save-photo',
                        onClick: handlePhotoSave,
                        disabled: loading,
                        className: 'bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors'
                    }, loading ? 'Sauvegarde...' : 'Sauvegarder la photo')
                ]),
                activeTab === 'password' && React.createElement('form', {
                    key: 'password-form',
                    onSubmit: handlePasswordChange,
                    className: 'space-y-6 max-w-md mx-auto'
                }, [
                    React.createElement('div', { key: 'current-password-field' }, [
                        React.createElement('label', {
                            key: 'current-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Mot de passe actuel'),
                        React.createElement('input', {
                            key: 'current-input',
                            type: 'password',
                            value: formData.currentPassword,
                            onChange: (e) => setFormData(prev => ({ ...prev, currentPassword: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                            required: true
                        })
                    ]),
                    React.createElement('div', { key: 'new-password-field' }, [
                        React.createElement('label', {
                            key: 'new-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Nouveau mot de passe'),
                        React.createElement('input', {
                            key: 'new-input',
                            type: 'password',
                            value: formData.newPassword,
                            onChange: (e) => setFormData(prev => ({ ...prev, newPassword: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                            required: true
                        })
                    ]),
                    React.createElement('div', { key: 'confirm-password-field' }, [
                        React.createElement('label', {
                            key: 'confirm-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Confirmer le nouveau mot de passe'),
                        React.createElement('input', {
                            key: 'confirm-input',
                            type: 'password',
                            value: formData.confirmPassword,
                            onChange: (e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                            required: true
                        })
                    ]),
                    React.createElement('button', {
                        key: 'submit-password',
                        type: 'submit',
                        disabled: loading,
                        className: 'w-full bg-blue-600 text-white py-3 rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors'
                    }, loading ? 'Modification...' : 'Modifier le mot de passe')
                ])
            ])
        ]);
    } catch (error) {
        console.error('ProfilUtilisateur component error:', error);
        reportError(error);
    }
}

const EspaceAgent = ({ embedded = false, user = null }) => {
    const [activeTab, setActiveTab] = React.useState('profil');
    const [agent, setAgent] = React.useState(null);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        loadAgentData();
    }, [user]);

    const loadAgentData = async () => {
        try {
            if (user) {
                // Utiliser directement les informations de l'utilisateur connecté
                let agentData = {
                    ...user,
                    matricule: user.matricule || user.username || 'N/A',
                    nom: user.name ? user.name.split(' ').pop() : 'Non défini',
                    prenom: user.name ? user.name.split(' ')[0] : 'Non défini',
                    email: user.email || 'Non défini',
                    direction: user.direction || 'Non définie',
                    role: user.role || 'Agent'
                };

                // Essayer de récupérer des informations supplémentaires depuis la base personnel
                try {
                    let personnelRecord = null;
                    
                    // Essayer d'abord avec l'ID direct
                    try {
                        personnelRecord = await trickleGetObject('personnel', user.objectId || user.id);
                    } catch (directError) {
                        // Si pas trouvé, chercher dans la liste
                        const personnelResponse = await trickleListObjects('personnel', 100, true);
                        personnelRecord = personnelResponse.items.find(item => 
                            item.objectData.email === user.email ||
                            item.objectData.matricule === user.matricule ||
                            (user.name && item.objectData.nom === user.name.split(' ').pop())
                        );
                    }
                    
                    if (personnelRecord) {
                        agentData = {
                            ...agentData,
                            ...personnelRecord.objectData,
                            objectId: personnelRecord.objectId
                        };
                    } else {
                        // Créer les données personnel si elles n'existent pas
                        const donneesPersonnel = {
                            matricule: user.matricule || user.username || 'N/A',
                            nom: user.name ? user.name.split(' ').pop() : 'Nom',
                            prenom: user.name ? user.name.split(' ')[0] : 'Prénom',
                            email: user.email,
                            direction: user.direction || 'DIR001',
                            direction_id: user.direction || 'DIR001',
                            grade: user.grade || 'Agent',
                            poste: user.poste || 'Agent',
                            statut: 'actif',
                            solde_conges: 30
                        };
                        
                        const nouveauPersonnel = await trickleCreateObject('personnel', donneesPersonnel);
                        agentData = {
                            ...agentData,
                            ...donneesPersonnel,
                            objectId: nouveauPersonnel.objectId
                        };
                    }
                } catch (error) {
                    console.log('Erreur gestion données personnel:', error);
                }
                
                setAgent(agentData);
            }
        } catch (error) {
            console.error('Erreur chargement agent:', error);
            setAgent(user || null);
        } finally {
            setLoading(false);
        }
    };

    try {
        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-xl font-bold mb-4'
                }, 'Espace Agent'),
                React.createElement('p', {
                    key: 'msg',
                    className: 'text-gray-600'
                }, 'Chargement...')
            ]);
        }

        if (!agent) {
            return React.createElement('div', {
                className: 'p-6 text-center'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-xl font-bold mb-4'
                }, 'Espace Agent'),
                React.createElement('p', {
                    key: 'msg',
                    className: 'text-red-600'
                }, 'Aucune information agent disponible')
            ]);
        }

        return React.createElement('div', {
            className: 'min-h-screen bg-gray-50'
        }, [
            // Header
            React.createElement('div', {
                key: 'header',
                className: 'bg-white shadow-sm border-b p-4'
            }, [
                React.createElement('h1', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-900'
                }, 'Espace Agent'),
                React.createElement('p', {
                    key: 'subtitle',
                    className: 'text-sm text-gray-600'
                }, `${agent.prenom} ${agent.nom} - ${agent.matricule}`)
            ]),

            // Navigation
            React.createElement('div', {
                key: 'nav',
                className: 'bg-white border-b p-4'
            }, [
                React.createElement('div', {
                    key: 'nav-buttons',
                    className: 'flex flex-wrap gap-2'
                }, [
                    { id: 'profil', label: 'Profil' },
                    { id: 'conges', label: 'Congés' },
                    { id: 'formations', label: 'Formations' },
                    { id: 'documents', label: 'Documents' },
                    { id: 'cv', label: 'CV' }
                ].map(tab => 
                    React.createElement('button', {
                        key: tab.id,
                        onClick: () => setActiveTab(tab.id),
                        className: `px-4 py-2 rounded-md text-sm font-medium ${
                            activeTab === tab.id
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`
                    }, tab.label)
                ))
            ]),

            // Content
            React.createElement('div', {
                key: 'content',
                className: 'p-6'
            }, [
                activeTab === 'profil' && React.createElement('div', {
                    key: 'profil-content',
                    className: 'space-y-6'
                }, [
                    React.createElement(InfoPersonnelle, {
                        key: 'info-personnelle',
                        agent: agent
                    }),
                    React.createElement(InfoProfessionnelle, {
                        key: 'info-professionnelle',
                        agent: agent
                    })
                ]),
                
                activeTab === 'cv' && React.createElement(CVAgent, {
                    key: 'cv-component',
                    agent: agent
                }),

                activeTab === 'conges' && React.createElement(CongesAgent, {
                    key: 'conges-component',
                    agent: agent
                }),

                (activeTab === 'formations' || activeTab === 'documents') && 
                React.createElement('div', {
                    key: 'other-content',
                    className: 'bg-white rounded-lg shadow p-6'
                }, [
                    React.createElement('h2', {
                        key: 'title',
                        className: 'text-xl font-bold mb-4'
                    }, activeTab === 'formations' ? 'Mes Formations' : 'Mes Documents'),
                    React.createElement('p', {
                        key: 'msg',
                        className: 'text-gray-600'
                    }, 'Module en cours de développement...')
                ])
            ])
        ]);

    } catch (error) {
        console.error('EspaceAgent component error:', error);
        return React.createElement('div', {
            className: 'p-6 text-center text-red-600'
        }, 'Erreur lors du chargement de l\'espace agent');
    }
};

window.EspaceAgent = EspaceAgent;
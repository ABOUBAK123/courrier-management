function ValidationCongePanel({ user }) {
    const [demandes, setDemandes] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [filter, setFilter] = React.useState('enAttente');

    React.useEffect(() => {
        chargerDemandes();
    }, [filter]);

    const chargerDemandes = async () => {
        try {
            setLoading(true);
            const response = await fetch(`api/conges.php?action=getDemandesValidation&validateur=${user.id}&statut=${filter}`);
            if (response.ok) {
                const data = await response.json();
                setDemandes(data);
            }
        } catch (error) {
            console.error('Erreur chargement demandes:', error);
        } finally {
            setLoading(false);
        }
    };

    const validerDemande = async (demandeId, action, commentaire = '') => {
        try {
            const response = await fetch('api/conges.php?action=validerDemande', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    demandeId,
                    action,
                    validateurId: user.id,
                    commentaire
                })
            });

            if (response.ok) {
                chargerDemandes();
            }
        } catch (error) {
            console.error('Erreur validation:', error);
        }
    };

    const deleguerValidation = async (demandeId, nouvelValidateur) => {
        try {
            const response = await fetch('api/conges.php?action=deleguerValidation', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    demandeId,
                    ancienValidateur: user.id,
                    nouvelValidateur
                })
            });

            if (response.ok) {
                chargerDemandes();
            }
        } catch (error) {
            console.error('Erreur délégation:', error);
        }
    };

    return (
        <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">Validation des Congés</h2>
                <select 
                    value={filter} 
                    onChange={(e) => setFilter(e.target.value)}
                    className="border rounded px-3 py-2"
                >
                    <option value="enAttente">En attente</option>
                    <option value="validees">Validées</option>
                    <option value="rejetees">Rejetées</option>
                    <option value="toutes">Toutes</option>
                </select>
            </div>

            {loading ? (
                <div className="text-center py-8">Chargement...</div>
            ) : (
                <div className="space-y-4">
                    {demandes.map((demande) => (
                        <div key={demande.id} className="border rounded-lg p-4">
                            <div className="flex justify-between items-start mb-3">
                                <div>
                                    <h3 className="font-semibold">{demande.utilisateurNom}</h3>
                                    <p className="text-sm text-gray-600">{demande.typeConge}</p>
                                </div>
                                <span className={`px-2 py-1 rounded text-sm ${
                                    demande.statut === 'EN_ATTENTE' ? 'bg-yellow-100 text-yellow-800' :
                                    demande.statut === 'VALIDEE' ? 'bg-green-100 text-green-800' :
                                    'bg-red-100 text-red-800'
                                }`}>
                                    {demande.statut}
                                </span>
                            </div>

                            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                                <div>
                                    <span className="font-medium">Dates:</span> {demande.dateDebut} - {demande.dateFin}
                                </div>
                                <div>
                                    <span className="font-medium">Durée:</span> {demande.dureeJours} jour(s)
                                </div>
                                <div>
                                    <span className="font-medium">Niveau validation:</span> {demande.niveauValidation}
                                </div>
                                <div>
                                    <span className="font-medium">Solde restant:</span> {demande.soldeRestant} jours
                                </div>
                            </div>

                            {demande.motif && (
                                <div className="mb-4">
                                    <span className="font-medium">Motif:</span>
                                    <p className="text-gray-700 mt-1">{demande.motif}</p>
                                </div>
                            )}

                            {demande.statut === 'EN_ATTENTE' && (
                                <div className="flex gap-2 pt-3 border-t">
                                    <button
                                        onClick={() => validerDemande(demande.id, 'approuver')}
                                        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 flex items-center"
                                    >
                                        <i className="fas fa-check mr-2"></i>
                                        Approuver
                                    </button>
                                    <button
                                        onClick={() => {
                                            const commentaire = prompt('Motif de refus (optionnel):');
                                            if (commentaire !== null) {
                                                validerDemande(demande.id, 'rejeter', commentaire);
                                            }
                                        }}
                                        className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 flex items-center"
                                    >
                                        <i className="fas fa-times mr-2"></i>
                                        Refuser
                                    </button>
                                    <button
                                        onClick={() => {
                                            const delegue = prompt('Email du délégué:');
                                            if (delegue) {
                                                deleguerValidation(demande.id, delegue);
                                            }
                                        }}
                                        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 flex items-center"
                                    >
                                        <i className="fas fa-user-plus mr-2"></i>
                                        Déléguer
                                    </button>
                                </div>
                            )}
                        </div>
                    ))}

                    {demandes.length === 0 && (
                        <div className="text-center py-8 text-gray-500">
                            Aucune demande à valider
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

window.ValidationCongePanel = ValidationCongePanel;
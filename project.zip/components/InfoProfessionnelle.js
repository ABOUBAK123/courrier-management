function InfoProfessionnelle({ agent, readOnly = true }) {
    try {
        const [editMode, setEditMode] = React.useState(false);
        const [directions, setDirections] = React.useState([]);
        const [formData, setFormData] = React.useState({
            matricule: agent?.matricule || '',
            directionGenerale: agent?.directionGenerale || '',
            directionCentrale: agent?.directionCentrale || '',
            sousDirection: agent?.sousDirection || '',
            service: agent?.service || '',
            categorie: agent?.categorie || '',
            grade: agent?.grade || '',
            emploi: agent?.emploi || '',
            lieuTravail: agent?.lieuTravail || '',
            dateEmbauche: agent?.dateEmbauche || ''
        });

        React.useEffect(() => {
            loadDirections();
        }, []);

        const loadDirections = async () => {
            try {
                const response = await trickleListObjects('directions', 100, true);
                const directionData = response.items.map(item => item.objectData);
                setDirections(directionData);
            } catch (error) {
                console.error('Erreur lors du chargement des directions:', error);
            }
        };

        const getDirectionsByType = (type) => {
            return directions.filter(dir => dir.typeDirection === type);
        };

        const handleInputChange = (field, value) => {
            setFormData(prev => ({ ...prev, [field]: value }));
        };

        const handleSave = async () => {
            try {
                // Validation basique
                if (!formData.matricule) {
                    alert('Le matricule est obligatoire');
                    return;
                }

                await trickleUpdateObject(`agent-pro:${agent.matricule}`, agent.matricule, formData);
                setEditMode(false);
                alert('Informations professionnelles mises à jour avec succès');
            } catch (error) {
                // Si l'objet n'existe pas, le créer
                try {
                    await trickleCreateObject(`agent-pro:${agent.matricule}`, formData);
                    setEditMode(false);
                    alert('Informations professionnelles créées avec succès');
                } catch (createError) {
                    alert('Erreur lors de la mise à jour');
                }
            }
        };

        const fields = [
            { key: 'matricule', label: 'Matricule', type: 'text', required: true, readonly: true },
            { 
                key: 'directionGenerale', 
                label: 'Direction Générale', 
                type: 'select', 
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('DIRECTION GENERAL').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            { 
                key: 'directionCentrale', 
                label: 'Direction Centrale', 
                type: 'select', 
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('DIRECTION').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            { 
                key: 'sousDirection', 
                label: 'Sous-Direction', 
                type: 'select', 
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('SOUS-DIRECTION').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            { 
                key: 'service', 
                label: 'Service', 
                type: 'select', 
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('SERVICES').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            { 
                key: 'categorie', 
                label: 'Catégorie', 
                type: 'select', 
                options: [
                    { value: '', label: 'Sélectionner' },
                    { value: 'A', label: 'Catégorie A' },
                    { value: 'B', label: 'Catégorie B' },
                    { value: 'C', label: 'Catégorie C' },
                    { value: 'D', label: 'Catégorie D' }
                ]
            },
            { 
                key: 'grade', 
                label: 'Grade', 
                type: 'select', 
                options: [
                    { value: '', label: 'Sélectionner' },
                    { value: 'DIRECTEUR', label: 'Directeur' },
                    { value: 'SOUS-DIRECTEUR', label: 'Sous-Directeur' },
                    { value: 'CHEF DE SERVICE', label: 'Chef de Service' },
                    { value: 'CHEF DE BUREAU', label: 'Chef de Bureau' },
                    { value: 'INGENIEUR', label: 'Ingénieur' },
                    { value: 'TECHNICIEN', label: 'Technicien' },
                    { value: 'ASSISTANT', label: 'Assistant' },
                    { value: 'AGENT', label: 'Agent' }
                ]
            },
            { key: 'emploi', label: 'Emploi', type: 'text' },
            { key: 'lieuTravail', label: 'Lieu de Travail', type: 'text' },
            { key: 'dateEmbauche', label: 'Date d\'embauche', type: 'date', required: true, readonly: true }
        ];

        return React.createElement('div', {
            className: 'bg-white rounded-lg shadow-md',
            'data-name': 'info-professionnelle',
            'data-file': 'components/InfoProfessionnelle.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'px-6 py-4 border-b border-gray-200 flex justify-between items-center'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-medium text-gray-900'
                }, 'Informations Professionnelles'),
                !readOnly && React.createElement('button', {
                    key: 'edit-btn',
                    onClick: () => editMode ? handleSave() : setEditMode(true),
                    className: `px-3 py-1 rounded text-sm ${
                        editMode ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`
                }, editMode ? 'Enregistrer' : 'Modifier'),
                
                readOnly && React.createElement('div', {
                    key: 'readonly-notice',
                    className: 'text-sm text-gray-500 bg-gray-50 px-3 py-1 rounded'
                }, '🔒 Lecture seule - Contactez les RH pour modifications')
            ]),
            React.createElement('div', {
                key: 'content',
                className: 'p-6'
            }, [
                React.createElement('div', {
                    key: 'form',
                    className: 'grid grid-cols-1 md:grid-cols-2 gap-6'
                }, fields.map(field =>
                    React.createElement('div', {
                        key: field.key
                    }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, [
                            field.label,
                            field.required && React.createElement('span', {
                                key: 'required',
                                className: 'text-red-500 ml-1'
                            }, '*')
                        ]),
                        field.type === 'select' ? React.createElement('select', {
                            key: 'input',
                            value: formData[field.key],
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            disabled: !editMode || field.readonly || readOnly,
                            className: `w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                !editMode || field.readonly || readOnly ? 'bg-gray-50' : ''
                            }`
                        }, field.options.map(option =>
                            React.createElement('option', {
                                key: typeof option === 'object' ? option.value : option,
                                value: typeof option === 'object' ? option.value : option
                            }, typeof option === 'object' ? option.label : option)
                        )) : React.createElement('input', {
                            key: 'input',
                            type: field.type,
                            value: formData[field.key],
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            disabled: !editMode || field.readonly,
                            className: `w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                !editMode || field.readonly || readOnly ? 'bg-gray-50' : ''
                            }`
                        })
                    ])
                ))
            ])
        ]);

    } catch (error) {
        console.error('InfoProfessionnelle component error:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.InfoProfessionnelle = InfoProfessionnelle;
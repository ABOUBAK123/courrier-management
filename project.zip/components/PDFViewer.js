function PDFViewer({ documentUrl, onClose, onSaveSignatureZone, parapheur, signaturesCount = 0, showSignatureZones = false, showAppliedSignatures = false, mailData = null }) {
    try {
        const [loading, setLoading] = React.useState(true);
        const [signatureZones, setSignatureZones] = React.useState([]);
        const [activeZone, setActiveZone] = React.useState(null);
        const [dragging, setDragging] = React.useState(false);
        const [resizing, setResizing] = React.useState(false);
        const [dragOffset, setDragOffset] = React.useState({ x: 0, y: 0 });
        const [editMode, setEditMode] = React.useState(true);
        const [documentLoaded, setDocumentLoaded] = React.useState(false);
        const [ftpConfig, setFtpConfig] = React.useState(null);
        const [documentError, setDocumentError] = React.useState(null);
        const [actualDocumentUrl, setDocumentUrl] = React.useState(documentUrl);
        const [cacheStats, setCacheStats] = React.useState(null);

        React.useEffect(() => {
            loadFtpConfig();
            loadDocument();
            setupSignatureZones();
            // Mettre à jour les stats du cache
            setCacheStats(window.cacheManager.getStats());
        }, [signaturesCount, showSignatureZones, showAppliedSignatures, parapheur, documentUrl]);

        const loadFtpConfig = async () => {
            try {
                const settings = await trickleListObjects('ftp-config', 10, true);
                if (settings.items.length > 0) {
                    setFtpConfig(settings.items[0].objectData);
                }
            } catch (error) {
                console.error('Erreur chargement config FTP:', error);
            }
        };

        const loadDocument = async () => {
            try {
                setLoading(true);
                setDocumentError(null);
                
                if (!documentUrl) {
                    throw new Error('URL du document manquante');
                }

                // Utiliser le système de chargement de documents
                const loadedDocumentUrl = await window.documentLoader.loadDocument(documentUrl);
                
                // Mettre à jour l'URL pour l'affichage
                setDocumentUrl(loadedDocumentUrl);
                setDocumentLoaded(true);
                setTimeout(() => setLoading(false), 500);

            } catch (error) {
                console.error('Erreur chargement document:', error);
                setDocumentError(error.message);
                setLoading(false);
            }
        };

        const setupSignatureZones = () => {
            if (showSignatureZones && signaturesCount > 0) {
                const zones = [];
                
                for (let i = 0; i < signaturesCount; i++) {
                    const row = Math.floor(i / 3);
                    const col = i % 3;
                    
                    zones.push({
                        id: i + 1,
                        x: 50 + (col * 250),
                        y: 100 + (row * 120),
                        width: 180,
                        height: 80,
                        label: `SIGNATURE ${i + 1}`,
                        signerIndex: i
                    });
                }
                setSignatureZones(zones);
            } else if (showAppliedSignatures && parapheur?.signatures) {
                const appliedZones = parapheur.signatures.map((sig, i) => ({
                    id: i + 1,
                    x: 50 + ((i % 3) * 250),
                    y: 100 + (Math.floor(i / 3) * 120),
                    width: 180,
                    height: 80,
                    label: `SIGNÉ PAR`,
                    signerName: sig.utilisateur || 'Utilisateur',
                    signedAt: sig.completedAt || new Date().toISOString(),
                    completed: sig.completed
                }));
                setSignatureZones(appliedZones);
            }
        };

        const handleZoneMouseDown = (e, zoneId) => {
            e.preventDefault();
            const rect = e.currentTarget.getBoundingClientRect();
            setActiveZone(zoneId);
            setDragging(true);
            setDragOffset({
                x: e.clientX - rect.left,
                y: e.clientY - rect.top
            });
        };

        const saveZonesPositions = () => {
            console.log('💾 Sauvegarde des zones de signature:', signatureZones);
            if (onSaveSignatureZone) {
                signatureZones.forEach(zone => onSaveSignatureZone(zone));
            }
            alert(`${signatureZones.length} zone${signatureZones.length > 1 ? 's' : ''} de signature sauvegardée${signatureZones.length > 1 ? 's' : ''}`);
            onClose();
        };

        const resetZones = () => {
            const resetZones = signatureZones.map((zone, i) => ({
                ...zone,
                x: 50 + ((i % 3) * 250),
                y: 100 + (Math.floor(i / 3) * 120),
                width: 180,
                height: 80
            }));
            setSignatureZones(resetZones);
            setActiveZone(null);
        };

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4'
        }, [
            React.createElement('div', {
                key: 'pdf-modal',
                className: 'bg-white rounded-lg shadow-2xl max-w-6xl w-full max-h-[95vh] overflow-auto'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'bg-gray-800 text-white p-4 rounded-t-lg flex justify-between items-center'
                }, [
                    React.createElement('div', {
                        key: 'title-section',
                        className: 'flex items-center space-x-4'
                    }, [
                        React.createElement('h3', {
                            key: 'title',
                            className: 'text-lg font-bold'
                        }, showAppliedSignatures ? 
                            `Document Signé - ${parapheur?.nom || 'Document'}` : 
                            `Positionnement des zones de signature (${signaturesCount} zone${signaturesCount > 1 ? 's' : ''})`
                        ),
                        React.createElement('span', {
                            key: 'mode-indicator',
                            className: `px-3 py-1 rounded-full text-xs font-medium ${
                                showAppliedSignatures ? 'bg-green-600 text-white' :
                                editMode ? 'bg-blue-600 text-white' : 'bg-gray-600 text-gray-300'
                            }`
                        }, showAppliedSignatures ? '✅ DOCUMENT SIGNÉ' :
                            editMode ? '✏️ MODE ÉDITION' : '🔒 LECTURE SEULE')
                    ]),

                    React.createElement('div', {
                        key: 'buttons',
                        className: 'flex space-x-3'
                    }, showAppliedSignatures ? [
                        React.createElement('button', {
                            key: 'close-btn',
                            onClick: onClose,
                            className: 'bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-sm font-medium transition-colors'
                        }, [
                            React.createElement('i', { key: 'icon', className: 'fas fa-times mr-2' }),
                            'Fermer'
                        ])
                    ] : [
                        React.createElement('button', {
                            key: 'reset-btn',
                            onClick: resetZones,
                            className: 'bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded text-sm font-medium transition-colors'
                        }, [
                            React.createElement('i', { key: 'icon', className: 'fas fa-undo mr-2' }),
                            'Reset'
                        ]),
                        React.createElement('button', {
                            key: 'save-btn',
                            onClick: saveZonesPositions,
                            className: 'bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-sm font-medium transition-colors'
                        }, [
                            React.createElement('i', { key: 'icon', className: 'fas fa-save mr-2' }),
                            'Sauvegarder & Fermer'
                        ]),
                        React.createElement('button', {
                            key: 'close-btn',
                            onClick: onClose,
                            className: 'bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-sm font-medium transition-colors'
                        }, [
                            React.createElement('i', { key: 'icon', className: 'fas fa-times mr-2' }),
                            'Fermer'
                        ])
                    ])
                ]),

                React.createElement('div', {
                    key: 'content',
                    className: 'p-6'
                }, [
                    React.createElement('div', {
                        key: 'pdf-viewer-info',
                        className: 'mb-4 p-4 bg-blue-50 rounded-lg'
                    }, [
                        React.createElement('p', {
                            key: 'info-text',
                            className: 'text-blue-800 text-sm'
                        }, [
                            React.createElement('i', { key: 'info-icon', className: 'fas fa-info-circle mr-2' }),
                            showAppliedSignatures ? 
                                'Document signé avec toutes les signatures appliquées.' :
                                showSignatureZones ? 
                                    'Positionnez les zones de signature en les glissant. Redimensionnez-les en utilisant la poignée dans le coin inférieur droit.' :
                                    'Aperçu du document. Les zones de signature seront positionnées automatiquement.'
                        ])
                    ]),

                    React.createElement('div', {
                        key: 'pdf-container',
                        className: 'relative bg-gray-100 border-2 border-gray-300 rounded-lg overflow-hidden',
                        style: { 
                            width: '800px', 
                            height: '600px',
                            background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)'
                        }
                    }, [
                        loading && React.createElement('div', {
                            key: 'loading-overlay',
                            className: 'absolute inset-0 bg-white bg-opacity-90 flex items-center justify-center z-50'
                        }, [
                            React.createElement('div', {
                                key: 'loading-content',
                                className: 'text-center'
                            }, [
                                React.createElement('div', {
                                    key: 'spinner',
                                    className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4'
                                }),
                                React.createElement('p', {
                                    key: 'loading-text',
                                    className: 'text-gray-600 font-medium'
                                }, 'Chargement du document PDF...'),
                                ftpConfig && React.createElement('p', {
                                    key: 'ftp-info',
                                    className: 'text-sm text-gray-500 mt-2'
                                }, `Connexion FTP: ${ftpConfig.server}`)
                            ])
                        ]),

                        documentError && React.createElement('div', {
                            key: 'error-overlay',
                            className: 'absolute inset-0 bg-red-50 flex items-center justify-center z-40'
                        }, [
                            React.createElement('div', {
                                key: 'error-content',
                                className: 'text-center p-6 max-w-md'
                            }, [
                                React.createElement('i', {
                                    key: 'error-icon',
                                    className: 'fas fa-exclamation-triangle text-4xl text-red-500 mb-4'
                                }),
                                React.createElement('h4', {
                                    key: 'error-title',
                                    className: 'text-lg font-semibold text-red-700 mb-2'
                                }, 'Erreur de chargement du document'),
                                React.createElement('p', {
                                    key: 'error-message',
                                    className: 'text-red-600 mb-4'
                                }, documentError),
                                React.createElement('div', {
                                    key: 'error-actions',
                                    className: 'flex justify-center space-x-2 mb-4'
                                }, [
                                    React.createElement('button', {
                                        key: 'retry-btn',
                                        onClick: () => {
                                            setDocumentError(null);
                                            loadDocument();
                                        },
                                        className: 'bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700'
                                    }, 'Réessayer'),
                                    React.createElement('button', {
                                        key: 'force-reload-btn',
                                        onClick: () => {
                                            window.cacheManager.cache.delete(window.cacheManager.generateCacheKey(documentUrl));
                                            setDocumentError(null);
                                            loadDocument();
                                        },
                                        className: 'bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700'
                                    }, 'Forcer reload'),
                                    React.createElement('button', {
                                        key: 'close-error-btn',
                                        onClick: onClose,
                                        className: 'bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700'
                                    }, 'Fermer')
                                ]),
                                React.createElement('div', {
                                    key: 'ftp-debug',
                                    className: 'p-3 bg-gray-100 rounded text-sm text-left'
                                }, [
                                    React.createElement('strong', { key: 'debug-title' }, 'Informations:'),
                                    React.createElement('br', { key: 'br1' }),
                                    `URL: ${documentUrl}`,
                                    React.createElement('br', { key: 'br2' }),
                                    mailData && `Courrier: ${mailData.numero}`,
                                    mailData && React.createElement('br', { key: 'br3' }),
                                    mailData?.files && `Fichiers: ${mailData.files.length}`
                                ])
                            ])
                        ]),

                        documentLoaded && React.createElement('div', {
                            key: 'pdf-embed',
                            className: 'absolute inset-4 bg-white rounded shadow-inner'
                        }, [
                            React.createElement('div', {
                                key: 'pdf-container',
                                className: 'w-full h-full flex flex-col'
                            }, [
                                React.createElement('div', {
                                    key: 'pdf-toolbar',
                                    className: 'bg-gray-100 p-2 text-sm text-gray-600 border-b flex justify-between items-center'
                                }, [
                                    React.createElement('span', {
                                        key: 'doc-name'
                                    }, `Document: ${documentUrl.split('/').pop()}`),
                                    cacheStats && React.createElement('span', {
                                        key: 'cache-info',
                                        className: 'text-xs bg-green-100 px-2 py-1 rounded'
                                    }, `Cache: ${Math.round(cacheStats.hitRate * 100)}% hits`)
                                ]),
                                React.createElement('iframe', {
                                    key: 'pdf-iframe',
                                    src: actualDocumentUrl,
                                    className: 'flex-1 border-0',
                                    title: 'Document PDF',
                                    onError: () => {
                                        console.error('Erreur chargement iframe PDF');
                                        setDocumentError('Impossible de charger le document PDF');
                                    }
                                })
                            ])
                        ]),

                        React.createElement('div', {
                            key: 'pdf-content',
                            className: 'w-full h-full bg-white shadow-inner relative',
                            style: { 
                                backgroundImage: 'url("data:image/svg+xml,%3Csvg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23f0f0f0" fill-opacity="0.4"%3E%3Ccircle cx="20" cy="20" r="1"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
                                backgroundSize: '20px 20px'
                            }
                        }, [
                            React.createElement('div', {
                                key: 'document-header',
                                className: 'absolute top-4 left-4 right-4 bg-white bg-opacity-90 p-3 rounded shadow-sm'
                            }, [
                                React.createElement('h4', {
                                    key: 'doc-title',
                                    className: 'font-bold text-gray-800'
                                }, showAppliedSignatures ? 
                                    `${parapheur?.nom || 'Document'} - Version Signée` : 
                                    'Document PDF - Zones de Signature'
                                ),
                                React.createElement('p', {
                                    key: 'doc-info',
                                    className: 'text-sm text-gray-600 mt-1'
                                }, showAppliedSignatures ? 
                                    `Signé le ${new Date().toLocaleDateString()} par ${signaturesCount} signataire${signaturesCount > 1 ? 's' : ''}` :
                                    `${signaturesCount} zone${signaturesCount > 1 ? 's' : ''} de signature à positionner`
                                )
                            ]),

                            (showSignatureZones || showAppliedSignatures) && signatureZones.map(zone =>
                                React.createElement('div', {
                                    key: `signature-zone-${zone.id}`,
                                    style: {
                                        left: `${zone.x}px`,
                                        top: `${zone.y}px`,
                                        width: `${zone.width}px`,
                                        height: `${zone.height}px`
                                    },
                                    className: `absolute border-2 ${
                                        showAppliedSignatures 
                                            ? 'border-green-500 bg-green-100 cursor-default' 
                                            : activeZone === zone.id 
                                                ? 'border-red-500 bg-red-100 shadow-2xl cursor-move' 
                                                : 'border-blue-500 bg-blue-100 hover:border-blue-700 cursor-move'
                                    } bg-opacity-80 select-none transition-all`,
                                    onMouseDown: showAppliedSignatures ? undefined : (e) => handleZoneMouseDown(e, zone.id),
                                    title: showAppliedSignatures ? 'Zone de signature appliquée' : `Zone ${zone.id} - Glisser pour déplacer`
                                }, [
                                    React.createElement('div', {
                                        key: 'zone-content',
                                        className: 'h-full flex flex-col items-center justify-center text-center p-2'
                                    }, [
                                        React.createElement('i', {
                                            key: 'signature-icon',
                                            className: `fas ${showAppliedSignatures ? 'fa-check-circle' : 'fa-signature'} text-xl ${
                                                showAppliedSignatures ? 'text-green-700' :
                                                activeZone === zone.id ? 'text-red-700' : 'text-blue-700'
                                            } mb-1`
                                        }),
                                        React.createElement('div', {
                                            key: 'zone-label',
                                            className: `text-xs font-bold ${
                                                showAppliedSignatures ? 'text-green-800' :
                                                activeZone === zone.id ? 'text-red-800' : 'text-blue-800'
                                            }`
                                        }, zone.label),
                                        showAppliedSignatures && zone.signerName && React.createElement('div', {
                                            key: 'signer-name',
                                            className: 'text-xs text-green-700 mt-1'
                                        }, zone.signerName),
                                        showAppliedSignatures && zone.signedAt && React.createElement('div', {
                                            key: 'signed-date',
                                            className: 'text-xs text-green-600 mt-1'
                                        }, new Date(zone.signedAt).toLocaleDateString()),
                                        !showAppliedSignatures && React.createElement('div', {
                                            key: 'zone-size',
                                            className: `text-xs ${
                                                activeZone === zone.id ? 'text-red-600' : 'text-blue-600'
                                            } mt-1`
                                        }, `${Math.round(zone.width)}×${Math.round(zone.height)}`)
                                    ])
                                ])
                            )
                        ])
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Erreur PDFViewer:', error);
        return null;
    }
}
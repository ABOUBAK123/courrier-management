function Header({ user, onLogout, onSectionChange, onToggleSidebar }) {
    try {
        const [showMobileMenu, setShowMobileMenu] = React.useState(false);
        const [showNotifications, setShowNotifications] = React.useState(false);
        const [showUserMenu, setShowUserMenu] = React.useState(false);

        return React.createElement('header', {
            className: 'bg-white shadow-md border-b border-gray-200 header-mobile',
            'data-name': 'header',
            'data-file': 'components/Header.js'
        }, [
            React.createElement('div', {
                key: 'header-content',
                className: 'flex items-center justify-between px-4 py-3'
            }, [
                React.createElement('div', {
                    key: 'left-section',
                    className: 'flex items-center'
                }, [
                    React.createElement('button', {
                        key: 'mobile-menu-btn',
                        onClick: () => setShowMobileMenu(!showMobileMenu),
                        className: 'md:hidden mr-3 p-2 rounded-lg hover:bg-gray-100'
                    }, [
                        React.createElement('i', {
                            key: 'menu-icon',
                            className: 'fas fa-bars text-gray-600'
                        })
                    ]),
                    React.createElement('h1', {
                        key: 'title',
                        className: 'text-xl md:text-2xl font-bold text-gray-800'
                    }, 'Système de Gestion Administrative')
                ]),
                React.createElement('div', {
                    key: 'right-section',
                    className: 'flex items-center space-x-2 md:space-x-4'
                }, [
                    React.createElement(window.NotificationCenter, {
                        key: 'notifications',
                        user: user
                    }),
                    React.createElement('div', {
                        key: 'user-menu',
                        className: 'relative'
                    }, [
                        React.createElement('button', {
                            key: 'user-btn',
                            onClick: () => setShowUserMenu(!showUserMenu),
                            className: 'flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100'
                        }, [
                            React.createElement('div', {
                                key: 'avatar',
                                className: 'w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center overflow-hidden'
                            }, user?.photo ? 
                                React.createElement('img', {
                                    key: 'avatar-img',
                                    src: user.photo,
                                    alt: 'Photo de profil',
                                    className: 'w-full h-full object-cover'
                                }) :
                                React.createElement('span', {
                                    key: 'initial',
                                    className: 'text-white text-sm font-medium'
                                }, user?.name?.charAt(0) || 'U')
                            ),
                            React.createElement('span', {
                                key: 'name',
                                className: 'hidden md:block text-gray-700 font-medium'
                            }, user?.name || 'Utilisateur'),
                            React.createElement('i', {
                                key: 'chevron',
                                className: 'fas fa-chevron-down text-gray-400 text-sm'
                            })
                        ]),
                        showUserMenu && React.createElement('div', {
                            key: 'user-dropdown',
                            className: 'absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200'
                        }, [
                            React.createElement('button', {
                                key: 'profile-btn',
                                onClick: () => {
                                    onSectionChange('profil');
                                    setShowUserMenu(false);
                                },
                                className: 'w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center'
                            }, [
                                React.createElement('i', {
                                    key: 'profile-icon',
                                    className: 'fas fa-user mr-3 text-gray-400'
                                }),
                                'Mon Profil'
                            ]),
                            React.createElement('hr', {
                                key: 'divider',
                                className: 'my-1'
                            }),
                            React.createElement('button', {
                                key: 'logout-btn',
                                onClick: () => {
                                    onLogout();
                                    setShowUserMenu(false);
                                },
                                className: 'w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center'
                            }, [
                                React.createElement('i', {
                                    key: 'logout-icon',
                                    className: 'fas fa-sign-out-alt mr-3 text-red-400'
                                }),
                                'Déconnexion'
                            ])
                        ])
                    ])
                ])
            ]),
            showMobileMenu && React.createElement('div', {
                key: 'mobile-menu',
                className: 'md:hidden bg-white border-t border-gray-200 p-4'
            }, [
                React.createElement('div', {
                    key: 'mobile-actions',
                    className: 'space-y-2'
                }, [
                    React.createElement('button', {
                        key: 'profile-btn',
                        onClick: () => {
                            onSectionChange('profil');
                            setShowMobileMenu(false);
                        },
                        className: 'w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 flex items-center'
                    }, [
                        React.createElement('i', {
                            key: 'profile-icon',
                            className: 'fas fa-user mr-3 text-gray-400'
                        }),
                        'Mon Profil'
                    ]),
                    React.createElement('button', {
                        key: 'logout-btn',
                        onClick: () => {
                            onLogout();
                            setShowMobileMenu(false);
                        },
                        className: 'w-full text-left px-3 py-2 rounded-lg hover:bg-red-50 text-red-600 flex items-center'
                    }, [
                        React.createElement('i', {
                            key: 'logout-icon',
                            className: 'fas fa-sign-out-alt mr-3 text-red-400'
                        }),
                        'Déconnexion'
                    ])
                ])
            ]),
            showNotifications && React.createElement(Notifications, {
                key: 'notifications',
                onClose: () => setShowNotifications(false)
            })
        ]);
    } catch (error) {
        console.error('Header component error:', error);
        reportError(error);
    }
}

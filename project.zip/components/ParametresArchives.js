function ParametresArchives({ user }) {
    try {
        const [settings, setSettings] = React.useState({
            delaiArchivage: 365,
            archivageAuto: true
        });
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadSettings();
        }, [user]);

        const loadSettings = async () => {
            try {
                const response = await trickleListObjects(`archive-settings:${user.direction}`, 10, true);
                if (response.items.length > 0) {
                    setSettings(response.items[0].objectData);
                }
            } catch (error) {
                console.error('Erreur lors du chargement des paramètres:', error);
            } finally {
                setLoading(false);
            }
        };

        const handleSave = async () => {
            try {
                const response = await trickleListObjects(`archive-settings:${user.direction}`, 10, true);
                
                if (response.items.length > 0) {
                    await trickleUpdateObject(`archive-settings:${user.direction}`, response.items[0].objectId, settings);
                } else {
                    await trickleCreateObject(`archive-settings:${user.direction}`, {
                        ...settings,
                        direction: user.direction,
                        updatedBy: user.name,
                        updatedAt: new Date().toISOString()
                    });
                }
                
                alert('Paramètres d\'archivage sauvegardés avec succès!');
            } catch (error) {
                alert('Erreur lors de la sauvegarde');
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center',
                'data-name': 'loading',
                'data-file': 'components/ParametresArchives.js'
            }, 'Chargement des paramètres...');
        }

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'parametres-archives',
            'data-file': 'components/ParametresArchives.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Paramètres d\'Archivage'),
            React.createElement('div', {
                key: 'settings-form',
                className: 'bg-white rounded-lg shadow-md p-6 space-y-6'
            }, [
                React.createElement('div', {
                    key: 'auto-archive-section',
                    className: 'border-b pb-6'
                }, [
                    React.createElement('h3', {
                        key: 'auto-title',
                        className: 'text-lg font-semibold text-gray-800 mb-4'
                    }, 'Archivage Automatique'),
                    React.createElement('label', {
                        key: 'auto-option',
                        className: 'flex items-center mb-4'
                    }, [
                        React.createElement('input', {
                            key: 'auto-checkbox',
                            type: 'checkbox',
                            checked: settings.archivageAuto,
                            onChange: (e) => setSettings(prev => ({ ...prev, archivageAuto: e.target.checked })),
                            className: 'mr-3'
                        }),
                        React.createElement('span', {
                            key: 'auto-label'
                        }, 'Activer l\'archivage automatique des courriers')
                    ]),
                    React.createElement('div', { key: 'delai-field' }, [
                        React.createElement('label', {
                            key: 'delai-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Délai d\'archivage (jours)'),
                        React.createElement('input', {
                            key: 'delai-input',
                            type: 'number',
                            min: '30',
                            max: '3650',
                            value: settings.delaiArchivage,
                            onChange: (e) => setSettings(prev => ({ ...prev, delaiArchivage: parseInt(e.target.value) })),
                            className: 'w-32 px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('p', {
                            key: 'delai-help',
                            className: 'text-sm text-gray-500 mt-1'
                        }, 'Les courriers seront automatiquement archivés après ce délai')
                    ])
                ])
            ]),
            React.createElement('div', {
                key: 'buttons',
                className: 'flex space-x-4 mt-6'
            }, [
                React.createElement('button', {
                    key: 'save-btn',
                    onClick: handleSave,
                    className: 'btn-primary text-white px-6 py-2 rounded-md'
                }, 'Sauvegarder'),
                React.createElement('button', {
                    key: 'reset-btn',
                    onClick: () => setSettings({ delaiArchivage: 365, archivageAuto: true }),
                    className: 'bg-gray-500 text-white px-6 py-2 rounded-md hover:bg-gray-600'
                }, 'Réinitialiser')
            ])
        ]);
    } catch (error) {
        console.error('ParametresArchives component error:', error);
        reportError(error);
    }
}

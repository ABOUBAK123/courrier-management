window.ValidationDRH = function({ user, onValidation }) {
    const { useState, useEffect } = React;
    
    const [demandes, setDemandes] = useState([]);
    const [historique, setHistorique] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('en_attente');
    const [processing, setProcessing] = useState(false);

    useEffect(() => {
        loadDemandes();
    }, []);

    const loadDemandes = async () => {
        try {
            const response = await trickleListObjects('demande_conge', 100, true);
            
            // Demandes en attente de validation DRH (étape 2)
            const demandesEnAttente = response.items.filter(demande => {
                const workflow = demande.objectData.workflow || [];
                const etapeActuelle = demande.objectData.etape_actuelle || 1;
                
                // Vérifier que c'est l'étape DRH et qu'elle est en attente
                if (workflow.length >= 2 && etapeActuelle === 2) {
                    const etapeDRH = workflow[1];
                    return etapeDRH && 
                           etapeDRH.type === 'validation_drh' && 
                           etapeDRH.statut === 'en_attente' &&
                           !etapeDRH.decision &&
                           workflow[0].decision === 'approuver'; // Le supérieur a approuvé
                }
                return false;
            });
            
            // Historique des demandes traitées par DRH
            const historiqueDRH = response.items.filter(demande => {
                const workflow = demande.objectData.workflow || [];
                return workflow.length >= 2 && 
                       workflow[1].type === 'validation_drh' && 
                       workflow[1].decision;
            });
            
            setDemandes(demandesEnAttente);
            setHistorique(historiqueDRH);
        } catch (error) {
            console.error('Erreur chargement demandes DRH:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleValidation = async (demandeId, decision, commentaire) => {
        setProcessing(true);
        try {
            await window.workflowCongesHierarchique.validerEtape(
                demandeId, 'DRH', decision, commentaire
            );
            await loadDemandes();
            if (onValidation) onValidation();
        } catch (error) {
            console.error('Erreur validation DRH:', error);
        } finally {
            setProcessing(false);
        }
    };

    if (loading) {
        return React.createElement('div', { 
            className: 'flex justify-center items-center py-12' 
        }, 'Chargement des demandes DRH...');
    }

    return React.createElement('div', { className: 'p-6' }, [
        // En-tête avec onglets
        React.createElement('div', { key: 'header', className: 'mb-6' }, [
            React.createElement('h2', { 
                key: 'title', 
                className: 'text-2xl font-bold text-gray-800 mb-4' 
            }, 'Validation DRH'),
            
            // Navigation par onglets
            React.createElement('div', { key: 'tabs', className: 'border-b border-gray-200' },
                React.createElement('nav', { className: '-mb-px flex space-x-8' }, [
                    React.createElement('button', {
                        key: 'tab-attente',
                        onClick: () => setActiveTab('en_attente'),
                        className: `py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                            activeTab === 'en_attente' 
                                ? 'border-blue-500 text-blue-600' 
                                : 'border-transparent text-gray-500 hover:text-gray-700'
                        }`
                    }, `📋 En attente (${demandes.length})`),
                    
                    React.createElement('button', {
                        key: 'tab-historique',
                        onClick: () => setActiveTab('historique'),
                        className: `py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                            activeTab === 'historique' 
                                ? 'border-blue-500 text-blue-600' 
                                : 'border-transparent text-gray-500 hover:text-gray-700'
                        }`
                    }, `📚 Historique (${historique.length})`)
                ])
            )
        ]),

        // Contenu des onglets
        React.createElement('div', { key: 'content', className: 'mt-6' }, [
            // Onglet demandes en attente
            activeTab === 'en_attente' && React.createElement('div', { 
                key: 'attente-content' 
            }, demandes.length === 0 ? 
                React.createElement('div', { className: 'text-center py-12 text-gray-500' }, [
                    React.createElement('i', { 
                        key: 'icon', 
                        className: 'fas fa-inbox text-4xl mb-4 text-gray-300' 
                    }),
                    React.createElement('p', { key: 'text' }, 'Aucune demande en attente de validation DRH')
                ]) : 
                React.createElement('div', { className: 'space-y-4' },
                    demandes.map(demande => 
                        React.createElement(window.ValidationCongePanel, {
                            key: demande.objectId,
                            demande: demande,
                            onValidation: handleValidation,
                            currentUser: { id: 'DRH', nom: 'Direction RH' },
                            processing: processing,
                            isDRH: true
                        })
                    )
                )
            ),

            // Onglet historique DRH
            activeTab === 'historique' && React.createElement('div', { 
                key: 'historique-content' 
            }, historique.length === 0 ? 
                React.createElement('div', { className: 'text-center py-12 text-gray-500' }, [
                    React.createElement('i', { 
                        key: 'icon', 
                        className: 'fas fa-history text-4xl mb-4 text-gray-300' 
                    }),
                    React.createElement('p', { key: 'text' }, 'Aucune validation DRH dans l\'historique')
                ]) : 
                React.createElement('div', { className: 'space-y-4' },
                    historique.map(demande => {
                        const etapeDRH = demande.objectData.workflow[1];
                        
                        return React.createElement('div', { 
                            key: demande.objectId, 
                            className: 'bg-white border rounded-lg p-4 shadow-sm' 
                        }, [
                            React.createElement('div', { 
                                key: 'header', 
                                className: 'flex justify-between items-start mb-3' 
                            }, [
                                React.createElement('div', { key: 'info' }, [
                                    React.createElement('h4', { 
                                        className: 'font-semibold text-gray-900' 
                                    }, demande.objectData.agent_nom),
                                    React.createElement('p', { 
                                        className: 'text-sm text-gray-600' 
                                    }, `${demande.objectData.type_conge} - ${demande.objectData.duree_jours} jour(s)`)
                                ]),
                                React.createElement('span', { 
                                    className: `px-2 py-1 rounded-full text-xs font-medium ${
                                        etapeDRH?.decision === 'approuver' 
                                            ? 'bg-green-100 text-green-800' 
                                            : 'bg-red-100 text-red-800'
                                    }` 
                                }, etapeDRH?.decision === 'approuver' ? '✅ Approuvé DRH' : '❌ Refusé DRH')
                            ]),
                            React.createElement('div', { 
                                key: 'details', 
                                className: 'text-sm text-gray-600 space-y-1' 
                            }, [
                                React.createElement('p', {}, 
                                    `📅 ${new Date(demande.objectData.date_debut).toLocaleDateString('fr-FR')} au ${new Date(demande.objectData.date_fin).toLocaleDateString('fr-FR')}`
                                ),
                                React.createElement('p', {}, 
                                    `🕒 Validé DRH le ${new Date(etapeDRH?.date_decision).toLocaleDateString('fr-FR')}`
                                ),
                                etapeDRH?.commentaire && React.createElement('p', { 
                                    className: 'italic text-gray-500 mt-2' 
                                }, `💬 ${etapeDRH.commentaire}`)
                            ])
                        ]);
                    })
                )
            )
        ])
    ]);
};
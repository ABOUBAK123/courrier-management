function GestionConge({ user }) {
    try {
        const [conges, setConges] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);

        React.useEffect(() => {
            loadConges();
        }, [user]);

        const loadConges = async () => {
            try {
                const response = await trickleListObjects(`conge:${user.direction}`, 100, true);
                const congeData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setConges(congeData);
            } catch (error) {
                console.error('Erreur chargement congés:', error);
            }
        };

        const handleSave = async (demandeData) => {
            try {
                const savedDemande = await trickleCreateObject(`conge:${user.direction}`, demandeData);
                setShowForm(false);
                loadConges();
                return savedDemande;
            } catch (error) {
                window.toastManager?.error('Erreur lors de la soumission');
                throw error;
            }
        };

        const handleApprove = async (congeId) => {
            try {
                const conge = conges.find(c => c.id === congeId);
                await trickleUpdateObject(`conge:${user.direction}`, congeId, {
                    ...conge,
                    status: 'approuve',
                    approuvePar: user.name,
                    dateApprobation: new Date().toISOString()
                });
                alert('Congé approuvé');
                loadConges();
            } catch (error) {
                alert('Erreur lors de l\'approbation');
            }
        };

        const getStatusColor = (status) => {
            switch (status) {
                case 'attente': return 'bg-yellow-100 text-yellow-800';
                case 'approuve': return 'bg-green-100 text-green-800';
                case 'refuse': return 'bg-red-100 text-red-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        };

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'gestion-conge',
            'data-file': 'components/GestionConge.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold text-gray-800'
                }, 'Gestion des Congés'),
                React.createElement('button', {
                    key: 'add-btn',
                    onClick: () => setShowForm(true),
                    className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'
                }, 'Demander Congé')
            ]),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Employé', 'Type', 'Date Début', 'Date Fin', 'Statut', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, conges.map(conge =>
                        React.createElement('tr', {
                            key: conge.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'employe',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, conge.employe),
                            React.createElement('td', {
                                key: 'type',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, conge.typeConge),
                            React.createElement('td', {
                                key: 'debut',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, new Date(conge.dateDebut).toLocaleDateString()),
                            React.createElement('td', {
                                key: 'fin',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, new Date(conge.dateFin).toLocaleDateString()),
                            React.createElement('td', {
                                key: 'status',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('span', {
                                    key: 'status-badge',
                                    className: `px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(conge.status)}`
                                }, conge.status)
                            ]),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium'
                            }, conge.status === 'attente' && [
                                React.createElement('button', {
                                    key: 'approve',
                                    onClick: () => handleApprove(conge.id),
                                    className: 'text-green-600 hover:text-green-900 mr-2'
                                }, 'Approuver')
                            ])
                        ])
                    ))
                ])
            ]),
            React.createElement(DemandeCongeModal, {
                key: 'modal',
                isOpen: showForm,
                onClose: () => setShowForm(false),
                onSubmit: handleSave,
                user: user
            })
        ]);
    } catch (error) {
        console.error('GestionConge component error:', error);
        reportError(error);
    }
}

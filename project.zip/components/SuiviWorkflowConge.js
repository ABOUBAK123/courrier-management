window.SuiviWorkflowConge = function SuiviWorkflowConge({ demande }) {
    try {
        if (!demande || !demande.objectData.workflow) {
            return React.createElement('div', {
                className: 'text-gray-500 text-center py-4'
            }, 'Aucun workflow disponible');
        }

        const workflow = demande.objectData.workflow;
        const etapeActuelle = demande.objectData.etape_actuelle || 1;

        return React.createElement('div', {
            className: 'bg-white rounded-lg shadow p-6',
            'data-name': 'suivi-workflow-conge',
            'data-file': 'components/SuiviWorkflowConge.js'
        },
            React.createElement('h3', {
                className: 'text-lg font-semibold mb-4 text-gray-800'
            }, '📋 Suivi du Workflow de Validation'),

            React.createElement('div', {
                className: 'space-y-4'
            },
                workflow.map((etape, index) => {
                    const estValide = etape.valide;
                    const estEnCours = !estValide && index === etapeActuelle - 1;
                    const estEnAttente = index > etapeActuelle - 1;

                    let statusIcon = '⏳';
                    let statusColor = 'text-gray-400';
                    let bgColor = 'bg-gray-50';

                    if (estValide) {
                        statusIcon = etape.decision === 'approuver' ? '✅' : '❌';
                        statusColor = etape.decision === 'approuver' ? 'text-green-600' : 'text-red-600';
                        bgColor = etape.decision === 'approuver' ? 'bg-green-50' : 'bg-red-50';
                    } else if (estEnCours) {
                        statusIcon = '🔄';
                        statusColor = 'text-blue-600';
                        bgColor = 'bg-blue-50';
                    }

                    return React.createElement('div', {
                        key: index,
                        className: `p-4 rounded-lg border ${bgColor} ${
                            estEnCours ? 'border-blue-300' : 'border-gray-200'
                        }`
                    },
                        React.createElement('div', {
                            className: 'flex items-center justify-between'
                        },
                            React.createElement('div', {
                                className: 'flex items-center space-x-3'
                            },
                                React.createElement('span', {
                                    className: 'text-2xl'
                                }, statusIcon),
                                React.createElement('div', null,
                                    React.createElement('h4', {
                                        className: `font-medium ${statusColor}`
                                    }, `Étape ${index + 1}: ${etape.poste}`),
                                    React.createElement('p', {
                                        className: 'text-sm text-gray-600'
                                    }, etape.validateur_nom)
                                )
                            ),
                            React.createElement('div', {
                                className: 'text-right text-sm'
                            },
                                estValide && React.createElement('div', {
                                    className: statusColor
                                },
                                    React.createElement('div', null, 
                                        etape.decision === 'approuver' ? 'APPROUVÉ' : 'REFUSÉ'
                                    ),
                                    etape.date_validation && React.createElement('div', {
                                        className: 'text-xs text-gray-500'
                                    }, new Date(etape.date_validation).toLocaleDateString())
                                ),
                                estEnCours && React.createElement('div', {
                                    className: 'text-blue-600 font-medium'
                                }, 'EN COURS'),
                                estEnAttente && React.createElement('div', {
                                    className: 'text-gray-400'
                                }, 'EN ATTENTE')
                            )
                        ),
                        etape.commentaire && React.createElement('div', {
                            className: 'mt-2 p-2 bg-white rounded border-l-4 border-gray-300'
                        },
                            React.createElement('p', {
                                className: 'text-sm text-gray-700'
                            }, `💬 ${etape.commentaire}`)
                        )
                    );
                })
            ),

            // Résumé du statut
            React.createElement('div', {
                className: 'mt-6 p-4 bg-gray-100 rounded-lg'
            },
                React.createElement('div', {
                    className: 'flex items-center justify-between'
                },
                    React.createElement('span', {
                        className: 'font-medium text-gray-700'
                    }, 'Statut global:'),
                    React.createElement('span', {
                        className: `font-bold ${
                            demande.objectData.statut === 'approuvee' ? 'text-green-600' :
                            demande.objectData.statut === 'refusee' ? 'text-red-600' :
                            demande.objectData.statut === 'en_cours' ? 'text-blue-600' :
                            'text-orange-600'
                        }`
                    }, 
                        demande.objectData.statut === 'approuvee' ? '✅ APPROUVÉE' :
                        demande.objectData.statut === 'refusee' ? '❌ REFUSÉE' :
                        demande.objectData.statut === 'en_cours' ? '🔄 EN COURS' :
                        '⏳ EN ATTENTE'
                    )
                )
            )
        );
    } catch (error) {
        console.error('SuiviWorkflowConge error:', error);
        return React.createElement('div', {
            className: 'text-red-600 p-4'
        }, 'Erreur lors du chargement du workflow');
    }
};
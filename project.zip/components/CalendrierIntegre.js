window.CalendrierIntegre = function CalendrierIntegre({ user }) {
    try {
        const [conges, setConges] = React.useState([]);
        const [dateActuelle, setDateActuelle] = React.useState(new Date());
        const [vueCalendrier, setVueCalendrier] = React.useState('mois');
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadCongesValides();
        }, [dateActuelle, vueCalendrier]);

        const loadCongesValides = async () => {
            try {
                const response = await trickleListObjects('demande_conge', 200, true);
                const congesApprouves = response.items.filter(item => 
                    item.objectData.statut === 'approuvee'
                );
                setConges(congesApprouves);
            } catch (error) {
                console.error('Erreur chargement congés:', error);
            } finally {
                setLoading(false);
            }
        };

        const getJoursMois = () => {
            const debut = new Date(dateActuelle.getFullYear(), dateActuelle.getMonth(), 1);
            const fin = new Date(dateActuelle.getFullYear(), dateActuelle.getMonth() + 1, 0);
            const jours = [];
            
            for (let d = new Date(debut); d <= fin; d.setDate(d.getDate() + 1)) {
                jours.push(new Date(d));
            }
            return jours;
        };

        const getCongesPourJour = (jour) => {
            return conges.filter(conge => {
                const debut = new Date(conge.objectData.date_debut);
                const fin = new Date(conge.objectData.date_fin);
                return jour >= debut && jour <= fin;
            });
        };

        const changerMois = (direction) => {
            const nouvelleDdate = new Date(dateActuelle);
            nouvelleDdate.setMonth(nouvelleDdate.getMonth() + direction);
            setDateActuelle(nouvelleDdate);
        };

        if (loading) {
            return (
                <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
            );
        }

        return (
            <div className="p-6" data-name="calendrier-integre" data-file="components/CalendrierIntegre.js">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-2xl font-bold text-gray-900">Calendrier des Congés</h1>
                    <div className="flex items-center space-x-4">
                        <select 
                            value={vueCalendrier}
                            onChange={(e) => setVueCalendrier(e.target.value)}
                            className="border border-gray-300 rounded-md px-3 py-2"
                        >
                            <option value="mois">Vue Mois</option>
                            <option value="semaine">Vue Semaine</option>
                        </select>
                        <div className="flex space-x-2">
                            <button
                                onClick={() => changerMois(-1)}
                                className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
                            >
                                <i className="fas fa-chevron-left"></i>
                            </button>
                            <button
                                onClick={() => changerMois(1)}
                                className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
                            >
                                <i className="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                    <div className="px-6 py-4 border-b bg-blue-50">
                        <h2 className="text-lg font-semibold text-center">
                            {dateActuelle.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
                        </h2>
                    </div>

                    <div className="p-6">
                        <div className="grid grid-cols-7 gap-2 mb-4">
                            {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(jour => (
                                <div key={jour} className="text-center font-semibold text-gray-600 py-2">
                                    {jour}
                                </div>
                            ))}
                        </div>
                        
                        <div className="grid grid-cols-7 gap-2">
                            {getJoursMois().map((jour, index) => {
                                const congesJour = getCongesPourJour(jour);
                                const estAujourdhui = jour.toDateString() === new Date().toDateString();
                                
                                return (
                                    <div
                                        key={index}
                                        className={`min-h-24 p-2 border rounded ${
                                            estAujourdhui ? 'border-blue-500 bg-blue-50' :
                                            congesJour.length > 0 ? 'border-orange-300 bg-orange-50' : 
                                            'border-gray-200 bg-white'
                                        }`}
                                    >
                                        <div className={`text-sm font-medium mb-1 ${
                                            estAujourdhui ? 'text-blue-600' : 'text-gray-900'
                                        }`}>
                                            {jour.getDate()}
                                        </div>
                                        {congesJour.slice(0, 2).map((conge, i) => (
                                            <div
                                                key={i}
                                                className="text-xs bg-orange-200 text-orange-800 px-1 py-0.5 rounded mb-1 truncate"
                                                title={`${conge.objectData.agent_nom} - ${conge.objectData.type_conge}`}
                                            >
                                                {conge.objectData.agent_nom}
                                            </div>
                                        ))}
                                        {congesJour.length > 2 && (
                                            <div className="text-xs text-gray-500">
                                                +{congesJour.length - 2}
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('CalendrierIntegre error:', error);
        return <div className="p-6 text-red-600">Erreur lors du chargement</div>;
    }
};
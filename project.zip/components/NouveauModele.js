function NouveauModele({ user, onClose }) {
    try {
        const [currentStep, setCurrentStep] = React.useState(1);
        const [saving, setSaving] = React.useState(false);
        const [users, setUsers] = React.useState([]);
        const [showDocumentViewer, setShowDocumentViewer] = React.useState(false);
        const [selectedDocument, setSelectedDocument] = React.useState(null);
        const [formData, setFormData] = React.useState({
            nomModele: '',
            description: '',
            validations: [],
            signatures: [],
            documents: [],
            piecesJointes: [],
            notifications: { emails: [], cc: [] }
        });

        React.useEffect(() => {
            loadUsers();
        }, []);

        const loadUsers = async () => {
            try {
                const response = await trickleListObjects('user', 100, true);
                const userData = response.items.map(item => item.objectData);
                setUsers(userData);
            } catch (error) {
                console.error('Erreur chargement utilisateurs:', error);
            }
        };

        const openDocument = (document) => {
            setSelectedDocument({
                ...document,
                signaturesCount: formData.signatures.length,
                showSignatureZones: true
            });
            setShowDocumentViewer(true);
        };

        const handleSaveSignatureZone = (zone) => {
            if (!selectedDocument) return;
            
            setFormData(prev => ({
                ...prev,
                documents: prev.documents.map(doc => 
                    doc.id === selectedDocument.id 
                        ? { ...doc, signatureZones: [...(doc.signatureZones || []), zone] }
                        : doc
                )
            }));
        };

        const handleEnregistrer = async () => {
            if (!formData.nomModele) {
                alert('Le nom du modèle est requis');
                return;
            }

            setSaving(true);
            try {
                const modelData = {
                    nomModele: formData.nomModele,
                    description: formData.description,
                    proprietaire: user.name,
                    groupe: user.direction,
                    dateCreation: new Date().toISOString(),
                    status: 'modele',
                    validations: formData.validations.map((v, index) => ({
                        ...v,
                        ordre: index + 1
                    })),
                    signatures: formData.signatures.map((s, index) => ({
                        ...s,
                        ordre: index + 1
                    })),
                    documents: formData.documents,
                    piecesJointes: formData.piecesJointes,
                    notifications: formData.notifications,
                    createdBy: user.id
                };

                await trickleCreateObject(`model:${user.direction}`, modelData);
                alert('Modèle enregistré avec succès!');
                
                setFormData({
                    nomModele: '',
                    description: '',
                    validations: [],
                    signatures: [],
                    documents: [],
                    piecesJointes: [],
                    notifications: { emails: [], cc: [] }
                });
                setCurrentStep(1);
                if (onClose) onClose();
            } catch (error) {
                alert('Erreur lors de l\'enregistrement');
            } finally {
                setSaving(false);
            }
        };

        const handleDupliquer = () => {
            const newFormData = {
                ...formData,
                nomModele: formData.nomModele + ' (Copie)',
                validations: formData.validations.map(v => ({ ...v, id: Date.now() + Math.random() })),
                signatures: formData.signatures.map(s => ({ ...s, id: Date.now() + Math.random() }))
            };
            setFormData(newFormData);
            alert('Modèle dupliqué! Modifiez le nom si nécessaire.');
        };

        const handleSupprimer = () => {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce modèle?')) {
                setFormData({
                    nomModele: '',
                    description: '',
                    validations: [],
                    signatures: [],
                    documents: [],
                    piecesJointes: [],
                    notifications: { emails: [], cc: [] }
                });
                setCurrentStep(1);
                alert('Modèle supprimé');
            }
        };

        return React.createElement('div', {
            className: 'fade-in',
            'data-name': 'nouveau-modele',
            'data-file': 'components/NouveauModele.js'
        }, [
            React.createElement(NouveauModeleFormContent, {
                key: 'form',
                currentStep,
                setCurrentStep,
                formData,
                setFormData,
                users,
                handleEnregistrer,
                handleDupliquer,
                handleSupprimer,
                saving,
                showDocumentViewer,
                setShowDocumentViewer,
                selectedDocument,
                openDocument,
                handleSaveSignatureZone
            }),
            showDocumentViewer && selectedDocument && React.createElement(PDFViewer, {
                key: 'pdf-viewer',
                documentUrl: selectedDocument.url,
                onClose: () => setShowDocumentViewer(false),
                onSaveSignatureZone: handleSaveSignatureZone,
                signaturesCount: selectedDocument.signaturesCount,
                showSignatureZones: selectedDocument.showSignatureZones
            })
        ]);
    } catch (error) {
        console.error('NouveauModele component error:', error);
        reportError(error);
    }
}

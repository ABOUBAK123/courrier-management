function Login({ onLogin }) {
    try {
        const [email, setEmail] = React.useState('');
        const [password, setPassword] = React.useState('');
        const [loading, setLoading] = React.useState(false);
        const [error, setError] = React.useState('');
        const [showForgotPassword, setShowForgotPassword] = React.useState(false);
        const [forgotEmail, setForgotEmail] = React.useState('');
        const [resetMessage, setResetMessage] = React.useState('');

        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            setError('');

            try {
                const result = await onLogin(email, password);
                if (result.success) {
                    window.toastManager?.success('Connexion réussie');
                } else {
                    window.toastManager?.error(result.error || 'Identifiants incorrects');
                    setError(result.error);
                }
            } catch (err) {
                window.toastManager?.error('Erreur de connexion au serveur');
                setError('Erreur de connexion');
                console.error('Login error:', err);
            } finally {
                setLoading(false);
            }
        };

        const handleForgotPassword = async (e) => {
            e.preventDefault();
            setLoading(true);
            setError('');
            setResetMessage('');

            try {
                // Vérifier si l'email existe dans la base des utilisateurs
                const users = await trickleListObjects('user', 100, true);
                const userExists = users.items.find(u => u.objectData.email === forgotEmail);

                if (!userExists) {
                    setError('Aucun compte associé à cette adresse email');
                    setLoading(false);
                    return;
                }

                // Générer un token de réinitialisation
                const resetToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
                const resetExpiry = new Date(Date.now() + 3600000).toISOString(); // 1 heure

                // Sauvegarder le token de réinitialisation
                await trickleCreateObject('password-reset', {
                    email: forgotEmail,
                    token: resetToken,
                    expiry: resetExpiry,
                    used: false,
                    createdAt: new Date().toISOString()
                });

                // Simuler l'envoi d'email (en réalité, vous utiliseriez un service d'email)
                console.log(`Email de réinitialisation envoyé à: ${forgotEmail}`);
                console.log(`Token de réinitialisation: ${resetToken}`);
                
                setResetMessage('Un email de réinitialisation a été envoyé à votre adresse email.');
                setForgotEmail('');
                
                // Fermer le modal après 3 secondes
                setTimeout(() => {
                    setShowForgotPassword(false);
                    setResetMessage('');
                }, 3000);

            } catch (error) {
                setError('Erreur lors de l\'envoi de l\'email de réinitialisation');
                console.error('Forgot password error:', error);
            } finally {
                setLoading(false);
            }
        };

        return React.createElement('div', {
            className: 'min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 to-purple-900',
            'data-name': 'login-container',
            'data-file': 'components/Login.js'
        }, [
                React.createElement('div', {
                    key: 'login-form',
                    className: 'bg-white p-8 rounded-lg shadow-lg w-full max-w-md'
                }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'text-center mb-8'
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: 'fas fa-envelope text-4xl text-blue-600 mb-4'
                    }),
                    React.createElement('h1', {
                        key: 'title',
                        className: 'text-2xl font-bold text-gray-800'
                    }, 'Gestion du Courrier'),
                    React.createElement('p', {
                        key: 'subtitle',
                        className: 'text-gray-600 mt-2'
                    }, 'Connectez-vous à votre compte')
                ]),
                React.createElement('form', {
                    key: 'form',
                    onSubmit: handleSubmit,
                    className: 'space-y-6'
                }, [
                    React.createElement('div', { key: 'email-field' }, [
                        React.createElement('label', {
                            key: 'email-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Email'),
                        React.createElement('input', {
                            key: 'email-input',
                            type: 'email',
                            value: email,
                            onChange: (e) => setEmail(e.target.value),
                            className: 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent',
                            placeholder: 'votre@email.com',
                            required: true
                        })
                    ]),
                    React.createElement('div', { key: 'password-field' }, [
                        React.createElement('label', {
                            key: 'password-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Mot de passe'),
                        React.createElement('input', {
                            key: 'password-input',
                            type: 'password',
                            value: password,
                            onChange: (e) => setPassword(e.target.value),
                            className: 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent',
                            placeholder: '••••••••',
                            required: true
                        })
                    ]),
                    error && React.createElement('div', {
                        key: 'error',
                        className: 'bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm'
                    }, error),
                    React.createElement('button', {
                        key: 'submit',
                        type: 'submit',
                        disabled: loading,
                        className: 'w-full btn-primary text-white py-3 px-4 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed'
                    }, loading ? 'Connexion en cours...' : 'Se connecter'),
                    React.createElement('div', {
                        key: 'forgot-password-link',
                        className: 'text-center'
                    }, [
                        React.createElement('button', {
                            key: 'forgot-btn',
                            type: 'button',
                            onClick: () => setShowForgotPassword(true),
                            className: 'text-blue-600 hover:text-blue-800 text-sm font-medium'
                        }, 'Mot de passe oublié ?')
                    ])
                ])
            ]),
            showForgotPassword && React.createElement('div', {
                key: 'forgot-modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md mx-4'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4 text-center'
                    }, 'Réinitialiser le mot de passe'),
                    React.createElement('p', {
                        key: 'modal-description',
                        className: 'text-gray-600 text-sm mb-4 text-center'
                    }, 'Saisissez votre adresse email pour recevoir un lien de réinitialisation'),
                    React.createElement('form', {
                        key: 'forgot-form',
                        onSubmit: handleForgotPassword,
                        className: 'space-y-4'
                    }, [
                        React.createElement('input', {
                            key: 'forgot-email',
                            type: 'email',
                            value: forgotEmail,
                            onChange: (e) => setForgotEmail(e.target.value),
                            className: 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500',
                            placeholder: 'Votre adresse email',
                            required: true
                        }),
                        error && React.createElement('div', {
                            key: 'forgot-error',
                            className: 'bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm'
                        }, error),
                        resetMessage && React.createElement('div', {
                            key: 'reset-message',
                            className: 'bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm'
                        }, resetMessage),
                        React.createElement('div', {
                            key: 'modal-buttons',
                            className: 'flex space-x-4'
                        }, [
                            React.createElement('button', {
                                key: 'send-btn',
                                type: 'submit',
                                disabled: loading,
                                className: 'flex-1 btn-primary text-white py-2 rounded-lg disabled:opacity-50'
                            }, loading ? 'Envoi...' : 'Envoyer'),
                            React.createElement('button', {
                                key: 'cancel-btn',
                                type: 'button',
                                onClick: () => {
                                    setShowForgotPassword(false);
                                    setForgotEmail('');
                                    setError('');
                                    setResetMessage('');
                                },
                                className: 'flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600'
                            }, 'Annuler')
                        ])
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Login component error:', error);
        reportError(error);
    }
}

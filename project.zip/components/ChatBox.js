function ChatBox({ user }) {
    try {
        const [isOpen, setIsOpen] = React.useState(false);
        const [messages, setMessages] = React.useState([]);
        const [newMessage, setNewMessage] = React.useState('');
        const [users, setUsers] = React.useState([]);
        const [selectedUserId, setSelectedUserId] = React.useState('');
        const [onlineUsers, setOnlineUsers] = React.useState(new Set());
        const [unreadCounts, setUnreadCounts] = React.useState({});

        React.useEffect(() => {
            loadUsers();
            updateOnlineStatus();
            const onlineInterval = setInterval(updateOnlineStatus, 30000);
            return () => clearInterval(onlineInterval);
        }, []);

        React.useEffect(() => {
            if (selectedUserId) {
                loadMessages();
                markMessagesAsRead();
                const interval = setInterval(loadMessages, 2000); // Temps réel
                return () => clearInterval(interval);
            }
        }, [selectedUserId]);

        React.useEffect(() => {
            if (isOpen) {
                loadUnreadCounts();
                const unreadInterval = setInterval(loadUnreadCounts, 5000);
                return () => clearInterval(unreadInterval);
            }
        }, [isOpen]);

        const loadUsers = async () => {
            try {
                const response = await trickleListObjects('user', 100, true);
                const userData = response.items
                    .map(item => item.objectData)
                    .filter(u => u.email !== user.email);
                setUsers(userData);
            } catch (error) {
                console.error('Erreur chargement utilisateurs:', error);
            }
        };

        const updateOnlineStatus = async () => {
            try {
                await trickleCreateObject(`online:${user.email}`, {
                    lastSeen: new Date().toISOString(),
                    status: 'online'
                });

                const onlineData = await trickleListObjects('online', 100, true);
                const now = new Date();
                const online = new Set();
                
                onlineData.items.forEach(item => {
                    const lastSeen = new Date(item.objectData.lastSeen);
                    if (now - lastSeen < 60000) { // En ligne si vu dans la dernière minute
                        const email = item.objectData.email || item.objectType.split(':')[1];
                        if (email) online.add(email);
                    }
                });
                
                setOnlineUsers(online);
            } catch (error) {
                console.error('Erreur statut en ligne:', error);
            }
        };

        const loadMessages = async () => {
            if (!selectedUserId) return;
            try {
                const selectedUser = users.find(u => u.email === selectedUserId);
                if (!selectedUser) return;

                const chatId = [user.email, selectedUser.email].sort().join('-');
                const response = await trickleListObjects(`chat:${chatId}`, 50, true);
                const messageData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setMessages(messageData.reverse());
            } catch (error) {
                console.error('Erreur chargement messages:', error);
            }
        };

        const loadUnreadCounts = async () => {
            try {
                const counts = {};
                for (const u of users) {
                    const chatId = [user.email, u.email].sort().join('-');
                    const response = await trickleListObjects(`chat:${chatId}`, 100, true);
                    const unread = response.items.filter(item => 
                        item.objectData.sender !== user.email && !item.objectData.read
                    ).length;
                    if (unread > 0) counts[u.email] = unread;
                }
                setUnreadCounts(counts);
            } catch (error) {
                console.error('Erreur comptage non lus:', error);
            }
        };

        const markMessagesAsRead = async () => {
            if (!selectedUserId) return;
            try {
                const selectedUser = users.find(u => u.email === selectedUserId);
                if (!selectedUser) return;

                const chatId = [user.email, selectedUser.email].sort().join('-');
                const response = await trickleListObjects(`chat:${chatId}`, 100, true);
                
                for (const item of response.items) {
                    if (item.objectData.sender !== user.email && !item.objectData.read) {
                        await trickleUpdateObject(`chat:${chatId}`, item.objectId, {
                            ...item.objectData,
                            read: true
                        });
                    }
                }
            } catch (error) {
                console.error('Erreur marquage lu:', error);
            }
        };

        const sendMessage = async (e) => {
            e.preventDefault();
            if (!newMessage.trim() || !selectedUserId) return;

            try {
                const selectedUser = users.find(u => u.email === selectedUserId);
                if (!selectedUser) return;

                const chatId = [user.email, selectedUser.email].sort().join('-');
                const messageData = {
                    sender: user.email,
                    senderName: user.name,
                    receiver: selectedUser.email,
                    message: newMessage,
                    timestamp: new Date().toISOString(),
                    read: false
                };

                await trickleCreateObject(`chat:${chatId}`, messageData);
                
                await trickleCreateObject(`notification:${selectedUser.email}`, {
                    message: `Nouveau message de ${user.name}`,
                    type: 'chat',
                    read: false,
                    createdAt: new Date().toISOString()
                });

                setNewMessage('');
                loadMessages();
            } catch (error) {
                console.error('Erreur envoi message:', error);
            }
        };

        const selectedUser = users.find(u => u.email === selectedUserId);

        return React.createElement('div', {
            className: 'fixed bottom-4 right-4 z-50',
            'data-name': 'chat-box',
            'data-file': 'components/ChatBox.js'
        }, [
            React.createElement('button', {
                key: 'toggle-button',
                onClick: () => setIsOpen(!isOpen),
                className: 'bg-blue-600 text-white rounded-full p-3 shadow-lg hover:bg-blue-700 transition-colors relative'
            }, [
                React.createElement('i', {
                    key: 'chat-icon',
                    className: `fas ${isOpen ? 'fa-times' : 'fa-comments'} text-lg`
                }),
                Object.keys(unreadCounts).length > 0 && React.createElement('span', {
                    key: 'unread-badge',
                    className: 'absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center'
                }, Object.values(unreadCounts).reduce((a, b) => a + b, 0))
            ]),
            isOpen && React.createElement('div', {
                key: 'chat-window',
                className: 'absolute bottom-16 right-0 w-96 h-96 bg-white rounded-lg shadow-xl border border-gray-200 flex'
            }, [
                React.createElement('div', {
                    key: 'users-column',
                    className: 'w-1/3 border-r border-gray-200 flex flex-col'
                }, [
                    React.createElement('div', {
                        key: 'users-header',
                        className: 'bg-blue-600 text-white p-2 rounded-tl-lg'
                    }, [
                        React.createElement('h4', {
                            key: 'users-title',
                            className: 'font-semibold text-sm'
                        }, 'Utilisateurs')
                    ]),
                    React.createElement('div', {
                        key: 'users-list',
                        className: 'flex-1 overflow-y-auto'
                    }, users.map(u =>
                        React.createElement('div', {
                            key: u.email,
                            onClick: () => setSelectedUserId(u.email),
                            className: `p-2 cursor-pointer hover:bg-gray-100 border-b border-gray-100 ${
                                selectedUserId === u.email ? 'bg-blue-50' : ''
                            }`
                        }, [
                            React.createElement('div', {
                                key: 'user-info',
                                className: 'flex items-center'
                            }, [
                                React.createElement('div', {
                                    key: 'status-indicator',
                                    className: `w-2 h-2 rounded-full mr-2 ${
                                        onlineUsers.has(u.email) ? 'bg-green-500' : 'bg-gray-400'
                                    }`
                                }),
                                React.createElement('div', {
                                    key: 'user-details',
                                    className: 'flex-1 min-w-0'
                                }, [
                                    React.createElement('p', {
                                        key: 'user-name',
                                        className: 'text-xs font-medium truncate'
                                    }, u.name),
                                    unreadCounts[u.email] && React.createElement('span', {
                                        key: 'unread-count',
                                        className: 'bg-red-500 text-white text-xs rounded-full px-1'
                                    }, unreadCounts[u.email])
                                ])
                            ])
                        ])
                    ))
                ]),
                React.createElement('div', {
                    key: 'chat-column',
                    className: 'w-2/3 flex flex-col'
                }, [
                    React.createElement('div', {
                        key: 'chat-header',
                        className: 'bg-blue-600 text-white p-2 rounded-tr-lg'
                    }, [
                        React.createElement('h4', {
                            key: 'chat-title',
                            className: 'font-semibold text-sm'
                        }, selectedUser ? selectedUser.name : 'Sélectionner un utilisateur')
                    ]),
                    React.createElement('div', {
                        key: 'messages',
                        className: 'flex-1 overflow-y-auto p-2 space-y-2'
                    }, selectedUser ? messages.map(msg =>
                        React.createElement('div', {
                            key: msg.id,
                            className: `flex ${msg.sender === user.email ? 'justify-end' : 'justify-start'}`
                        }, [
                            React.createElement('div', {
                                key: 'bubble',
                                className: `max-w-xs px-2 py-1 rounded text-xs ${
                                    msg.sender === user.email 
                                        ? 'bg-blue-600 text-white' 
                                        : 'bg-gray-200 text-gray-800'
                                }`
                            }, [
                                React.createElement('p', { key: 'text' }, msg.message),
                                React.createElement('p', {
                                    key: 'time',
                                    className: `text-xs mt-1 ${msg.sender === user.email ? 'text-blue-100' : 'text-gray-500'}`
                                }, new Date(msg.timestamp).toLocaleTimeString())
                            ])
                        ])
                    ) : React.createElement('div', {
                        key: 'no-user',
                        className: 'text-center text-gray-500 text-xs mt-8'
                    }, 'Sélectionnez un utilisateur')),
                    React.createElement('form', {
                        key: 'message-form',
                        onSubmit: sendMessage,
                        className: 'p-2 border-t'
                    }, [
                        React.createElement('div', {
                            key: 'input-container',
                            className: 'flex space-x-2'
                        }, [
                            React.createElement('input', {
                                key: 'message-input',
                                type: 'text',
                                value: newMessage,
                                onChange: (e) => setNewMessage(e.target.value),
                                placeholder: 'Tapez...',
                                className: 'flex-1 px-2 py-1 border border-gray-300 rounded text-xs',
                                disabled: !selectedUserId
                            }),
                            React.createElement('button', {
                                key: 'send-button',
                                type: 'submit',
                                disabled: !selectedUserId || !newMessage.trim(),
                                className: 'bg-blue-600 text-white px-2 py-1 rounded text-xs hover:bg-blue-700 disabled:opacity-50'
                            }, 'Envoyer')
                        ])
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('ChatBox component error:', error);
        reportError(error);
    }
}

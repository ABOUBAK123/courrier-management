function NouveauModeleForm({ 
    currentStep, 
    setCurrentStep, 
    formData, 
    setFormData, 
    handleEnregistrer, 
    handleDupliquer, 
    handleSupprimer, 
    saving 
}) {
    try {
        const steps = [
            { id: 1, title: 'Général', icon: 'fas fa-info-circle' },
            { id: 2, title: 'Attribution', icon: 'fas fa-users' },
            { id: 3, title: 'Documents', icon: 'fas fa-file' },
            { id: 4, title: 'Notification', icon: 'fas fa-envelope' },
            { id: 5, title: 'Opération', icon: 'fas fa-cogs' }
        ];

        const renderStepContent = () => {
            switch (currentStep) {
                case 1:
                    return React.createElement('div', {
                        key: 'step1',
                        className: 'space-y-4'
                    }, [
                        React.createElement('div', { key: 'nom-field' }, [
                            React.createElement('label', {
                                key: 'nom-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Nom du modèle *'),
                            React.createElement('input', {
                                key: 'nom-input',
                                type: 'text',
                                value: formData.nomModele,
                                onChange: (e) => setFormData(prev => ({ ...prev, nomModele: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                                required: true
                            })
                        ]),
                        React.createElement('div', { key: 'description-field' }, [
                            React.createElement('label', {
                                key: 'description-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Description'),
                            React.createElement('textarea', {
                                key: 'description-textarea',
                                value: formData.description,
                                onChange: (e) => setFormData(prev => ({ ...prev, description: e.target.value })),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                                rows: 3
                            })
                        ])
                    ]);

                case 5:
                    return React.createElement('div', {
                        key: 'step5',
                        className: 'space-y-6'
                    }, [
                        React.createElement('h4', {
                            key: 'operations-title',
                            className: 'text-lg font-medium text-gray-800 text-center'
                        }, 'Actions disponibles'),
                        React.createElement('div', {
                            key: 'operations',
                            className: 'flex justify-center space-x-4'
                        }, [
                            React.createElement('button', {
                                key: 'duplicate',
                                onClick: handleDupliquer,
                                className: 'bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium'
                            }, [
                                React.createElement('i', {
                                    key: 'duplicate-icon',
                                    className: 'fas fa-copy mr-2'
                                }),
                                'Dupliquer'
                            ]),
                            React.createElement('button', {
                                key: 'delete',
                                onClick: handleSupprimer,
                                className: 'bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium'
                            }, [
                                React.createElement('i', {
                                    key: 'delete-icon',
                                    className: 'fas fa-trash mr-2'
                                }),
                                'Supprimer'
                            ]),
                            React.createElement('button', {
                                key: 'save',
                                onClick: handleEnregistrer,
                                disabled: saving,
                                className: 'bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium disabled:opacity-50'
                            }, [
                                React.createElement('i', {
                                    key: 'save-icon',
                                    className: 'fas fa-save mr-2'
                                }),
                                saving ? 'Enregistrement...' : 'Enregistrer'
                            ])
                        ])
                    ]);

                default:
                    return React.createElement('div', {
                        className: 'text-center p-6'
                    }, `Étape ${currentStep} - Identique au parapheur`);
            }
        };

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'nouveau-modele-form',
            'data-file': 'components/NouveauModeleForm.js'
        }, [
            React.createElement('div', {
                key: 'steps-nav',
                className: 'flex justify-between mb-8'
            }, steps.map(step =>
                React.createElement('div', {
                    key: step.id,
                    className: `flex items-center ${currentStep === step.id ? 'text-blue-600' : 'text-gray-400'}`
                }, [
                    React.createElement('div', {
                        key: 'step-circle',
                        className: `w-8 h-8 rounded-full flex items-center justify-center mr-2 ${
                            currentStep === step.id ? 'bg-blue-600 text-white' : 'bg-gray-200'
                        }`
                    }, step.id),
                    React.createElement('span', {
                        key: 'step-title',
                        className: 'text-sm font-medium'
                    }, step.title)
                ])
            )),
            React.createElement('div', {
                key: 'form-content',
                className: 'bg-white rounded-lg shadow-md p-6 mb-6'
            }, renderStepContent()),
            React.createElement('div', {
                key: 'navigation',
                className: 'flex justify-between'
            }, [
                React.createElement('button', {
                    key: 'prev',
                    onClick: () => setCurrentStep(Math.max(1, currentStep - 1)),
                    disabled: currentStep === 1,
                    className: 'bg-gray-500 text-white px-4 py-2 rounded-lg disabled:opacity-50'
                }, 'Précédent'),
                currentStep < 5 && React.createElement('button', {
                    key: 'next',
                    onClick: () => setCurrentStep(Math.min(5, currentStep + 1)),
                    className: 'bg-blue-600 text-white px-4 py-2 rounded-lg'
                }, 'Suivant')
            ])
        ]);
    } catch (error) {
        console.error('NouveauModeleForm component error:', error);
        reportError(error);
    }
}

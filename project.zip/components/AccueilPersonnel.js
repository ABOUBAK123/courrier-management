function AccueilPersonnel({ user }) {
    try {
        const [stats, setStats] = React.useState({
            totalPersonnel: 0,
            congesEnCours: 0,
            formationsActives: 0,
            demandesAttente: 0
        });

        React.useEffect(() => {
            loadStats();
        }, [user]);

        const loadStats = async () => {
            try {
                const personnel = await trickleListObjects(`personnel:${user.direction}`, 100, true);
                const conges = await trickleListObjects(`conge:${user.direction}`, 100, true);
                const formations = await trickleListObjects(`formation:${user.direction}`, 100, true);
                
                setStats({
                    totalPersonnel: personnel.items.length,
                    congesEnCours: conges.items.filter(c => c.objectData.status === 'approuve').length,
                    formationsActives: formations.items.filter(f => f.objectData.status === 'active').length,
                    demandesAttente: conges.items.filter(c => c.objectData.status === 'attente').length
                });
            } catch (error) {
                console.error('Erreur chargement stats:', error);
            }
        };

        const statCards = [
            { title: 'Total Personnel', value: stats.totalPersonnel, icon: 'fas fa-users', color: 'bg-blue-500' },
            { title: 'Congés en Cours', value: stats.congesEnCours, icon: 'fas fa-calendar-check', color: 'bg-green-500' },
            { title: 'Formations Actives', value: stats.formationsActives, icon: 'fas fa-chalkboard-teacher', color: 'bg-purple-500' },
            { title: 'Demandes en Attente', value: stats.demandesAttente, icon: 'fas fa-clock', color: 'bg-orange-500' }
        ];

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'accueil-personnel',
            'data-file': 'components/AccueilPersonnel.js'
        }, [
            React.createElement('div', {
                key: 'stats-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6'
            }, statCards.map((card, index) =>
                React.createElement('div', {
                    key: index,
                    className: 'bg-white rounded-lg shadow-md p-6 card-hover'
                }, [
                    React.createElement('div', {
                        key: 'card-content',
                        className: 'flex items-center'
                    }, [
                        React.createElement('div', {
                            key: 'icon-container',
                            className: `${card.color} p-3 rounded-lg`
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: `${card.icon} text-white text-xl`
                            })
                        ]),
                        React.createElement('div', {
                            key: 'card-info',
                            className: 'ml-4'
                        }, [
                            React.createElement('p', {
                                key: 'card-title',
                                className: 'text-sm font-medium text-gray-600'
                            }, card.title),
                            React.createElement('p', {
                                key: 'card-value',
                                className: 'text-2xl font-bold text-gray-900'
                            }, card.value)
                        ])
                    ])
                ])
            )),
            React.createElement('div', {
                key: 'quick-actions',
                className: 'bg-white rounded-lg shadow-md p-6'
            }, [
                React.createElement('h3', {
                    key: 'actions-title',
                    className: 'text-lg font-semibold text-gray-800 mb-4'
                }, 'Actions Rapides'),
                React.createElement('div', {
                    key: 'actions-grid',
                    className: 'grid grid-cols-1 md:grid-cols-3 gap-4'
                }, [
                    React.createElement('button', {
                        key: 'new-personnel',
                        className: 'flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors'
                    }, [
                        React.createElement('i', {
                            key: 'personnel-icon',
                            className: 'fas fa-user-plus text-blue-600 mr-3'
                        }),
                        React.createElement('span', {
                            key: 'personnel-text',
                            className: 'text-blue-800 font-medium'
                        }, 'Ajouter Personnel')
                    ]),
                    React.createElement('button', {
                        key: 'new-conge',
                        className: 'flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors'
                    }, [
                        React.createElement('i', {
                            key: 'conge-icon',
                            className: 'fas fa-calendar-plus text-green-600 mr-3'
                        }),
                        React.createElement('span', {
                            key: 'conge-text',
                            className: 'text-green-800 font-medium'
                        }, 'Demande Congé')
                    ]),
                    React.createElement('button', {
                        key: 'new-formation',
                        className: 'flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors'
                    }, [
                        React.createElement('i', {
                            key: 'formation-icon',
                            className: 'fas fa-plus text-purple-600 mr-3'
                        }),
                        React.createElement('span', {
                            key: 'formation-text',
                            className: 'text-purple-800 font-medium'
                        }, 'Nouvelle Formation')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('AccueilPersonnel component error:', error);
        reportError(error);
    }
}

function DocumentManager({ mailId, documents = [], onDocumentOpen, editable = false }) {
    try {
        const [ftpConfig, setFtpConfig] = React.useState(null);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadFtpConfig();
        }, []);

        const loadFtpConfig = async () => {
            try {
                const settings = await trickleListObjects('ftp-config', 10, true);
                if (settings.items.length > 0) {
                    setFtpConfig(settings.items[0].objectData);
                }
            } catch (error) {
                console.error('Erreur chargement config FTP:', error);
            } finally {
                setLoading(false);
            }
        };

        const buildDocumentUrl = (fileName) => {
            if (!ftpConfig) return fileName;
            
            const protocol = ftpConfig.server.startsWith('ftp://') ? '' : 'ftp://';
            const auth = ftpConfig.username && ftpConfig.password ? 
                `${ftpConfig.username}:${ftpConfig.password}@` : '';
            const port = ftpConfig.port && ftpConfig.port !== '21' ? `:${ftpConfig.port}` : '';
            
            return `${protocol}${auth}${ftpConfig.server}${port}/${fileName}`;
        };

        const handleDocumentClick = (doc) => {
            const fullUrl = doc.ftpPath ? buildDocumentUrl(doc.ftpPath) : doc.url || doc.name;
            
            if (onDocumentOpen) {
                onDocumentOpen(fullUrl, doc);
            } else {
                // Ouvrir directement
                if (doc.type && doc.type.includes('pdf')) {
                    window.open(fullUrl, '_blank');
                } else {
                    // Utiliser DocumentViewer pour autres types
                    console.log('Ouverture document:', fullUrl);
                }
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'text-center py-4',
                'data-name': 'document-manager-loading',
                'data-file': 'components/DocumentManager.js'
            }, 'Chargement des documents...');
        }

        return React.createElement('div', {
            className: 'space-y-3',
            'data-name': 'document-manager',
            'data-file': 'components/DocumentManager.js'
        }, [
            ftpConfig && React.createElement('div', {
                key: 'ftp-status',
                className: 'bg-green-50 border border-green-200 rounded-lg p-3'
            }, [
                React.createElement('div', {
                    key: 'status-content',
                    className: 'flex items-center text-sm'
                }, [
                    React.createElement('i', {
                        key: 'status-icon',
                        className: 'fas fa-server text-green-600 mr-2'
                    }),
                    React.createElement('span', {
                        key: 'status-text',
                        className: 'text-green-800'
                    }, `Serveur FTP connecté: ${ftpConfig.server}`)
                ])
            ]),

            documents.length === 0 ? React.createElement('div', {
                key: 'no-docs',
                className: 'text-center py-8 text-gray-500'
            }, [
                React.createElement('i', {
                    key: 'no-docs-icon',
                    className: 'fas fa-file-alt text-3xl mb-2'
                }),
                React.createElement('p', {
                    key: 'no-docs-text'
                }, 'Aucun document joint')
            ]) : documents.map((doc, index) =>
                React.createElement('div', {
                    key: `doc-${index}`,
                    className: 'bg-white border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors',
                    onClick: () => handleDocumentClick(doc)
                }, [
                    React.createElement('div', {
                        key: 'doc-content',
                        className: 'flex items-center justify-between'
                    }, [
                        React.createElement('div', {
                            key: 'doc-info',
                            className: 'flex items-center space-x-3'
                        }, [
                            React.createElement('i', {
                                key: 'doc-icon',
                                className: `fas ${
                                    doc.type && doc.type.includes('pdf') ? 'fa-file-pdf text-red-500' :
                                    doc.type && doc.type.includes('image') ? 'fa-file-image text-blue-500' :
                                    'fa-file text-gray-500'
                                } text-2xl`
                            }),
                            React.createElement('div', {
                                key: 'doc-details'
                            }, [
                                React.createElement('h4', {
                                    key: 'doc-name',
                                    className: 'font-medium text-gray-900'
                                }, doc.name),
                                React.createElement('p', {
                                    key: 'doc-meta',
                                    className: 'text-sm text-gray-500'
                                }, [
                                    doc.size && `${Math.round(doc.size / 1024)} KB`,
                                    doc.ftpPath && ' • Stocké sur FTP',
                                    doc.uploadDate && ` • ${new Date(doc.uploadDate).toLocaleDateString()}`
                                ].filter(Boolean).join(''))
                            ])
                        ]),
                        React.createElement('div', {
                            key: 'doc-actions',
                            className: 'flex items-center space-x-2'
                        }, [
                            React.createElement('button', {
                                key: 'view-btn',
                                className: 'text-blue-600 hover:text-blue-800 text-sm font-medium'
                            }, 'Ouvrir'),
                            ftpConfig && React.createElement('span', {
                                key: 'ftp-badge',
                                className: 'bg-green-100 text-green-800 text-xs px-2 py-1 rounded'
                            }, 'FTP')
                        ])
                    ])
                ])
            )
        ]);
    } catch (error) {
        console.error('DocumentManager component error:', error);
        return React.createElement('div', {
            className: 'text-red-600 p-4'
        }, 'Erreur lors du chargement des documents');
    }
}
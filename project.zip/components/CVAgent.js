function CVAgent({ agent }) {
    try {
        const [cv, setCv] = React.useState(null);
        const [uploading, setUploading] = React.useState(false);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadCV();
        }, [agent]);

        const loadCV = async () => {
            try {
                const result = await trickleListObjects(`cv:${agent.matricule}`, 1, true);
                if (result.items.length > 0) {
                    setCv(result.items[0].objectData);
                }
            } catch (error) {
                console.error('Erreur chargement CV:', error);
            }
            setLoading(false);
        };

        const handleFileUpload = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            if (file.type !== 'application/pdf') {
                alert('Seuls les fichiers PDF sont acceptés');
                return;
            }

            setUploading(true);
            try {
                // Simulation d'upload de fichier
                const reader = new FileReader();
                reader.onload = async (event) => {
                    const cvData = {
                        fileName: `cv_${agent.matricule}_${Date.now()}.pdf`,
                        originalName: file.name,
                        uploadDate: new Date().toISOString(),
                        size: file.size,
                        content: event.target.result
                    };

                    await trickleCreateObject(`cv:${agent.matricule}`, cvData);
                    setCv(cvData);
                    alert('CV uploadé avec succès');
                    setUploading(false);
                };
                reader.readAsDataURL(file);
            } catch (error) {
                alert('Erreur lors de l\'upload');
                setUploading(false);
            }
        };

        const handleDownload = () => {
            if (cv && cv.content) {
                const link = document.createElement('a');
                link.href = cv.content;
                link.download = cv.originalName;
                link.click();
            }
        };

        const handleDelete = async () => {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce CV ?')) {
                try {
                    const result = await trickleListObjects(`cv:${agent.matricule}`, 1, true);
                    if (result.items.length > 0) {
                        await trickleDeleteObject(`cv:${agent.matricule}`, result.items[0].objectId);
                        setCv(null);
                        alert('CV supprimé avec succès');
                    }
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'flex justify-center py-8'
            }, [
                React.createElement('i', {
                    key: 'spinner',
                    className: 'fas fa-spinner fa-spin text-blue-600 text-2xl'
                })
            ]);
        }

        return React.createElement('div', {
            'data-name': 'cv-agent',
            'data-file': 'components/CVAgent.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold'
                }, 'Curriculum Vitae'),
                React.createElement('label', {
                    key: 'upload-btn',
                    className: `px-4 py-2 rounded-lg text-sm font-medium cursor-pointer ${
                        uploading ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'
                    } text-white`
                }, [
                    React.createElement('input', {
                        key: 'file-input',
                        type: 'file',
                        accept: '.pdf',
                        onChange: handleFileUpload,
                        disabled: uploading,
                        className: 'hidden'
                    }),
                    React.createElement('i', {
                        key: 'icon',
                        className: `fas ${uploading ? 'fa-spinner fa-spin' : 'fa-upload'} mr-2`
                    }),
                    uploading ? 'Upload en cours...' : 'Télécharger CV'
                ])
            ]),

            cv ? React.createElement('div', {
                key: 'cv-display',
                className: 'bg-green-50 border border-green-200 rounded-lg p-6'
            }, [
                React.createElement('div', {
                    key: 'cv-info',
                    className: 'flex items-center justify-between mb-4'
                }, [
                    React.createElement('div', { key: 'details' }, [
                        React.createElement('p', {
                            key: 'name',
                            className: 'font-medium text-green-800'
                        }, cv.originalName),
                        React.createElement('p', {
                            key: 'date',
                            className: 'text-sm text-green-600'
                        }, `Uploadé le ${new Date(cv.uploadDate).toLocaleDateString()}`),
                        React.createElement('p', {
                            key: 'size',
                            className: 'text-sm text-green-600'
                        }, `Taille: ${(cv.size / 1024).toFixed(1)} KB`)
                    ]),
                    React.createElement('div', {
                        key: 'actions',
                        className: 'flex space-x-2'
                    }, [
                        React.createElement('button', {
                            key: 'download',
                            onClick: handleDownload,
                            className: 'bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700'
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: 'fas fa-download mr-1'
                            }),
                            'Télécharger'
                        ]),
                        React.createElement('button', {
                            key: 'delete',
                            onClick: handleDelete,
                            className: 'bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700'
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: 'fas fa-trash mr-1'
                            }),
                            'Supprimer'
                        ])
                    ])
                ])
            ]) : React.createElement('div', {
                key: 'empty',
                className: 'text-center py-12 border-2 border-dashed border-gray-300 rounded-lg'
            }, [
                React.createElement('i', {
                    key: 'icon',
                    className: 'fas fa-file-pdf text-gray-400 text-4xl mb-4'
                }),
                React.createElement('p', {
                    key: 'message',
                    className: 'text-gray-600'
                }, 'Aucun CV téléchargé')
            ])
        ]);

    } catch (error) {
        console.error('CVAgent component error:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.CVAgent = CVAgent;
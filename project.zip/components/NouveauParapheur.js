function NouveauParapheur({ user, onClose }) {
    try {
        const [currentStep, setCurrentStep] = React.useState(1);
        const [users, setUsers] = React.useState([]);
        const [models, setModels] = React.useState([]);
        const [saving, setSaving] = React.useState(false);
        const [formData, setFormData] = React.useState({
            model: '',
            nom: '',
            description: '',
            validations: [],
            signatures: [],
            documents: [],
            piecesJointes: [],
            notifications: { emails: [], cc: [] }
        });

        React.useEffect(() => {
            loadUsers();
            loadModels();
        }, []);

        const loadUsers = async () => {
            try {
                const response = await trickleListObjects('user', 100, true);
                const userData = response.items.map(item => item.objectData);
                setUsers(userData);
            } catch (error) {
                console.error('Erreur chargement utilisateurs:', error);
            }
        };

        const loadModels = async () => {
            try {
                const response = await trickleListObjects(`model:${user.direction}`, 100, true);
                const modelData = response.items.map(item => item.objectData);
                setModels(modelData);
            } catch (error) {
                console.error('Erreur chargement modèles:', error);
            }
        };

        const handleModelChange = (modelName) => {
            setFormData(prev => ({ ...prev, model: modelName }));
            if (modelName) {
                const selectedModel = models.find(m => m.nomModele === modelName);
                if (selectedModel) {
                    setFormData(prev => ({
                        ...prev,
                        model: modelName,
                        description: selectedModel.description || '',
                        validations: selectedModel.validations || [],
                        signatures: selectedModel.signatures || [],
                        documents: selectedModel.documents || [],
                        piecesJointes: selectedModel.piecesJointes || [],
                        notifications: selectedModel.notifications || { emails: [], cc: [] }
                    }));
                    alert(`Modèle "${modelName}" chargé avec succès!`);
                }
            }
        };

        const sendNotificationsToUsers = async (parapheurId, parapheurNom) => {
            try {
                // Notifications aux validateurs
                for (const validation of formData.validations) {
                    if (validation.utilisateur) {
                        await trickleCreateObject(`notification:${validation.utilisateur}`, {
                            message: `Nouveau parapheur "${parapheurNom}" en attente de validation`,
                            type: 'parapheur_validation',
                            parapheurId: parapheurId,
                            action: 'validation',
                            read: false,
                            createdAt: new Date().toISOString()
                        });
                    }
                }

                // Notifications aux signataires
                for (const signature of formData.signatures) {
                    if (signature.utilisateur) {
                        await trickleCreateObject(`notification:${signature.utilisateur}`, {
                            message: `Nouveau parapheur "${parapheurNom}" en attente de signature`,
                            type: 'parapheur_signature',
                            parapheurId: parapheurId,
                            action: 'signature',
                            read: false,
                            createdAt: new Date().toISOString()
                        });
                    }
                }
            } catch (error) {
                console.error('Erreur envoi notifications:', error);
            }
        };

        const handleDemarrer = async () => {
            if (!formData.nom) {
                alert('Le nom du parapheur est requis');
                return;
            }

            setSaving(true);
            try {
                console.log('Création parapheur par:', user.name, user.email);
                
                const parapheurData = {
                    nom: formData.nom,
                    description: formData.description,
                    model: formData.model,
                    proprietaire: user.name,
                    proprietaireEmail: user.email,
                    direction: user.direction,
                    status: 'demarre',
                    currentStep: 1,
                    currentStepType: formData.validations.length > 0 ? 'validation' : 'signature',
                    validations: formData.validations.map((v, index) => ({
                        ...v,
                        ordre: index + 1,
                        completed: false,
                        completedAt: null,
                        completedBy: null
                    })),
                    signatures: formData.signatures.map((s, index) => ({
                        ...s,
                        ordre: index + 1,
                        completed: false,
                        completedAt: null,
                        completedBy: null
                    })),
                    documents: formData.documents,
                    piecesJointes: formData.piecesJointes,
                    notifications: formData.notifications,
                    createdBy: user.email,
                    createdAt: new Date().toISOString(),
                    progression: 0
                };

                console.log('Données parapheur à sauvegarder:', parapheurData);

                // Sauvegarder le parapheur GLOBALEMENT (pas par direction)
                const result = await trickleCreateObject('parapheurs', parapheurData);
                
                console.log('Parapheur créé avec ID:', result.objectId);
                
                // Envoyer notifications aux utilisateurs concernés
                await sendNotificationsToUsers(result.objectId, formData.nom);
                
                alert('Parapheur démarré avec succès! Les notifications ont été envoyées.');
                
                if (onClose) onClose();
            } catch (error) {
                alert('Erreur lors du démarrage du parapheur');
                console.error('Erreur démarrage:', error);
            } finally {
                setSaving(false);
            }
        };

        const handleDupliquer = () => {
            const newFormData = {
                ...formData,
                nom: formData.nom + ' (Copie)',
                validations: formData.validations.map(v => ({ ...v, id: Date.now() + Math.random() })),
                signatures: formData.signatures.map(s => ({ ...s, id: Date.now() + Math.random() }))
            };
            setFormData(newFormData);
            alert('Parapheur dupliqué! Modifiez le nom si nécessaire.');
        };

        const handleSupprimer = () => {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce parapheur?')) {
                setFormData({
                    model: '',
                    nom: '',
                    description: '',
                    validations: [],
                    signatures: [],
                    documents: [],
                    piecesJointes: [],
                    notifications: { emails: [], cc: [] }
                });
                setCurrentStep(1);
                alert('Parapheur supprimé');
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'nouveau-parapheur',
            'data-file': 'components/NouveauParapheur.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Nouveau Parapheur'),
            React.createElement(NouveauParapheurForm, {
                key: 'form',
                currentStep,
                setCurrentStep,
                formData,
                setFormData,
                users,
                models,
                handleDemarrer,
                handleDupliquer,
                handleSupprimer,
                saving,
                handleModelChange
            })
        ]);
    } catch (error) {
        console.error('NouveauParapheur component error:', error);
        reportError(error);
    }
}

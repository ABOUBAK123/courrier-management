function SuiviDemandes({ agentId }) {
    try {
        const [demandes, setDemandes] = React.useState([]);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            if (agentId) {
                loadDemandesAgent();
            }
        }, [agentId]);

        const loadDemandesAgent = async () => {
            try {
                setLoading(true);
                const response = await trickleListObjects(`demande_conge:${agentId}`, 50, true);
                setDemandes(response.items);
            } catch (error) {
                console.error('Erreur lors du chargement des demandes:', error);
            } finally {
                setLoading(false);
            }
        };

        const getProgressSteps = (statut) => {
            const steps = [
                { label: 'Soumise', completed: true },
                { label: 'En cours d\'examen', completed: statut !== 'en_attente' },
                { label: statut === 'approuve' ? 'Approuvée' : statut === 'refuse' ? 'Refusée' : 'En attente', 
                  completed: statut !== 'en_attente', 
                  isLast: true,
                  success: statut === 'approuve',
                  error: statut === 'refuse' }
            ];
            return steps;
        };

        const ProgressBar = ({ statut }) => {
            const steps = getProgressSteps(statut);
            
            return React.createElement('div', {
                className: 'flex items-center space-x-2'
            }, steps.map((step, index) => [
                React.createElement('div', {
                    key: `step-${index}`,
                    className: 'flex flex-col items-center'
                }, [
                    React.createElement('div', {
                        key: 'circle',
                        className: `w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${
                            step.completed ? 
                                (step.error ? 'bg-red-500 text-white' : 'bg-green-500 text-white') : 
                                'bg-gray-300 text-gray-600'
                        }`
                    }, step.completed ? (step.error ? '✕' : '✓') : index + 1),
                    React.createElement('span', {
                        key: 'label',
                        className: 'text-xs mt-1 text-center'
                    }, step.label)
                ]),
                !step.isLast && React.createElement('div', {
                    key: `line-${index}`,
                    className: `h-1 w-8 ${step.completed ? 'bg-green-500' : 'bg-gray-300'}`
                })
            ].filter(Boolean)));
        };

        return React.createElement('div', {
            className: 'mt-6',
            'data-name': 'suivi-demandes',
            'data-file': 'components/SuiviDemandes.js'
        }, [
            React.createElement('h3', {
                key: 'title',
                className: 'text-lg font-semibold mb-4'
            }, 'Suivi de mes demandes'),

            loading ? React.createElement('div', {
                key: 'loading',
                className: 'text-center py-4'
            }, 'Chargement...') : demandes.length === 0 ? React.createElement('div', {
                key: 'empty',
                className: 'text-gray-500 text-center py-4'
            }, 'Aucune demande trouvée') : React.createElement('div', {
                key: 'demandes-list',
                className: 'space-y-4'
            }, demandes.map(demande => 
                React.createElement('div', {
                    key: demande.objectId,
                    className: 'bg-white p-4 rounded-lg shadow border'
                }, [
                    React.createElement('div', {
                        key: 'header',
                        className: 'flex justify-between items-start mb-3'
                    }, [
                        React.createElement('div', {
                            key: 'info'
                        }, [
                            React.createElement('h4', {
                                key: 'type',
                                className: 'font-medium'
                            }, demande.objectData.type_conge || 'Congé'),
                            React.createElement('p', {
                                key: 'dates',
                                className: 'text-sm text-gray-600'
                            }, `Du ${demande.objectData.date_debut} au ${demande.objectData.date_fin}`)
                        ]),
                        React.createElement('span', {
                            key: 'date-soumission',
                            className: 'text-xs text-gray-500'
                        }, `Soumise le ${new Date(demande.createdAt).toLocaleDateString()}`)
                    ]),
                    
                    React.createElement('div', {
                        key: 'progress',
                        className: 'mb-3'
                    }, React.createElement(ProgressBar, { statut: demande.objectData.statut })),
                    
                    demande.objectData.commentaire_validation && React.createElement('div', {
                        key: 'comment',
                        className: 'mt-3 p-2 bg-gray-50 rounded text-sm'
                    }, [
                        React.createElement('strong', { key: 'label' }, 'Commentaire: '),
                        demande.objectData.commentaire_validation
                    ])
                ])
            ))
        ]);
    } catch (error) {
        console.error('SuiviDemandes component error:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur lors du chargement');
    }
}

window.SuiviDemandes = SuiviDemandes;
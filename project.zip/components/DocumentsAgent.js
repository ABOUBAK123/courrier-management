function DocumentsAgent({ agent }) {
    try {
        const [documents, setDocuments] = React.useState([]);
        const [showModal, setShowModal] = React.useState(false);

        React.useEffect(() => {
            loadDocuments();
        }, [agent]);

        const loadDocuments = async () => {
            const agentDocs = [
                {
                    id: 1,
                    nom: 'CV_Updated_2024.pdf',
                    type: 'CV',
                    taille: '245KB',
                    dateUpload: '2024-01-15',
                    statut: 'valide'
                },
                {
                    id: 2,
                    nom: 'Diplome_Master.pdf',
                    type: 'Diplôme',
                    taille: '1.2MB',
                    dateUpload: '2024-01-10',
                    statut: 'attente'
                }
            ];
            setDocuments(agentDocs);
        };

        const getTypeIcon = (type) => {
            switch (type) {
                case 'CV': return 'fas fa-file-alt text-blue-600';
                case 'Diplôme': return 'fas fa-graduation-cap text-green-600';
                case 'Certificat': return 'fas fa-certificate text-yellow-600';
                case 'Justificatif': return 'fas fa-file-invoice text-purple-600';
                default: return 'fas fa-file text-gray-600';
            }
        };

        const getStatutColor = (statut) => {
            switch (statut) {
                case 'valide': return 'bg-green-100 text-green-800';
                case 'attente': return 'bg-yellow-100 text-yellow-800';
                case 'refuse': return 'bg-red-100 text-red-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        };

        return React.createElement('div', {
            className: 'p-6 space-y-6',
            'data-name': 'documents-agent',
            'data-file': 'components/DocumentsAgent.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Mes Documents'),
                React.createElement('button', {
                    key: 'upload-btn',
                    onClick: () => setShowModal(true),
                    className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: 'fas fa-upload mr-2'
                    }),
                    'Téléverser'
                ])
            ]),
            React.createElement('div', {
                key: 'stats',
                className: 'grid grid-cols-2 md:grid-cols-4 gap-4'
            }, [
                ['CV', 'Diplômes', 'Certificats', 'Justificatifs'].map(type =>
                    React.createElement('div', {
                        key: type,
                        className: 'bg-white rounded-lg shadow-md p-4 text-center'
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: `${getTypeIcon(type)} text-2xl mb-2`
                        }),
                        React.createElement('p', {
                            key: 'label',
                            className: 'text-sm font-medium text-gray-700'
                        }, type),
                        React.createElement('p', {
                            key: 'count',
                            className: 'text-xl font-bold text-gray-900'
                        }, documents.filter(d => d.type.includes(type.slice(0, -1))).length)
                    ])
                )
            ]),
            showModal && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Téléverser un Document'),
                    React.createElement('form', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('div', { key: 'type' }, [
                            React.createElement('label', {
                                key: 'label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Type de document'),
                            React.createElement('select', {
                                key: 'select',
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            }, [
                                React.createElement('option', { key: 'default', value: '' }, 'Sélectionner'),
                                React.createElement('option', { key: 'cv', value: 'CV' }, 'CV'),
                                React.createElement('option', { key: 'diplome', value: 'Diplôme' }, 'Diplôme'),
                                React.createElement('option', { key: 'cert', value: 'Certificat' }, 'Certificat'),
                                React.createElement('option', { key: 'just', value: 'Justificatif' }, 'Justificatif')
                            ])
                        ]),
                        React.createElement('div', { key: 'file' }, [
                            React.createElement('label', {
                                key: 'label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Fichier'),
                            React.createElement('input', {
                                key: 'input',
                                type: 'file',
                                accept: '.pdf,.doc,.docx,.jpg,.jpeg,.png',
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ])
                    ]),
                    React.createElement('div', {
                        key: 'actions',
                        className: 'flex justify-end space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'cancel',
                            onClick: () => setShowModal(false),
                            className: 'px-4 py-2 text-gray-600 hover:text-gray-800'
                        }, 'Annuler'),
                        React.createElement('button', {
                            key: 'submit',
                            className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'
                        }, 'Téléverser')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('DocumentsAgent component error:', error);
        reportError(error);
    }
}

const Grades = () => {
    const [grades, setGrades] = React.useState([]);
    const [loading, setLoading] = React.useState(false);
    const [showForm, setShowForm] = React.useState(false);
    const [editingGrade, setEditingGrade] = React.useState(null);
    const [formData, setFormData] = React.useState({
        nom: '',
        niveau: '',
        description: '',
        salaireBase: ''
    });

    const loadGrades = async () => {
        setLoading(true);
        try {
            const result = await trickleListObjects('grade', 100, true);
            setGrades(result.items || []);
        } catch (error) {
            console.error('Erreur chargement grades:', error);
        }
        setLoading(false);
    };

    React.useEffect(() => {
        loadGrades();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        
        try {
            if (editingGrade) {
                await trickleUpdateObject('grade', editingGrade.objectId, formData);
            } else {
                await trickleCreateObject('grade', formData);
            }
            setShowForm(false);
            setEditingGrade(null);
            setFormData({ nom: '', niveau: '', description: '', salaireBase: '' });
            loadGrades();
        } catch (error) {
            alert('Erreur lors de la sauvegarde');
        }
        setLoading(false);
    };

    const handleEdit = (grade) => {
        setEditingGrade(grade);
        setFormData(grade.objectData);
        setShowForm(true);
    };

    const handleDelete = async (gradeId) => {
        if (confirm('Êtes-vous sûr de vouloir supprimer ce grade ?')) {
            try {
                await trickleDeleteObject('grade', gradeId);
                loadGrades();
            } catch (error) {
                alert('Erreur lors de la suppression');
            }
        }
    };

    try {
        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'grades',
            'data-file': 'components/Grades.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-xl font-bold'
                }, 'Grades'),
                React.createElement('button', {
                    key: 'add-btn',
                    onClick: () => setShowForm(true),
                    className: 'bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700'
                }, 'Ajouter un grade')
            ]),

            showForm && React.createElement('div', {
                key: 'form',
                className: 'bg-white p-6 rounded-lg shadow border'
            }, [
                React.createElement('h3', {
                    key: 'form-title',
                    className: 'text-lg font-semibold mb-4'
                }, editingGrade ? 'Modifier le grade' : 'Nouveau grade'),
                
                React.createElement('form', {
                    key: 'form-content',
                    onSubmit: handleSubmit,
                    className: 'space-y-4'
                }, [
                    React.createElement('div', {
                        key: 'row1',
                        className: 'grid grid-cols-2 gap-4'
                    }, [
                        React.createElement('div', { key: 'nom' }, [
                            React.createElement('label', {
                                className: 'block text-sm font-medium mb-1'
                            }, 'Nom du grade'),
                            React.createElement('input', {
                                type: 'text',
                                value: formData.nom,
                                onChange: (e) => setFormData({...formData, nom: e.target.value}),
                                className: 'w-full border rounded-md px-3 py-2',
                                required: true
                            })
                        ]),
                        React.createElement('div', { key: 'niveau' }, [
                            React.createElement('label', {
                                className: 'block text-sm font-medium mb-1'
                            }, 'Niveau'),
                            React.createElement('input', {
                                type: 'number',
                                value: formData.niveau,
                                onChange: (e) => setFormData({...formData, niveau: e.target.value}),
                                className: 'w-full border rounded-md px-3 py-2'
                            })
                        ])
                    ]),
                    React.createElement('div', { key: 'description' }, [
                        React.createElement('label', {
                            className: 'block text-sm font-medium mb-1'
                        }, 'Description'),
                        React.createElement('textarea', {
                            value: formData.description,
                            onChange: (e) => setFormData({...formData, description: e.target.value}),
                            className: 'w-full border rounded-md px-3 py-2',
                            rows: 3
                        })
                    ]),
                    React.createElement('div', {
                        key: 'buttons',
                        className: 'flex space-x-3'
                    }, [
                        React.createElement('button', {
                            type: 'submit',
                            disabled: loading,
                            className: 'bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700'
                        }, loading ? 'Enregistrement...' : 'Enregistrer'),
                        React.createElement('button', {
                            type: 'button',
                            onClick: () => {
                                setShowForm(false);
                                setEditingGrade(null);
                                setFormData({ nom: '', niveau: '', description: '', salaireBase: '' });
                            },
                            className: 'bg-gray-300 text-gray-700 px-4 py-2 rounded hover:bg-gray-400'
                        }, 'Annuler')
                    ])
                ])
            ]),

            React.createElement('div', {
                key: 'list',
                className: 'bg-white rounded-lg shadow overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'min-w-full divide-y divide-gray-200'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Nom', 'Niveau', 'Description', 'Actions'
                        ].map((header, index) => 
                            React.createElement('th', {
                                key: index,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'divide-y divide-gray-200'
                    }, grades.map((grade, index) => 
                        React.createElement('tr', { key: index }, [
                            React.createElement('td', {
                                key: 'nom',
                                className: 'px-6 py-4 text-sm font-medium text-gray-900'
                            }, grade.objectData.nom),
                            React.createElement('td', {
                                key: 'niveau',
                                className: 'px-6 py-4 text-sm text-gray-500'
                            }, grade.objectData.niveau),
                            React.createElement('td', {
                                key: 'description',
                                className: 'px-6 py-4 text-sm text-gray-500'
                            }, grade.objectData.description),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 text-sm space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'edit',
                                    onClick: () => handleEdit(grade),
                                    className: 'text-blue-600 hover:text-blue-800'
                                }, 'Modifier'),
                                React.createElement('button', {
                                    key: 'delete',
                                    onClick: () => handleDelete(grade.objectId),
                                    className: 'text-red-600 hover:text-red-800'
                                }, 'Supprimer')
                            ])
                        ])
                    ))
                ])
            ])
        ]);

    } catch (error) {
        console.error('Grades component error:', error);
        return React.createElement('div', {
            className: 'p-6 text-center text-red-600'
        }, 'Erreur lors du chargement');
    }
};

window.Grades = Grades;
function ConfigServerModal({ type, onClose, onSave }) {
    try {
        const [config, setConfig] = React.useState({
            server: '',
            port: type === 'ftp' ? '21' : type === 'sftp' ? '22' : '445',
            username: '',
            password: '',
            directory: type === 'ftp' ? '/documents' : '',
            share: type === 'smb' ? '' : undefined
        });
        const [testing, setTesting] = React.useState(false);

        const testConnection = async () => {
            setTesting(true);
            setTimeout(() => {
                setTesting(false);
                alert('Test de connexion réussi !');
            }, 2000);
        };

        const handleSave = async () => {
            if (!config.server || !config.username) {
                alert('Veuillez remplir tous les champs obligatoires');
                return;
            }

            try {
                // Sauvegarder la configuration dans la base de données
                await trickleCreateObject(`${type}-config`, {
                    ...config,
                    configuredAt: new Date().toISOString(),
                    type: type
                });
                
                console.log(`Configuration ${type} sauvegardée:`, config);
                onSave(config);
            } catch (error) {
                console.error('Erreur sauvegarde config:', error);
                alert('Erreur lors de la sauvegarde de la configuration');
            }
        };

        const getTitle = () => {
            switch(type) {
                case 'ftp': return 'Configuration Serveur FTP';
                case 'sftp': return 'Configuration Serveur SFTP';
                case 'smb': return 'Configuration Partage SMB';
                default: return 'Configuration';
            }
        };

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
        }, [
            React.createElement('div', {
                className: 'bg-white rounded-lg p-6 w-full max-w-md mx-4'
            }, [
                React.createElement('div', { className: 'flex justify-between items-center mb-4' }, [
                    React.createElement('h3', { className: 'text-lg font-medium' }, getTitle()),
                    React.createElement('button', {
                        onClick: onClose,
                        className: 'text-gray-400 hover:text-gray-600'
                    }, React.createElement('i', { className: 'fas fa-times' }))
                ]),

                React.createElement('div', { className: 'space-y-4' }, [
                    React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium mb-1' }, 'Serveur'),
                        React.createElement('input', {
                            type: 'text',
                            value: config.server,
                            onChange: (e) => setConfig({...config, server: e.target.value}),
                            placeholder: type === 'smb' ? '192.168.1.100' : 'serveur.example.com',
                            className: 'w-full px-3 py-2 border rounded-md'
                        })
                    ]),

                    React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium mb-1' }, 'Port'),
                        React.createElement('input', {
                            type: 'number',
                            value: config.port,
                            onChange: (e) => setConfig({...config, port: e.target.value}),
                            className: 'w-full px-3 py-2 border rounded-md'
                        })
                    ]),

                    type === 'ftp' && React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium mb-1' }, 'Répertoire'),
                        React.createElement('input', {
                            type: 'text',
                            value: config.directory || '',
                            onChange: (e) => setConfig({...config, directory: e.target.value}),
                            placeholder: '/documents',
                            className: 'w-full px-3 py-2 border rounded-md'
                        })
                    ]),

                    type === 'smb' && React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium mb-1' }, 'Partage'),
                        React.createElement('input', {
                            type: 'text',
                            value: config.share || '',
                            onChange: (e) => setConfig({...config, share: e.target.value}),
                            placeholder: 'Documents',
                            className: 'w-full px-3 py-2 border rounded-md'
                        })
                    ]),

                    React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium mb-1' }, 'Utilisateur'),
                        React.createElement('input', {
                            type: 'text',
                            value: config.username,
                            onChange: (e) => setConfig({...config, username: e.target.value}),
                            className: 'w-full px-3 py-2 border rounded-md'
                        })
                    ]),

                    React.createElement('div', {}, [
                        React.createElement('label', { className: 'block text-sm font-medium mb-1' }, 'Mot de passe'),
                        React.createElement('input', {
                            type: 'password',
                            value: config.password,
                            onChange: (e) => setConfig({...config, password: e.target.value}),
                            className: 'w-full px-3 py-2 border rounded-md'
                        })
                    ])
                ]),

                React.createElement('div', { className: 'flex justify-between mt-6' }, [
                    React.createElement('div', { className: 'flex gap-2' }, [
                        React.createElement('button', {
                            onClick: testConnection,
                            disabled: testing,
                            className: 'px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 disabled:opacity-50'
                        }, testing ? 'Test...' : 'Tester'),
                        type === 'ftp' && React.createElement('button', {
                            onClick: () => {
                                const testUrl = `ftp://${config.server}:${config.port || 21}`;
                                const helpText = `Pour tester manuellement:\n\n1. Ouvrez FileZilla ou un client FTP\n2. Connectez-vous avec:\n   - Hôte: ${config.server}\n   - Port: ${config.port || 21}\n   - Utilisateur: ${config.username}\n   - Mode: Passif\n\n3. Si la connexion fonctionne, les paramètres sont corrects.`;
                                alert(helpText);
                            },
                            className: 'px-4 py-2 bg-orange-600 text-white rounded hover:bg-orange-700'
                        }, '📋 Aide Test')
                    ]),
                    
                React.createElement('div', { className: 'space-x-2' }, [
                    React.createElement('button', {
                        onClick: onClose,
                        className: 'px-4 py-2 border rounded hover:bg-gray-50'
                    }, 'Annuler'),
                    type === 'ftp' && React.createElement('button', {
                        onClick: async () => {
                            try {
                                window.toastManager?.info('Test de connexion FTP...');
                                
                                // Validation des paramètres
                                const validation = FTPClient.validateConfig(config);
                                if (!validation.valid) {
                                    window.toastManager?.error(`Paramètres invalides: ${validation.errors.join(', ')}`);
                                    return;
                                }
                                
                                // Test côté client
                                const result = await FTPClient.testConnection({
                                    host: config.server,
                                    server: config.server,
                                    username: config.username,
                                    password: config.password,
                                    port: config.port || 21
                                });
                                
                                if (result.success) {
                                    window.toastManager?.success(`✓ ${result.message}`);
                                    if (result.responseTime) {
                                        console.log(`Temps de réponse: ${result.responseTime}ms`);
                                    }
                                } else {
                                    window.toastManager?.error(`✗ ${result.message}`);
                                }
                                
                                // Log pour debugging
                                console.log('Résultat test FTP:', result);
                                
                            } catch (error) {
                                console.error('Erreur test connexion FTP:', error);
                                window.toastManager?.error(`Erreur: ${error.message}`);
                            }
                        },
                        className: 'px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700'
                    }, 'Tester Connectivité'),
                    React.createElement('button', {
                        onClick: handleSave,
                        className: 'px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
                    }, 'Sauvegarder')
                ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Erreur ConfigServerModal:', error);
        return null;
    }
}
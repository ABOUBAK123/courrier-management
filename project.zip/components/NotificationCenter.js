function NotificationCenter({ user }) {
    const [notifications, setNotifications] = React.useState([]);
    const [unreadCount, setUnreadCount] = React.useState(0);
    const [showPanel, setShowPanel] = React.useState(false);

    React.useEffect(() => {
        loadNotifications();
        const interval = setInterval(loadNotifications, 10000); // Refresh toutes les 10s
        return () => clearInterval(interval);
    }, [user]);

    const loadNotifications = async () => {
        try {
            const result = await trickleListObjects('notification', 50, true);
            const mesNotifications = result.items.filter(notif => 
                notif.objectData.destinataireId === user.id
            );
            
            setNotifications(mesNotifications);
            setUnreadCount(mesNotifications.filter(n => n.objectData.statut === 'non_lue').length);
        } catch (error) {
            console.error('Erreur chargement notifications:', error);
        }
    };

    const markAsRead = async (notificationId) => {
        try {
            await trickleUpdateObject('notification', notificationId, {
                statut: 'lue'
            });
            await loadNotifications();
        } catch (error) {
            console.error('Erreur marquage lu:', error);
        }
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        const maintenant = new Date();
        const diffMs = maintenant - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 60) return `Il y a ${diffMins} min`;
        if (diffHours < 24) return `Il y a ${diffHours}h`;
        return `Il y a ${diffDays} jour(s)`;
    };

    return React.createElement('div', {
        className: 'relative',
        'data-name': 'notification-center',
        'data-file': 'components/NotificationCenter.js'
    }, [
        // Bouton notifications
        React.createElement('button', {
            key: 'button',
            onClick: () => setShowPanel(!showPanel),
            className: 'relative p-2 text-gray-600 hover:text-gray-900'
        }, [
            React.createElement('i', {
                key: 'icon',
                className: 'fas fa-bell text-xl'
            }),
            unreadCount > 0 && React.createElement('span', {
                key: 'badge',
                className: 'absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center'
            }, unreadCount)
        ]),

        // Panel notifications
        showPanel && React.createElement('div', {
            key: 'panel',
            className: 'absolute right-0 top-full mt-2 w-80 bg-white border rounded-lg shadow-lg z-50'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'px-4 py-3 border-b'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'font-semibold'
                }, 'Notifications'),
                unreadCount > 0 && React.createElement('span', {
                    key: 'count',
                    className: 'text-sm text-gray-500'
                }, `${unreadCount} non lue(s)`)
            ]),

            React.createElement('div', {
                key: 'list',
                className: 'max-h-96 overflow-y-auto'
            }, notifications.length === 0 ? 
                React.createElement('div', {
                    className: 'p-4 text-center text-gray-500'
                }, 'Aucune notification') :
                notifications.slice(0, 10).map(notif =>
                    React.createElement('div', {
                        key: notif.objectId,
                        className: `p-3 border-b hover:bg-gray-50 cursor-pointer ${
                            notif.objectData.statut === 'non_lue' ? 'bg-blue-50' : ''
                        }`,
                        onClick: () => markAsRead(notif.objectId)
                    }, [
                        React.createElement('div', {
                            key: 'content',
                            className: 'flex justify-between items-start'
                        }, [
                            React.createElement('div', {
                                key: 'text',
                                className: 'flex-1'
                            }, [
                                React.createElement('p', {
                                    key: 'title',
                                    className: 'font-medium text-sm'
                                }, notif.objectData.titre),
                                React.createElement('p', {
                                    key: 'message',
                                    className: 'text-gray-600 text-xs mt-1'
                                }, notif.objectData.message)
                            ]),
                            React.createElement('span', {
                                key: 'time',
                                className: 'text-xs text-gray-400'
                            }, formatDate(notif.objectData.dateCreation))
                        ])
                    ])
                )
            )
        ])
    ]);
}

window.NotificationCenter = NotificationCenter;
function MailList({ user }) {
    try {
        const [mails, setMails] = React.useState([]);
        const [filteredMails, setFilteredMails] = React.useState([]);
        const [filter, setFilter] = React.useState('tous');
        const [searchTerm, setSearchTerm] = React.useState('');
        const [loading, setLoading] = React.useState(true);
        const [showPDFViewer, setShowPDFViewer] = React.useState(false);
        const [selectedMail, setSelectedMail] = React.useState(null);
        const [showEditModal, setShowEditModal] = React.useState(false);
        const [editData, setEditData] = React.useState({});

        React.useEffect(() => {
            loadMails();
            // Précharger les documents PDF des premiers courriers
            preloadDocuments();
        }, [user]);

        const preloadDocuments = async () => {
            try {
                const response = await trickleListObjects(`mail:${user.direction}`, 5, true);
                const documentsToPreload = [];
                
                response.items.forEach(mail => {
                    if (mail.objectData.files && mail.objectData.files.length > 0) {
                        const firstFile = mail.objectData.files[0];
                        if (firstFile.ftpPath || firstFile.name) {
                            // Construire l'URL du document pour préchargement
                            const documentUrl = firstFile.ftpPath || firstFile.name;
                            documentsToPreload.push(documentUrl);
                        }
                    }
                });

                if (documentsToPreload.length > 0) {
                    console.log('Préchargement de', documentsToPreload.length, 'documents');
                    await window.documentLoader.preloadDocuments(documentsToPreload);
                }
            } catch (error) {
                console.warn('Erreur préchargement documents:', error);
            }
        };

        React.useEffect(() => {
            filterMails();
        }, [mails, filter, searchTerm]);

        const loadMails = async () => {
            try {
                const response = await trickleListObjects(`mail:${user.direction}`, 100, true);
                const mailData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setMails(mailData);
            } catch (error) {
                console.error('Erreur lors du chargement des courriers:', error);
            } finally {
                setLoading(false);
            }
        };

        const filterMails = () => {
            let filtered = mails;

            if (filter !== 'tous') {
                if (filter === 'arrives') filtered = filtered.filter(m => m.type === 'arrive');
                else if (filter === 'departs') filtered = filtered.filter(m => m.type === 'depart');
                else if (filter === 'attente') filtered = filtered.filter(m => m.status === 'attente');
            }

            if (searchTerm) {
                filtered = filtered.filter(m => 
                    m.objet.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    m.numero.toLowerCase().includes(searchTerm.toLowerCase())
                );
            }

            setFilteredMails(filtered);
        };

        const handleViewMail = async (mail) => {
            try {
                // Construire l'URL du document
                let documentUrl = null;
                
                if (mail.files && mail.files.length > 0) {
                    const firstFile = mail.files[0];
                    
                    if (firstFile.localPath || firstFile.id) {
                        // Document stocké localement
                        documentUrl = firstFile.localPath || firstFile.id;
                    } else if (firstFile.content) {
                        // Document en base64
                        documentUrl = `data:application/pdf;base64,${firstFile.content}`;
                    } else if (firstFile.ftpPath) {
                        // Document sur serveur FTP
                        documentUrl = firstFile.ftpPath;
                    } else if (firstFile.name) {
                        // Fallback sur le nom de fichier
                        documentUrl = firstFile.name;
                    }
                }
                
                if (!documentUrl) {
                    alert('Aucun document trouvé pour ce courrier');
                    return;
                }
                
                setSelectedMail({
                    ...mail,
                    documentUrl: documentUrl
                });
                setShowPDFViewer(true);
            } catch (error) {
                console.error('Erreur ouverture document:', error);
                alert('Erreur lors de l\'ouverture du document');
            }
        };

        const getStorageConfig = async () => {
            try {
                // Vérifier FTP
                const ftpConfig = await trickleListObjects('ftp-config', 10, true);
                if (ftpConfig.items.length > 0) {
                    return { type: 'ftp', config: ftpConfig.items[0].objectData };
                }
                
                // Vérifier SFTP
                const sftpConfig = await trickleListObjects('sftp-config', 10, true);
                if (sftpConfig.items.length > 0) {
                    return { type: 'sftp', config: sftpConfig.items[0].objectData };
                }
                
                // Vérifier SMB
                const smbConfig = await trickleListObjects('smb-config', 10, true);
                if (smbConfig.items.length > 0) {
                    return { type: 'smb', config: smbConfig.items[0].objectData };
                }
                
                return null;
            } catch (error) {
                console.error('Erreur chargement config stockage:', error);
                return null;
            }
        };

        const buildSecureDocumentUrl = (fileName, storageConfig) => {
            const { type, config } = storageConfig;
            
            switch (type) {
                case 'ftp':
                    // Utiliser une URL de proxy pour éviter les problèmes CORS
                    const ftpUrl = encodeURIComponent(`ftp://${config.server}:${config.port || 21}/${fileName}`);
                    return `/api/document-proxy.php?url=${ftpUrl}&user=${encodeURIComponent(config.username)}&pass=${encodeURIComponent(config.password)}`;
                
                case 'sftp':
                    const sftpUrl = encodeURIComponent(`sftp://${config.server}:${config.port || 22}/${fileName}`);
                    return `/api/document-proxy.php?url=${sftpUrl}&user=${encodeURIComponent(config.username)}`;
                
                case 'smb':
                    const smbUrl = encodeURIComponent(`smb://${config.server}/${config.share}/${fileName}`);
                    return `/api/document-proxy.php?url=${smbUrl}&user=${encodeURIComponent(config.username)}&pass=${encodeURIComponent(config.password)}`;
                
                default:
                    return fileName;
            }
        };

        const handleEditMail = (mail) => {
            setEditData({
                id: mail.id,
                objet: mail.objet,
                expediteur: mail.expediteur || '',
                destinateur: mail.destinateur || '',
                numeroEmission: mail.numeroEmission || '',
                numeroReference: mail.numeroReference || '',
                priority: mail.priority
            });
            setShowEditModal(true);
        };

        const handleSaveEdit = async () => {
            try {
                await trickleUpdateObject(`mail:${user.direction}`, editData.id, {
                    ...mails.find(m => m.id === editData.id),
                    objet: editData.objet,
                    expediteur: editData.expediteur,
                    destinateur: editData.destinateur,
                    numeroEmission: editData.numeroEmission,
                    numeroReference: editData.numeroReference,
                    priority: editData.priority,
                    updatedAt: new Date().toISOString()
                });
                
                alert('Courrier modifié avec succès!');
                setShowEditModal(false);
                loadMails();
            } catch (error) {
                alert('Erreur lors de la modification');
            }
        };

        const getStatusColor = (status) => {
            const statusObj = STATUSES.find(s => s.value === status);
            return statusObj ? statusObj.color : 'bg-gray-100 text-gray-800';
        };

        const getPriorityColor = (priority) => {
            const priorityObj = PRIORITIES.find(p => p.value === priority);
            return priorityObj ? priorityObj.color : 'text-gray-600';
        };

        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center',
                'data-name': 'loading',
                'data-file': 'components/MailList.js'
            }, 'Chargement...');
        }

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'mail-list',
            'data-file': 'components/MailList.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Liste des Courriers'),
                React.createElement('div', {
                    key: 'search',
                    className: 'flex items-center space-x-4'
                }, [
                    React.createElement('input', {
                        key: 'search-input',
                        type: 'text',
                        placeholder: 'Rechercher...',
                        value: searchTerm,
                        onChange: (e) => setSearchTerm(e.target.value),
                        className: 'px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500'
                    })
                ])
            ]),
            React.createElement('div', {
                key: 'filters',
                className: 'flex space-x-2 mb-6'
            }, [
                { value: 'tous', label: 'Tous' },
                { value: 'arrives', label: 'Arrivés' },
                { value: 'departs', label: 'Départs' },
                { value: 'attente', label: 'En attente' }
            ].map(filterOption =>
                React.createElement('button', {
                    key: filterOption.value,
                    onClick: () => setFilter(filterOption.value),
                    className: `px-4 py-2 rounded-lg transition-colors ${
                        filter === filterOption.value 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`
                }, filterOption.label)
            )),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Numéro', 'Objet', 'Type', 'Priorité', 'Statut', 'Agent', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, filteredMails.map(mail =>
                        React.createElement('tr', {
                            key: mail.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'numero-cell',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, mail.numero),
                            React.createElement('td', {
                                key: 'objet-cell',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.objet),
                            React.createElement('td', {
                                key: 'type-cell',
                                className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                            }, mail.type === 'arrive' ? 'Arrivé' : 'Départ'),
                            React.createElement('td', {
                                key: 'priority-cell',
                                className: `px-6 py-4 whitespace-nowrap text-sm font-medium ${getPriorityColor(mail.priority)}`
                            }, PRIORITIES.find(p => p.value === mail.priority)?.label || mail.priority),
                            React.createElement('td', {
                                key: 'status-cell',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('span', {
                                    key: 'status-badge',
                                    className: `px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(mail.status)}`
                                }, STATUSES.find(s => s.value === mail.status)?.label || mail.status)
                            ]),
                            React.createElement('td', {
                                key: 'agent-cell',
                                className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                            }, mail.createdByName || 'Non défini'),
                            React.createElement('td', {
                                key: 'actions-cell',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'view',
                                    onClick: () => handleViewMail(mail),
                                    className: 'text-blue-600 hover:text-blue-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'eye-icon',
                                        className: 'fas fa-eye'
                                    })
                                ]),
                                React.createElement('button', {
                                    key: 'edit',
                                    onClick: () => handleEditMail(mail),
                                    className: 'text-green-600 hover:text-green-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'edit-icon',
                                        className: 'fas fa-edit'
                                    })
                                ])
                            ])
                        ])
                    ))
                ])
            ]),
            showPDFViewer && selectedMail && React.createElement(PDFViewer, {
                key: 'pdf-viewer',
                documentUrl: selectedMail.documentUrl,
                onClose: () => setShowPDFViewer(false),
                showSignatureZones: false,
                mailData: selectedMail
            }),
            showEditModal && React.createElement('div', {
                key: 'edit-modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Modifier le Courrier'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('input', {
                            key: 'objet',
                            type: 'text',
                            placeholder: 'Objet',
                            value: editData.objet,
                            onChange: (e) => setEditData(prev => ({ ...prev, objet: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('input', {
                            key: 'expediteur',
                            type: 'text',
                            placeholder: 'Expéditeur',
                            value: editData.expediteur,
                            onChange: (e) => setEditData(prev => ({ ...prev, expediteur: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('select', {
                            key: 'priority',
                            value: editData.priority,
                            onChange: (e) => setEditData(prev => ({ ...prev, priority: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }, PRIORITIES.map(p => 
                            React.createElement('option', { key: p.value, value: p.value }, p.label)
                        ))
                    ]),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save-btn',
                            onClick: handleSaveEdit,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, 'Sauvegarder'),
                        React.createElement('button', {
                            key: 'cancel-btn',
                            onClick: () => setShowEditModal(false),
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('MailList component error:', error);
        reportError(error);
    }
}

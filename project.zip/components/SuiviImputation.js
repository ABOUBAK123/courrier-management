function SuiviImputation({ user }) {
    try {
        const [trackings, setTrackings] = React.useState([]);

        React.useEffect(() => {
            loadTrackings();
        }, [user]);

        const loadTrackings = async () => {
            try {
                const response = await trickleListObjects(`imputation:${user.direction}`, 100, true);
                let trackingData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));

                trackingData = await cleanDuplicateTrackings(trackingData);
                setTrackings(trackingData);
            } catch (error) {
                console.error('Erreur lors du chargement:', error);
            }
        };

        const cleanDuplicateTrackings = async (trackings) => {
            try {
                const groupedByMail = {};
                trackings.forEach(tracking => {
                    const mailNumber = tracking.mailNumber;
                    if (!groupedByMail[mailNumber]) {
                        groupedByMail[mailNumber] = [];
                    }
                    groupedByMail[mailNumber].push(tracking);
                });

                const cleanedTrackings = [];
                const toDelete = [];

                for (const mailNumber in groupedByMail) {
                    const group = groupedByMail[mailNumber];
                    
                    if (group.length > 1) {
                        const withResponse = group.find(t => t.responseFile && t.status === 'traite');
                        const withoutResponse = group.filter(t => !t.responseFile || t.status !== 'traite');
                        
                        if (withResponse) {
                            cleanedTrackings.push(withResponse);
                            withoutResponse.forEach(t => toDelete.push(t.id));
                        } else {
                            const latest = group.sort((a, b) => new Date(b.date) - new Date(a.date))[0];
                            cleanedTrackings.push(latest);
                            group.filter(t => t.id !== latest.id).forEach(t => toDelete.push(t.id));
                        }
                    } else {
                        cleanedTrackings.push(group[0]);
                    }
                }

                for (const deleteId of toDelete) {
                    await trickleDeleteObject(`imputation:${user.direction}`, deleteId);
                }

                return cleanedTrackings;
            } catch (error) {
                console.error('Erreur nettoyage doublons:', error);
                return trackings;
            }
        };

        const handleValidate = async (tracking) => {
            try {
                // Trouver la direction parent qui a fait l'imputation originale
                const parentDirection = await findOriginalImputingDirection(tracking);
                
                if (parentDirection) {
                    // Créer ou mettre à jour le suivi dans la direction parent
                    await createOrUpdateParentTracking(parentDirection, tracking);
                } else {
                    // Si pas de parent trouvé, finaliser dans la direction originale
                    await finalizeInOriginalDirection(tracking);
                }

                // Supprimer de la direction actuelle
                await trickleDeleteObject(`imputation:${user.direction}`, tracking.id);
                
                // Marquer comme validé dans la direction actuelle
                await markAsValidatedInCurrentDirection(tracking);

                alert('Courrier validé avec succès');
                loadTrackings();
            } catch (error) {
                alert('Erreur lors de la validation');
                console.error('Validation error:', error);
            }
        };

        const findOriginalImputingDirection = async (tracking) => {
            try {
                // Récupérer toutes les directions
                const allDirections = await trickleListObjects('directions', 100, true);
                const directionCodes = allDirections.items.map(d => d.objectData.code);
                
                // Chercher dans toutes les directions pour trouver qui a imputé vers nous
                for (const dirCode of directionCodes) {
                    if (dirCode === user.direction) continue;
                    
                    const mails = await trickleListObjects(`mail:${dirCode}`, 100, true);
                    const mail = mails.items.find(m => {
                        const mailData = m.objectData;
                        return mailData.numero === tracking.mailNumber && 
                               (mailData.imputedTo === user.direction || mailData.reimputedTo === user.direction);
                    });
                    
                    if (mail) {
                        return dirCode; // Cette direction nous a imputé le courrier
                    }
                }
                
                return null;
            } catch (error) {
                console.error('Erreur recherche direction parent:', error);
                return null;
            }
        };

        const createOrUpdateParentTracking = async (parentDirection, tracking) => {
            try {
                // Vérifier s'il existe déjà un suivi dans la direction parent
                const parentTrackings = await trickleListObjects(`imputation:${parentDirection}`, 100, true);
                const existingTracking = parentTrackings.items.find(t => 
                    t.objectData.mailNumber === tracking.mailNumber
                );

                if (existingTracking) {
                    // Mettre à jour le suivi existant avec les informations complètes
                    await trickleUpdateObject(`imputation:${parentDirection}`, existingTracking.objectId, {
                        ...existingTracking.objectData,
                        status: 'traite',
                        treatmentName: tracking.treatmentName,
                        responseFile: tracking.responseFile,
                        treatedDate: tracking.treatedDate || new Date().toISOString(),
                        validatedBy: user.direction,
                        validationDate: new Date().toISOString()
                    });
                } else {
                    // Créer un nouveau suivi dans la direction parent
                    await trickleCreateObject(`imputation:${parentDirection}`, {
                        mailId: tracking.originalMailId || tracking.mailId,
                        mailNumber: tracking.mailNumber,
                        mailObject: tracking.mailObject,
                        imputedTo: user.direction,
                        imputedBy: parentDirection,
                        status: 'traite',
                        treatmentName: tracking.treatmentName,
                        responseFile: tracking.responseFile,
                        treatedDate: tracking.treatedDate || new Date().toISOString(),
                        validatedBy: user.direction,
                        validationDate: new Date().toISOString(),
                        date: new Date().toISOString()
                    });
                }
            } catch (error) {
                console.error('Erreur création suivi parent:', error);
            }
        };

        const finalizeInOriginalDirection = async (tracking) => {
            try {
                // Trouver le courrier original et le marquer comme finalement validé
                const originalDirection = tracking.originalDirection || user.direction;
                const mails = await trickleListObjects(`mail:${originalDirection}`, 100, true);
                const originalMail = mails.items.find(m => 
                    m.objectData.numero === tracking.mailNumber
                );
                
                if (originalMail) {
                    await trickleUpdateObject(`mail:${originalDirection}`, originalMail.objectId, {
                        ...originalMail.objectData,
                        status: 'valide',
                        finalValidatedBy: user.direction,
                        finalValidationDate: new Date().toISOString(),
                        treatmentName: tracking.treatmentName,
                        responseFile: tracking.responseFile
                    });
                }
            } catch (error) {
                console.error('Erreur finalisation:', error);
            }
        };

        const markAsValidatedInCurrentDirection = async (tracking) => {
            try {
                const mails = await trickleListObjects(`mail:${user.direction}`, 100, true);
                const mail = mails.items.find(m => m.objectData.numero === tracking.mailNumber);
                
                if (mail) {
                    await trickleUpdateObject(`mail:${user.direction}`, mail.objectId, {
                        ...mail.objectData,
                        status: 'valide',
                        validatedBy: user.direction,
                        validationDate: new Date().toISOString(),
                        treatmentName: tracking.treatmentName,
                        responseFile: tracking.responseFile
                    });
                }
            } catch (error) {
                console.error('Erreur marquage validation:', error);
            }
        };

        const handleReject = async (tracking) => {
            try {
                const mails = await trickleListObjects(`mail:${tracking.imputedTo}`, 100, true);
                const mail = mails.items.find(m => m.objectData.numero === tracking.mailNumber);
                
                if (mail) {
                    await trickleUpdateObject(`mail:${tracking.imputedTo}`, mail.objectId, {
                        ...mail.objectData,
                        status: 'traitement',
                        rejectedBy: user.direction,
                        rejectionDate: new Date().toISOString()
                    });
                }

                await trickleUpdateObject(`imputation:${user.direction}`, tracking.id, {
                    ...tracking,
                    status: 'rejete',
                    rejectedBy: user.direction,
                    rejectionDate: new Date().toISOString()
                });

                alert('Courrier rejeté et retourné en traitement');
                loadTrackings();
            } catch (error) {
                alert('Erreur lors du rejet');
                console.error('Rejection error:', error);
            }
        };

        const downloadFile = (filename) => {
            alert(`Téléchargement du fichier: ${filename}`);
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'suivi-imputation',
            'data-file': 'components/SuiviImputation.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Suivi des Imputations'),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Numéro', 'Objet', 'Traitement', 'Imputé à', 'Fichier réponse', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, trackings.map(tracking =>
                        React.createElement('tr', {
                            key: tracking.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'numero',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, tracking.mailNumber),
                            React.createElement('td', {
                                key: 'objet',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, tracking.mailObject),
                            React.createElement('td', {
                                key: 'traitement',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, tracking.treatmentName || 'En cours'),
                            React.createElement('td', {
                                key: 'imputed-to',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, tracking.imputedTo),
                            React.createElement('td', {
                                key: 'file',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, tracking.responseFile ? [
                                React.createElement('button', {
                                    key: 'download-btn',
                                    onClick: () => downloadFile(tracking.responseFile),
                                    className: 'text-blue-600 hover:text-blue-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'download-icon',
                                        className: 'fas fa-download mr-1'
                                    }),
                                    'Télécharger'
                                ])
                            ] : 'Aucun fichier'),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, tracking.status === 'traite' ? [
                                React.createElement('button', {
                                    key: 'validate',
                                    onClick: () => handleValidate(tracking),
                                    className: 'bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 mr-2'
                                }, 'Valider'),
                                React.createElement('button', {
                                    key: 'reject',
                                    onClick: () => handleReject(tracking),
                                    className: 'bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700'
                                }, 'Rejeter')
                            ] : [
                                React.createElement('span', {
                                    key: 'status',
                                    className: 'text-orange-600 font-medium'
                                }, tracking.status === 'rejete' ? 'Rejeté' : 'En traitement')
                            ])
                        ])
                    ))
                ])
            ])
        ]);
    } catch (error) {
        console.error('SuiviImputation component error:', error);
        reportError(error);
    }
}

window.ValidationCongesPage = function ValidationCongesPage({ user }) {
    try {
        const [demandes, setDemandes] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [selectedDemande, setSelectedDemande] = React.useState(null);
        const [notification, setNotification] = React.useState('');

        React.useEffect(() => {
            loadDemandesEnAttente();
        }, []);

        const loadDemandesEnAttente = async () => {
            try {
                setLoading(true);
                const response = await trickleListObjects('demande_conge', 50, true);
                const demandesEnAttente = response.items.filter(item => 
                    item.objectData.statut === 'en_attente' || 
                    item.objectData.statut === 'soumise'
                );
                setDemandes(demandesEnAttente);
            } catch (error) {
                setNotification('Erreur lors du chargement des demandes');
            } finally {
                setLoading(false);
            }
        };

        const approuverDemande = async (demandeId, decision, commentaire = '') => {
            try {
                const demande = demandes.find(d => d.objectId === demandeId);
                if (!demande) return;

                const nouveauStatut = decision === 'approuver' ? 'approuvee' : 'refusee';
                
                await trickleUpdateObject('demande_conge', demandeId, {
                    ...demande.objectData,
                    statut: nouveauStatut,
                    date_validation: new Date().toISOString(),
                    validateur_id: user.id,
                    commentaire_validation: commentaire
                });

                // Notification automatique
                await window.workflowCongesHierarchique.envoyerNotificationDecision(
                    demande.objectData.agent_id,
                    decision,
                    demande.objectData.type_conge,
                    commentaire
                );

                setNotification(`Demande ${decision === 'approuver' ? 'approuvée' : 'refusée'} avec succès`);
                loadDemandesEnAttente();
            } catch (error) {
                setNotification('Erreur lors de la validation');
            }
        };

        const getStatutColor = (statut) => {
            switch (statut) {
                case 'en_attente': return 'text-yellow-600 bg-yellow-100';
                case 'soumise': return 'text-blue-600 bg-blue-100';
                case 'approuvee': return 'text-green-600 bg-green-100';
                case 'refusee': return 'text-red-600 bg-red-100';
                default: return 'text-gray-600 bg-gray-100';
            }
        };

        if (loading) {
            return (
                <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
            );
        }

        return (
            <div className="p-6" data-name="validation-conges-page" data-file="components/ValidationCongesPage.js">
                <div className="mb-6">
                    <h1 className="text-2xl font-bold text-gray-900">Validation des Congés</h1>
                    <p className="text-gray-600">Gérez les demandes de congés en attente de validation</p>
                </div>

                {notification && (
                    <div className="mb-4 p-4 bg-blue-100 border border-blue-300 rounded-md">
                        <p className="text-blue-800">{notification}</p>
                    </div>
                )}

                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                    <div className="px-6 py-4 border-b border-gray-200">
                        <h2 className="text-lg font-semibold">Demandes en attente ({demandes.length})</h2>
                    </div>

                    {demandes.length === 0 ? (
                        <div className="p-8 text-center text-gray-500">
                            <i className="fas fa-check-circle text-4xl mb-4"></i>
                            <p>Aucune demande en attente de validation</p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Agent</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Période</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durée</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {demandes.map((demande) => (
                                        <tr key={demande.objectId} className="hover:bg-gray-50">
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <div className="text-sm font-medium text-gray-900">
                                                    {demande.objectData.agent_nom}
                                                </div>
                                                <div className="text-sm text-gray-500">
                                                    {demande.objectData.agent_direction}
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                {demande.objectData.type_conge}
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                <div>{new Date(demande.objectData.date_debut).toLocaleDateString()}</div>
                                                <div className="text-gray-500">au {new Date(demande.objectData.date_fin).toLocaleDateString()}</div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                {demande.objectData.duree_jours} jour(s)
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatutColor(demande.objectData.statut)}`}>
                                                    {demande.objectData.statut}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                                                <button
                                                    onClick={() => approuverDemande(demande.objectId, 'approuver')}
                                                    className="text-green-600 hover:text-green-900"
                                                >
                                                    <i className="fas fa-check"></i> Approuver
                                                </button>
                                                <button
                                                    onClick={() => approuverDemande(demande.objectId, 'refuser')}
                                                    className="text-red-600 hover:text-red-900"
                                                >
                                                    <i className="fas fa-times"></i> Refuser
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        );
    } catch (error) {
        console.error('ValidationCongesPage error:', error);
        return (
            <div className="p-6 text-center">
                <p className="text-red-600">Erreur lors du chargement de la page</p>
            </div>
        );
    }
};
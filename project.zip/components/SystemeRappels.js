function SystemeRappels({ onClose }) {
    const [rappels, setRappels] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [configRappels, setConfigRappels] = React.useState({
        delaiAvertissement: 24,
        frequenceRappel: 48,
        rappelActif: true
    });

    React.useEffect(() => {
        chargerRappels();
        chargerConfiguration();
    }, []);

    const chargerRappels = async () => {
        try {
            setLoading(true);
            const rappelsData = await window.rappelManager.obtenirRappelsEnAttente();
            setRappels(rappelsData);
        } catch (error) {
            console.error('Erreur chargement rappels:', error);
        } finally {
            setLoading(false);
        }
    };

    const chargerConfiguration = async () => {
        try {
            const config = await window.rappelManager.obtenirConfiguration();
            if (config) setConfigRappels(config);
        } catch (error) {
            console.error('Erreur chargement configuration:', error);
        }
    };

    const sauvegarderConfiguration = async () => {
        try {
            await window.rappelManager.sauvegarderConfiguration(configRappels);
            alert('Configuration sauvegardée');
        } catch (error) {
            alert('Erreur lors de la sauvegarde');
        }
    };

    if (loading) {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                <div className="bg-white rounded-lg p-6">
                    <div className="text-center">Chargement des rappels...</div>
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center p-6 border-b">
                    <h2 className="text-xl font-bold">Système de Rappels</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
                        <i className="fas fa-times"></i>
                    </button>
                </div>
                <div className="p-6">
                    <div className="mb-6 bg-gray-50 p-4 rounded">
                        <h3 className="font-semibold mb-4">Configuration</h3>
                        <div className="grid grid-cols-3 gap-4">
                            <div>
                                <label className="block text-sm font-medium mb-2">Délai (heures)</label>
                                <input type="number" value={configRappels.delaiAvertissement} 
                                    onChange={(e) => setConfigRappels({...configRappels, delaiAvertissement: parseInt(e.target.value)})}
                                    className="w-full border rounded px-3 py-2" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">Fréquence (heures)</label>
                                <input type="number" value={configRappels.frequenceRappel}
                                    onChange={(e) => setConfigRappels({...configRappels, frequenceRappel: parseInt(e.target.value)})}
                                    className="w-full border rounded px-3 py-2" />
                            </div>
                            <div className="flex items-end">
                                <label className="flex items-center">
                                    <input type="checkbox" checked={configRappels.rappelActif}
                                        onChange={(e) => setConfigRappels({...configRappels, rappelActif: e.target.checked})}
                                        className="mr-2" />
                                    Actifs
                                </label>
                            </div>
                        </div>
                        <button onClick={sauvegarderConfiguration} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                            Sauvegarder
                        </button>
                    </div>
                    <div>
                        <h3 className="font-semibold mb-4">Rappels ({rappels.length})</h3>
                        {rappels.length === 0 ? (
                            <div className="text-center py-8 text-gray-500">Aucun rappel en attente</div>
                        ) : (
                            <div className="space-y-4">
                                {rappels.map((rappel) => (
                                    <div key={rappel.id} className="border rounded p-4">
                                        <div className="font-medium">{rappel.titre}</div>
                                        <div className="text-sm text-gray-600 mt-1">{rappel.description}</div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

window.SystemeRappels = SystemeRappels;
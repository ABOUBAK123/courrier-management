function FormationsAgent({ agent }) {
    try {
        const [formations, setFormations] = React.useState([]);
        const [showModal, setShowModal] = React.useState(false);

        React.useEffect(() => {
            loadFormations();
        }, [agent]);

        const loadFormations = async () => {
            const agentFormations = [
                {
                    id: 1,
                    titre: 'Formation Bureautique',
                    type: 'assignee',
                    dateDebut: '2024-03-15',
                    dateFin: '2024-03-17',
                    statut: 'planifie',
                    formateur: 'Centre de Formation'
                },
                {
                    id: 2,
                    titre: 'Gestion du Temps',
                    type: 'demandee',
                    dateDebut: '2024-04-01',
                    dateFin: '2024-04-02',
                    statut: 'attente',
                    justification: 'Améliorer ma productivité'
                }
            ];
            setFormations(agentFormations);
        };

        const getStatutColor = (statut) => {
            switch (statut) {
                case 'planifie': return 'bg-blue-100 text-blue-800';
                case 'en_cours': return 'bg-orange-100 text-orange-800';
                case 'termine': return 'bg-green-100 text-green-800';
                case 'attente': return 'bg-yellow-100 text-yellow-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        };

        return React.createElement('div', {
            className: 'p-6 space-y-6',
            'data-name': 'formations-agent',
            'data-file': 'components/FormationsAgent.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Mes Formations'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowModal(true),
                    className: 'bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700'
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: 'fas fa-plus mr-2'
                    }),
                    'Demander Formation'
                ])
            ]),
            React.createElement('div', {
                key: 'stats',
                className: 'grid grid-cols-1 md:grid-cols-3 gap-6'
            }, [
                React.createElement('div', {
                    key: 'assignees',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-semibold text-gray-800 mb-2'
                    }, 'Formations Assignées'),
                    React.createElement('p', {
                        key: 'count',
                        className: 'text-3xl font-bold text-blue-600'
                    }, formations.filter(f => f.type === 'assignee').length)
                ]),
                React.createElement('div', {
                    key: 'demandees',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-semibold text-gray-800 mb-2'
                    }, 'Demandes Personnelles'),
                    React.createElement('p', {
                        key: 'count',
                        className: 'text-3xl font-bold text-green-600'
                    }, formations.filter(f => f.type === 'demandee').length)
                ]),
                React.createElement('div', {
                    key: 'terminees',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-semibold text-gray-800 mb-2'
                    }, 'Terminées'),
                    React.createElement('p', {
                        key: 'count',
                        className: 'text-3xl font-bold text-purple-600'
                    }, formations.filter(f => f.statut === 'termine').length)
                ])
            ]),
            React.createElement('div', {
                key: 'list',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'px-6 py-4 bg-gray-50 border-b'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-semibold text-gray-800'
                    }, 'Liste des Formations')
                ]),
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Formation', 'Type', 'Période', 'Statut', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, formations.map(formation =>
                        React.createElement('tr', {
                            key: formation.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'titre',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('div', {
                                    key: 'titre-content',
                                    className: 'text-sm font-medium text-gray-900'
                                }, formation.titre),
                                formation.formateur && React.createElement('div', {
                                    key: 'formateur',
                                    className: 'text-sm text-gray-500'
                                }, formation.formateur)
                            ]),
                            React.createElement('td', {
                                key: 'type',
                                className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                            }, formation.type === 'assignee' ? 'Assignée' : 'Demandée'),
                            React.createElement('td', {
                                key: 'periode',
                                className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                            }, `${new Date(formation.dateDebut).toLocaleDateString()} - ${new Date(formation.dateFin).toLocaleDateString()}`),
                            React.createElement('td', {
                                key: 'statut',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('span', {
                                    key: 'badge',
                                    className: `px-2 py-1 text-xs font-semibold rounded-full ${getStatutColor(formation.statut)}`
                                }, formation.statut)
                            ]),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium'
                            }, [
                                React.createElement('button', {
                                    key: 'view',
                                    className: 'text-blue-600 hover:text-blue-900'
                                }, 'Voir')
                            ])
                        ])
                    ))
                ])
            ]),
            showModal && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Demande de Formation'),
                    React.createElement('form', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('div', { key: 'titre' }, [
                            React.createElement('label', {
                                key: 'label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Titre de la formation'),
                            React.createElement('input', {
                                key: 'input',
                                type: 'text',
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ]),
                        React.createElement('div', { key: 'justification' }, [
                            React.createElement('label', {
                                key: 'label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Justification *'),
                            React.createElement('textarea', {
                                key: 'textarea',
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                                rows: 3,
                                required: true
                            })
                        ])
                    ]),
                    React.createElement('div', {
                        key: 'actions',
                        className: 'flex justify-end space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'cancel',
                            onClick: () => setShowModal(false),
                            className: 'px-4 py-2 text-gray-600 hover:text-gray-800'
                        }, 'Annuler'),
                        React.createElement('button', {
                            key: 'submit',
                            className: 'bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700'
                        }, 'Envoyer')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('FormationsAgent component error:', error);
        reportError(error);
    }
}

window.ActeCongeGenerator = function({ acteData, onClose }) {
    const { useState } = React;
    const [generating, setGenerating] = useState(false);

    const generatePDF = async () => {
        setGenerating(true);
        try {
            // Simuler la génération PDF
            const pdfContent = `
ACTE DE MISE EN CONGÉ
N° ${acteData.numero_acte}

Agent: ${acteData.agent_nom}
Matricule: ${acteData.matricule}
Type de congé: ${acteData.type_conge}
Du: ${new Date(acteData.date_debut).toLocaleDateString('fr-FR')}
Au: ${new Date(acteData.date_fin).toLocaleDateString('fr-FR')}
Durée: ${acteData.duree_jours} jour(s)

Validateurs:
${acteData.validateurs.map(v => `- ${v.nom} (${new Date(v.date).toLocaleDateString('fr-FR')})`).join('\n')}

Généré le: ${new Date(acteData.date_generation).toLocaleDateString('fr-FR')}
Statut: APPROUVÉ
            `;
            
            // Créer un blob PDF simulé
            const blob = new Blob([pdfContent], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            
            // Télécharger
            const a = document.createElement('a');
            a.href = url;
            a.download = `Acte_Conge_${acteData.numero_acte}.txt`;
            a.click();
            
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error('Erreur génération PDF:', error);
        } finally {
            setGenerating(false);
        }
    };

    return React.createElement('div', { 
        className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50' 
    },
        React.createElement('div', { 
            className: 'bg-white rounded-lg p-6 max-w-md w-full mx-4' 
        }, [
            React.createElement('div', { 
                key: 'header',
                className: 'flex justify-between items-center mb-4' 
            }, [
                React.createElement('h3', { 
                    key: 'title',
                    className: 'text-lg font-semibold' 
                }, 'Acte de Congé Généré'),
                React.createElement('button', {
                    key: 'close',
                    onClick: onClose,
                    className: 'text-gray-500 hover:text-gray-700'
                }, '✕')
            ]),
            
            React.createElement('div', { 
                key: 'content',
                className: 'mb-6 text-sm space-y-2' 
            }, [
                React.createElement('p', { key: 'info1' }, 
                    `📄 N° Acte: ${acteData.numero_acte}`),
                React.createElement('p', { key: 'info2' }, 
                    `👤 Agent: ${acteData.agent_nom}`),
                React.createElement('p', { key: 'info3' }, 
                    `📅 Période: ${new Date(acteData.date_debut).toLocaleDateString('fr-FR')} - ${new Date(acteData.date_fin).toLocaleDateString('fr-FR')}`),
                React.createElement('p', { key: 'info4' }, 
                    `⏱️ Durée: ${acteData.duree_jours} jour(s)`),
                React.createElement('div', { key: 'status', className: 'pt-2' },
                    React.createElement('span', { 
                        className: 'px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium' 
                    }, '✅ APPROUVÉ DÉFINITIVEMENT')
                )
            ]),
            
            React.createElement('div', { 
                key: 'actions',
                className: 'flex space-x-3' 
            }, [
                React.createElement('button', {
                    key: 'download',
                    onClick: generatePDF,
                    disabled: generating,
                    className: 'flex-1 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 disabled:opacity-50'
                }, generating ? '⏳ Génération...' : '📄 Télécharger PDF'),
                
                React.createElement('button', {
                    key: 'close-btn',
                    onClick: onClose,
                    className: 'px-4 py-2 text-gray-600 border rounded hover:bg-gray-50'
                }, 'Fermer')
            ])
        ])
    );
};
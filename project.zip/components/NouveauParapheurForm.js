function NouveauParapheurForm({ 
    currentStep, 
    setCurrentStep, 
    formData, 
    setFormData, 
    users, 
    models, 
    handleDemarrer, 
    handleDupliquer, 
    handleSupprimer, 
    saving,
    handleModelChange
}) {
    try {
        const [showDocumentViewer, setShowDocumentViewer] = React.useState(false);
        const [selectedDocument, setSelectedDocument] = React.useState(null);

        const addValidationStep = () => {
            const newValidation = {
                id: Date.now(),
                utilisateur: '',
                ordre: formData.validations.length + 1,
                obligatoire: true
            };
            setFormData(prev => ({
                ...prev,
                validations: [...prev.validations, newValidation]
            }));
        };

        const addSignatureStep = () => {
            const newSignature = {
                id: Date.now(),
                utilisateur: '',
                ordre: formData.signatures.length + 1,
                obligatoire: true
            };
            setFormData(prev => ({
                ...prev,
                signatures: [...prev.signatures, newSignature]
            }));
        };

        const updateValidationStep = (id, field, value) => {
            setFormData(prev => ({
                ...prev,
                validations: prev.validations.map(v => 
                    v.id === id ? { ...v, [field]: value } : v
                )
            }));
        };

        const updateSignatureStep = (id, field, value) => {
            setFormData(prev => ({
                ...prev,
                signatures: prev.signatures.map(s => 
                    s.id === id ? { ...s, [field]: value } : s
                )
            }));
        };

        const removeValidationStep = (id) => {
            setFormData(prev => ({
                ...prev,
                validations: prev.validations.filter(v => v.id !== id)
            }));
        };

        const removeSignatureStep = (id) => {
            setFormData(prev => ({
                ...prev,
                signatures: prev.signatures.filter(s => s.id !== id)
            }));
        };

        const handleDocumentUpload = (e) => {
            const files = Array.from(e.target.files);
            const newDocuments = files.map(file => ({
                id: Date.now() + Math.random(),
                name: file.name,
                size: file.size,
                type: file.type,
                url: URL.createObjectURL(file),
                uploadedAt: new Date().toISOString(),
                signatureZones: []
            }));
            
            setFormData(prev => ({
                ...prev,
                documents: [...prev.documents, ...newDocuments]
            }));
        };

        const removeDocument = (id) => {
            setFormData(prev => ({
                ...prev,
                documents: prev.documents.filter(doc => doc.id !== id)
            }));
        };

        const openDocument = (document) => {
            setSelectedDocument(document);
            setShowDocumentViewer(true);
        };

        const handleSaveSignatureZone = (zone) => {
            if (!selectedDocument) return;
            
            setFormData(prev => ({
                ...prev,
                documents: prev.documents.map(doc => 
                    doc.id === selectedDocument.id 
                        ? { ...doc, signatureZones: [...(doc.signatureZones || []), zone] }
                        : doc
                )
            }));
        };

        return React.createElement(NouveauParapheurFormContent, {
            currentStep,
            setCurrentStep,
            formData,
            setFormData,
            users,
            models,
            handleDemarrer,
            handleDupliquer,
            handleSupprimer,
            saving,
            showDocumentViewer,
            setShowDocumentViewer,
            selectedDocument,
            addValidationStep,
            addSignatureStep,
            updateValidationStep,
            updateSignatureStep,
            removeValidationStep,
            removeSignatureStep,
            handleDocumentUpload,
            removeDocument,
            openDocument,
            handleSaveSignatureZone,
            handleModelChange
        });
    } catch (error) {
        console.error('NouveauParapheurForm component error:', error);
        reportError(error);
    }
}

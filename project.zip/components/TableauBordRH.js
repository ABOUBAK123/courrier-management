window.TableauBordRH = function TableauBordRH({ user }) {
    try {
        const [stats, setStats] = React.useState({});
        const [demandesRecentes, setDemandesRecentes] = React.useState([]);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadTableauBord();
        }, []);

        const loadTableauBord = async () => {
            try {
                const response = await trickleListObjects('demande_conge', 200, true);
                const demandes = response.items;
                
                const statistiques = calculerStatistiques(demandes);
                setStats(statistiques);
                
                const recentes = demandes.slice(0, 10);
                setDemandesRecentes(recentes);
            } catch (error) {
                console.error('Erreur chargement tableau de bord:', error);
            } finally {
                setLoading(false);
            }
        };

        const calculerStatistiques = (demandes) => {
            const maintenant = new Date();
            const debutMois = new Date(maintenant.getFullYear(), maintenant.getMonth(), 1);
            const finMois = new Date(maintenant.getFullYear(), maintenant.getMonth() + 1, 0);

            const demandesMois = demandes.filter(d => {
                const dateCreation = new Date(d.createdAt);
                return dateCreation >= debutMois && dateCreation <= finMois;
            });

            const congesValides = demandes.filter(d => 
                d.objectData.statut === 'approuvee' &&
                new Date(d.objectData.date_debut) >= maintenant
            );

            return {
                totalDemandes: demandes.length,
                demandesMois: demandesMois.length,
                enAttente: demandes.filter(d => d.objectData.statut === 'en_attente').length,
                approuvees: demandes.filter(d => d.objectData.statut === 'approuvee').length,
                refusees: demandes.filter(d => d.objectData.statut === 'refusee').length,
                absencesProchaines: congesValides.length,
                tauxApprobation: demandes.length > 0 
                    ? Math.round((demandes.filter(d => d.objectData.statut === 'approuvee').length / demandes.length) * 100)
                    : 0
            };
        };

        const exporterDonnees = async (format) => {
            try {
                await window.exportManager.exporterConges(format);
            } catch (error) {
                console.error('Erreur export:', error);
            }
        };

        if (loading) {
            return (
                <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
            );
        }

        return (
            <div className="p-6" data-name="tableau-bord-rh" data-file="components/TableauBordRH.js">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-2xl font-bold text-gray-900">Tableau de bord RH</h1>
                    <div className="flex space-x-2">
                        <button 
                            onClick={() => exporterDonnees('csv')}
                            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                        >
                            <i className="fas fa-file-csv mr-2"></i>CSV
                        </button>
                        <button 
                            onClick={() => exporterDonnees('pdf')}
                            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                        >
                            <i className="fas fa-file-pdf mr-2"></i>PDF
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">Total demandes</p>
                                <p className="text-2xl font-bold">{stats.totalDemandes}</p>
                            </div>
                            <i className="fas fa-calendar-alt text-blue-500 text-2xl"></i>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">En attente</p>
                                <p className="text-2xl font-bold text-yellow-600">{stats.enAttente}</p>
                            </div>
                            <i className="fas fa-clock text-yellow-500 text-2xl"></i>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">Absences prévues</p>
                                <p className="text-2xl font-bold text-orange-600">{stats.absencesProchaines}</p>
                            </div>
                            <i className="fas fa-user-minus text-orange-500 text-2xl"></i>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">Taux approbation</p>
                                <p className="text-2xl font-bold text-green-600">{stats.tauxApprobation}%</p>
                            </div>
                            <i className="fas fa-check-circle text-green-500 text-2xl"></i>
                        </div>
                    </div>
                </div>

                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                    <div className="px-6 py-4 border-b">
                        <h2 className="text-lg font-semibold">Demandes récentes</h2>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Agent</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Période</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                {demandesRecentes.map((demande) => (
                                    <tr key={demande.objectId}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            {demande.objectData.agent_nom}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                                            {demande.objectData.type_conge}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                                            {new Date(demande.objectData.date_debut).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`px-2 py-1 text-xs rounded-full ${
                                                demande.objectData.statut === 'approuvee' ? 'bg-green-100 text-green-800' :
                                                demande.objectData.statut === 'refusee' ? 'bg-red-100 text-red-800' :
                                                'bg-yellow-100 text-yellow-800'
                                            }`}>
                                                {demande.objectData.statut}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {new Date(demande.createdAt).toLocaleDateString()}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('TableauBordRH error:', error);
        return <div className="p-6 text-red-600">Erreur lors du chargement</div>;
    }
};
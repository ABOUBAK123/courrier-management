const ToastNotification = ({ toast, onRemove }) => {
    const [isVisible, setIsVisible] = React.useState(false);
    const [isRemoving, setIsRemoving] = React.useState(false);

    React.useEffect(() => {
        setIsVisible(true);
        
        const timer = setTimeout(() => {
            handleRemove();
        }, toast.duration || 5000);

        return () => clearTimeout(timer);
    }, []);

    const handleRemove = () => {
        setIsRemoving(true);
        setTimeout(() => {
            onRemove(toast.id);
        }, 300);
    };

    const getToastStyles = () => {
        const baseStyles = 'p-4 rounded-lg shadow-lg border-l-4 flex items-start space-x-3 min-w-80 max-w-md';
        
        switch (toast.type) {
            case 'success':
                return `${baseStyles} bg-green-50 border-green-400 text-green-800`;
            case 'error':
                return `${baseStyles} bg-red-50 border-red-400 text-red-800`;
            case 'warning':
                return `${baseStyles} bg-yellow-50 border-yellow-400 text-yellow-800`;
            case 'info':
                return `${baseStyles} bg-blue-50 border-blue-400 text-blue-800`;
            case 'loading':
                return `${baseStyles} bg-gray-50 border-gray-400 text-gray-800`;
            default:
                return `${baseStyles} bg-gray-50 border-gray-400 text-gray-800`;
        }
    };

    const getIcon = () => {
        switch (toast.type) {
            case 'success':
                return 'fas fa-check-circle text-green-500';
            case 'error':
                return 'fas fa-exclamation-circle text-red-500';
            case 'warning':
                return 'fas fa-exclamation-triangle text-yellow-500';
            case 'info':
                return 'fas fa-info-circle text-blue-500';
            case 'loading':
                return 'fas fa-spinner fa-spin text-gray-500';
            default:
                return 'fas fa-bell text-gray-500';
        }
    };

    const animationClass = isRemoving 
        ? 'transform translate-x-full opacity-0' 
        : isVisible 
            ? 'transform translate-x-0 opacity-100' 
            : 'transform translate-x-full opacity-0';

    return React.createElement('div', {
        className: `transition-all duration-300 ease-in-out ${animationClass} mb-2`,
        'data-name': 'toast-notification',
        'data-file': 'components/ToastNotification.js'
    }, [
        React.createElement('div', {
            key: 'toast-content',
            className: getToastStyles()
        }, [
            React.createElement('div', {
                key: 'icon',
                className: 'flex-shrink-0'
            }, [
                React.createElement('i', {
                    key: 'icon-element',
                    className: getIcon()
                })
            ]),
            React.createElement('div', {
                key: 'content',
                className: 'flex-1'
            }, [
                toast.title && React.createElement('div', {
                    key: 'title',
                    className: 'font-semibold mb-1'
                }, toast.title),
                React.createElement('div', {
                    key: 'message',
                    className: 'text-sm'
                }, toast.message)
            ]),
            toast.type !== 'loading' && React.createElement('button', {
                key: 'close-btn',
                onClick: handleRemove,
                className: 'flex-shrink-0 ml-2 text-gray-400 hover:text-gray-600'
            }, [
                React.createElement('i', {
                    key: 'close-icon',
                    className: 'fas fa-times'
                })
            ])
        ])
    ]);
};

window.ToastNotification = ToastNotification;
function EnTraitement({ user }) {
    try {
        const [mails, setMails] = React.useState([]);
        const [showModal, setShowModal] = React.useState(false);
        const [showReimputeModal, setShowReimputeModal] = React.useState(false);
        const [selectedMail, setSelectedMail] = React.useState(null);
        const [showPDFViewer, setShowPDFViewer] = React.useState(false);
        const [directions, setDirections] = React.useState([]);
        const [instructions, setInstructions] = React.useState([]);
        const [treatmentData, setTreatmentData] = React.useState({
            nomTraitement: '',
            fichierReponse: null
        });
        const [reimputationData, setReimputationData] = React.useState({
            direction: '',
            instruction: '',
            instructionParticuliere: '',
            delai: ''
        });

        React.useEffect(() => {
            loadProcessingMails();
            loadDirections();
            loadInstructions();
        }, [user]);

        const canViewProcessingMails = (userRole) => {
            return ['DIRECTEUR GENERAL', 'DIRECTEUR', 'DIR CAB', 'SOUS-DIRECTEUR', 'ASSISTANT', 'CHEF DE SERVICE'].includes(userRole);
        };

        const canReimpute = (userRole) => {
            return ['DIR CAB', 'DIRECTEUR GENERAL', 'DIRECTEUR', 'SOUS-DIRECTEUR'].includes(userRole);
        };

        const loadProcessingMails = async () => {
            try {
                if (!canViewProcessingMails(user.role)) return;
                const response = await trickleListObjects(`mail:${user.direction}`, 100, true);
                const processingMails = response.items
                    .map(item => ({ ...item.objectData, id: item.objectId }))
                    .filter(mail => mail.status === 'traitement' && mail.imputedTo === user.direction);
                setMails(processingMails);
            } catch (error) {
                console.error('Erreur lors du chargement:', error);
            }
        };

        const loadDirections = async () => {
            try {
                const response = await trickleListObjects('directions', 100, true);
                const allDirections = response.items.map(item => item.objectData);
                const childDirections = allDirections.filter(dir => 
                    dir.directionParent === user.direction
                );
                setDirections(childDirections);
            } catch (error) {
                console.error('Erreur chargement directions:', error);
            }
        };

        const loadInstructions = async () => {
            try {
                const response = await trickleListObjects('instructions', 100, true);
                const instructionData = response.items.map(item => item.objectData);
                setInstructions(instructionData);
            } catch (error) {
                console.error('Erreur chargement instructions:', error);
            }
        };

        const handleViewMail = (mail) => {
            setSelectedMail(mail);
            setShowPDFViewer(true);
        };

        const handleTreat = async () => {
            try {
                await trickleUpdateObject(`mail:${user.direction}`, selectedMail.id, {
                    ...selectedMail,
                    status: 'traite',
                    treatmentName: treatmentData.nomTraitement,
                    responseFile: treatmentData.fichierReponse,
                    treatedBy: user.direction,
                    treatmentDate: new Date().toISOString()
                });

                if (selectedMail.imputedBy) {
                    await trickleCreateObject(`imputation:${selectedMail.imputedBy}`, {
                        mailId: selectedMail.originalMailId || selectedMail.id,
                        mailNumber: selectedMail.numero,
                        mailObject: selectedMail.objet,
                        imputedTo: user.direction,
                        imputedBy: selectedMail.imputedBy,
                        status: 'traite',
                        treatmentName: treatmentData.nomTraitement,
                        responseFile: treatmentData.fichierReponse,
                        treatedDate: new Date().toISOString(),
                        date: new Date().toISOString()
                    });
                }

                alert('Courrier traité avec succès');
                setShowModal(false);
                loadProcessingMails();
                setTreatmentData({ nomTraitement: '', fichierReponse: null });
            } catch (error) {
                alert('Erreur lors du traitement');
            }
        };

        const handleReimpute = async () => {
            try {
                await trickleUpdateObject(`mail:${user.direction}`, selectedMail.id, {
                    ...selectedMail,
                    status: 'reimpute',
                    reimputedTo: reimputationData.direction,
                    reimputedBy: user.direction,
                    reimputationDate: new Date().toISOString()
                });

                await trickleCreateObject(`mail:${reimputationData.direction}`, {
                    ...selectedMail,
                    status: 'traitement',
                    direction: reimputationData.direction,
                    imputedTo: reimputationData.direction,
                    imputedBy: user.direction,
                    instruction: reimputationData.instruction,
                    instructionParticuliere: reimputationData.instructionParticuliere,
                    delai: reimputationData.delai,
                    reimputationDate: new Date().toISOString()
                });

                alert('Courrier réimputé avec succès');
                setShowReimputeModal(false);
                loadProcessingMails();
                setReimputationData({ direction: '', instruction: '', instructionParticuliere: '', delai: '' });
            } catch (error) {
                alert('Erreur lors de la réimputation');
            }
        };

        if (!canViewProcessingMails(user.role)) {
            return React.createElement('div', {
                className: 'p-6 text-center text-red-600'
            }, 'Accès non autorisé pour ce rôle');
        }

        return React.createElement('div', {
            className: 'p-6 fade-in'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Courriers En Traitement'),
            mails.length === 0 ? React.createElement('div', {
                key: 'no-mails',
                className: 'bg-white rounded-lg shadow-md p-8 text-center text-gray-500'
            }, 'Aucun courrier en traitement') : React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Numéro', 'Objet', 'Instruction', 'Imputé par', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, mails.map(mail =>
                        React.createElement('tr', {
                            key: mail.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'numero',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, mail.numero),
                            React.createElement('td', {
                                key: 'objet',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.objet),
                            React.createElement('td', {
                                key: 'instruction',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.instruction || '-'),
                            React.createElement('td', {
                                key: 'imputed-by',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.imputedBy || '-'),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'view',
                                    onClick: () => handleViewMail(mail),
                                    className: 'text-blue-600 hover:text-blue-900 mr-2',
                                    title: 'Voir le document'
                                }, [
                                    React.createElement('i', {
                                        key: 'eye-icon',
                                        className: 'fas fa-eye'
                                    })
                                ]),
                                React.createElement('button', {
                                    key: 'treat',
                                    onClick: () => {
                                        setSelectedMail(mail);
                                        setShowModal(true);
                                    },
                                    className: 'bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 mr-2'
                                }, 'Traiter'),
                                canReimpute(user.role) && React.createElement('button', {
                                    key: 'reimpute',
                                    onClick: () => {
                                        setSelectedMail(mail);
                                        setShowReimputeModal(true);
                                    },
                                    className: 'bg-orange-600 text-white px-3 py-1 rounded hover:bg-orange-700'
                                }, 'Imputer')
                            ])
                        ])
                    ))
                ])
            ]),
            showPDFViewer && selectedMail && React.createElement(PDFViewer, {
                key: 'pdf-viewer',
                documentUrl: `data:application/pdf;base64,${selectedMail.files?.[0]?.content || ''}`,
                onClose: () => setShowPDFViewer(false),
                showSignatureZones: false
            }),
            React.createElement(EnTraitementModals, {
                key: 'treatment-modal',
                showModal,
                setShowModal,
                selectedMail,
                treatmentData,
                setTreatmentData,
                handleTreat
            }),
            showReimputeModal && React.createElement(ReimputeModal, {
                key: 'reimpute-modal',
                showReimputeModal,
                setShowReimputeModal,
                selectedMail,
                reimputationData,
                setReimputationData,
                handleReimpute,
                directions,
                instructions
            })
        ]);
    } catch (error) {
        console.error('EnTraitement component error:', error);
        reportError(error);
    }
}

function TypeDirections({ user }) {
    try {
        const [types, setTypes] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [editingType, setEditingType] = React.useState(null);
        const [formData, setFormData] = React.useState({
            nom: '',
            description: ''
        });

        React.useEffect(() => {
            loadTypes();
        }, []);

        const resetForm = () => {
            setFormData({ nom: '', description: '' });
            setEditingType(null);
            setShowForm(false);
        };

        const loadTypes = async () => {
            try {
                const response = await trickleListObjects('type-directions', 100, true);
                const typeData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setTypes(typeData);
            } catch (error) {
                console.error('Erreur lors du chargement des types:', error);
            }
        };

        const handleEdit = (type) => {
            setEditingType(type);
            setFormData({
                nom: type.nom || '',
                description: type.description || ''
            });
            setShowForm(true);
        };

        const handleSave = async () => {
            try {
                if (editingType) {
                    // Mode modification
                    await trickleUpdateObject('type-directions', editingType.id, {
                        ...editingType,
                        nom: formData.nom,
                        description: formData.description,
                        updatedBy: user.name,
                        updatedAt: new Date().toISOString()
                    });
                    alert('Type de direction modifié avec succès!');
                } else {
                    // Mode création
                    await trickleCreateObject('type-directions', {
                        ...formData,
                        createdBy: user.name,
                        createdAt: new Date().toISOString()
                    });
                    alert('Type de direction créé avec succès!');
                }
                
                resetForm();
                loadTypes();
            } catch (error) {
                alert(editingType ? 'Erreur lors de la modification' : 'Erreur lors de la création');
            }
        };

        const handleDelete = async (typeId) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce type?')) {
                try {
                    await trickleDeleteObject('type-directions', typeId);
                    alert('Type supprimé avec succès');
                    loadTypes();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'type-directions',
            'data-file': 'components/TypeDirections.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Types de Directions'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouveau Type')
            ]),
            React.createElement('div', {
                key: 'types-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            }, types.map(type =>
                React.createElement('div', {
                    key: type.id,
                    className: 'bg-white rounded-lg shadow-md p-6 card-hover'
                }, [
                    React.createElement('div', {
                        key: 'type-header',
                        className: 'flex justify-between items-start mb-4'
                    }, [
                        React.createElement('h3', {
                            key: 'type-name',
                            className: 'text-lg font-semibold text-gray-800'
                        }, type.nom),
                        React.createElement('div', {
                            key: 'actions',
                            className: 'flex space-x-2'
                        }, [
                            React.createElement('button', {
                                key: 'edit-btn',
                                onClick: () => handleEdit(type),
                                className: 'text-blue-600 hover:text-blue-900',
                                title: 'Modifier'
                            }, React.createElement('i', { className: 'fas fa-edit' })),
                            React.createElement('button', {
                                key: 'delete-btn',
                                onClick: () => handleDelete(type.id),
                                className: 'text-red-600 hover:text-red-900',
                                title: 'Supprimer'
                            }, React.createElement('i', { className: 'fas fa-trash' }))
                        ])
                    ]),
                    React.createElement('p', {
                        key: 'type-description',
                        className: 'text-gray-600 mb-4'
                    }, type.description || 'Aucune description'),
                    React.createElement('div', {
                        key: 'type-info',
                        className: 'text-sm text-gray-500'
                    }, [
                        React.createElement('p', { key: 'created-by' }, `Créé par: ${type.createdBy}`),
                        React.createElement('p', { key: 'created-date' }, `Date: ${new Date(type.createdAt).toLocaleDateString()}`)
                    ])
                ])
            )),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, editingType ? 'Modifier le Type de Direction' : 'Nouveau Type de Direction'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('input', {
                            key: 'nom-input',
                            type: 'text',
                            placeholder: 'Nom du type',
                            value: formData.nom,
                            onChange: (e) => setFormData(prev => ({ ...prev, nom: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('textarea', {
                            key: 'description-textarea',
                            placeholder: 'Description',
                            value: formData.description,
                            onChange: (e) => setFormData(prev => ({ ...prev, description: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            rows: 3
                        })
                    ]),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save-btn',
                            onClick: handleSave,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, editingType ? 'Modifier' : 'Créer'),
                        React.createElement('button', {
                            key: 'cancel-btn',
                            onClick: resetForm,
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('TypeDirections component error:', error);
        reportError(error);
    }
}

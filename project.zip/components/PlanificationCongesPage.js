window.PlanificationCongesPage = function PlanificationCongesPage({ user }) {
    try {
        const [congesPlannifies, setCongesPlannifies] = React.useState([]);
        const [equipe, setEquipe] = React.useState([]);
        const [periodeSelectionnee, setPeriodeSelectionnee] = React.useState('mois');
        const [dateActuelle, setDateActuelle] = React.useState(new Date());
        const [conflits, setConflits] = React.useState([]);

        React.useEffect(() => {
            loadCongesPlannifies();
            loadEquipe();
        }, [dateActuelle, periodeSelectionnee]);

        React.useEffect(() => {
            detecterConflits();
        }, [congesPlannifies]);

        const loadCongesPlannifies = async () => {
            try {
                const response = await trickleListObjects('demande_conge', 100, true);
                const congesApprouves = response.items.filter(item => 
                    item.objectData.statut === 'approuvee' &&
                    new Date(item.objectData.date_debut) >= new Date()
                );
                setCongesPlannifies(congesApprouves);
            } catch (error) {
                console.error('Erreur chargement congés:', error);
            }
        };

        const loadEquipe = async () => {
            try {
                const response = await trickleListObjects('personnel', 100, true);
                setEquipe(response.items);
            } catch (error) {
                console.error('Erreur chargement équipe:', error);
            }
        };

        const detecterConflits = () => {
            const conflitsDetectes = [];
            
            congesPlannifies.forEach((conge1, index) => {
                congesPlannifies.slice(index + 1).forEach(conge2 => {
                    if (conge1.objectData.agent_direction === conge2.objectData.agent_direction) {
                        const debut1 = new Date(conge1.objectData.date_debut);
                        const fin1 = new Date(conge1.objectData.date_fin);
                        const debut2 = new Date(conge2.objectData.date_debut);
                        const fin2 = new Date(conge2.objectData.date_fin);

                        if ((debut1 <= fin2 && fin1 >= debut2)) {
                            conflitsDetectes.push({
                                id: `${conge1.objectId}-${conge2.objectId}`,
                                agent1: conge1.objectData.agent_nom,
                                agent2: conge2.objectData.agent_nom,
                                direction: conge1.objectData.agent_direction,
                                periode: `${debut1.toLocaleDateString()} - ${fin2.toLocaleDateString()}`
                            });
                        }
                    }
                });
            });
            
            setConflits(conflitsDetectes);
        };

        const getCalendrierJours = () => {
            const debut = new Date(dateActuelle.getFullYear(), dateActuelle.getMonth(), 1);
            const fin = new Date(dateActuelle.getFullYear(), dateActuelle.getMonth() + 1, 0);
            const jours = [];
            
            for (let d = new Date(debut); d <= fin; d.setDate(d.getDate() + 1)) {
                jours.push(new Date(d));
            }
            return jours;
        };

        const getCongesPourJour = (jour) => {
            return congesPlannifies.filter(conge => {
                const debut = new Date(conge.objectData.date_debut);
                const fin = new Date(conge.objectData.date_fin);
                return jour >= debut && jour <= fin;
            });
        };

        const changerMois = (direction) => {
            const nouvelleDdate = new Date(dateActuelle);
            nouvelleDdate.setMonth(nouvelleDdate.getMonth() + direction);
            setDateActuelle(nouvelleDdate);
        };

        return (
            <div className="p-6" data-name="planification-conges-page" data-file="components/PlanificationCongesPage.js">
                <div className="mb-6 flex justify-between items-center">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Planification des Congés</h1>
                        <p className="text-gray-600">Visualisez et gérez la planification des congés de votre équipe</p>
                    </div>
                    <div className="flex space-x-4">
                        <select 
                            value={periodeSelectionnee}
                            onChange={(e) => setPeriodeSelectionnee(e.target.value)}
                            className="border border-gray-300 rounded-md px-3 py-2"
                        >
                            <option value="semaine">Vue Semaine</option>
                            <option value="mois">Vue Mois</option>
                            <option value="trimestre">Vue Trimestre</option>
                        </select>
                    </div>
                </div>

                {conflits.length > 0 && (
                    <div className="mb-6 p-4 bg-red-100 border border-red-300 rounded-md">
                        <h3 className="text-lg font-semibold text-red-800 mb-2">
                            <i className="fas fa-exclamation-triangle mr-2"></i>
                            Conflits détectés ({conflits.length})
                        </h3>
                        {conflits.map(conflit => (
                            <div key={conflit.id} className="text-red-700 mb-1">
                                {conflit.agent1} et {conflit.agent2} - {conflit.direction} ({conflit.periode})
                            </div>
                        ))}
                    </div>
                )}

                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                    <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                        <h2 className="text-lg font-semibold">
                            Calendrier - {dateActuelle.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
                        </h2>
                        <div className="flex space-x-2">
                            <button
                                onClick={() => changerMois(-1)}
                                className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
                            >
                                <i className="fas fa-chevron-left"></i>
                            </button>
                            <button
                                onClick={() => changerMois(1)}
                                className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
                            >
                                <i className="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>

                    <div className="p-6">
                        <div className="grid grid-cols-7 gap-2 mb-4">
                            {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(jour => (
                                <div key={jour} className="text-center font-semibold text-gray-600 py-2">
                                    {jour}
                                </div>
                            ))}
                        </div>
                        
                        <div className="grid grid-cols-7 gap-2">
                            {getCalendrierJours().map((jour, index) => {
                                const congesJour = getCongesPourJour(jour);
                                return (
                                    <div
                                        key={index}
                                        className={`min-h-24 p-2 border border-gray-200 rounded ${
                                            congesJour.length > 0 ? 'bg-blue-50' : 'bg-white'
                                        }`}
                                    >
                                        <div className="text-sm font-medium mb-1">{jour.getDate()}</div>
                                        {congesJour.slice(0, 2).map((conge, i) => (
                                            <div
                                                key={i}
                                                className="text-xs bg-blue-200 text-blue-800 px-1 py-0.5 rounded mb-1 truncate"
                                                title={`${conge.objectData.agent_nom} - ${conge.objectData.type_conge}`}
                                            >
                                                {conge.objectData.agent_nom}
                                            </div>
                                        ))}
                                        {congesJour.length > 2 && (
                                            <div className="text-xs text-gray-500">
                                                +{congesJour.length - 2} autre(s)
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>

                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white shadow-md rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4">Statistiques du mois</h3>
                        <div className="space-y-3">
                            <div className="flex justify-between">
                                <span>Total congés planifiés:</span>
                                <span className="font-semibold">{congesPlannifies.length}</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Conflits détectés:</span>
                                <span className={`font-semibold ${conflits.length > 0 ? 'text-red-600' : 'text-green-600'}`}>
                                    {conflits.length}
                                </span>
                            </div>
                            <div className="flex justify-between">
                                <span>Agents en congés aujourd'hui:</span>
                                <span className="font-semibold">
                                    {getCongesPourJour(new Date()).length}
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white shadow-md rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4">Actions rapides</h3>
                        <div className="space-y-2">
                            <button className="w-full text-left px-4 py-2 bg-blue-100 text-blue-800 rounded hover:bg-blue-200">
                                <i className="fas fa-calendar-plus mr-2"></i>
                                Planifier nouveau congé
                            </button>
                            <button className="w-full text-left px-4 py-2 bg-green-100 text-green-800 rounded hover:bg-green-200">
                                <i className="fas fa-download mr-2"></i>
                                Exporter planning
                            </button>
                            <button className="w-full text-left px-4 py-2 bg-yellow-100 text-yellow-800 rounded hover:bg-yellow-200">
                                <i className="fas fa-exclamation-triangle mr-2"></i>
                                Résoudre conflits
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('PlanificationCongesPage error:', error);
        return (
            <div className="p-6 text-center">
                <p className="text-red-600">Erreur lors du chargement de la page</p>
            </div>
        );
    }
};
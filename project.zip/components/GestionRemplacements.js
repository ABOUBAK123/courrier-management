function GestionRemplacements() {
    const [remplacements, setRemplacements] = React.useState([]);
    const [personnel, setPersonnel] = React.useState([]);
    const [congesActifs, setCongesActifs] = React.useState([]);
    const [showModal, setShowModal] = React.useState(false);
    const [selectedConge, setSelectedConge] = React.useState(null);

    React.useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [remplacementsResult, personnelResult, congesResult] = await Promise.all([
                trickleListObjects('remplacement', 200, true),
                trickleListObjects('personnel', 200, true),
                trickleListObjects('conge', 200, true)
            ]);

            setRemplacements(remplacementsResult.items);
            setPersonnel(personnelResult.items);
            
            const congesApprouves = congesResult.items.filter(c => 
                c.objectData.status === 'approuve' && 
                new Date(c.objectData.dateFin) >= new Date()
            );
            setCongesActifs(congesApprouves);

        } catch (error) {
            console.error('Erreur chargement données:', error);
        }
    };

    const assignerRemplacement = async (congeId, remplacantId, taches) => {
        try {
            const conge = congesActifs.find(c => c.objectId === congeId);
            const remplacant = personnel.find(p => p.objectId === remplacantId);

            await trickleCreateObject('remplacement', {
                congeId,
                employeAbsentId: conge.objectData.employeId,
                remplacantId,
                dateDebut: conge.objectData.dateDebut,
                dateFin: conge.objectData.dateFin,
                taches: taches.split('\n'),
                status: 'assigne',
                dateAssignation: new Date().toISOString()
            });

            // Notification email au remplaçant
            await EmailNotifications.sendReplacementNotification(conge, remplacant, taches);
            
            loadData();
            setShowModal(false);

        } catch (error) {
            console.error('Erreur assignation remplacement:', error);
        }
    };

    const getPersonnelDisponible = (conge) => {
        return personnel.filter(p => 
            p.objectData.departement === conge.objectData.departement &&
            p.objectId !== conge.objectData.employeId &&
            p.objectData.status === 'actif'
        );
    };

    return React.createElement('div', {
        className: 'space-y-6',
        'data-name': 'gestion-remplacements',
        'data-file': 'components/GestionRemplacements.js'
    }, [
        React.createElement('h2', {
            key: 'title',
            className: 'text-xl font-bold text-gray-800 flex items-center'
        }, [
            React.createElement('i', { key: 'icon', className: 'fas fa-user-friends mr-2 text-blue-600' }),
            'Gestion des Remplacements'
        ]),

        // Congés nécessitant un remplacement
        React.createElement('div', {
            key: 'conges-section',
            className: 'bg-white rounded-lg shadow-md p-6'
        }, [
            React.createElement('h3', {
                key: 'subtitle',
                className: 'text-lg font-semibold mb-4'
            }, 'Congés nécessitant un remplacement'),
            
            congesActifs.length === 0 ? 
                React.createElement('p', {
                    key: 'empty',
                    className: 'text-gray-500 text-center py-4'
                }, 'Aucun congé actif') :
                React.createElement('div', {
                    key: 'list',
                    className: 'space-y-3'
                }, congesActifs.map(conge => {
                    const hasReplacement = remplacements.some(r => r.objectData.congeId === conge.objectId);
                    
                    return React.createElement('div', {
                        key: conge.objectId,
                        className: `border rounded-lg p-4 ${hasReplacement ? 'bg-green-50 border-green-200' : 'bg-yellow-50 border-yellow-200'}`
                    }, [
                        React.createElement('div', {
                            key: 'info',
                            className: 'flex justify-between items-start'
                        }, [
                            React.createElement('div', { key: 'details' }, [
                                React.createElement('h4', {
                                    key: 'name',
                                    className: 'font-semibold'
                                }, `${conge.objectData.prenom} ${conge.objectData.nom}`),
                                React.createElement('p', {
                                    key: 'dates',
                                    className: 'text-sm text-gray-600'
                                }, `${conge.objectData.dateDebut} → ${conge.objectData.dateFin}`),
                                React.createElement('p', {
                                    key: 'dept',
                                    className: 'text-sm text-blue-600'
                                }, conge.objectData.departement)
                            ]),
                            React.createElement('div', {
                                key: 'actions',
                                className: 'flex items-center space-x-2'
                            }, [
                                hasReplacement ? 
                                    React.createElement('span', {
                                        key: 'status',
                                        className: 'bg-green-100 text-green-800 px-2 py-1 rounded text-sm'
                                    }, '✓ Remplacé') :
                                    React.createElement('button', {
                                        key: 'assign',
                                        onClick: () => {
                                            setSelectedConge(conge);
                                            setShowModal(true);
                                        },
                                        className: 'bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700'
                                    }, 'Assigner remplaçant')
                            ])
                        ])
                    ]);
                }))
        ]),

        // Modal d'assignation
        showModal && React.createElement(RemplacementModal, {
            key: 'modal',
            conge: selectedConge,
            personnel: getPersonnelDisponible(selectedConge),
            onAssign: assignerRemplacement,
            onClose: () => setShowModal(false)
        })
    ]);
}

function RemplacementModal({ conge, personnel, onAssign, onClose }) {
    const [selectedPersonnel, setSelectedPersonnel] = React.useState('');
    const [taches, setTaches] = React.useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (selectedPersonnel && taches.trim()) {
            onAssign(conge.objectId, selectedPersonnel, taches);
        }
    };

    return React.createElement('div', {
        className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
    }, 
        React.createElement('div', {
            className: 'bg-white rounded-lg p-6 w-full max-w-md'
        }, [
            React.createElement('h3', {
                key: 'title',
                className: 'text-lg font-semibold mb-4'
            }, 'Assigner un remplaçant'),
            
            React.createElement('form', {
                key: 'form',
                onSubmit: handleSubmit,
                className: 'space-y-4'
            }, [
                React.createElement('div', { key: 'personnel-field' }, [
                    React.createElement('label', {
                        key: 'label',
                        className: 'block text-sm font-medium mb-1'
                    }, 'Remplaçant'),
                    React.createElement('select', {
                        key: 'select',
                        value: selectedPersonnel,
                        onChange: (e) => setSelectedPersonnel(e.target.value),
                        className: 'w-full border border-gray-300 rounded px-3 py-2',
                        required: true
                    }, [
                        React.createElement('option', { key: 'empty', value: '' }, 'Sélectionner...'),
                        ...personnel.map(p => 
                            React.createElement('option', {
                                key: p.objectId,
                                value: p.objectId
                            }, `${p.objectData.prenom} ${p.objectData.nom}`)
                        )
                    ])
                ]),
                
                React.createElement('div', { key: 'taches-field' }, [
                    React.createElement('label', {
                        key: 'label',
                        className: 'block text-sm font-medium mb-1'
                    }, 'Tâches à effectuer'),
                    React.createElement('textarea', {
                        key: 'textarea',
                        value: taches,
                        onChange: (e) => setTaches(e.target.value),
                        className: 'w-full border border-gray-300 rounded px-3 py-2',
                        rows: 4,
                        placeholder: 'Décrivez les tâches à effectuer...',
                        required: true
                    })
                ]),
                
                React.createElement('div', {
                    key: 'buttons',
                    className: 'flex justify-end space-x-2'
                }, [
                    React.createElement('button', {
                        key: 'cancel',
                        type: 'button',
                        onClick: onClose,
                        className: 'px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50'
                    }, 'Annuler'),
                    React.createElement('button', {
                        key: 'submit',
                        type: 'submit',
                        className: 'px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
                    }, 'Assigner')
                ])
            ])
        ])
    );
}

window.GestionRemplacements = GestionRemplacements;
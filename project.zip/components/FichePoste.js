function FichePoste({ agent }) {
    try {
        const [fichePoste, setFichePoste] = React.useState(null);
        const [editMode, setEditMode] = React.useState(false);
        const [loading, setLoading] = React.useState(true);
        const [formData, setFormData] = React.useState({
            intitule: '',
            missions: '',
            competencesRequises: '',
            formations: '',
            responsabilites: ''
        });

        React.useEffect(() => {
            loadFichePoste();
        }, [agent]);

        const loadFichePoste = async () => {
            try {
                const result = await trickleListObjects(`fiche-poste:${agent.matricule}`, 1, true);
                if (result.items.length > 0) {
                    const fiche = result.items[0];
                    setFichePoste(fiche);
                    setFormData(fiche.objectData);
                }
            } catch (error) {
                console.error('Erreur chargement fiche poste:', error);
            }
            setLoading(false);
        };

        const handleInputChange = (field, value) => {
            setFormData(prev => ({ ...prev, [field]: value }));
        };

        const handleSave = async () => {
            try {
                if (fichePoste) {
                    await trickleUpdateObject(`fiche-poste:${agent.matricule}`, fichePoste.objectId, formData);
                } else {
                    await trickleCreateObject(`fiche-poste:${agent.matricule}`, formData);
                }
                setEditMode(false);
                loadFichePoste();
                alert('Fiche de poste mise à jour avec succès');
            } catch (error) {
                alert('Erreur lors de la mise à jour');
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'flex justify-center py-8'
            }, [
                React.createElement('i', {
                    key: 'spinner',
                    className: 'fas fa-spinner fa-spin text-blue-600 text-2xl'
                })
            ]);
        }

        const fields = [
            { key: 'intitule', label: 'Intitulé du poste', type: 'text' },
            { key: 'missions', label: 'Missions principales', type: 'textarea', rows: 4 },
            { key: 'competencesRequises', label: 'Compétences requises', type: 'textarea', rows: 3 },
            { key: 'formations', label: 'Formations nécessaires', type: 'textarea', rows: 2 },
            { key: 'responsabilites', label: 'Responsabilités', type: 'textarea', rows: 3 }
        ];

        return React.createElement('div', {
            'data-name': 'fiche-poste',
            'data-file': 'components/FichePoste.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold'
                }, 'Fiche de Poste'),
                React.createElement('button', {
                    key: 'edit-btn',
                    onClick: () => editMode ? handleSave() : setEditMode(true),
                    className: `px-4 py-2 rounded-lg text-sm font-medium ${
                        editMode ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: `fas ${editMode ? 'fa-save' : 'fa-edit'} mr-2`
                    }),
                    editMode ? 'Enregistrer' : 'Modifier'
                ])
            ]),

            !fichePoste && !editMode ? React.createElement('div', {
                key: 'empty',
                className: 'text-center py-12'
            }, [
                React.createElement('i', {
                    key: 'icon',
                    className: 'fas fa-clipboard-list text-gray-400 text-4xl mb-4'
                }),
                React.createElement('p', {
                    key: 'message',
                    className: 'text-gray-600 mb-4'
                }, 'Aucune fiche de poste définie'),
                React.createElement('button', {
                    key: 'create-btn',
                    onClick: () => setEditMode(true),
                    className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'
                }, 'Créer une fiche de poste')
            ]) : React.createElement('div', {
                key: 'form',
                className: 'space-y-6'
            }, fields.map(field =>
                React.createElement('div', {
                    key: field.key
                }, [
                    React.createElement('label', {
                        key: 'label',
                        className: 'block text-sm font-medium text-gray-700 mb-2'
                    }, field.label),
                    field.type === 'textarea' ? React.createElement('textarea', {
                        key: 'input',
                        value: formData[field.key] || '',
                        onChange: (e) => handleInputChange(field.key, e.target.value),
                        disabled: !editMode,
                        rows: field.rows || 3,
                        className: `w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 ${
                            !editMode ? 'bg-gray-50' : ''
                        }`
                    }) : React.createElement('input', {
                        key: 'input',
                        type: field.type,
                        value: formData[field.key] || '',
                        onChange: (e) => handleInputChange(field.key, e.target.value),
                        disabled: !editMode,
                        className: `w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 ${
                            !editMode ? 'bg-gray-50' : ''
                        }`
                    })
                ])
            ))
        ]);

    } catch (error) {
        console.error('FichePoste component error:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.FichePoste = FichePoste;

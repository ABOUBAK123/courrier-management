function DocumentViewer({ documentUrl, onClose }) {
    try {
        const [onlyofficeConfig, setOnlyofficeConfig] = React.useState(null);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadOnlyOfficeConfig();
        }, []);

        const loadOnlyOfficeConfig = async () => {
            try {
                const settings = await trickleListObjects('general-settings', 10, true);
                if (settings.items.length > 0) {
                    const config = settings.items[0].objectData;
                    setOnlyofficeConfig({
                        server: config.onlyofficeServer,
                        secret: config.onlyofficeSecret
                    });
                }
            } catch (error) {
                console.error('Erreur chargement config OnlyOffice:', error);
            } finally {
                setLoading(false);
            }
        };

        const openWithOnlyOffice = () => {
            if (!onlyofficeConfig || !onlyofficeConfig.server) {
                alert('OnlyOffice n\'est pas configuré dans les paramètres généraux');
                return;
            }

            const onlyofficeUrl = `${onlyofficeConfig.server}/editor?url=${encodeURIComponent(documentUrl)}`;
            window.open(onlyofficeUrl, '_blank', 'width=1200,height=800');
        };

        if (loading) {
            return React.createElement('div', {
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50',
                'data-name': 'document-viewer-loading',
                'data-file': 'components/DocumentViewer.js'
            }, [
                React.createElement('div', {
                    key: 'loading-content',
                    className: 'bg-white rounded-lg p-6'
                }, 'Chargement de la configuration OnlyOffice...')
            ]);
        }

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50',
            'data-name': 'document-viewer',
            'data-file': 'components/DocumentViewer.js'
        }, [
            React.createElement('div', {
                key: 'viewer-content',
                className: 'bg-white rounded-lg p-6 max-w-md w-full mx-4'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'flex justify-between items-center mb-4'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-semibold'
                    }, 'Ouvrir le document'),
                    React.createElement('button', {
                        key: 'close-btn',
                        onClick: onClose,
                        className: 'text-gray-500 hover:text-gray-700'
                    }, [
                        React.createElement('i', {
                            key: 'close-icon',
                            className: 'fas fa-times'
                        })
                    ])
                ]),
                React.createElement('div', {
                    key: 'content',
                    className: 'text-center'
                }, [
                    React.createElement('i', {
                        key: 'file-icon',
                        className: 'fas fa-file-alt text-4xl text-blue-600 mb-4'
                    }),
                    React.createElement('p', {
                        key: 'description',
                        className: 'text-gray-600 mb-4'
                    }, 'Document disponible pour visualisation'),
                    React.createElement('div', {
                        key: 'actions',
                        className: 'space-y-2'
                    }, [
                        React.createElement('button', {
                            key: 'download-btn',
                            onClick: async () => {
                                try {
                                    const loadedUrl = await window.documentLoader.loadDocument(documentUrl);
                                    const link = document.createElement('a');
                                    link.href = loadedUrl;
                                    link.download = documentUrl.split('/').pop() || 'document';
                                    link.click();
                                } catch (error) {
                                    alert('Erreur lors du téléchargement');
                                }
                            },
                            className: 'w-full bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700'
                        }, 'Télécharger le document'),
                        onlyofficeConfig && onlyofficeConfig.server && React.createElement('button', {
                            key: 'open-btn',
                            onClick: openWithOnlyOffice,
                            className: 'w-full bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700'
                        }, 'Ouvrir avec OnlyOffice')
                    ]),
                    !onlyofficeConfig?.server && React.createElement('p', {
                        key: 'no-config',
                        className: 'text-amber-600 text-sm mt-2'
                    }, 'OnlyOffice non configuré - Téléchargement disponible')
                ])
            ])
        ]);
    } catch (error) {
        console.error('DocumentViewer component error:', error);
        reportError(error);
    }
}

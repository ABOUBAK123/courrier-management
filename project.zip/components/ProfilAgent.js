function ProfilAgent({ agent }) {
    try {
        const [profileData, setProfileData] = React.useState(null);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadProfileData();
        }, [agent]);

        const loadProfileData = async () => {
            try {
                // Utiliser les vraies données de l'agent
                const fullProfile = {
                    ...agent,
                    // Ajouter des données par défaut si manquantes
                    matricule: agent.matricule || 'Non défini',
                    direction: agent.direction || 'Non définie',
                    service: agent.service || 'Non défini',
                    dateEmbauche: agent.dateEmbauche || 'Non définie',
                    telephone: agent.telephone || 'Non défini',
                    adresse: agent.adresse || 'Non définie',
                    situationFamiliale: agent.situationFamiliale || 'Non définie',
                    nombreEnfants: agent.nombreEnfants || 0,
                    grade: agent.grade || 'Non défini',
                    soldeConges: agent.soldeConges || 0,
                    congesUtilises: agent.congesUtilises || 0
                };
                setProfileData(fullProfile);
            } catch (error) {
                console.error('Erreur chargement profil:', error);
            } finally {
                setLoading(false);
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center'
            }, 'Chargement du profil...');
        }

        return React.createElement('div', {
            className: 'p-6',
            'data-name': 'profil-agent',
            'data-file': 'components/ProfilAgent.js'
        }, [
            React.createElement(ProfilAgentTabs, {
                key: 'profil-tabs',
                agent: profileData
            }),
            profileData && React.createElement(window.SuiviDemandes, {
                key: 'suivi-demandes',
                agentId: profileData.id || profileData.objectId
            })
        ].filter(Boolean));
    } catch (error) {
        console.error('ProfilAgent component error:', error);
        reportError(error);
    }
}

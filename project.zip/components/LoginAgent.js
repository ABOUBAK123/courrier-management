function LoginAgent({ onLogin, onBack }) {
    try {
        const [matricule, setMatricule] = React.useState('');
        const [loading, setLoading] = React.useState(false);

        const creerDonneesPersonnel = async (agentData) => {
            try {
                // Vérifier si les données personnel existent déjà
                const personnelExistant = await trickleGetObject('personnel', agentData.objectId);
                if (personnelExistant) {
                    return personnelExistant;
                }
            } catch (error) {
                // L'agent n'existe pas dans personnel, le créer
                const donneesPersonnel = {
                    matricule: agentData.matricule,
                    nom: agentData.name ? agentData.name.split(' ').pop() : 'Nom',
                    prenom: agentData.name ? agentData.name.split(' ')[0] : 'Prénom',
                    email: agentData.email,
                    direction: agentData.direction || 'DIR001',
                    direction_id: agentData.direction || 'DIR001',
                    departement: agentData.departement || 'Non défini',
                    grade: agentData.grade || 'Agent',
                    poste: agentData.poste || 'Agent',
                    statut: 'actif',
                    date_embauche: new Date().toISOString(),
                    solde_conges: 30
                };
                
                return await trickleCreateObject('personnel', donneesPersonnel);
            }
        };

        const handleLogin = async (e) => {
            e.preventDefault();
            if (!matricule.trim()) {
                alert('Veuillez saisir votre matricule');
                return;
            }

            setLoading(true);
            try {
                // Rechercher l'agent par matricule
                const users = await trickleListObjects('user', 100, true);
                const agent = users.items.find(item => 
                    item.objectData.matricule && 
                    item.objectData.matricule.toLowerCase() === matricule.toLowerCase() &&
                    item.objectData.role === 'AGENT'
                );

                if (agent) {
                    const agentData = {
                        ...agent.objectData,
                        id: agent.objectId,
                        objectId: agent.objectId
                    };
                    
                    // Créer ou mettre à jour les données personnel si nécessaire
                    try {
                        await creerDonneesPersonnel(agentData);
                    } catch (error) {
                        console.warn('Erreur création données personnel:', error);
                    }
                    
                    onLogin(agentData);
                } else {
                    alert('Aucun agent trouvé avec ce matricule');
                }
            } catch (error) {
                alert('Erreur lors de la connexion');
            } finally {
                setLoading(false);
            }
        };

        return React.createElement('div', {
            className: 'w-full max-w-md mx-auto bg-white rounded-lg shadow-lg p-6',
            'data-name': 'login-agent',
            'data-file': 'components/LoginAgent.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'text-center mb-6'
            }, [
                React.createElement('div', {
                    key: 'icon',
                    className: 'w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4'
                }, [
                    React.createElement('i', {
                        key: 'user-icon',
                        className: 'fas fa-user-circle text-white text-2xl'
                    })
                ]),
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Connexion Agent'),
                React.createElement('p', {
                    key: 'subtitle',
                    className: 'text-gray-600 mt-2'
                }, 'Accès rapide avec votre matricule')
            ]),
            React.createElement('form', {
                key: 'form',
                onSubmit: handleLogin,
                className: 'space-y-4'
            }, [
                React.createElement('div', {
                    key: 'matricule-field'
                }, [
                    React.createElement('label', {
                        key: 'label',
                        className: 'block text-sm font-medium text-gray-700 mb-2'
                    }, 'Matricule Agent'),
                    React.createElement('input', {
                        key: 'input',
                        type: 'text',
                        value: matricule,
                        onChange: (e) => setMatricule(e.target.value),
                        placeholder: 'Ex: AG-1001',
                        className: 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500',
                        required: true
                    })
                ]),
                React.createElement('button', {
                    key: 'submit',
                    type: 'submit',
                    disabled: loading,
                    className: 'w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors font-medium'
                }, loading ? 'Connexion...' : 'Se connecter'),
                React.createElement('button', {
                    key: 'back',
                    type: 'button',
                    onClick: onBack,
                    className: 'w-full bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors font-medium'
                }, 'Retour')
            ]),
        ]);
    } catch (error) {
        console.error('LoginAgent component error:', error);
        reportError(error);
    }
}

function EmployeeForm({ user, editingEmployee, onClose }) {
    try {
        const [activeTab, setActiveTab] = React.useState(1);
        
        React.useEffect(() => {
            if (editingEmployee) {
                // Pré-remplir les données si on édite un employé existant
                setFormData({
                    matricule: editingEmployee.matricule || '',
                    nom: editingEmployee.nom || '',
                    prenom: editingEmployee.prenom || '',
                    nomJeuneFille: editingEmployee.nomJeuneFille || '',
                    dateNaissance: editingEmployee.dateNaissance || '',
                    lieuNaissance: editingEmployee.lieuNaissance || '',
                    nomPere: editingEmployee.nomPere || '',
                    nomMere: editingEmployee.nomMere || '',
                    sexe: editingEmployee.sexe || '',
                    numeroCNI: editingEmployee.numeroCNI || '',
                    telephone: editingEmployee.telephone || '',
                    email: editingEmployee.email || '',
                    situationFamiliale: editingEmployee.situationFamiliale || '',
                    nombreEnfants: editingEmployee.nombreEnfants || 0,
                    directionGenerale: editingEmployee.directionGenerale || '',
                    directionCentrale: editingEmployee.directionCentrale || '',
                    sousDirection: editingEmployee.sousDirection || '',
                    service: editingEmployee.service || '',
                    emploi: editingEmployee.emploi || '',
                    lieuTravail: editingEmployee.lieuTravail || '',
                    categorie: editingEmployee.categorie || '',
                    grade: editingEmployee.grade || ''
                });
            }
        }, [editingEmployee]);
        
        const [loading, setLoading] = React.useState(false);
        const [formData, setFormData] = React.useState({
            // Informations personnelles
            matricule: '',
            nom: '',
            prenom: '',
            nomJeuneFille: '',
            dateNaissance: '',
            lieuNaissance: '',
            nomPere: '',
            nomMere: '',
            sexe: '',
            numeroCNI: '',
            telephone: '',
            email: '',
            situationFamiliale: '',
            nombreEnfants: 0,
            // Informations professionnelles
            directionGenerale: '',
            directionCentrale: '',
            sousDirection: '',
            service: '',
            emploi: '',
            lieuTravail: '',
            categorie: '',
            grade: ''
        });

        const handleInputChange = (field, value) => {
            setFormData(prev => ({ ...prev, [field]: value }));
        };

        const validateTab1 = () => {
            const required = ['matricule', 'nom', 'prenom', 'dateNaissance', 'email'];
            return required.every(field => formData[field].trim() !== '');
        };

        const handleSave = async () => {
            if (!validateTab1()) {
                alert('Veuillez remplir tous les champs obligatoires marqués avec ⭐');
                setActiveTab(1);
                return;
            }

            setLoading(true);
            try {
                const employeeData = {
                    ...formData,
                    direction: user.direction,
                    updatedAt: new Date().toISOString()
                };

                if (editingEmployee) {
                    // Mode modification
                    if (editingEmployee.source === 'personnel') {
                        await trickleUpdateObject(`personnel:${user.direction}`, editingEmployee.id, employeeData);
                    } else {
                        // Créer un nouvel enregistrement personnel basé sur l'utilisateur
                        employeeData.createdBy = user.name;
                        employeeData.createdAt = new Date().toISOString();
                        employeeData.sourceUserId = editingEmployee.id;
                        await trickleCreateObject(`personnel:${user.direction}`, employeeData);
                    }
                    alert('Employé modifié avec succès!');
                } else {
                    // Mode création
                    employeeData.createdBy = user.name;
                    employeeData.createdAt = new Date().toISOString();
                    await trickleCreateObject(`personnel:${user.direction}`, employeeData);
                    alert('Employé ajouté avec succès!');
                }
                
                onClose();
            } catch (error) {
                alert(editingEmployee ? 'Erreur lors de la modification' : 'Erreur lors de l\'ajout');
                console.error('Save error:', error);
            } finally {
                setLoading(false);
            }
        };

        const tabs = [
            { id: 1, title: 'Informations Personnelles', icon: 'fas fa-user' },
            { id: 2, title: 'Informations Professionnelles', icon: 'fas fa-briefcase' }
        ];

        const renderTabContent = () => {
            if (activeTab === 1) {
                return React.createElement(EmployeeFormTab1, {
                    formData,
                    handleInputChange,
                    editingEmployee
                });
            }
            return React.createElement(EmployeeFormTab2, {
                formData,
                handleInputChange,
                editingEmployee
            });
        };

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'employee-form',
            'data-file': 'components/EmployeeForm.js'
        }, [
            React.createElement('div', {
                key: 'tabs',
                className: 'flex border-b border-gray-200'
            }, tabs.map(tab =>
                React.createElement('button', {
                    key: tab.id,
                    onClick: () => setActiveTab(tab.id),
                    className: `flex items-center px-6 py-3 text-sm font-medium transition-colors ${
                        activeTab === tab.id
                            ? 'border-b-2 border-blue-600 text-blue-600 bg-blue-50'
                            : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
                    }`
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: `${tab.icon} mr-2`
                    }),
                    React.createElement('span', {
                        key: 'title'
                    }, tab.title)
                ])
            )),
            React.createElement('div', {
                key: 'content',
                className: 'min-h-96'
            }, renderTabContent()),
            React.createElement('div', {
                key: 'actions',
                className: 'flex justify-between pt-6 border-t border-gray-200'
            }, [
                React.createElement('button', {
                    key: 'prev',
                    onClick: () => setActiveTab(Math.max(1, activeTab - 1)),
                    disabled: activeTab === 1,
                    className: 'bg-gray-500 text-white px-4 py-2 rounded-lg disabled:opacity-50'
                }, 'Précédent'),
                React.createElement('div', {
                    key: 'right-actions',
                    className: 'space-x-4'
                }, [
                    activeTab < 2 && React.createElement('button', {
                        key: 'next',
                        onClick: () => setActiveTab(Math.min(2, activeTab + 1)),
                        className: 'bg-blue-600 text-white px-4 py-2 rounded-lg'
                    }, 'Suivant'),
                    React.createElement('button', {
                        key: 'save',
                        onClick: handleSave,
                        disabled: loading,
                        className: 'bg-green-600 text-white px-6 py-2 rounded-lg font-medium disabled:opacity-50'
                    }, loading ? 'Enregistrement...' : (editingEmployee ? 'Modifier' : 'Enregistrer'))
                ])
            ])
        ]);
    } catch (error) {
        console.error('EmployeeForm component error:', error);
        reportError(error);
    }
}

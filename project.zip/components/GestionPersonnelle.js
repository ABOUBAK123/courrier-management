function GestionPersonnelle({ user }) {
    try {
        const [activeTab, setActiveTab] = React.useState(
            user && user.role === 'AGENT' ? 'espace-agent' : 'accueil'
        );

        const tabs = [
            { id: 'accueil', label: 'Accueil', icon: 'fas fa-home' },
            { id: 'personnel', label: 'Personnel', icon: 'fas fa-users' },
            { id: 'import-personnel', label: 'Import Personnel', icon: 'fas fa-file-excel' },
            { id: 'conge', label: 'Gestion Congé', icon: 'fas fa-calendar-alt' },
            { id: 'formation', label: 'Formation', icon: 'fas fa-graduation-cap' },
            { id: 'espace-agent', label: 'Espace Agent', icon: 'fas fa-user-circle' }
        ];

        // Filtrer les onglets selon le rôle utilisateur
        const visibleTabs = user && user.role === 'AGENT' 
            ? tabs.filter(tab => tab.id === 'espace-agent')
            : tabs;

        const renderTabContent = () => {
            switch (activeTab) {
                case 'accueil':
                    return React.createElement(AccueilPersonnel, { user });
                case 'personnel':
                    return React.createElement(PersonnelList, { user });
                case 'import-personnel':
                    return React.createElement(ImportPersonnel, { user });
                case 'conge':
                    return React.createElement(GestionConge, { user });
                case 'formation':
                    return React.createElement(Formation, { user });
                case 'espace-agent':
                    return React.createElement(EspaceAgent, { user, embedded: true });
                default:
                    return React.createElement('div', {
                        className: 'p-6 text-center text-gray-600'
                    }, 'Section en développement');
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'gestion-personnelle',
            'data-file': 'components/GestionPersonnelle.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, user && user.role === 'AGENT' ? 'Mon Espace Agent' : 'Gestion Personnelle'),
            React.createElement('div', {
                key: 'tabs-container',
                className: 'bg-white rounded-lg shadow-md mb-6'
            }, [
                visibleTabs.length > 1 && React.createElement('div', {
                    key: 'tabs-nav',
                    className: 'flex border-b border-gray-200 overflow-x-auto'
                }, visibleTabs.map(tab =>
                    React.createElement('button', {
                        key: tab.id,
                        onClick: () => setActiveTab(tab.id),
                        className: `flex items-center px-6 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                            activeTab === tab.id
                                ? 'border-b-2 border-blue-600 text-blue-600 bg-blue-50'
                                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
                        }`
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: `${tab.icon} mr-2`
                        }),
                        React.createElement('span', {
                            key: 'label'
                        }, tab.label)
                    ])
                )),
                React.createElement('div', {
                    key: 'tab-content',
                    className: activeTab === 'espace-agent' ? '' : 'p-6'
                }, renderTabContent())
            ])
        ]);
    } catch (error) {
        console.error('GestionPersonnelle component error:', error);
        reportError(error);
    }
}

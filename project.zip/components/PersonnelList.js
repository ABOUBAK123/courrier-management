function PersonnelList({ user }) {
    try {
        const [personnel, setPersonnel] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [editingPerson, setEditingPerson] = React.useState(null);

        React.useEffect(() => {
            loadPersonnel();
        }, [user]);

        const loadPersonnel = async () => {
            try {
                // Charger le personnel existant
                const personnelResponse = await trickleListObjects(`personnel:${user.direction}`, 100, true);
                const personnelData = personnelResponse.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId,
                    source: 'personnel'
                }));

                // Charger tous les utilisateurs de la direction
                const usersResponse = await trickleListObjects('user', 100, true);
                const usersData = usersResponse.items
                    .filter(item => item.objectData.direction === user.direction)
                    .map(item => ({
                        ...item.objectData,
                        id: item.objectId,
                        source: 'user',
                        nom: item.objectData.name?.split(' ')[1] || item.objectData.name || '',
                        prenom: item.objectData.name?.split(' ')[0] || '',
                        email: item.objectData.email,
                        matricule: item.objectData.matricule || '',
                        poste: item.objectData.role || '',
                        grade: item.objectData.grade || '',
                        isIncomplete: true // Marquer comme incomplet pour affichage
                    }));

                // Marquer les utilisateurs qui ont déjà un profil personnel complet
                const existingMatricules = personnelData.map(p => p.matricule).filter(Boolean);
                const updatedUsersData = usersData.map(user => ({
                    ...user,
                    isIncomplete: !existingMatricules.includes(user.matricule)
                }));
                
                setPersonnel([...personnelData, ...updatedUsersData]);
            } catch (error) {
                console.error('Erreur chargement personnel:', error);
            }
        };

        const handleEdit = (person) => {
            setEditingPerson(person);
            setShowForm(true);
        };

        const handleDelete = async (person) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer cet employé?')) {
                try {
                    if (person.source === 'personnel') {
                        await trickleDeleteObject(`personnel:${user.direction}`, person.id);
                    } else {
                        await trickleDeleteObject('user', person.id);
                    }
                    alert('Employé supprimé avec succès');
                    loadPersonnel();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        const getStatusBadge = (person) => {
            if (person.source === 'user' && person.isIncomplete) {
                return React.createElement('span', {
                    className: 'px-2 py-1 text-xs bg-orange-100 text-orange-800 rounded-full'
                }, 'Profil incomplet');
            } else if (person.source === 'user') {
                return React.createElement('span', {
                    className: 'px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full'
                }, 'Utilisateur');
            }
            return React.createElement('span', {
                className: 'px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full'
            }, 'Profil complet');
        };

        return React.createElement('div', {
            className: 'p-6',
            'data-name': 'personnel-list',
            'data-file': 'components/PersonnelList.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Liste du Personnel'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouvel Employé')
            ]),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Matricule', 'Nom Complet', 'Email', 'Poste', 'Grade', 'Statut', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody'
                    }, personnel.map(person =>
                        React.createElement('tr', {
                            key: person.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'matricule',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('span', {
                                    key: 'matricule-text',
                                    className: 'text-sm font-medium text-gray-900'
                                }, person.matricule || '-')
                            ]),
                            React.createElement('td', {
                                key: 'nom',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, `${person.nom || ''} ${person.prenom || ''}`),
                            React.createElement('td', {
                                key: 'email',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, person.email || '-'),
                            React.createElement('td', {
                                key: 'poste',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, person.emploi || person.poste || '-'),
                            React.createElement('td', {
                                key: 'grade',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, person.grade || '-'),
                            React.createElement('td', {
                                key: 'statut',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, getStatusBadge(person)),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'edit',
                                    onClick: () => handleEdit(person),
                                    className: 'text-blue-600 hover:text-blue-900 mr-2',
                                    title: person.source === 'user' && person.isIncomplete ? 'Compléter le profil' : 'Modifier'
                                }, [
                                    React.createElement('i', {
                                        key: 'edit-icon',
                                        className: person.source === 'user' && person.isIncomplete ? 'fas fa-user-plus' : 'fas fa-edit'
                                    }),
                                    React.createElement('span', {
                                        key: 'edit-text',
                                        className: 'ml-1 hidden sm:inline'
                                    }, person.source === 'user' && person.isIncomplete ? 'Compléter' : 'Modifier')
                                ]),
                                React.createElement('button', {
                                    key: 'delete',
                                    onClick: () => handleDelete(person),
                                    className: 'text-red-600 hover:text-red-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'delete-icon',
                                        className: 'fas fa-trash'
                                    })
                                ])
                            ])
                        ])
                    ))
                ])
            ]),
            showForm && React.createElement(EmployeeForm, {
                key: 'employee-form',
                user,
                editingEmployee: editingPerson,
                onClose: () => {
                    setShowForm(false);
                    setEditingPerson(null);
                    loadPersonnel();
                }
            })
        ]);

    } catch (error) {
        console.error('PersonnelList component error:', error);
        return React.createElement('div', {
            className: 'text-red-600 p-4'
        }, 'Erreur lors du chargement de la liste du personnel');
    }
}

window.PersonnelList = PersonnelList;
function InfoPersonnelle({ agent, readOnly = false }) {
    try {
        const [editMode, setEditMode] = React.useState(false);
        const [formData, setFormData] = React.useState({
            nom: agent?.nom || '',
            prenom: agent?.prenom || '',
            dateNaissance: agent?.dateNaissance || '',
            lieuNaissance: agent?.lieuNaissance || '',
            telephone: agent?.telephone || '',
            email: agent?.email || '',
            adresse: agent?.adresse || '',
            situationFamiliale: agent?.situationFamiliale || 'celibataire',
            nombreEnfants: agent?.nombreEnfants || 0,
            personneUrgence: agent?.personneUrgence || '',
            telephoneUrgence: agent?.telephoneUrgence || ''
        });

        const handleInputChange = (field, value) => {
            setFormData(prev => ({ ...prev, [field]: value }));
        };

        const handleSave = async () => {
            try {
                // Validation basique
                if (!formData.nom || !formData.email) {
                    alert('Le nom et l\'email sont obligatoires');
                    return;
                }

                await trickleUpdateObject(`agent-info:${agent.matricule}`, agent.matricule, formData);
                setEditMode(false);
                alert('Informations personnelles mises à jour avec succès');
            } catch (error) {
                // Si l'objet n'existe pas, le créer
                try {
                    await trickleCreateObject(`agent-info:${agent.matricule}`, formData);
                    setEditMode(false);
                    alert('Informations personnelles créées avec succès');
                } catch (createError) {
                    alert('Erreur lors de la mise à jour');
                }
            }
        };

        const fields = [
            { key: 'nom', label: 'Nom', type: 'text', required: true },
            { key: 'prenom', label: 'Prénom', type: 'text', required: true },
            { key: 'dateNaissance', label: 'Date de naissance', type: 'date', required: true },
            { key: 'lieuNaissance', label: 'Lieu de naissance', type: 'text' },
            { key: 'telephone', label: 'Téléphone', type: 'tel' },
            { key: 'email', label: 'Email', type: 'email', required: true },
            { key: 'adresse', label: 'Adresse', type: 'textarea' },
            { key: 'situationFamiliale', label: 'Situation familiale', type: 'select', 
              options: ['celibataire', 'marie', 'divorce', 'veuf'] },
            { key: 'nombreEnfants', label: 'Nombre d\'enfants', type: 'number' },
            { key: 'personneUrgence', label: 'Personne à contacter en urgence', type: 'text' },
            { key: 'telephoneUrgence', label: 'Téléphone urgence', type: 'tel' }
        ];

        return React.createElement('div', {
            className: 'bg-white rounded-lg shadow-md',
            'data-name': 'info-personnelle',
            'data-file': 'components/InfoPersonnelle.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'px-6 py-4 border-b border-gray-200 flex justify-between items-center'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-medium text-gray-900'
                }, 'Informations Personnelles'),
                !readOnly && React.createElement('button', {
                    key: 'edit-btn',
                    onClick: () => editMode ? handleSave() : setEditMode(true),
                    className: `px-3 py-1 rounded text-sm ${
                        editMode ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`
                }, editMode ? 'Enregistrer' : 'Modifier')
            ]),
            React.createElement('div', {
                key: 'content',
                className: 'p-6'
            }, [
                React.createElement('div', {
                    key: 'form',
                    className: 'grid grid-cols-1 md:grid-cols-2 gap-6'
                }, fields.map(field =>
                    React.createElement('div', {
                        key: field.key,
                        className: field.type === 'textarea' ? 'md:col-span-2' : ''
                    }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, [
                            field.label,
                            field.required && React.createElement('span', {
                                key: 'required',
                                className: 'text-red-500 ml-1'
                            }, '*')
                        ]),
                        field.type === 'select' ? React.createElement('select', {
                            key: 'input',
                            value: formData[field.key],
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            disabled: !editMode || readOnly,
                            className: `w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                !editMode ? 'bg-gray-50' : ''
                            }`
                        }, field.options.map(option =>
                            React.createElement('option', {
                                key: option,
                                value: option
                            }, option.charAt(0).toUpperCase() + option.slice(1))
                        )) : field.type === 'textarea' ? React.createElement('textarea', {
                            key: 'input',
                            value: formData[field.key],
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            disabled: !editMode,
                            rows: 3,
                            className: `w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                !editMode ? 'bg-gray-50' : ''
                            }`
                        }) : React.createElement('input', {
                            key: 'input',
                            type: field.type,
                            value: formData[field.key],
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            disabled: !editMode,
                            className: `w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                !editMode ? 'bg-gray-50' : ''
                            }`
                        })
                    ])
                ))
            ])
        ]);

    } catch (error) {
        console.error('InfoPersonnelle component error:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.InfoPersonnelle = InfoPersonnelle;
function ListeArchives({ user }) {
    try {
        const [archives, setArchives] = React.useState([]);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadArchives();
        }, [user]);

        const loadArchives = async () => {
            try {
                const response = await trickleListObjects(`archive:${user.direction}`, 100, true);
                const archiveData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setArchives(archiveData);
            } catch (error) {
                console.error('Erreur lors du chargement des archives:', error);
            } finally {
                setLoading(false);
            }
        };

        const viewDocument = (archive) => {
            alert(`Visualisation du document archivé: ${archive.numero}\nObjet: ${archive.objet}`);
        };

        const downloadDocument = (archive) => {
            alert(`Téléchargement du document: ${archive.numero}`);
        };

        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center',
                'data-name': 'loading',
                'data-file': 'components/ListeArchives.js'
            }, 'Chargement des archives...');
        }

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'liste-archives',
            'data-file': 'components/ListeArchives.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Liste des Archives'),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Numéro', 'Objet', 'Type', 'Date archivage', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, archives.map(archive =>
                        React.createElement('tr', {
                            key: archive.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'numero',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, archive.numero),
                            React.createElement('td', {
                                key: 'objet',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, archive.objet),
                            React.createElement('td', {
                                key: 'type',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, archive.type === 'arrive' ? 'Arrivé' : 'Départ'),
                            React.createElement('td', {
                                key: 'date-archive',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, new Date(archive.dateArchivage).toLocaleDateString()),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'view',
                                    onClick: () => viewDocument(archive),
                                    className: 'text-blue-600 hover:text-blue-900 mr-2'
                                }, [
                                    React.createElement('i', {
                                        key: 'eye-icon',
                                        className: 'fas fa-eye'
                                    })
                                ]),
                                React.createElement('button', {
                                    key: 'download',
                                    onClick: () => downloadDocument(archive),
                                    className: 'text-green-600 hover:text-green-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'download-icon',
                                        className: 'fas fa-download'
                                    })
                                ])
                            ])
                        ])
                    ))
                ])
            ])
        ]);
    } catch (error) {
        console.error('ListeArchives component error:', error);
        reportError(error);
    }
}

function CalendrierEquipe({ equipeId, user }) {
    const [evenements, setEvenements] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [moisActuel, setMoisActuel] = React.useState(new Date());
    const [conflits, setConflits] = React.useState([]);

    React.useEffect(() => {
        chargerEvenements();
        detecterConflits();
    }, [moisActuel, equipeId]);

    const chargerEvenements = async () => {
        try {
            setLoading(true);
            const debut = new Date(moisActuel.getFullYear(), moisActuel.getMonth(), 1);
            const fin = new Date(moisActuel.getFullYear(), moisActuel.getMonth() + 1, 0);
            
            const response = await fetch(`api/conges.php?action=getCongesEquipe&equipe=${equipeId}&debut=${debut.toISOString()}&fin=${fin.toISOString()}`);
            if (response.ok) {
                const data = await response.json();
                setEvenements(data);
            }
        } catch (error) {
            console.error('Erreur chargement événements:', error);
        } finally {
            setLoading(false);
        }
    };

    const detecterConflits = async () => {
        try {
            const response = await fetch(`api/conges.php?action=detecterConflits&equipe=${equipeId}&mois=${moisActuel.toISOString()}`);
            if (response.ok) {
                const data = await response.json();
                setConflits(data);
            }
        } catch (error) {
            console.error('Erreur détection conflits:', error);
        }
    };

    const changerMois = (direction) => {
        const nouveauMois = new Date(moisActuel);
        nouveauMois.setMonth(nouveauMois.getMonth() + direction);
        setMoisActuel(nouveauMois);
    };

    const genererJoursCalendrier = () => {
        const debut = new Date(moisActuel.getFullYear(), moisActuel.getMonth(), 1);
        const fin = new Date(moisActuel.getFullYear(), moisActuel.getMonth() + 1, 0);
        const jours = [];

        for (let jour = 1; jour <= fin.getDate(); jour++) {
            const date = new Date(moisActuel.getFullYear(), moisActuel.getMonth(), jour);
            const dateStr = date.toISOString().split('T')[0];
            
            const evenementsJour = evenements.filter(evt => 
                dateStr >= evt.dateDebut && dateStr <= evt.dateFin
            );

            const conflitJour = conflits.find(conflit => 
                dateStr >= conflit.dateDebut && dateStr <= conflit.dateFin
            );

            jours.push({
                jour,
                date: dateStr,
                evenements: evenementsJour,
                conflit: conflitJour,
                isWeekend: date.getDay() === 0 || date.getDay() === 6
            });
        }

        return jours;
    };

    if (loading) {
        return (
            <div className="bg-white rounded-lg shadow p-6">
                <div className="text-center">Chargement du calendrier...</div>
            </div>
        );
    }

    const jours = genererJoursCalendrier();

    return (
        <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">Calendrier de l'équipe</h2>
                <div className="flex items-center gap-4">
                    <button onClick={() => changerMois(-1)} className="p-2 hover:bg-gray-100 rounded">
                        <i className="fas fa-chevron-left"></i>
                    </button>
                    <span className="font-medium">
                        {moisActuel.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
                    </span>
                    <button onClick={() => changerMois(1)} className="p-2 hover:bg-gray-100 rounded">
                        <i className="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>

            {conflits.length > 0 && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded">
                    <div className="font-medium text-red-800 mb-2">
                        <i className="fas fa-exclamation-triangle mr-2"></i>
                        Conflits détectés ({conflits.length})
                    </div>
                    {conflits.slice(0, 3).map((conflit, index) => (
                        <div key={index} className="text-sm text-red-700">
                            {conflit.dateDebut} : {conflit.message}
                        </div>
                    ))}
                </div>
            )}

            <div className="grid grid-cols-7 gap-1 mb-2">
                {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(jour => (
                    <div key={jour} className="p-2 text-center font-medium text-gray-600">
                        {jour}
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
                {jours.map((jour) => (
                    <div key={jour.jour} className={`min-h-[80px] p-1 border rounded ${
                        jour.isWeekend ? 'bg-gray-50' : 'bg-white'
                    } ${jour.conflit ? 'border-red-300 bg-red-50' : ''}`}>
                        <div className="text-sm font-medium mb-1">{jour.jour}</div>
                        <div className="space-y-1">
                            {jour.evenements.slice(0, 2).map((evt, index) => (
                                <div key={index} className="text-xs p-1 rounded truncate"
                                     style={{backgroundColor: evt.couleur, color: 'white'}}>
                                    {evt.utilisateur}
                                </div>
                            ))}
                            {jour.evenements.length > 2 && (
                                <div className="text-xs text-gray-500">
                                    +{jour.evenements.length - 2} autres
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

window.CalendrierEquipe = CalendrierEquipe;

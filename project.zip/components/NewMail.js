function NewMail({ user, onClose = null, modal = false }) {
    try {
        const [activeTab, setActiveTab] = React.useState('arrive');
        const [nextNumber, setNextNumber] = React.useState('');
        const [formData, setFormData] = React.useState({
            priority: 'normale',
            date: new Date().toISOString().split('T')[0],
            objet: '',
            expediteur: '',
            numeroEmission: '',
            destinateur: '',
            numeroReference: '',
            files: [],
            externalDocuments: []
        });
        const [showExternalDocForm, setShowExternalDocForm] = React.useState(false);
        const [newExternalDoc, setNewExternalDoc] = React.useState({
            name: '',
            url: '',
            type: '',
            storageType: 'azure'
        });
        const [saving, setSaving] = React.useState(false);
        const [showScanner, setShowScanner] = React.useState(false);

        React.useEffect(() => {
            updateNextNumberPreview();
        }, [activeTab, user]);

        const updateNextNumberPreview = async () => {
            try {
                const preview = await generateMailNumber(activeTab, user.direction, new Date().getFullYear());
                setNextNumber(preview);
            } catch (error) {
                console.error('Erreur preview numéro:', error);
                setNextNumber(`${activeTab === 'arrive' ? 'A' : 'D'}-0001-${user.direction}-${new Date().getFullYear()}`);
            }
        };

        const handleSubmit = async (e) => {
            e.preventDefault();
            setSaving(true);
            
            try {
                // Générer le numéro définitif avec incrémentation
                const mailNumber = await generateMailNumber(activeTab, user.direction, new Date().getFullYear());
                
                const mailData = {
                    numero: mailNumber,
                    type: activeTab,
                    priority: formData.priority,
                    date: formData.date,
                    objet: formData.objet,
                    expediteur: activeTab === 'arrive' ? formData.expediteur : user.name,
                    destinateur: activeTab === 'depart' ? formData.destinateur : '',
                    numeroEmission: formData.numeroEmission,
                    numeroReference: formData.numeroReference,
                    status: 'attente',
                    direction: user.direction,
                    createdBy: user.id,
                    createdByName: user.name,
                    files: formData.files,
                    externalDocuments: formData.externalDocuments,
                    createdAt: new Date().toISOString()
                };

                await createMail(mailData);
                
                // Reset form et mettre à jour le preview
                setFormData({
                    priority: 'normale',
                    date: new Date().toISOString().split('T')[0],
                    objet: '',
                    expediteur: '',
                    numeroEmission: '',
                    destinateur: '',
                    numeroReference: '',
                    files: [],
                    externalDocuments: []
                });
                setNewExternalDoc({
                    name: '',
                    url: '',
                    type: '',
                    storageType: 'azure'
                });
                updateNextNumberPreview();
                
                if (onClose) onClose();
            } catch (error) {
                console.error('Error saving mail:', error);
            } finally {
                setSaving(false);
            }
        };

        const handleChange = (field, value) => {
            setFormData(prev => ({ ...prev, [field]: value }));
        };

        const handleFileChange = async (e) => {
            const files = Array.from(e.target.files);
            const processedFiles = [];

            for (const file of files) {
                // Vérifier la taille du fichier (limite 10MB)
                if (file.size > 10 * 1024 * 1024) {
                    window.toastManager?.error(`Fichier ${file.name} trop volumineux (max 10MB)`);
                    continue;
                }

                // Stocker le fichier localement
                const fileId = await uploadToFTP(file);
                const fileData = {
                    id: fileId,
                    name: file.name,
                    size: file.size,
                    type: file.type,
                    uploadDate: new Date().toISOString(),
                    localPath: fileId,
                    isLocal: true
                };
                processedFiles.push(fileData);
            }

            setFormData(prev => ({ ...prev, files: [...prev.files, ...processedFiles] }));
        };

        const uploadToFTP = async (file) => {
            try {
                // Convertir le fichier en Base64 pour stockage local
                const base64Data = await fileToBase64(file);
                
                // Créer un identifiant unique pour le fichier
                const fileId = `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
                
                // Stocker dans localStorage temporairement
                const fileData = {
                    id: fileId,
                    name: file.name,
                    size: file.size,
                    type: file.type,
                    data: base64Data,
                    uploadDate: new Date().toISOString()
                };
                
                localStorage.setItem(`mail_file_${fileId}`, JSON.stringify(fileData));
                
                window.toastManager?.success(`Fichier ${file.name} ajouté`);
                return fileId; // Retourner l'ID au lieu du chemin FTP
                
            } catch (error) {
                console.error('Erreur stockage fichier:', error);
                window.toastManager?.error(`Erreur stockage: ${error.message}`);
                return file.name;
            }
        };

        // Fonction pour convertir fichier en Base64
        const fileToBase64 = (file) => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => resolve(reader.result);
                reader.onerror = error => reject(error);
            });
        };

        const addExternalDocument = () => {
            if (!newExternalDoc.url.trim()) {
                alert('Veuillez saisir l\'URL du document');
                return;
            }
            
            if (!validateDocumentUrl(newExternalDoc.url)) {
                alert('URL invalide. Veuillez utiliser une URL sécurisée (HTTPS, FTP, SFTP)');
                return;
            }

            const docMetadata = createDocumentMetadata(
                newExternalDoc.url,
                newExternalDoc.name || extractFileNameFromUrl(newExternalDoc.url),
                newExternalDoc.type,
                null
            );
            
            docMetadata.storageType = newExternalDoc.storageType;

            setFormData(prev => ({
                ...prev,
                externalDocuments: [...prev.externalDocuments, docMetadata]
            }));

            setNewExternalDoc({
                name: '',
                url: '',
                type: '',
                storageType: 'azure'
            });
            setShowExternalDocForm(false);
        };

        const handleScannerResult = (scannedData) => {
            if (scannedData && scannedData.extractedData) {
                const extracted = scannedData.extractedData;
                
                // Pré-remplir les champs selon le type de courrier
                if (activeTab === 'arrive') {
                    setFormData(prev => ({
                        ...prev,
                        objet: extracted.objet || prev.objet,
                        expediteur: extracted.expediteur || prev.expediteur,
                        numeroEmission: extracted.reference || prev.numeroEmission,
                        priority: extracted.priorite === 'Urgent' ? 'urgent' : 
                                 extracted.priorite === 'Normal' ? 'normale' : prev.priority
                    }));
                } else {
                    setFormData(prev => ({
                        ...prev,
                        objet: extracted.objet || prev.objet,
                        destinateur: extracted.destinataire || extracted.expediteur || prev.destinateur,
                        numeroReference: extracted.reference || prev.numeroReference,
                        priority: extracted.priorite === 'Urgent' ? 'urgent' : 
                                 extracted.priorite === 'Normal' ? 'normale' : prev.priority
                    }));
                }
            }
            setShowScanner(false);
        };

        const removeExternalDocument = (docId) => {
            setFormData(prev => ({
                ...prev,
                externalDocuments: prev.externalDocuments.filter(doc => doc.id !== docId)
            }));
        };

        const containerClass = modal ? 
            'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50' :
            'p-6 max-w-4xl mx-auto fade-in';

        const contentClass = modal ?
            'bg-white rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto' :
            '';

        return React.createElement('div', {
            className: containerClass,
            'data-name': 'new-mail',
            'data-file': 'components/NewMail.js'
        }, [
            React.createElement('div', {
                key: 'content',
                className: contentClass
            }, [
                modal && React.createElement('div', {
                    key: 'modal-header',
                    className: 'flex justify-between items-center mb-6'
                }, [
                    React.createElement('h2', {
                        key: 'modal-title',
                        className: 'text-2xl font-bold text-gray-800'
                    }, 'Nouveau Courrier'),
                    React.createElement('button', {
                        key: 'close-btn',
                        onClick: onClose,
                        className: 'text-gray-500 hover:text-gray-700'
                    }, [
                        React.createElement('i', {
                            key: 'close-icon',
                            className: 'fas fa-times text-xl'
                        })
                    ])
                ]),
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Nouveau Courrier'),
            React.createElement('div', {
                key: 'tabs',
                className: 'flex mb-6 bg-gray-100 rounded-lg p-1'
            }, [
                React.createElement('button', {
                    key: 'arrive-tab',
                    onClick: () => setActiveTab('arrive'),
                    className: `flex-1 py-2 px-4 rounded-md transition-colors ${
                        activeTab === 'arrive' ? 'bg-white text-blue-600 shadow' : 'text-gray-600'
                    }`
                }, 'Courrier Arrivé'),
                React.createElement('button', {
                    key: 'depart-tab',
                    onClick: () => setActiveTab('depart'),
                    className: `flex-1 py-2 px-4 rounded-md transition-colors ${
                        activeTab === 'depart' ? 'bg-white text-blue-600 shadow' : 'text-gray-600'
                    }`
                }, 'Courrier Départ')
            ]),
            React.createElement('form', {
                key: 'form',
                onSubmit: handleSubmit,
                className: 'bg-white rounded-lg shadow-md p-6 space-y-4'
            }, [
                React.createElement('div', {
                    key: 'info-banner',
                    className: 'bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4'
                }, [
                    React.createElement('div', {
                        key: 'banner-content',
                        className: 'flex justify-between items-center'
                    }, [
                        React.createElement('p', {
                            key: 'numbering-info',
                            className: 'text-sm text-blue-700'
                        }, `📋 Prochain numéro: ${nextNumber}`),
                        React.createElement('button', {
                            key: 'scanner-btn',
                            type: 'button',
                            onClick: () => setShowScanner(true),
                            className: 'bg-purple-600 text-white px-3 py-1 rounded-md text-sm hover:bg-purple-700 flex items-center'
                        }, [
                            React.createElement('i', { key: 'scan-icon', className: 'fas fa-scanner mr-2' }),
                            'Scanner & OCR'
                        ])
                    ])
                ]),
                React.createElement('div', {
                    key: 'priority-date',
                    className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                }, [
                    React.createElement('div', { key: 'priority-field' }, [
                        React.createElement('label', {
                            key: 'priority-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Priorité'),
                        React.createElement('select', {
                            key: 'priority-select',
                            value: formData.priority,
                            onChange: (e) => handleChange('priority', e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                        }, PRIORITIES.map(p => 
                            React.createElement('option', { key: p.value, value: p.value }, p.label)
                        ))
                    ]),
                    React.createElement('div', { key: 'date-field' }, [
                        React.createElement('label', {
                            key: 'date-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Date d\'émission'),
                        React.createElement('input', {
                            key: 'date-input',
                            type: 'date',
                            value: formData.date,
                            onChange: (e) => handleChange('date', e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                            required: true
                        })
                    ])
                ]),
                React.createElement('div', { key: 'objet-field' }, [
                    React.createElement('label', {
                        key: 'objet-label',
                        className: 'block text-sm font-medium text-gray-700 mb-2'
                    }, 'Objet'),
                    React.createElement('input', {
                        key: 'objet-input',
                        type: 'text',
                        value: formData.objet,
                        onChange: (e) => handleChange('objet', e.target.value),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                        required: true
                    })
                ]),
                activeTab === 'arrive' ? [
                    React.createElement('div', {
                        key: 'arrive-fields',
                        className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                    }, [
                        React.createElement('div', { key: 'expediteur' }, [
                            React.createElement('label', {
                                key: 'expediteur-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Expéditeur'),
                            React.createElement('input', {
                                key: 'expediteur-input',
                                type: 'text',
                                value: formData.expediteur,
                                onChange: (e) => handleChange('expediteur', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                                required: true
                            })
                        ]),
                        React.createElement('div', { key: 'numero-emission' }, [
                            React.createElement('label', {
                                key: 'numero-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Numéro d\'émission'),
                            React.createElement('input', {
                                key: 'numero-input',
                                type: 'text',
                                value: formData.numeroEmission,
                                onChange: (e) => handleChange('numeroEmission', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                            })
                        ])
                    ])
                ] : [
                    React.createElement('div', {
                        key: 'depart-fields',
                        className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                    }, [
                        React.createElement('div', { key: 'destinateur' }, [
                            React.createElement('label', {
                                key: 'destinateur-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Destinateur'),
                            React.createElement('input', {
                                key: 'destinateur-input',
                                type: 'text',
                                value: formData.destinateur,
                                onChange: (e) => handleChange('destinateur', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                                required: true
                            })
                        ]),
                        React.createElement('div', { key: 'numero-reference' }, [
                            React.createElement('label', {
                                key: 'reference-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Numéro de référence'),
                            React.createElement('input', {
                                key: 'reference-input',
                                type: 'text',
                                value: formData.numeroReference,
                                onChange: (e) => handleChange('numeroReference', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                            })
                        ])
                    ])
                ],
                React.createElement('div', { key: 'files-field' }, [
                    React.createElement('label', {
                        key: 'files-label',
                        className: 'block text-sm font-medium text-gray-700 mb-2'
                    }, 'Fichiers joints'),
                    React.createElement('input', {
                        key: 'files-input',
                        type: 'file',
                        multiple: true,
                        accept: '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png',
                        onChange: handleFileChange,
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    }),
                    formData.files.length > 0 && React.createElement('div', {
                        key: 'files-list',
                        className: 'mt-2 space-y-1'
                    }, formData.files.map((file, index) => 
                        React.createElement('div', {
                            key: index,
                            className: 'flex items-center justify-between bg-gray-50 p-2 rounded text-sm'
                        }, [
                            React.createElement('span', {
                                key: 'filename',
                                className: 'text-gray-700'
                            }, `📎 ${file.name} (${(file.size / 1024).toFixed(1)} KB)`),
                            React.createElement('button', {
                                key: 'remove-btn',
                                type: 'button',
                                onClick: () => {
                                    // Supprimer du localStorage
                                    if (file.localPath) {
                                        localStorage.removeItem(`mail_file_${file.localPath}`);
                                    }
                                    // Supprimer de la liste
                                    setFormData(prev => ({
                                        ...prev,
                                        files: prev.files.filter((_, i) => i !== index)
                                    }));
                                },
                                className: 'text-red-500 hover:text-red-700'
                            }, '✕')
                        ])
                    ))
                ]),
                React.createElement('button', {
                    key: 'submit',
                    type: 'submit',
                    disabled: saving,
                    className: 'btn-primary text-white px-6 py-2 rounded-md font-medium disabled:opacity-50'
                }, saving ? 'Enregistrement...' : 'Enregistrer')
            ]),
            showScanner && React.createElement(ScannerOCR, {
                key: 'scanner-modal',
                onClose: () => setShowScanner(false),
                onDocumentScanned: handleScannerResult,
                mailType: activeTab
            })
            ])
        ]);
    } catch (error) {
        console.error('NewMail component error:', error);
        reportError(error);
    }
}

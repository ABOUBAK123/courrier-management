function CourrierTraite({ user }) {
    try {
        const [mails, setMails] = React.useState([]);

        React.useEffect(() => {
            loadTreatedMails();
        }, [user]);

        const loadTreatedMails = async () => {
            try {
                const response = await trickleListObjects(`mail:${user.direction}`, 100, true);
                const treatedMails = response.items
                    .map(item => ({ ...item.objectData, id: item.objectId }))
                    .filter(mail => 
                        mail.status === 'traite' || 
                        mail.status === 'valide' ||
                        (mail.finalValidatedBy && mail.finalValidationDate) ||
                        (mail.validatedBy && mail.validationDate)
                    );
                setMails(treatedMails);
            } catch (error) {
                console.error('Erreur lors du chargement:', error);
            }
        };

        const downloadResponseFile = (filename) => {
            alert(`Téléchargement du fichier de réponse: ${filename}`);
        };

        const viewMail = (mail) => {
            const validationInfo = mail.finalValidatedBy ? 
                `\nValidé finalement par: ${mail.finalValidatedBy}` :
                mail.validatedBy ? `\nValidé par: ${mail.validatedBy}` : '';
            
            alert(`Visualisation du courrier: ${mail.numero}\nObjet: ${mail.objet}\nTraitement: ${mail.treatmentName || 'Standard'}${validationInfo}`);
        };

        const getStatusDisplay = (mail) => {
            if (mail.finalValidatedBy) return { text: 'Validé Final', color: 'bg-purple-100 text-purple-800' };
            if (mail.status === 'valide') return { text: 'Validé', color: 'bg-green-100 text-green-800' };
            return { text: 'Traité', color: 'bg-blue-100 text-blue-800' };
        };

        const getValidatedBy = (mail) => {
            return mail.finalValidatedBy || mail.validatedBy || mail.treatedBy || '-';
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'courrier-traite',
            'data-file': 'components/CourrierTraite.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Courriers Traités'),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Numéro', 'Objet', 'Traitement', 'Statut', 'Validé par', 'Fichier réponse', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, mails.map(mail => {
                        const statusInfo = getStatusDisplay(mail);
                        return React.createElement('tr', {
                            key: mail.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'numero',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, mail.numero),
                            React.createElement('td', {
                                key: 'objet',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.objet),
                            React.createElement('td', {
                                key: 'traitement',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.treatmentName || 'Traitement standard'),
                            React.createElement('td', {
                                key: 'status',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('span', {
                                    key: 'status-badge',
                                    className: `px-2 py-1 text-xs font-medium rounded-full ${statusInfo.color}`
                                }, statusInfo.text)
                            ]),
                            React.createElement('td', {
                                key: 'validated-by',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, getValidatedBy(mail)),
                            React.createElement('td', {
                                key: 'response-file',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, mail.responseFile ? [
                                React.createElement('button', {
                                    key: 'download-response',
                                    onClick: () => downloadResponseFile(mail.responseFile),
                                    className: 'text-blue-600 hover:text-blue-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'download-icon',
                                        className: 'fas fa-download mr-1'
                                    }),
                                    'Télécharger'
                                ])
                            ] : 'Aucun fichier'),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium'
                            }, [
                                React.createElement('button', {
                                    key: 'view',
                                    onClick: () => viewMail(mail),
                                    className: 'text-blue-600 hover:text-blue-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'eye-icon',
                                        className: 'fas fa-eye'
                                    })
                                ])
                            ])
                        ]);
                    }))
                ])
            ])
        ]);
    } catch (error) {
        console.error('CourrierTraite component error:', error);
        reportError(error);
    }
}

function Formation({ user }) {
    try {
        const [formations, setFormations] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [formData, setFormData] = React.useState({
            titre: '',
            description: '',
            dateDebut: '',
            dateFin: '',
            formateur: '',
            participants: ''
        });

        React.useEffect(() => {
            loadFormations();
        }, [user]);

        const loadFormations = async () => {
            try {
                const response = await trickleListObjects(`formation:${user.direction}`, 100, true);
                const formationData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setFormations(formationData);
            } catch (error) {
                console.error('Erreur chargement formations:', error);
            }
        };

        const handleSave = async () => {
            try {
                await trickleCreateObject(`formation:${user.direction}`, {
                    ...formData,
                    status: 'active',
                    createdBy: user.name,
                    createdAt: new Date().toISOString()
                });
                
                alert('Formation créée avec succès!');
                setFormData({ titre: '', description: '', dateDebut: '', dateFin: '', formateur: '', participants: '' });
                setShowForm(false);
                loadFormations();
            } catch (error) {
                alert('Erreur lors de la création');
            }
        };

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'formation',
            'data-file': 'components/Formation.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold text-gray-800'
                }, 'Gestion des Formations'),
                React.createElement('button', {
                    key: 'add-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouvelle Formation')
            ]),
            React.createElement('div', {
                key: 'formations-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            }, formations.map(formation =>
                React.createElement('div', {
                    key: formation.id,
                    className: 'bg-white rounded-lg shadow-md p-6 card-hover'
                }, [
                    React.createElement('h4', {
                        key: 'titre',
                        className: 'text-lg font-semibold text-gray-800 mb-2'
                    }, formation.titre),
                    React.createElement('p', {
                        key: 'description',
                        className: 'text-gray-600 mb-3'
                    }, formation.description),
                    React.createElement('div', {
                        key: 'details',
                        className: 'text-sm text-gray-500 space-y-1'
                    }, [
                        React.createElement('p', {
                            key: 'formateur'
                        }, `Formateur: ${formation.formateur}`),
                        React.createElement('p', {
                            key: 'dates'
                        }, `Du ${new Date(formation.dateDebut).toLocaleDateString()} au ${new Date(formation.dateFin).toLocaleDateString()}`),
                        React.createElement('p', {
                            key: 'participants'
                        }, `Participants: ${formation.participants}`)
                    ])
                ])
            )),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Nouvelle Formation'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('input', {
                            key: 'titre',
                            type: 'text',
                            placeholder: 'Titre de la formation',
                            value: formData.titre,
                            onChange: (e) => setFormData(prev => ({ ...prev, titre: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('textarea', {
                            key: 'description',
                            placeholder: 'Description',
                            value: formData.description,
                            onChange: (e) => setFormData(prev => ({ ...prev, description: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            rows: 3
                        }),
                        React.createElement('input', {
                            key: 'formateur',
                            type: 'text',
                            placeholder: 'Formateur',
                            value: formData.formateur,
                            onChange: (e) => setFormData(prev => ({ ...prev, formateur: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('div', {
                            key: 'dates',
                            className: 'grid grid-cols-2 gap-4'
                        }, [
                            React.createElement('input', {
                                key: 'debut',
                                type: 'date',
                                value: formData.dateDebut,
                                onChange: (e) => setFormData(prev => ({ ...prev, dateDebut: e.target.value })),
                                className: 'px-3 py-2 border border-gray-300 rounded-md'
                            }),
                            React.createElement('input', {
                                key: 'fin',
                                type: 'date',
                                value: formData.dateFin,
                                onChange: (e) => setFormData(prev => ({ ...prev, dateFin: e.target.value })),
                                className: 'px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ]),
                        React.createElement('input', {
                            key: 'participants',
                            type: 'text',
                            placeholder: 'Nombre de participants',
                            value: formData.participants,
                            onChange: (e) => setFormData(prev => ({ ...prev, participants: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        })
                    ]),
                    React.createElement('div', {
                        key: 'buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save',
                            onClick: handleSave,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, 'Créer'),
                        React.createElement('button', {
                            key: 'cancel',
                            onClick: () => setShowForm(false),
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Formation component error:', error);
        reportError(error);
    }
}

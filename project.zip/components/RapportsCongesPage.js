window.RapportsCongesPage = function RapportsCongesPage({ user }) {
    try {
        const [statistiques, setStatistiques] = React.useState({});
        const [periodeRapport, setPeriodeRapport] = React.useState('mois');
        const [loading, setLoading] = React.useState(true);
        const [chartInstances, setChartInstances] = React.useState({});

        React.useEffect(() => {
            loadStatistiques();
            return () => {
                // Nettoyer les graphiques lors du démontage
                Object.values(chartInstances).forEach(chart => {
                    if (chart && typeof chart.destroy === 'function') {
                        chart.destroy();
                    }
                });
            };
        }, [periodeRapport]);

        const loadStatistiques = async () => {
            try {
                setLoading(true);
                const response = await trickleListObjects('demande_conge', 200, true);
                const demandes = response.items;

                const stats = calculerStatistiques(demandes);
                setStatistiques(stats);
                
                setTimeout(() => {
                    creerGraphiques(stats);
                }, 100);
            } catch (error) {
                console.error('Erreur chargement statistiques:', error);
            } finally {
                setLoading(false);
            }
        };

        const calculerStatistiques = (demandes) => {
            const maintenant = new Date();
            const debutPeriode = new Date();
            
            switch (periodeRapport) {
                case 'semaine':
                    debutPeriode.setDate(maintenant.getDate() - 7);
                    break;
                case 'mois':
                    debutPeriode.setMonth(maintenant.getMonth() - 1);
                    break;
                case 'trimestre':
                    debutPeriode.setMonth(maintenant.getMonth() - 3);
                    break;
                case 'annee':
                    debutPeriode.setFullYear(maintenant.getFullYear() - 1);
                    break;
            }

            const demandesPeriode = demandes.filter(d => 
                new Date(d.createdAt) >= debutPeriode
            );

            const parStatut = {};
            const parType = {};
            const parDirection = {};
            
            demandesPeriode.forEach(demande => {
                const statut = demande.objectData.statut || 'non_defini';
                const type = demande.objectData.type_conge || 'non_defini';
                const direction = demande.objectData.agent_direction || 'non_defini';
                
                parStatut[statut] = (parStatut[statut] || 0) + 1;
                parType[type] = (parType[type] || 0) + 1;
                parDirection[direction] = (parDirection[direction] || 0) + 1;
            });

            return {
                totalDemandes: demandesPeriode.length,
                demandesApprouvees: demandesPeriode.filter(d => d.objectData.statut === 'approuvee').length,
                demandesRefusees: demandesPeriode.filter(d => d.objectData.statut === 'refusee').length,
                demandesEnAttente: demandesPeriode.filter(d => d.objectData.statut === 'en_attente').length,
                parStatut,
                parType,
                parDirection,
                tauxApprobation: demandesPeriode.length > 0 
                    ? ((demandesPeriode.filter(d => d.objectData.statut === 'approuvee').length / demandesPeriode.length) * 100).toFixed(1)
                    : 0
            };
        };

        const creerGraphiques = (stats) => {
            // Graphique par statut
            const ctxStatut = document.getElementById('chartStatut');
            if (ctxStatut) {
                if (chartInstances.statut) {
                    chartInstances.statut.destroy();
                }
                
                const chartStatut = new ChartJS(ctxStatut, {
                    type: 'doughnut',
                    data: {
                        labels: Object.keys(stats.parStatut),
                        datasets: [{
                            data: Object.values(stats.parStatut),
                            backgroundColor: ['#10B981', '#EF4444', '#F59E0B', '#6B7280']
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: { display: true }
                        }
                    }
                });
                
                setChartInstances(prev => ({ ...prev, statut: chartStatut }));
            }

            // Graphique par type
            const ctxType = document.getElementById('chartType');
            if (ctxType) {
                if (chartInstances.type) {
                    chartInstances.type.destroy();
                }
                
                const chartType = new ChartJS(ctxType, {
                    type: 'bar',
                    data: {
                        labels: Object.keys(stats.parType),
                        datasets: [{
                            label: 'Nombre de demandes',
                            data: Object.values(stats.parType),
                            backgroundColor: '#3B82F6'
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: { display: false }
                        }
                    }
                });
                
                setChartInstances(prev => ({ ...prev, type: chartType }));
            }
        };

        if (loading) {
            return (
                <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
            );
        }

        return (
            <div className="p-6" data-name="rapports-conges-page" data-file="components/RapportsCongesPage.js">
                <div className="mb-6 flex justify-between items-center">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Rapports des Congés</h1>
                        <p className="text-gray-600">Analyses et statistiques des demandes de congés</p>
                    </div>
                    <select 
                        value={periodeRapport}
                        onChange={(e) => setPeriodeRapport(e.target.value)}
                        className="border border-gray-300 rounded-md px-3 py-2"
                    >
                        <option value="semaine">7 derniers jours</option>
                        <option value="mois">30 derniers jours</option>
                        <option value="trimestre">3 derniers mois</option>
                        <option value="annee">12 derniers mois</option>
                    </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">Total Demandes</p>
                                <p className="text-2xl font-bold text-gray-900">{statistiques.totalDemandes}</p>
                            </div>
                            <i className="fas fa-calendar-alt text-blue-500 text-2xl"></i>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">Approuvées</p>
                                <p className="text-2xl font-bold text-green-600">{statistiques.demandesApprouvees}</p>
                            </div>
                            <i className="fas fa-check-circle text-green-500 text-2xl"></i>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">En attente</p>
                                <p className="text-2xl font-bold text-yellow-600">{statistiques.demandesEnAttente}</p>
                            </div>
                            <i className="fas fa-clock text-yellow-500 text-2xl"></i>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm text-gray-600">Taux d'approbation</p>
                                <p className="text-2xl font-bold text-blue-600">{statistiques.tauxApprobation}%</p>
                            </div>
                            <i className="fas fa-percentage text-blue-500 text-2xl"></i>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-lg font-semibold mb-4">Répartition par statut</h3>
                        <canvas id="chartStatut" width="400" height="200"></canvas>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-lg font-semibold mb-4">Demandes par type</h3>
                        <canvas id="chartType" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('RapportsCongesPage error:', error);
        return (
            <div className="p-6 text-center">
                <p className="text-red-600">Erreur lors du chargement de la page</p>
            </div>
        );
    }
};

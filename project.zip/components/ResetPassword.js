function ResetPassword({ token, onResetComplete }) {
    try {
        const [newPassword, setNewPassword] = React.useState('');
        const [confirmPassword, setConfirmPassword] = React.useState('');
        const [loading, setLoading] = React.useState(false);
        const [error, setError] = React.useState('');
        const [validToken, setValidToken] = React.useState(null);

        React.useEffect(() => {
            validateToken();
        }, [token]);

        const validateToken = async () => {
            try {
                const resetRequests = await trickleListObjects('password-reset', 100, true);
                const resetRequest = resetRequests.items.find(r => 
                    r.objectData.token === token && 
                    !r.objectData.used && 
                    new Date(r.objectData.expiry) > new Date()
                );

                if (resetRequest) {
                    setValidToken(resetRequest);
                } else {
                    setError('Token de réinitialisation invalide ou expiré');
                }
            } catch (error) {
                setError('Erreur lors de la validation du token');
                console.error('Token validation error:', error);
            }
        };

        const handleResetPassword = async (e) => {
            e.preventDefault();
            
            if (newPassword !== confirmPassword) {
                setError('Les mots de passe ne correspondent pas');
                return;
            }

            if (newPassword.length < 6) {
                setError('Le mot de passe doit contenir au moins 6 caractères');
                return;
            }

            setLoading(true);
            setError('');

            try {
                // Mettre à jour le mot de passe de l'utilisateur
                const users = await trickleListObjects('user', 100, true);
                const user = users.items.find(u => u.objectData.email === validToken.objectData.email);

                if (user) {
                    await trickleUpdateObject('user', user.objectId, {
                        ...user.objectData,
                        password: newPassword,
                        passwordUpdatedAt: new Date().toISOString()
                    });

                    // Marquer le token comme utilisé
                    await trickleUpdateObject('password-reset', validToken.objectId, {
                        ...validToken.objectData,
                        used: true,
                        usedAt: new Date().toISOString()
                    });

                    alert('Mot de passe réinitialisé avec succès !');
                    if (onResetComplete) onResetComplete();
                } else {
                    setError('Utilisateur non trouvé');
                }
            } catch (error) {
                setError('Erreur lors de la réinitialisation du mot de passe');
                console.error('Reset password error:', error);
            } finally {
                setLoading(false);
            }
        };

        if (!validToken && !error) {
            return React.createElement('div', {
                className: 'min-h-screen flex items-center justify-center',
                'data-name': 'loading',
                'data-file': 'components/ResetPassword.js'
            }, 'Validation du token...');
        }

        if (error && !validToken) {
            return React.createElement('div', {
                className: 'min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 to-purple-900',
                'data-name': 'error-container',
                'data-file': 'components/ResetPassword.js'
            }, [
                React.createElement('div', {
                    key: 'error-card',
                    className: 'bg-white p-8 rounded-xl shadow-2xl w-full max-w-md text-center'
                }, [
                    React.createElement('i', {
                        key: 'error-icon',
                        className: 'fas fa-exclamation-triangle text-4xl text-red-600 mb-4'
                    }),
                    React.createElement('h2', {
                        key: 'error-title',
                        className: 'text-xl font-bold text-gray-800 mb-2'
                    }, 'Lien invalide'),
                    React.createElement('p', {
                        key: 'error-message',
                        className: 'text-gray-600'
                    }, error)
                ])
            ]);
        }

        return React.createElement('div', {
            className: 'min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 to-purple-900',
            'data-name': 'reset-container',
            'data-file': 'components/ResetPassword.js'
        }, [
            React.createElement('div', {
                key: 'reset-card',
                className: 'bg-white p-8 rounded-xl shadow-2xl w-full max-w-md fade-in'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'text-center mb-8'
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: 'fas fa-key text-4xl text-blue-600 mb-4'
                    }),
                    React.createElement('h1', {
                        key: 'title',
                        className: 'text-2xl font-bold text-gray-800'
                    }, 'Nouveau mot de passe'),
                    React.createElement('p', {
                        key: 'subtitle',
                        className: 'text-gray-600 mt-2'
                    }, `Pour: ${validToken?.objectData?.email}`)
                ]),
                React.createElement('form', {
                    key: 'form',
                    onSubmit: handleResetPassword,
                    className: 'space-y-6'
                }, [
                    React.createElement('div', { key: 'new-password-field' }, [
                        React.createElement('label', {
                            key: 'new-password-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Nouveau mot de passe'),
                        React.createElement('input', {
                            key: 'new-password-input',
                            type: 'password',
                            value: newPassword,
                            onChange: (e) => setNewPassword(e.target.value),
                            className: 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500',
                            placeholder: '••••••••',
                            required: true,
                            minLength: 6
                        })
                    ]),
                    React.createElement('div', { key: 'confirm-password-field' }, [
                        React.createElement('label', {
                            key: 'confirm-password-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Confirmer le mot de passe'),
                        React.createElement('input', {
                            key: 'confirm-password-input',
                            type: 'password',
                            value: confirmPassword,
                            onChange: (e) => setConfirmPassword(e.target.value),
                            className: 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500',
                            placeholder: '••••••••',
                            required: true,
                            minLength: 6
                        })
                    ]),
                    error && React.createElement('div', {
                        key: 'error',
                        className: 'bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm'
                    }, error),
                    React.createElement('button', {
                        key: 'submit',
                        type: 'submit',
                        disabled: loading,
                        className: 'w-full btn-primary text-white py-3 px-4 rounded-lg font-medium disabled:opacity-50'
                    }, loading ? 'Réinitialisation...' : 'Réinitialiser le mot de passe')
                ])
            ])
        ]);
    } catch (error) {
        console.error('ResetPassword component error:', error);
        reportError(error);
    }
}

function Instructions({ user }) {
    try {
        const [instructions, setInstructions] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [formData, setFormData] = React.useState({
            nom: '',
            description: ''
        });

        React.useEffect(() => {
            loadInstructions();
        }, []);

        const loadInstructions = async () => {
            try {
                const response = await trickleListObjects('instructions', 100, true);
                const instructionData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setInstructions(instructionData);
            } catch (error) {
                console.error('Erreur lors du chargement des instructions:', error);
            }
        };

        const handleSave = async () => {
            try {
                await trickleCreateObject('instructions', {
                    ...formData,
                    createdBy: user.name,
                    createdAt: new Date().toISOString()
                });
                
                alert('Instruction créée avec succès!');
                setFormData({ nom: '', description: '' });
                setShowForm(false);
                loadInstructions();
            } catch (error) {
                alert('Erreur lors de la création');
            }
        };

        const handleDelete = async (instructionId) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer cette instruction?')) {
                try {
                    await trickleDeleteObject('instructions', instructionId);
                    alert('Instruction supprimée avec succès');
                    loadInstructions();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'instructions',
            'data-file': 'components/Instructions.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Instructions de Traitement'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouvelle Instruction')
            ]),
            React.createElement('div', {
                key: 'instructions-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            }, instructions.map(instruction =>
                React.createElement('div', {
                    key: instruction.id,
                    className: 'bg-white rounded-lg shadow-md p-6 card-hover'
                }, [
                    React.createElement('div', {
                        key: 'instruction-header',
                        className: 'flex justify-between items-start mb-4'
                    }, [
                        React.createElement('h3', {
                            key: 'instruction-name',
                            className: 'text-lg font-semibold text-gray-800'
                        }, instruction.nom),
                        React.createElement('button', {
                            key: 'delete-btn',
                            onClick: () => handleDelete(instruction.id),
                            className: 'text-red-600 hover:text-red-900'
                        }, React.createElement('i', { className: 'fas fa-trash' }))
                    ]),
                    React.createElement('p', {
                        key: 'instruction-description',
                        className: 'text-gray-600 mb-4'
                    }, instruction.description || 'Aucune description'),
                    React.createElement('div', {
                        key: 'instruction-info',
                        className: 'text-sm text-gray-500'
                    }, [
                        React.createElement('p', { key: 'created-by' }, `Créé par: ${instruction.createdBy}`),
                        React.createElement('p', { key: 'created-date' }, `Date: ${new Date(instruction.createdAt).toLocaleDateString()}`)
                    ])
                ])
            )),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Nouvelle Instruction'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('input', {
                            key: 'nom-input',
                            type: 'text',
                            placeholder: 'Nom de l\'instruction',
                            value: formData.nom,
                            onChange: (e) => setFormData(prev => ({ ...prev, nom: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('textarea', {
                            key: 'description-textarea',
                            placeholder: 'Description',
                            value: formData.description,
                            onChange: (e) => setFormData(prev => ({ ...prev, description: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            rows: 3
                        })
                    ]),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save-btn',
                            onClick: handleSave,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, 'Créer'),
                        React.createElement('button', {
                            key: 'cancel-btn',
                            onClick: () => setShowForm(false),
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Instructions component error:', error);
        reportError(error);
    }
}

function RapportsConges() {
    const [reportData, setReportData] = React.useState({});
    const [filters, setFilters] = React.useState({
        departement: '',
        periode: 'mois_actuel',
        dateDebut: '',
        dateFin: ''
    });
    const [departements, setDepartements] = React.useState([]);
    const [loading, setLoading] = React.useState(false);

    React.useEffect(() => {
        loadDepartements();
        generateReport();
    }, []);

    React.useEffect(() => {
        generateReport();
    }, [filters]);

    const loadDepartements = async () => {
        try {
            const result = await trickleListObjects('direction', 100, true);
            setDepartements(result.items);
        } catch (error) {
            console.error('Erreur chargement départements:', error);
        }
    };

    const generateReport = async () => {
        setLoading(true);
        try {
            const result = await trickleListObjects('conge', 500, true);
            const conges = result.items;

            // Filtrer par période
            const { dateDebut, dateFin } = getPeriodeDates();
            const congesFiltres = conges.filter(conge => {
                const dateConge = new Date(conge.objectData.dateDebut);
                return dateConge >= dateDebut && dateConge <= dateFin;
            });

            // Filtrer par département si sélectionné
            const congesDepartement = filters.departement ? 
                congesFiltres.filter(c => c.objectData.departement === filters.departement) :
                congesFiltres;

            // Générer statistiques
            const stats = {
                totalDemandes: congesDepartement.length,
                demandesApprouvees: congesDepartement.filter(c => c.objectData.status === 'approuve').length,
                demandesRefusees: congesDepartement.filter(c => c.objectData.status === 'refuse').length,
                demandesEnAttente: congesDepartement.filter(c => c.objectData.status === 'en_attente').length,
                totalJours: congesDepartement.reduce((sum, c) => sum + (c.objectData.nombreJours || 0), 0)
            };

            // Stats par département
            const statsDepartement = {};
            congesFiltres.forEach(conge => {
                const dept = conge.objectData.departement || 'Non défini';
                if (!statsDepartement[dept]) {
                    statsDepartement[dept] = { total: 0, jours: 0 };
                }
                statsDepartement[dept].total++;
                statsDepartement[dept].jours += conge.objectData.nombreJours || 0;
            });

            // Stats par type de congé
            const statsType = {};
            congesDepartement.forEach(conge => {
                const type = conge.objectData.type || 'Non défini';
                if (!statsType[type]) {
                    statsType[type] = 0;
                }
                statsType[type]++;
            });

            setReportData({
                stats,
                statsDepartement,
                statsType,
                congesList: congesDepartement.slice(0, 50) // Limiter pour l'affichage
            });

        } catch (error) {
            console.error('Erreur génération rapport:', error);
        } finally {
            setLoading(false);
        }
    };

    const getPeriodeDates = () => {
        const maintenant = new Date();
        let dateDebut, dateFin;

        switch (filters.periode) {
            case 'mois_actuel':
                dateDebut = new Date(maintenant.getFullYear(), maintenant.getMonth(), 1);
                dateFin = new Date(maintenant.getFullYear(), maintenant.getMonth() + 1, 0);
                break;
            case 'trimestre_actuel':
                const trimestre = Math.floor(maintenant.getMonth() / 3);
                dateDebut = new Date(maintenant.getFullYear(), trimestre * 3, 1);
                dateFin = new Date(maintenant.getFullYear(), (trimestre + 1) * 3, 0);
                break;
            case 'annee_actuelle':
                dateDebut = new Date(maintenant.getFullYear(), 0, 1);
                dateFin = new Date(maintenant.getFullYear(), 11, 31);
                break;
            case 'personnalise':
                dateDebut = filters.dateDebut ? new Date(filters.dateDebut) : new Date();
                dateFin = filters.dateFin ? new Date(filters.dateFin) : new Date();
                break;
            default:
                dateDebut = new Date(maintenant.getFullYear(), maintenant.getMonth(), 1);
                dateFin = new Date(maintenant.getFullYear(), maintenant.getMonth() + 1, 0);
        }

        return { dateDebut, dateFin };
    };

    return React.createElement('div', {
        className: 'space-y-6',
        'data-name': 'rapports-conges',
        'data-file': 'components/RapportsConges.js'
    }, [
        // Filtres
        React.createElement('div', {
            key: 'filters',
            className: 'bg-white p-4 rounded-lg shadow'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-lg font-semibold mb-4'
            }, 'Filtres du rapport'),
            
            React.createElement('div', {
                key: 'filter-grid',
                className: 'grid grid-cols-1 md:grid-cols-4 gap-4'
            }, [
                React.createElement('select', {
                    key: 'periode',
                    value: filters.periode,
                    onChange: (e) => setFilters({...filters, periode: e.target.value}),
                    className: 'px-3 py-2 border rounded-md'
                }, [
                    React.createElement('option', { key: 'mois', value: 'mois_actuel' }, 'Mois actuel'),
                    React.createElement('option', { key: 'trimestre', value: 'trimestre_actuel' }, 'Trimestre actuel'),
                    React.createElement('option', { key: 'annee', value: 'annee_actuelle' }, 'Année actuelle'),
                    React.createElement('option', { key: 'perso', value: 'personnalise' }, 'Personnalisé')
                ]),

                React.createElement('select', {
                    key: 'dept',
                    value: filters.departement,
                    onChange: (e) => setFilters({...filters, departement: e.target.value}),
                    className: 'px-3 py-2 border rounded-md'
                }, [
                    React.createElement('option', { key: 'all', value: '' }, 'Tous les départements'),
                    ...departements.map(dept =>
                        React.createElement('option', {
                            key: dept.objectId,
                            value: dept.objectData.nom
                        }, dept.objectData.nom)
                    )
                ])
            ])
        ]),

        // Statistiques principales
        loading ? React.createElement('div', {
            key: 'loading',
            className: 'text-center py-8'
        }, 'Génération du rapport...') :
        React.createElement('div', {
            key: 'stats',
            className: 'grid grid-cols-1 md:grid-cols-4 gap-4'
        }, [
            React.createElement('div', {
                key: 'total',
                className: 'bg-blue-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-blue-600 text-sm font-medium'
                }, 'Total demandes'),
                React.createElement('p', {
                    key: 'value',
                    className: 'text-2xl font-bold text-blue-900'
                }, reportData.stats?.totalDemandes || 0)
            ]),
            React.createElement('div', {
                key: 'approved',
                className: 'bg-green-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-green-600 text-sm font-medium'
                }, 'Approuvées'),
                React.createElement('p', {
                    key: 'value',
                    className: 'text-2xl font-bold text-green-900'
                }, reportData.stats?.demandesApprouvees || 0)
            ]),
            React.createElement('div', {
                key: 'rejected',
                className: 'bg-red-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-red-600 text-sm font-medium'
                }, 'Refusées'),
                React.createElement('p', {
                    key: 'value',
                    className: 'text-2xl font-bold text-red-900'
                }, reportData.stats?.demandesRefusees || 0)
            ]),
            React.createElement('div', {
                key: 'days',
                className: 'bg-purple-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-purple-600 text-sm font-medium'
                }, 'Total jours'),
                React.createElement('p', {
                    key: 'value',
                    className: 'text-2xl font-bold text-purple-900'
                }, reportData.stats?.totalJours || 0)
            ])
        ])
    ]);
}

window.RapportsConges = RapportsConges;
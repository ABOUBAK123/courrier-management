function DemandeCongeAnnuelModal({ isOpen, onClose, onSubmit, agent }) {
    const [formData, setFormData] = React.useState({
        dateDebut: '',
        dateFin: '',
        nombreJoursPris: 0,
        motif: '',
        fichierJoint: null
    });
    
    const [soldeConges, setSoldeConges] = React.useState({ joursRestants: 30, joursUtilises: 0 });
    const [messageCalcul, setMessageCalcul] = React.useState('');
    const [erreurSolde, setErreurSolde] = React.useState(false);
    const [calculEnCours, setCalculEnCours] = React.useState(false);

    React.useEffect(() => {
        if (isOpen) {
            loadSoldeConges();
            resetForm();
        }
    }, [isOpen]);

    const resetForm = () => {
        setFormData({
            dateDebut: '',
            dateFin: '',
            nombreJoursPris: 0,
            motif: '',
            fichierJoint: null
        });
        setMessageCalcul('');
        setErreurSolde(false);
        setCalculEnCours(false);
    };

    const loadSoldeConges = async () => {
        try {
            const anneeActuelle = new Date().getFullYear();
            const result = await trickleListObjects(`conge_agent:${agent?.id}:${anneeActuelle}`, 100, true);
            
            let joursUtilises = 0;
            result.items.forEach(conge => {
                if (conge.objectData.type === 'Congé annuel' && conge.objectData.statut === 'Approuvé') {
                    joursUtilises += parseInt(conge.objectData.nombreJours) || 0;
                }
            });
            
            const joursRestants = 30 - joursUtilises;
            setSoldeConges({ joursRestants, joursUtilises });
        } catch (error) {
            console.error('Erreur chargement solde congés:', error);
            setSoldeConges({ joursRestants: 30, joursUtilises: 0 });
        }
    };

    const calculerJoursConges = (dateDebut, dateFin) => {
        if (!dateDebut || !dateFin) {
            setMessageCalcul('');
            setErreurSolde(false);
            setCalculEnCours(false);
            return 0;
        }

        const debut = new Date(dateDebut);
        const fin = new Date(dateFin);
        
        if (fin < debut) {
            setMessageCalcul('⚠️ La date de fin doit être après la date de début');
            setErreurSolde(true);
            setCalculEnCours(false);
            return 0;
        }

        // Calcul du nombre de jours (inclus les deux dates)
        const diffTime = fin.getTime() - debut.getTime();
        const jours = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        
        setCalculEnCours(true);
        
        // Vérification du solde disponible
        if (jours <= soldeConges.joursRestants) {
            setErreurSolde(false);
            const nouveauReste = soldeConges.joursRestants - jours;
            setMessageCalcul(`✅ Demande de ${jours} jour${jours > 1 ? 's' : ''} → OK. Après cette demande, il vous restera ${nouveauReste} jour${nouveauReste > 1 ? 's' : ''} de congés annuels.`);
        } else {
            setErreurSolde(true);
            setMessageCalcul(`❌ ERREUR: Vous demandez ${jours} jour${jours > 1 ? 's' : ''} mais il ne vous reste que ${soldeConges.joursRestants} jour${soldeConges.joursRestants > 1 ? 's' : ''} de congés annuels disponibles.`);
        }
        
        return jours;
    };

    const handleDateDebutChange = (value) => {
        setFormData(prev => {
            const newData = { ...prev, dateDebut: value };
            if (value && prev.dateFin) {
                newData.nombreJoursPris = calculerJoursConges(value, prev.dateFin);
            }
            return newData;
        });
    };

    const handleDateFinChange = (value) => {
        setFormData(prev => {
            const newData = { ...prev, dateFin: value };
            if (prev.dateDebut && value) {
                newData.nombreJoursPris = calculerJoursConges(prev.dateDebut, value);
            }
            return newData;
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (erreurSolde) return;
        
        try {
            const agentId = agent?.objectId || agent?.id || agent?.matricule;
            if (!agentId) {
                alert('Erreur: Impossible d\'identifier l\'agent. Veuillez vous reconnecter.');
                return;
            }

            const demandeData = {
                ...formData,
                type: 'Congé annuel',
                agent_nom: `${agent.objectData?.nom || agent.nom || ''} ${agent.objectData?.prenom || agent.prenom || ''}`,
                agent_direction: agent.objectData?.direction || agent.objectData?.departement || agent.direction || 'Non défini'
            };
            
            // Utiliser le nouveau workflow hiérarchique
            await window.workflowCongesHierarchique.traiterDemandeConge(agentId, demandeData);
            
            onSubmit(demandeData);
            onClose();
        } catch (error) {
            console.error('Erreur soumission demande:', error);
            alert(`Erreur lors de la soumission: ${error.message || 'Erreur inconnue'}`);
        }
    };

    if (!isOpen) return null;

    return React.createElement('div', {
        className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
    },
        React.createElement('div', {
            className: 'bg-white rounded-lg p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto'
        },
            // En-tête
            React.createElement('div', { className: 'mb-6 text-center' },
                React.createElement('h2', {
                    className: 'text-2xl font-bold text-blue-900 mb-2'
                }, '🏖️ Demande de Congé Annuel'),
                React.createElement('p', {
                    className: 'text-gray-600 text-sm'
                }, 'Choisissez librement vos dates de congés annuels')
            ),
            
            // Solde actuel
            React.createElement('div', { className: 'mb-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg' },
                React.createElement('h3', { className: 'font-semibold text-blue-900 mb-3 flex items-center' }, 
                    React.createElement('i', { className: 'fas fa-calendar-check mr-2' }),
                    'Votre Solde Congés Annuels'
                ),
                React.createElement('div', { className: 'grid grid-cols-3 gap-4 text-center' },
                    React.createElement('div', { className: 'p-2 bg-blue-100 rounded' },
                        React.createElement('div', { className: 'font-bold text-blue-800' }, '30'),
                        React.createElement('div', { className: 'text-xs text-blue-600' }, 'Quota annuel')
                    ),
                    React.createElement('div', { className: 'p-2 bg-orange-100 rounded' },
                        React.createElement('div', { className: 'font-bold text-orange-800' }, soldeConges.joursUtilises),
                        React.createElement('div', { className: 'text-xs text-orange-600' }, 'Jours utilisés')
                    ),
                    React.createElement('div', { className: 'p-2 bg-green-100 rounded' },
                        React.createElement('div', { className: 'font-bold text-green-800' }, soldeConges.joursRestants),
                        React.createElement('div', { className: 'text-xs text-green-600' }, 'Jours restants')
                    )
                )
            ),
            
            React.createElement('form', { onSubmit: handleSubmit },
                // Date de début
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 
                        '📅 Date de début *'
                    ),
                    React.createElement('input', {
                        type: 'date',
                        value: formData.dateDebut,
                        onChange: (e) => handleDateDebutChange(e.target.value),
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500',
                        required: true
                    })
                ),
                
                // Date de fin
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 
                        '📅 Date de fin *'
                    ),
                    React.createElement('input', {
                        type: 'date',
                        value: formData.dateFin,
                        onChange: (e) => handleDateFinChange(e.target.value),
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500',
                        required: true
                    })
                ),
                
                // Calcul automatique
                calculEnCours && React.createElement('div', { className: 'mb-4 p-4 border rounded-lg' },
                    React.createElement('h4', { className: 'font-medium text-gray-800 mb-2' }, 
                        '🧮 Calcul Automatique'
                    ),
                    React.createElement('div', { className: 'text-sm text-gray-600 mb-2' },
                        `Nombre de jours demandés: ${formData.nombreJoursPris} jour${formData.nombreJoursPris > 1 ? 's' : ''}`
                    ),
                    messageCalcul && React.createElement('div', { 
                        className: `p-3 rounded ${erreurSolde ? 'bg-red-100 border border-red-300' : 'bg-green-100 border border-green-300'}`
                    },
                        React.createElement('p', { 
                            className: `text-sm font-medium ${erreurSolde ? 'text-red-700' : 'text-green-700'}`
                        }, messageCalcul)
                    )
                ),
                
                // Motif
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 
                        '✍️ Motif (optionnel)'
                    ),
                    React.createElement('textarea', {
                        value: formData.motif,
                        onChange: (e) => setFormData({ ...formData, motif: e.target.value }),
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500',
                        rows: 3,
                        placeholder: 'Vacances en famille, repos, etc.'
                    })
                ),
                
                // Pièce justificative
                React.createElement('div', { className: 'mb-6' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 
                        '📎 Pièce justificative (optionnel)'
                    ),
                    React.createElement('input', {
                        type: 'file',
                        onChange: (e) => setFormData({ ...formData, fichierJoint: e.target.files[0] }),
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2',
                        accept: '.pdf,.jpg,.jpeg,.png,.doc,.docx'
                    }),
                    formData.fichierJoint && React.createElement('p', {
                        className: 'text-sm text-green-600 mt-1'
                    }, `✅ Fichier: ${formData.fichierJoint.name}`)
                ),
                
                // Boutons
                React.createElement('div', { className: 'flex justify-end space-x-4' },
                    React.createElement('button', {
                        type: 'button',
                        onClick: onClose,
                        className: 'px-6 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition-colors'
                    }, 'Annuler'),
                    React.createElement('button', {
                        type: 'submit',
                        disabled: erreurSolde || !calculEnCours,
                        className: `px-6 py-2 text-white rounded-md transition-colors ${
                            erreurSolde || !calculEnCours 
                                ? 'bg-gray-400 cursor-not-allowed' 
                                : 'bg-blue-600 hover:bg-blue-700'
                        }`
                    }, '🚀 Soumettre la demande')
                )
            )
        )
    );
}

window.DemandeCongeAnnuelModal = DemandeCongeAnnuelModal;

const ToastContainer = () => {
    const [toasts, setToasts] = React.useState([]);

    React.useEffect(() => {
        window.toastManager = {
            show: (message, type = 'info', options = {}) => {
                const id = Date.now() + Math.random();
                const toast = {
                    id,
                    message,
                    type,
                    title: options.title,
                    duration: options.duration || 5000,
                    ...options
                };

                setToasts(prev => [...prev, toast]);
                return id;
            },
            
            success: (message, options = {}) => {
                return window.toastManager.show(message, 'success', options);
            },
            
            error: (message, options = {}) => {
                return window.toastManager.show(message, 'error', { duration: 8000, ...options });
            },
            
            warning: (message, options = {}) => {
                return window.toastManager.show(message, 'warning', options);
            },
            
            info: (message, options = {}) => {
                return window.toastManager.show(message, 'info', options);
            },
            
            loading: (message, options = {}) => {
                return window.toastManager.show(message, 'loading', { duration: 0, ...options });
            },
            
            remove: (id) => {
                setToasts(prev => prev.filter(toast => toast.id !== id));
            },
            
            clear: () => {
                setToasts([]);
            },
            
            update: (id, updates) => {
                setToasts(prev => prev.map(toast => 
                    toast.id === id ? { ...toast, ...updates } : toast
                ));
            }
        };

        return () => {
            window.toastManager = null;
        };
    }, []);

    const removeToast = (id) => {
        setToasts(prev => prev.filter(toast => toast.id !== id));
    };

    return React.createElement('div', {
        className: 'fixed top-4 right-4 z-50 space-y-2',
        'data-name': 'toast-container',
        'data-file': 'components/ToastContainer.js'
    }, toasts.map(toast => 
        React.createElement(window.ToastNotification, {
            key: toast.id,
            toast,
            onRemove: removeToast
        })
    ));
};

window.ToastContainer = ToastContainer;
function FTPDebugPanel() {
    try {
        const [apiStatus, setApiStatus] = React.useState(null);
        const [testing, setTesting] = React.useState(false);

        const testAPI = async () => {
            setTesting(true);
            try {
                const response = await fetch('./api/test-access.php');
                const result = await response.json();
                setApiStatus({
                    success: true,
                    data: result,
                    status: response.status
                });
            } catch (error) {
                setApiStatus({
                    success: false,
                    error: error.message,
                    status: 'Erreur réseau'
                });
            }
            setTesting(false);
        };

        React.useEffect(() => {
            testAPI();
        }, []);

        return React.createElement('div', {
            className: 'bg-white rounded-lg shadow p-6',
            'data-name': 'ftp-debug-panel',
            'data-file': 'components/FTPDebugPanel.js'
        }, [
            React.createElement('div', { className: 'flex justify-between items-center mb-4' }, [
                React.createElement('h3', { className: 'text-lg font-medium' }, 
                    'Diagnostic API'),
                React.createElement('button', {
                    onClick: testAPI,
                    disabled: testing,
                    className: 'px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700'
                }, testing ? 'Test...' : 'Retester')
            ]),

            apiStatus && React.createElement('div', {
                className: `p-4 rounded border ${
                    apiStatus.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                }`
            }, [
                React.createElement('div', { className: 'flex items-center mb-2' }, [
                    React.createElement('i', { 
                        className: `fas ${apiStatus.success ? 'fa-check-circle text-green-600' : 'fa-exclamation-triangle text-red-600'} mr-2`
                    }),
                    React.createElement('span', { className: 'font-medium' }, 
                        apiStatus.success ? 'API Accessible' : 'Erreur API')
                ]),

                apiStatus.success && apiStatus.data && React.createElement('div', { 
                    className: 'text-sm space-y-1' 
                }, [
                    React.createElement('p', {}, `PHP: ${apiStatus.data.php_version}`),
                    React.createElement('p', {}, `Upload max: ${apiStatus.data.upload_max_filesize}`),
                    React.createElement('p', {}, `Post max: ${apiStatus.data.post_max_size}`),
                    React.createElement('p', {}, `FTP: ${apiStatus.data.ftp_support}`),
                    React.createElement('p', {}, `Status: ${apiStatus.status}`)
                ]),

                !apiStatus.success && React.createElement('p', { 
                    className: 'text-sm text-red-700' 
                }, `Erreur: ${apiStatus.error}`)
            ])
        ]);

    } catch (error) {
        console.error('Erreur FTPDebugPanel:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.FTPDebugPanel = FTPDebugPanel;
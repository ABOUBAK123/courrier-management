const CalendrierConges = ({ department }) => {
    const [currentDate, setCurrentDate] = React.useState(new Date());
    const [congesData, setCongesData] = React.useState([]);
    const [personnelData, setPersonnelData] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        loadCalendarData();
    }, [currentDate, department]);

    const loadCalendarData = async () => {
        try {
            setLoading(true);
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();
            
            // Load personnel
            const personnelResponse = await trickleListObjects('personnel', 100, true);
            const personnel = personnelResponse.items?.filter(p => 
                !department || p.objectData.direction === department
            ) || [];
            setPersonnelData(personnel);

            // Load congés for current month
            const congesPromises = personnel.map(async (p) => {
                const response = await trickleListObjects(`conge:${p.objectData.matricule}`, 50, true);
                return response.items?.filter(c => {
                    const debut = new Date(c.objectData.dateDebut);
                    const fin = new Date(c.objectData.dateFin);
                    return c.objectData.status === 'approuve' && 
                           ((debut.getFullYear() === year && debut.getMonth() === month) ||
                            (fin.getFullYear() === year && fin.getMonth() === month));
                }) || [];
            });

            const allConges = (await Promise.all(congesPromises)).flat();
            setCongesData(allConges);
        } catch (error) {
            console.error('Erreur chargement calendrier:', error);
        } finally {
            setLoading(false);
        }
    };

    const getDaysInMonth = () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startingDayOfWeek = firstDay.getDay();

        const days = [];
        for (let i = 0; i < startingDayOfWeek; i++) {
            days.push(null);
        }
        for (let day = 1; day <= daysInMonth; day++) {
            days.push(day);
        }
        return days;
    };

    const getCongesForDay = (day) => {
        if (!day) return [];
        const targetDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
        return congesData.filter(conge => {
            const debut = new Date(conge.objectData.dateDebut);
            const fin = new Date(conge.objectData.dateFin);
            return targetDate >= debut && targetDate <= fin;
        });
    };

    const monthNames = [
        'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
        'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];

    if (loading) {
        return React.createElement('div', {
            className: 'flex justify-center items-center h-64'
        }, React.createElement('div', {
            className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600'
        }));
    }

    return React.createElement('div', {
        className: 'bg-white rounded-lg shadow p-6',
        'data-name': 'calendrier-conges',
        'data-file': 'components/CalendrierConges.js'
    }, [
        // Header
        React.createElement('div', {
            key: 'header',
            className: 'flex justify-between items-center mb-6'
        }, [
            React.createElement('button', {
                key: 'prev',
                onClick: () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1)),
                className: 'p-2 hover:bg-gray-100 rounded'
            }, React.createElement('i', { className: 'fas fa-chevron-left' })),
            React.createElement('h2', {
                key: 'title',
                className: 'text-xl font-bold'
            }, `${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}`),
            React.createElement('button', {
                key: 'next',
                onClick: () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1)),
                className: 'p-2 hover:bg-gray-100 rounded'
            }, React.createElement('i', { className: 'fas fa-chevron-right' }))
        ]),

        // Calendar grid
        React.createElement('div', {
            key: 'calendar',
            className: 'grid grid-cols-7 gap-1'
        }, [
            // Day headers
            ...['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'].map(day =>
                React.createElement('div', {
                    key: day,
                    className: 'p-2 text-center font-semibold text-gray-600 bg-gray-50'
                }, day)
            ),
            // Calendar days
            ...getDaysInMonth().map((day, index) => {
                const dayConges = getCongesForDay(day);
                return React.createElement('div', {
                    key: index,
                    className: `min-h-20 p-1 border border-gray-200 ${day ? 'bg-white hover:bg-gray-50' : 'bg-gray-100'}`
                }, [
                    day && React.createElement('div', {
                        key: 'day-number',
                        className: 'text-sm font-medium mb-1'
                    }, day),
                    ...dayConges.map((conge, i) =>
                        React.createElement('div', {
                            key: i,
                            className: 'text-xs bg-blue-100 text-blue-800 p-1 rounded mb-1 truncate',
                            title: `${conge.objectData.nom} ${conge.objectData.prenom} - ${conge.objectData.type}`
                        }, `${conge.objectData.prenom.charAt(0)}. ${conge.objectData.nom}`)
                    )
                ]);
            })
        ])
    ]);
};

window.CalendrierConges = CalendrierConges;
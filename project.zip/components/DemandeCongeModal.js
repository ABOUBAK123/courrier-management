function DemandeCongeModal({ isOpen, onClose, onSubmit, agent }) {
    const [formData, setFormData] = React.useState({
        type: '',
        dateDebut: '',
        dateFin: '',
        nombreJoursPris: '',
        motif: '',
        fichierJoint: null,
        piecesJointes: []
    });
    
    const [typeConges, setTypeConges] = React.useState([]);
    const [selectedTypeData, setSelectedTypeData] = React.useState(null);
    const [soldeConges, setSoldeConges] = React.useState({ joursRestants: 30, joursUtilises: 0 });
    const [messageCalcul, setMessageCalcul] = React.useState('');
    const [erreurSolde, setErreurSolde] = React.useState(false);

    React.useEffect(() => {
        if (isOpen) {
            loadTypeConges();
            loadSoldeConges();
        }
    }, [isOpen]);

    const loadTypeConges = async () => {
        try {
            const result = await trickleListObjects('type_conge', 100, true);
            const typeCongesFromDB = result.items.map(item => ({
                id: item.objectId,
                nom: item.objectData.nom,
                description: item.objectData.description,
                nombre_jours: item.objectData.nombreJours ? parseInt(item.objectData.nombreJours) : null
            }));
            setTypeConges(typeCongesFromDB);
        } catch (error) {
            console.error('Erreur chargement types congés:', error);
            setTypeConges([
                { id: 'default-1', nom: 'Congé annuel', nombre_jours: null },
                { id: 'default-2', nom: 'Congé maladie', nombre_jours: 1 }
            ]);
        }
    };

    const loadSoldeConges = async () => {
        try {
            const anneeActuelle = new Date().getFullYear();
            const agentId = agent?.objectId || agent?.id || agent?.matricule;
            
            // Récupérer toutes les demandes de congés
            const result = await trickleListObjects('demande_conge', 100, true);
            
            let joursUtilises = 0;
            result.items.forEach(demande => {
                // Filtrer pour cet agent et cette année
                if ((demande.objectData.agent_id === agentId || demande.objectData.matricule === agentId) &&
                    demande.objectData.statut === 'approuve') {
                    
                    const dateDebut = new Date(demande.objectData.date_debut || demande.objectData.dateDebut);
                    if (dateDebut.getFullYear() === anneeActuelle && 
                        (demande.objectData.type_conge === 'Congé annuel' || demande.objectData.type === 'Congé annuel')) {
                        joursUtilises += parseInt(demande.objectData.duree_jours || demande.objectData.nombreJours) || 0;
                    }
                }
            });
            
            const quotaAnnuel = agent?.solde_conges || 25;
            const joursRestants = Math.max(0, quotaAnnuel - joursUtilises);
            setSoldeConges({ joursRestants, joursUtilises, quotaAnnuel });
        } catch (error) {
            console.error('Erreur chargement solde congés:', error);
            const quotaAnnuel = agent?.solde_conges || 25;
            setSoldeConges({ joursRestants: quotaAnnuel, joursUtilises: 0, quotaAnnuel });
        }
    };

    const handleTypeChange = (typeNom) => {
        const typeData = typeConges.find(t => t.nom === typeNom);
        setSelectedTypeData(typeData);
        
        // Reset des messages et erreurs
        setMessageCalcul('');
        setErreurSolde(false);
        
        let newFormData = { ...formData, type: typeNom, dateFin: '', nombreJoursPris: '' };
        
        // Exception pour congés annuels : pas de calcul automatique, l'utilisateur choisit librement
        if (typeNom === 'Congé annuel') {
            // Pour congés annuels, on laisse l'utilisateur choisir ses dates
            newFormData.dateFin = '';
            newFormData.nombreJoursPris = '';
        } else if (typeData && typeData.nombre_jours && formData.dateDebut) {
            // Pour les autres types, calcul automatique basé sur le nombre de jours fixe
            const dateDebut = new Date(formData.dateDebut);
            const dateFin = new Date(dateDebut);
            dateFin.setDate(dateFin.getDate() + parseInt(typeData.nombre_jours) - 1);
            
            newFormData.dateFin = dateFin.toISOString().split('T')[0];
            newFormData.nombreJoursPris = typeData.nombre_jours.toString();
        }
        
        setFormData(newFormData);
    };

    const handleDateDebutChange = (value) => {
        let newFormData = { ...formData, dateDebut: value };
        
        if (selectedTypeData) {
            if (selectedTypeData.nom === 'Congé annuel') {
                // Pour congés annuels, recalculer si on a déjà une date de fin
                if (formData.dateFin && value) {
                    calculerJoursCongeAnnuel(value, formData.dateFin, newFormData);
                }
            } else if (selectedTypeData.nombre_jours) {
                // Pour les autres types, calcul automatique
                const dateDebut = new Date(value);
                const dateFin = new Date(dateDebut);
                dateFin.setDate(dateFin.getDate() + parseInt(selectedTypeData.nombre_jours) - 1);
                
                newFormData.dateFin = dateFin.toISOString().split('T')[0];
                newFormData.nombreJoursPris = selectedTypeData.nombre_jours.toString();
            }
        }
        
        setFormData(newFormData);
    };

    const calculerJoursCongeAnnuel = (dateDebut, dateFin, formData) => {
        if (!dateDebut || !dateFin) return;
        
        const debut = new Date(dateDebut);
        const fin = new Date(dateFin);
        
        if (fin >= debut) {
            // Calcul du nombre de jours ouvrables (sans week-ends)
            let jours = 0;
            const current = new Date(debut);
            
            while (current <= fin) {
                const dayOfWeek = current.getDay();
                if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Exclure samedi (6) et dimanche (0)
                    jours++;
                }
                current.setDate(current.getDate() + 1);
            }
            
            formData.nombreJoursPris = jours.toString();
            
            // Vérification du solde disponible
            const soldeDisponible = soldeConges.joursRestants || (agent?.solde_conges || 25);
            if (jours <= soldeDisponible) {
                setErreurSolde(false);
                const nouveauReste = soldeDisponible - jours;
                setMessageCalcul(`Demande de ${jours} jour${jours > 1 ? 's' : ''} ouvrable${jours > 1 ? 's' : ''} → OK. Après validation, il vous restera ${nouveauReste} jour${nouveauReste !== 1 ? 's' : ''} de congés annuels.`);
            } else {
                setErreurSolde(true);
                setMessageCalcul(`ERREUR: Vous demandez ${jours} jour${jours > 1 ? 's' : ''} ouvrable${jours > 1 ? 's' : ''} mais il ne vous reste que ${soldeDisponible} jour${soldeDisponible !== 1 ? 's' : ''} de congés annuels disponibles.`);
            }
        } else {
            setMessageCalcul('');
            setErreurSolde(false);
        }
    };

    const handleDateFinChange = (value) => {
        let newFormData = { ...formData, dateFin: value };
        
        // Exception spéciale pour les congés annuels : calcul automatique
        if (selectedTypeData && selectedTypeData.nom === 'Congé annuel' && formData.dateDebut && value) {
            calculerJoursCongeAnnuel(formData.dateDebut, value, newFormData);
        }
        
        setFormData(newFormData);
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        setFormData({ ...formData, fichierJoint: file });
    };

    const handleMultipleFileChange = (e) => {
        const files = Array.from(e.target.files);
        const validFiles = files.filter(file => {
            if (file.size > 5 * 1024 * 1024) {
                alert(`Le fichier ${file.name} est trop volumineux (max 5MB)`);
                return false;
            }
            return true;
        });
        
        setFormData(prev => ({
            ...prev,
            piecesJointes: [...(prev.piecesJointes || []), ...validFiles]
        }));
    };

    const removeFile = (indexToRemove) => {
        setFormData(prev => ({
            ...prev,
            piecesJointes: prev.piecesJointes.filter((_, index) => index !== indexToRemove)
        }));
    };

    const uploadFiles = async (files) => {
        const uploadedFiles = [];
        for (const file of files) {
            try {
                const base64 = await new Promise((resolve) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.readAsDataURL(file);
                });
                
                uploadedFiles.push({
                    nom: file.name,
                    taille: file.size,
                    type: file.type,
                    contenu: base64,
                    date_upload: new Date().toISOString()
                });
            } catch (error) {
                console.error('Erreur upload fichier:', error);
            }
        }
        return uploadedFiles;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // Validation pour congés annuels
            if (formData.type === 'Congé annuel' && erreurSolde) {
                alert('Impossible de soumettre: Solde de congés insuffisant');
                return;
            }

            // Upload des pièces jointes si présentes
            let piecesJointesUpload = [];
            if (formData.piecesJointes && formData.piecesJointes.length > 0) {
                piecesJointesUpload = await uploadFiles(formData.piecesJointes);
            }

            const demandeData = {
                ...formData,
                agent_nom: `${agent?.prenom || agent?.nom || 'Agent'} ${agent?.nom || ''}`.trim(),
                agent_direction: agent?.direction || agent?.direction_id || 'Non définie',
                pieces_jointes: piecesJointesUpload
            };

            const demandeCompleteData = {
                agent_id: agent?.objectId || agent?.id || agent?.matricule,
                agent_nom: `${agent?.prenom || agent?.nom || 'Agent'} ${agent?.nom || ''}`.trim(),
                agent_direction: agent?.direction || agent?.direction_id || 'Non définie',
                type_conge: formData.type,
                date_debut: formData.dateDebut,
                date_fin: formData.dateFin,
                duree_jours: formData.nombreJoursPris,
                motif: formData.motif,
                pieces_jointes: piecesJointesUpload,
                statut: 'en_cours',
                date_creation: new Date().toISOString(),
                etape_actuelle: 1
            };

            const result = await window.workflowCongesHierarchique.traiterDemandeConge(demandeCompleteData);

            if (result) {
                alert('Demande de congé soumise avec succès! Elle sera traitée selon la hiérarchie.');
                onClose();
                
                // Réinitialiser le formulaire
                setFormData({
                    type: '',
                    dateDebut: '',
                    dateFin: '',
                    nombreJoursPris: '',
                    motif: '',
                    fichierJoint: null,
                    piecesJointes: []
                });
                setSelectedTypeData(null);
            }
        } catch (error) {
            console.error('Erreur soumission demande:', error);
            alert('Erreur lors de la soumission: ' + error.message);
        }
    };

    if (!isOpen) return null;

    const isCongeAnnuel = selectedTypeData && selectedTypeData.nom === 'Congé annuel';
    const isDateFinReadonly = selectedTypeData && selectedTypeData.nombre_jours && !isCongeAnnuel;

    return React.createElement('div', {
        className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
    },
        React.createElement('div', {
            className: 'bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto'
        },
            React.createElement('h2', {
                className: 'text-xl font-bold mb-4'
            }, 'Nouvelle demande de congé'),
            
            React.createElement('form', { onSubmit: handleSubmit },
                // Type de congé
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Type de congé *'),
                    React.createElement('select', {
                        value: formData.type,
                        onChange: (e) => handleTypeChange(e.target.value),
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2',
                        required: true
                    },
                        React.createElement('option', { value: '' }, 'Sélectionner un type'),
                        typeConges.map(type => 
                            React.createElement('option', { 
                                key: type.id, 
                                value: type.nom 
                            }, `${type.nom}${type.nombre_jours ? ` (${type.nombre_jours} jour${type.nombre_jours > 1 ? 's' : ''})` : ' (durée variable)'}`)
                        )
                    )
                ),
                
                // Date de début
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Date de début *'),
                    React.createElement('input', {
                        type: 'date',
                        value: formData.dateDebut,
                        onChange: (e) => handleDateDebutChange(e.target.value),
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2',
                        required: true
                    })
                ),
                
                // Date de fin
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Date de fin *'),
                    React.createElement('input', {
                        type: 'date',
                        value: formData.dateFin,
                        onChange: (e) => handleDateFinChange(e.target.value),
                        className: `w-full border border-gray-300 rounded-md px-3 py-2 ${isDateFinReadonly ? 'bg-gray-100' : ''}`,
                        required: true,
                        readOnly: isDateFinReadonly
                    }),
                    isDateFinReadonly && React.createElement('p', {
                        className: 'text-xs text-gray-500 mt-1'
                    }, 'Date calculée automatiquement'),
                    isCongeAnnuel && React.createElement('p', {
                        className: 'text-xs text-blue-600 mt-1'
                    }, 'Pour les congés annuels, choisissez librement vos dates')
                ),
                
                // Nombre de jours
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Nombre de jours *'),
                    React.createElement('input', {
                        type: 'number',
                        value: formData.nombreJoursPris,
                        onChange: (e) => setFormData({ ...formData, nombreJoursPris: e.target.value }),
                        className: `w-full border border-gray-300 rounded-md px-3 py-2 ${!isCongeAnnuel ? 'bg-gray-100' : ''}`,
                        required: true,
                        readOnly: true,
                        min: 1
                    }),
                    React.createElement('p', {
                        className: 'text-xs text-gray-500 mt-1'
                    }, isCongeAnnuel ? 'Calculé automatiquement selon les dates' : 'Calculé automatiquement selon le type')
                ),

                // Affichage spécial pour congés annuels
                isCongeAnnuel && React.createElement('div', { className: 'mb-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg' },
                    React.createElement('h4', { className: 'font-semibold text-blue-900 mb-3 flex items-center' }, 
                        React.createElement('i', { className: 'fas fa-calendar-alt mr-2' }),
                        'Gestion Congés Annuels'
                    ),
                    React.createElement('div', { className: 'grid grid-cols-2 gap-4 mb-3' },
                        React.createElement('div', { className: 'text-sm' },
                            React.createElement('span', { className: 'font-medium text-gray-700' }, 'Quota annuel: '),
                            React.createElement('span', { className: 'text-blue-800 font-bold' }, `${agent?.solde_conges || 25} jours`)
                        ),
                        React.createElement('div', { className: 'text-sm' },
                            React.createElement('span', { className: 'font-medium text-gray-700' }, 'Jours utilisés: '),
                            React.createElement('span', { className: 'text-orange-600 font-bold' }, `${soldeConges.joursUtilises || 0} jours`)
                        ),
                        React.createElement('div', { className: 'text-sm' },
                            React.createElement('span', { className: 'font-medium text-gray-700' }, 'Jours restants: '),
                            React.createElement('span', { className: 'text-green-600 font-bold' }, `${soldeConges.joursRestants || (agent?.solde_conges || 25)} jours`)
                        )
                    ),
                    messageCalcul && React.createElement('div', { 
                        className: `mt-3 p-2 rounded ${erreurSolde ? 'bg-red-100 border border-red-300' : 'bg-green-100 border border-green-300'}`
                    },
                        React.createElement('p', { 
                            className: `text-sm font-medium ${erreurSolde ? 'text-red-700' : 'text-green-700'}`
                        }, messageCalcul)
                    )
                ),
                
                // Motif
                React.createElement('div', { className: 'mb-4' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 'Motif'),
                    React.createElement('textarea', {
                        value: formData.motif,
                        onChange: (e) => setFormData({ ...formData, motif: e.target.value }),
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2',
                        rows: 3,
                        placeholder: 'Précisez le motif de votre demande...'
                    })
                ),
                
                // Pièces justificatives multiples
                React.createElement('div', { className: 'mb-6' },
                    React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-2' }, 
                        'Pièces justificatives (optionnel)'
                    ),
                    React.createElement('input', {
                        type: 'file',
                        multiple: true,
                        accept: '.pdf,.jpg,.jpeg,.png,.doc,.docx',
                        onChange: handleMultipleFileChange,
                        className: 'w-full border border-gray-300 rounded-md px-3 py-2'
                    }),
                    React.createElement('p', { className: 'text-xs text-gray-500 mt-1' },
                        'Formats acceptés: PDF, JPG, PNG, DOC, DOCX (max 5MB par fichier)'
                    ),
                    formData.piecesJointes && formData.piecesJointes.length > 0 && 
                    React.createElement('div', { className: 'mt-2' },
                        React.createElement('p', { className: 'text-sm font-medium text-gray-600' }, 'Fichiers sélectionnés:'),
                        React.createElement('ul', { className: 'text-sm text-gray-700' },
                            formData.piecesJointes.map((file, index) => 
                                React.createElement('li', { key: index, className: 'flex items-center justify-between py-1' },
                                    React.createElement('span', null, `${file.name} (${(file.size/1024/1024).toFixed(2)} MB)`),
                                    React.createElement('button', {
                                        type: 'button',
                                        onClick: () => removeFile(index),
                                        className: 'text-red-600 hover:text-red-800 ml-2'
                                    }, '✕')
                                )
                            )
                        )
                    )
                ),
                
                // Boutons
                React.createElement('div', { className: 'flex justify-end space-x-4' },
                    React.createElement('button', {
                        type: 'button',
                        onClick: onClose,
                        className: 'px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400'
                    }, 'Annuler'),
                    React.createElement('button', {
                        type: 'submit',
                        disabled: erreurSolde,
                        className: `px-4 py-2 text-white rounded-md flex items-center ${erreurSolde ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'}`
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-paper-plane mr-2'
                        }),
                        'Envoyer au supérieur hiérarchique'
                    ])
                )
            )
        )
    );
}
function ModelParapheur({ user }) {
    try {
        const [models, setModels] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);

        React.useEffect(() => {
            loadModels();
        }, [user]);

        const loadModels = async () => {
            try {
                const response = await trickleListObjects(`model:${user.direction}`, 100, true);
                const modelData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setModels(modelData);
            } catch (error) {
                console.error('Erreur lors du chargement:', error);
            }
        };

        const handleDelete = async (model) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce modèle?')) {
                try {
                    await trickleDeleteObject(`model:${user.direction}`, model.id);
                    alert('Modèle supprimé avec succès');
                    loadModels();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'model-parapheur',
            'data-file': 'components/ModelParapheur.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Modèles de Parapheur'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouveau Modèle')
            ]),
            React.createElement('div', {
                key: 'models-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            }, models.map(model =>
                React.createElement('div', {
                    key: model.id,
                    className: 'bg-white rounded-lg shadow-md p-6 card-hover'
                }, [
                    React.createElement('div', {
                        key: 'model-header',
                        className: 'flex justify-between items-start mb-4'
                    }, [
                        React.createElement('h3', {
                            key: 'model-name',
                            className: 'text-lg font-semibold text-gray-800'
                        }, model.nomModele),
                        React.createElement('button', {
                            key: 'delete-btn',
                            onClick: () => handleDelete(model),
                            className: 'text-red-600 hover:text-red-900'
                        }, [
                            React.createElement('i', {
                                key: 'trash-icon',
                                className: 'fas fa-trash'
                            })
                        ])
                    ]),
                    React.createElement('p', {
                        key: 'model-description',
                        className: 'text-gray-600 mb-4'
                    }, model.description || 'Aucune description'),
                    React.createElement('div', {
                        key: 'model-info',
                        className: 'text-sm text-gray-500'
                    }, [
                        React.createElement('p', {
                            key: 'created-by'
                        }, `Créé par: ${model.createdBy}`),
                        React.createElement('p', {
                            key: 'created-date'
                        }, `Date: ${new Date(model.dateCreation).toLocaleDateString()}`)
                    ])
                ])
            )),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-4xl max-h-screen overflow-y-auto'
                }, [
                    React.createElement('div', {
                        key: 'modal-header',
                        className: 'flex justify-between items-center mb-4'
                    }, [
                        React.createElement('h3', {
                            key: 'modal-title',
                            className: 'text-lg font-semibold'
                        }, 'Nouveau Modèle'),
                        React.createElement('button', {
                            key: 'close-btn',
                            onClick: () => setShowForm(false),
                            className: 'text-gray-500 hover:text-gray-700'
                        }, [
                            React.createElement('i', {
                                key: 'close-icon',
                                className: 'fas fa-times'
                            })
                        ])
                    ]),
                    React.createElement(NouveauModele, {
                        key: 'new-form',
                        user,
                        onClose: () => {
                            setShowForm(false);
                            loadModels();
                        }
                    })
                ])
            ])
        ]);
    } catch (error) {
        console.error('ModelParapheur component error:', error);
        reportError(error);
    }
}

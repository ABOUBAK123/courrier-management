const ReportingRH = () => {
    const [reportData, setReportData] = React.useState({
        byDepartment: [],
        byMonth: [],
        byType: [],
        totalStats: {}
    });
    const [selectedYear, setSelectedYear] = React.useState(new Date().getFullYear());
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        generateReport();
    }, [selectedYear]);

    const generateReport = async () => {
        try {
            setLoading(true);
            
            // Load all personnel and congés
            const personnelResponse = await trickleListObjects('personnel', 500, true);
            const personnel = personnelResponse.items || [];

            const allCongesPromises = personnel.map(async (p) => {
                const response = await trickleListObjects(`conge:${p.objectData.matricule}`, 100, true);
                return response.items?.filter(c => {
                    const year = new Date(c.objectData.dateCreation || c.createdAt).getFullYear();
                    return year === selectedYear && c.objectData.status === 'approuve';
                }).map(c => ({ ...c, personnel: p.objectData })) || [];
            });

            const allConges = (await Promise.all(allCongesPromises)).flat();

            // Generate statistics
            const byDepartment = generateDepartmentStats(allConges);
            const byMonth = generateMonthlyStats(allConges);
            const byType = generateTypeStats(allConges);
            const totalStats = generateTotalStats(allConges, personnel);

            setReportData({ byDepartment, byMonth, byType, totalStats });
        } catch (error) {
            console.error('Erreur génération rapport:', error);
        } finally {
            setLoading(false);
        }
    };

    const generateDepartmentStats = (conges) => {
        const stats = {};
        conges.forEach(conge => {
            const dept = conge.personnel.direction || 'Non défini';
            if (!stats[dept]) {
                stats[dept] = { total: 0, count: 0 };
            }
            stats[dept].total += parseInt(conge.objectData.nombreJoursPris) || 0;
            stats[dept].count += 1;
        });
        return Object.entries(stats).map(([dept, data]) => ({
            department: dept,
            totalJours: data.total,
            nombreDemandes: data.count,
            moyenne: (data.total / data.count).toFixed(1)
        }));
    };

    const generateMonthlyStats = (conges) => {
        const months = Array.from({ length: 12 }, (_, i) => ({
            month: i + 1,
            name: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'][i],
            totalJours: 0,
            count: 0
        }));

        conges.forEach(conge => {
            const month = new Date(conge.objectData.dateDebut).getMonth();
            months[month].totalJours += parseInt(conge.objectData.nombreJoursPris) || 0;
            months[month].count += 1;
        });

        return months;
    };

    const generateTypeStats = (conges) => {
        const stats = {};
        conges.forEach(conge => {
            const type = conge.objectData.type || 'Non défini';
            if (!stats[type]) {
                stats[type] = { total: 0, count: 0 };
            }
            stats[type].total += parseInt(conge.objectData.nombreJoursPris) || 0;
            stats[type].count += 1;
        });
        return Object.entries(stats).map(([type, data]) => ({
            type,
            totalJours: data.total,
            nombreDemandes: data.count
        }));
    };

    const generateTotalStats = (conges, personnel) => {
        const totalJours = conges.reduce((sum, c) => sum + (parseInt(c.objectData.nombreJoursPris) || 0), 0);
        const totalDemandes = conges.length;
        const totalPersonnel = personnel.length;
        const tauxUtilisation = ((totalJours / (totalPersonnel * 30)) * 100).toFixed(1);

        return { totalJours, totalDemandes, totalPersonnel, tauxUtilisation };
    };

    if (loading) {
        return React.createElement('div', {
            className: 'flex justify-center items-center h-64'
        }, React.createElement('div', {
            className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600'
        }));
    }

    return React.createElement('div', {
        className: 'space-y-6',
        'data-name': 'reporting-rh',
        'data-file': 'components/ReportingRH.js'
    }, [
        // Header
        React.createElement('div', {
            key: 'header',
            className: 'flex justify-between items-center'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800'
            }, 'Reporting Congés RH'),
            React.createElement('select', {
                key: 'year-select',
                value: selectedYear,
                onChange: (e) => setSelectedYear(parseInt(e.target.value)),
                className: 'border rounded px-3 py-2'
            }, [
                React.createElement('option', { key: 2024, value: 2024 }, '2024'),
                React.createElement('option', { key: 2023, value: 2023 }, '2023'),
                React.createElement('option', { key: 2022, value: 2022 }, '2022')
            ])
        ]),

        // Global stats
        React.createElement('div', {
            key: 'global-stats',
            className: 'grid grid-cols-1 md:grid-cols-4 gap-4'
        }, [
            React.createElement('div', {
                key: 'total-jours',
                className: 'bg-blue-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', { className: 'font-semibold text-blue-800' }, 'Total Jours'),
                React.createElement('p', { className: 'text-2xl font-bold text-blue-600' }, reportData.totalStats.totalJours)
            ]),
            React.createElement('div', {
                key: 'total-demandes',
                className: 'bg-green-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', { className: 'font-semibold text-green-800' }, 'Total Demandes'),
                React.createElement('p', { className: 'text-2xl font-bold text-green-600' }, reportData.totalStats.totalDemandes)
            ]),
            React.createElement('div', {
                key: 'personnel',
                className: 'bg-yellow-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', { className: 'font-semibold text-yellow-800' }, 'Personnel'),
                React.createElement('p', { className: 'text-2xl font-bold text-yellow-600' }, reportData.totalStats.totalPersonnel)
            ]),
            React.createElement('div', {
                key: 'taux',
                className: 'bg-purple-50 p-4 rounded-lg'
            }, [
                React.createElement('h3', { className: 'font-semibold text-purple-800' }, 'Taux Utilisation'),
                React.createElement('p', { className: 'text-2xl font-bold text-purple-600' }, `${reportData.totalStats.tauxUtilisation}%`)
            ])
        ]),

        // Department stats
        React.createElement('div', {
            key: 'dept-stats',
            className: 'bg-white rounded-lg shadow p-6'
        }, [
            React.createElement('h3', {
                key: 'title',
                className: 'text-lg font-semibold mb-4'
            }, 'Statistiques par Département'),
            React.createElement('div', {
                key: 'table',
                className: 'overflow-x-auto'
            }, React.createElement('table', {
                className: 'min-w-full divide-y divide-gray-200'
            }, [
                React.createElement('thead', {
                    key: 'header',
                    className: 'bg-gray-50'
                }, React.createElement('tr', {}, [
                    React.createElement('th', { className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Département'),
                    React.createElement('th', { className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Total Jours'),
                    React.createElement('th', { className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Nb Demandes'),
                    React.createElement('th', { className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase' }, 'Moyenne')
                ])),
                React.createElement('tbody', {
                    key: 'body',
                    className: 'bg-white divide-y divide-gray-200'
                }, reportData.byDepartment.map((dept, index) =>
                    React.createElement('tr', { key: index }, [
                        React.createElement('td', { className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900' }, dept.department),
                        React.createElement('td', { className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900' }, dept.totalJours),
                        React.createElement('td', { className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900' }, dept.nombreDemandes),
                        React.createElement('td', { className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900' }, dept.moyenne)
                    ])
                ))
            ]))
        ])
    ]);
};

window.ReportingRH = ReportingRH;
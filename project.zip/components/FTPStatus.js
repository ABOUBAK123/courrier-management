function FTPStatus() {
    try {
        const [ftpConfig, setFtpConfig] = React.useState(null);
        const [connectionStatus, setConnectionStatus] = React.useState('unknown');
        const [lastTest, setLastTest] = React.useState(null);

        React.useEffect(() => {
            loadFTPConfig();
        }, []);

        const loadFTPConfig = async () => {
            try {
                const settings = await trickleListObjects('ftp-config', 10, true);
                if (settings.items.length > 0) {
                    setFtpConfig(settings.items[0].objectData);
                }
            } catch (error) {
                console.error('Erreur chargement config FTP:', error);
            }
        };

        const testConnection = async () => {
            if (!ftpConfig) return;
            
            try {
                setConnectionStatus('testing');
                const result = await window.FTPManager.testConnection();
                
                if (result.success) {
                    setConnectionStatus('connected');
                    setLastTest(new Date().toLocaleString());
                    window.toastManager?.success('Connexion FTP active');
                } else {
                    setConnectionStatus('error');
                    window.toastManager?.error(result.message);
                }
            } catch (error) {
                setConnectionStatus('error');
                window.toastManager?.error(`Test échoué: ${error.message}`);
            }
        };

        const getStatusColor = () => {
            switch (connectionStatus) {
                case 'connected': return 'text-green-600';
                case 'error': return 'text-red-600';
                case 'testing': return 'text-yellow-600';
                default: return 'text-gray-600';
            }
        };

        const getStatusIcon = () => {
            switch (connectionStatus) {
                case 'connected': return 'fas fa-check-circle';
                case 'error': return 'fas fa-exclamation-circle';
                case 'testing': return 'fas fa-spinner fa-spin';
                default: return 'fas fa-question-circle';
            }
        };

        if (!ftpConfig) {
            return React.createElement('div', {
                className: 'bg-yellow-50 border border-yellow-200 rounded-lg p-3'
            }, [
                React.createElement('div', { className: 'flex items-center' }, [
                    React.createElement('i', { className: 'fas fa-exclamation-triangle text-yellow-600 mr-2' }),
                    React.createElement('span', { className: 'text-yellow-800' }, 'Configuration FTP non trouvée')
                ])
            ]);
        }

        return React.createElement('div', {
            className: 'bg-gray-50 border border-gray-200 rounded-lg p-3',
            'data-name': 'ftp-status',
            'data-file': 'components/FTPStatus.js'
        }, [
            React.createElement('div', { className: 'flex items-center justify-between mb-2' }, [
                React.createElement('div', { className: 'flex items-center' }, [
                    React.createElement('i', { className: `${getStatusIcon()} ${getStatusColor()} mr-2` }),
                    React.createElement('span', { className: 'font-medium' }, 'Serveur FTP'),
                    React.createElement('span', { className: getStatusColor() }, 
                        connectionStatus === 'connected' ? ' (Connecté)' :
                        connectionStatus === 'error' ? ' (Erreur)' :
                        connectionStatus === 'testing' ? ' (Test...)' : ' (Non testé)'
                    )
                ]),
                React.createElement('button', {
                    onClick: testConnection,
                    disabled: connectionStatus === 'testing',
                    className: 'px-2 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 disabled:opacity-50'
                }, 'Tester')
            ]),
            React.createElement('div', { className: 'text-sm text-gray-600' }, [
                React.createElement('div', {}, `Serveur: ${ftpConfig.server}:${ftpConfig.port}`),
                React.createElement('div', {}, `Utilisateur: ${ftpConfig.username}`),
                ftpConfig.directory && React.createElement('div', {}, `Répertoire: ${ftpConfig.directory}`),
                lastTest && React.createElement('div', {}, `Dernier test: ${lastTest}`)
            ])
        ]);

    } catch (error) {
        console.error('Erreur FTPStatus:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant FTP');
    }
}

window.FTPStatus = FTPStatus;
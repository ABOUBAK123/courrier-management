function StatistiquesConges() {
    const [stats, setStats] = React.useState({});
    const [loading, setLoading] = React.useState(true);
    const [chartInstance, setChartInstance] = React.useState(null);

    React.useEffect(() => {
        loadStatistics();
        return () => {
            if (chartInstance) {
                chartInstance.destroy();
            }
        };
    }, []);

    const loadStatistics = async () => {
        try {
            const congesResult = await trickleListObjects('conge', 500, true);
            const personnelResult = await trickleListObjects('personnel', 500, true);
            
            const statsData = calculateStats(congesResult.items, personnelResult.items);
            setStats(statsData);
            
            setTimeout(() => {
                createChart(statsData);
            }, 100);
        } catch (error) {
            console.error('Erreur chargement stats:', error);
        } finally {
            setLoading(false);
        }
    };

    const calculateStats = (conges, personnel) => {
        const currentYear = new Date().getFullYear();
        const congesAnnee = conges.filter(c => 
            new Date(c.objectData.dateCreation).getFullYear() === currentYear
        );

        const parDepartement = {};
        const parMois = Array(12).fill(0);
        
        congesAnnee.forEach(conge => {
            const dept = conge.objectData.departement || 'Non défini';
            if (!parDepartement[dept]) {
                parDepartement[dept] = { total: 0, approuve: 0, refuse: 0, attente: 0 };
            }
            parDepartement[dept].total++;
            parDepartement[dept][conge.objectData.status]++;
            
            const mois = new Date(conge.objectData.dateCreation).getMonth();
            parMois[mois]++;
        });

        return {
            totalDemandes: congesAnnee.length,
            approuvees: congesAnnee.filter(c => c.objectData.status === 'approuve').length,
            refusees: congesAnnee.filter(c => c.objectData.status === 'refuse').length,
            enAttente: congesAnnee.filter(c => c.objectData.status === 'en_attente').length,
            parDepartement,
            parMois,
            totalEmployes: personnel.length
        };
    };

    const createChart = (statsData) => {
        const ctx = document.getElementById('congesChart');
        if (!ctx || !window.Chart) return;

        if (chartInstance) {
            chartInstance.destroy();
        }

        const chart = new window.Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'],
                datasets: [{
                    label: 'Demandes de congés',
                    data: statsData.parMois,
                    backgroundColor: 'rgba(59, 130, 246, 0.5)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
        setChartInstance(chart);
    };

    if (loading) {
        return React.createElement('div', { className: 'p-4 text-center' }, 'Chargement statistiques...');
    }

    return React.createElement('div', {
        className: 'space-y-6',
        'data-name': 'statistiques-conges',
        'data-file': 'components/StatistiquesConges.js'
    }, [
        React.createElement('h2', {
            key: 'title',
            className: 'text-xl font-bold text-gray-800 mb-6'
        }, '📊 Statistiques Congés'),

        // Cartes de résumé
        React.createElement('div', {
            key: 'cards',
            className: 'grid grid-cols-1 md:grid-cols-4 gap-4 mb-6'
        }, [
            React.createElement('div', {
                key: 'total',
                className: 'bg-blue-100 p-4 rounded-lg text-center'
            }, [
                React.createElement('div', { key: 'number', className: 'text-2xl font-bold text-blue-800' }, stats.totalDemandes),
                React.createElement('div', { key: 'label', className: 'text-blue-600' }, 'Total demandes')
            ]),
            React.createElement('div', {
                key: 'approved',
                className: 'bg-green-100 p-4 rounded-lg text-center'
            }, [
                React.createElement('div', { key: 'number', className: 'text-2xl font-bold text-green-800' }, stats.approuvees),
                React.createElement('div', { key: 'label', className: 'text-green-600' }, 'Approuvées')
            ]),
            React.createElement('div', {
                key: 'pending',
                className: 'bg-yellow-100 p-4 rounded-lg text-center'
            }, [
                React.createElement('div', { key: 'number', className: 'text-2xl font-bold text-yellow-800' }, stats.enAttente),
                React.createElement('div', { key: 'label', className: 'text-yellow-600' }, 'En attente')
            ]),
            React.createElement('div', {
                key: 'rejected',
                className: 'bg-red-100 p-4 rounded-lg text-center'
            }, [
                React.createElement('div', { key: 'number', className: 'text-2xl font-bold text-red-800' }, stats.refusees),
                React.createElement('div', { key: 'label', className: 'text-red-600' }, 'Refusées')
            ])
        ]),

        // Graphique
        React.createElement('div', {
            key: 'chart',
            className: 'bg-white p-6 rounded-lg shadow-md'
        }, [
            React.createElement('h3', {
                key: 'chart-title',
                className: 'text-lg font-semibold mb-4'
            }, 'Évolution mensuelle'),
            React.createElement('canvas', {
                key: 'canvas',
                id: 'congesChart',
                style: { maxHeight: '300px' }
            })
        ])
    ]);
}

window.StatistiquesConges = StatistiquesConges;
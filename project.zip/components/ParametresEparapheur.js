function ParametresEparapheur({ user }) {
    try {
        const [settings, setSettings] = React.useState({
            apiSignature: '',
            emailNotifications: true,
            smsNotifications: false,
            autoArchive: true,
            delaiValidation: 7
        });
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadSettings();
        }, [user]);

        const loadSettings = async () => {
            try {
                const response = await trickleListObjects(`settings:${user.direction}`, 10, true);
                if (response.items.length > 0) {
                    setSettings(response.items[0].objectData);
                }
            } catch (error) {
                console.error('Erreur lors du chargement des paramètres:', error);
            } finally {
                setLoading(false);
            }
        };

        const handleSave = async () => {
            try {
                const response = await trickleListObjects(`settings:${user.direction}`, 10, true);
                
                if (response.items.length > 0) {
                    await trickleUpdateObject(`settings:${user.direction}`, response.items[0].objectId, settings);
                } else {
                    await trickleCreateObject(`settings:${user.direction}`, {
                        ...settings,
                        direction: user.direction,
                        updatedBy: user.name,
                        updatedAt: new Date().toISOString()
                    });
                }
                
                alert('Paramètres sauvegardés avec succès!');
            } catch (error) {
                alert('Erreur lors de la sauvegarde');
            }
        };

        const handleReset = () => {
            setSettings({
                apiSignature: '',
                emailNotifications: true,
                smsNotifications: false,
                autoArchive: true,
                delaiValidation: 7
            });
        };

        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center',
                'data-name': 'loading',
                'data-file': 'components/ParametresEparapheur.js'
            }, 'Chargement des paramètres...');
        }

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'parametres-eparapheur',
            'data-file': 'components/ParametresEparapheur.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Paramètres E-parapheur'),
            React.createElement('div', {
                key: 'settings-form',
                className: 'bg-white rounded-lg shadow-md p-6 space-y-6'
            }, [
                React.createElement('div', {
                    key: 'api-section',
                    className: 'border-b pb-6'
                }, [
                    React.createElement('h3', {
                        key: 'api-title',
                        className: 'text-lg font-semibold text-gray-800 mb-4'
                    }, 'API de Signature'),
                    React.createElement('div', { key: 'api-field' }, [
                        React.createElement('label', {
                            key: 'api-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'URL de l\'API de signature'),
                        React.createElement('input', {
                            key: 'api-input',
                            type: 'url',
                            value: settings.apiSignature,
                            onChange: (e) => setSettings(prev => ({ ...prev, apiSignature: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            placeholder: 'https://api.signature.com/sign'
                        }),
                        React.createElement('p', {
                            key: 'api-help',
                            className: 'text-sm text-gray-500 mt-1'
                        }, 'URL de l\'API qui sera appelée lors de la signature des documents')
                    ])
                ]),
                React.createElement('div', {
                    key: 'notifications-section',
                    className: 'border-b pb-6'
                }, [
                    React.createElement('h3', {
                        key: 'notifications-title',
                        className: 'text-lg font-semibold text-gray-800 mb-4'
                    }, 'Notifications'),
                    React.createElement('div', {
                        key: 'notification-options',
                        className: 'space-y-3'
                    }, [
                        React.createElement('label', {
                            key: 'email-option',
                            className: 'flex items-center'
                        }, [
                            React.createElement('input', {
                                key: 'email-checkbox',
                                type: 'checkbox',
                                checked: settings.emailNotifications,
                                onChange: (e) => setSettings(prev => ({ ...prev, emailNotifications: e.target.checked })),
                                className: 'mr-3'
                            }),
                            React.createElement('span', {
                                key: 'email-label'
                            }, 'Notifications par email')
                        ]),
                        React.createElement('label', {
                            key: 'sms-option',
                            className: 'flex items-center'
                        }, [
                            React.createElement('input', {
                                key: 'sms-checkbox',
                                type: 'checkbox',
                                checked: settings.smsNotifications,
                                onChange: (e) => setSettings(prev => ({ ...prev, smsNotifications: e.target.checked })),
                                className: 'mr-3'
                            }),
                            React.createElement('span', {
                                key: 'sms-label'
                            }, 'Notifications par SMS')
                        ])
                    ])
                ]),
                React.createElement('div', {
                    key: 'archive-section',
                    className: 'border-b pb-6'
                }, [
                    React.createElement('h3', {
                        key: 'archive-title',
                        className: 'text-lg font-semibold text-gray-800 mb-4'
                    }, 'Archivage'),
                    React.createElement('label', {
                        key: 'auto-archive-option',
                        className: 'flex items-center mb-4'
                    }, [
                        React.createElement('input', {
                            key: 'auto-archive-checkbox',
                            type: 'checkbox',
                            checked: settings.autoArchive,
                            onChange: (e) => setSettings(prev => ({ ...prev, autoArchive: e.target.checked })),
                            className: 'mr-3'
                        }),
                        React.createElement('span', {
                            key: 'auto-archive-label'
                        }, 'Archivage automatique des parapheurs terminés')
                    ]),
                    React.createElement('div', { key: 'delai-field' }, [
                        React.createElement('label', {
                            key: 'delai-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Délai de validation (jours)'),
                        React.createElement('input', {
                            key: 'delai-input',
                            type: 'number',
                            min: '1',
                            max: '30',
                            value: settings.delaiValidation,
                            onChange: (e) => setSettings(prev => ({ ...prev, delaiValidation: parseInt(e.target.value) })),
                            className: 'w-32 px-3 py-2 border border-gray-300 rounded-md'
                        })
                    ])
                ])
            ]),
            React.createElement('div', {
                key: 'buttons',
                className: 'flex space-x-4 mt-6'
            }, [
                React.createElement('button', {
                    key: 'save-btn',
                    onClick: handleSave,
                    className: 'btn-primary text-white px-6 py-2 rounded-md'
                }, 'Sauvegarder'),
                React.createElement('button', {
                    key: 'reset-btn',
                    onClick: handleReset,
                    className: 'bg-gray-500 text-white px-6 py-2 rounded-md hover:bg-gray-600'
                }, 'Réinitialiser')
            ])
        ]);
    } catch (error) {
        console.error('ParametresEparapheur component error:', error);
        reportError(error);
    }
}

function SoldeCongesWidget({ userId }) {
    const [soldes, setSoldes] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        if (userId) {
            chargerSoldes();
        }
    }, [userId]);

    const chargerSoldes = async () => {
        try {
            setLoading(true);
            const response = await fetch(`api/conges.php?action=getSoldes&userId=${userId}`);
            if (response.ok) {
                const data = await response.json();
                setSoldes(data);
            }
        } catch (error) {
            console.error('Erreur chargement soldes:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="bg-white rounded-lg shadow p-4">
                <div className="text-center">Chargement des soldes...</div>
            </div>
        );
    }

    return (
        <div className="bg-white rounded-lg shadow p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
                <i className="fas fa-calendar-check mr-2 text-blue-600"></i>
                Mes Soldes de Congés
            </h3>
            
            <div className="space-y-3">
                {soldes.map((solde) => (
                    <div key={solde.typeId} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center">
                            <div 
                                className="w-4 h-4 rounded mr-3" 
                                style={{backgroundColor: solde.couleur}}
                            ></div>
                            <div>
                                <div className="font-medium">{solde.typeNom}</div>
                                <div className="text-sm text-gray-500">
                                    Acquis: {solde.acquis} | Pris: {solde.pris}
                                </div>
                            </div>
                        </div>
                        <div className="text-right">
                            <div className={`text-lg font-bold ${
                                solde.restant > 0 ? 'text-green-600' : 
                                solde.restant < 0 ? 'text-red-600' : 'text-gray-600'
                            }`}>
                                {solde.restant}
                            </div>
                            <div className="text-sm text-gray-500">jours</div>
                        </div>
                    </div>
                ))}
            </div>
            
            {soldes.length === 0 && (
                <div className="text-center text-gray-500 py-4">
                    Aucun solde disponible
                </div>
            )}
        </div>
    );
}

window.SoldeCongesWidget = SoldeCongesWidget;
function ProfilAgentTabs({ agent }) {
    try {
        const [activeTab, setActiveTab] = React.useState('personnel');

        const tabs = [
            { id: 'personnel', label: 'Informations Personnelles', icon: 'fas fa-user' },
            { id: 'professionnel', label: 'Informations Professionnelles', icon: 'fas fa-briefcase' },
            { id: 'fiche', label: 'Fiche de Poste', icon: 'fas fa-clipboard-list' },
            { id: 'cv', label: 'CV', icon: 'fas fa-file-alt' }
        ];

        return React.createElement('div', {
            className: 'bg-white rounded-lg shadow-md',
            'data-name': 'profil-agent-tabs',
            'data-file': 'components/ProfilAgentTabs.js'
        }, [
            // En-tête avec photo et infos de base
            React.createElement('div', {
                key: 'header',
                className: 'bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg p-6'
            }, [
                React.createElement('div', {
                    key: 'header-content',
                    className: 'flex items-center'
                }, [
                    React.createElement('div', {
                        key: 'avatar',
                        className: 'w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-6'
                    }, [
                        React.createElement('i', {
                            key: 'avatar-icon',
                            className: 'fas fa-user text-3xl'
                        })
                    ]),
                    React.createElement('div', {
                        key: 'info'
                    }, [
                        React.createElement('h1', {
                            key: 'name',
                            className: 'text-2xl font-bold'
                        }, `${agent.prenom} ${agent.nom}`),
                        React.createElement('p', {
                            key: 'poste',
                            className: 'text-blue-100 text-lg'
                        }, agent.poste),
                        React.createElement('p', {
                            key: 'email',
                            className: 'text-blue-200 text-sm'
                        }, agent.email)
                    ])
                ])
            ]),

            // Navigation par onglets
            React.createElement('div', {
                key: 'tabs',
                className: 'border-b border-gray-200'
            }, [
                React.createElement('nav', {
                    key: 'nav',
                    className: 'flex space-x-8 px-6'
                }, tabs.map(tab =>
                    React.createElement('button', {
                        key: tab.id,
                        onClick: () => setActiveTab(tab.id),
                        className: `py-4 px-1 border-b-2 font-medium text-sm ${
                            activeTab === tab.id
                                ? 'border-blue-500 text-blue-600'
                                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                        }`
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: `${tab.icon} mr-2`
                        }),
                        tab.label
                    ])
                ))
            ]),

            // Contenu des onglets
            React.createElement('div', {
                key: 'content',
                className: 'p-6'
            }, [
                activeTab === 'personnel' && React.createElement(InfoPersonnelle, {
                    key: 'personnel-tab',
                    agent: agent,
                    readOnly: false
                }),

                activeTab === 'professionnel' && React.createElement(InfoProfessionnelle, {
                    key: 'professionnel-tab',
                    agent: agent,
                    readOnly: true
                }),

                activeTab === 'fiche' && React.createElement(FichePoste, {
                    key: 'fiche-tab',
                    agent: agent
                }),

                activeTab === 'cv' && React.createElement(CVAgent, {
                    key: 'cv-tab',
                    agent: agent
                })
            ])
        ]);

    } catch (error) {
        console.error('ProfilAgentTabs component error:', error);
        return React.createElement('div', {
            className: 'text-red-600 p-4'
        }, 'Erreur lors du chargement du profil');
    }
}

window.ProfilAgentTabs = ProfilAgentTabs;
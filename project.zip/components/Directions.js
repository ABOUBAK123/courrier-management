function Directions({ user }) {
    try {
        const [directions, setDirections] = React.useState([]);
        const [typeDirections, setTypeDirections] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [editMode, setEditMode] = React.useState(false);
        const [editingDirectionId, setEditingDirectionId] = React.useState(null);
        const [formData, setFormData] = React.useState({
            nomDirection: '',
            code: '',
            directionParent: '',
            typeDirection: '',
            nomResponsable: '',
            emailResponsable: ''
        });

        React.useEffect(() => {
            loadDirections();
            loadTypeDirections();
        }, []);

        const loadDirections = async () => {
            try {
                const response = await trickleListObjects('directions', 100, true);
                const directionData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setDirections(directionData);
            } catch (error) {
                console.error('Erreur lors du chargement des directions:', error);
            }
        };

        const loadTypeDirections = async () => {
            try {
                const response = await trickleListObjects('type-directions', 100, true);
                const typeData = response.items.map(item => item.objectData);
                setTypeDirections(typeData);
            } catch (error) {
                console.error('Erreur lors du chargement des types:', error);
            }
        };

        const handleEdit = (direction) => {
            setEditMode(true);
            setEditingDirectionId(direction.id);
            setFormData({
                nomDirection: direction.nomDirection,
                code: direction.code,
                directionParent: direction.directionParent || '',
                typeDirection: direction.typeDirection,
                nomResponsable: direction.nomResponsable,
                emailResponsable: direction.emailResponsable
            });
            setShowForm(true);
        };

        const handleSave = async () => {
            try {
                if (editMode) {
                    await trickleUpdateObject('directions', editingDirectionId, {
                        ...formData,
                        updatedBy: user.name,
                        updatedAt: new Date().toISOString()
                    });
                    alert('Direction modifiée avec succès!');
                } else {
                    await trickleCreateObject('directions', {
                        ...formData,
                        createdBy: user.name,
                        createdAt: new Date().toISOString()
                    });
                    alert('Direction créée avec succès!');
                }
                
                resetForm();
                loadDirections();
            } catch (error) {
                alert('Erreur lors de la sauvegarde');
            }
        };

        const resetForm = () => {
            setFormData({ 
                nomDirection: '', code: '', directionParent: '', 
                typeDirection: '', nomResponsable: '', emailResponsable: '' 
            });
            setShowForm(false);
            setEditMode(false);
            setEditingDirectionId(null);
        };

        const handleDelete = async (directionId) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer cette direction?')) {
                try {
                    await trickleDeleteObject('directions', directionId);
                    alert('Direction supprimée avec succès');
                    loadDirections();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'directions',
            'data-file': 'components/Directions.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Gestion des Directions'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => {
                        resetForm();
                        setShowForm(true);
                    },
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouvelle Direction')
            ]),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Code', 'Nom Direction', 'Type', 'Responsable', 'Email', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, directions.map(direction =>
                        React.createElement('tr', {
                            key: direction.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'code',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, direction.code),
                            React.createElement('td', {
                                key: 'nom',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, direction.nomDirection),
                            React.createElement('td', {
                                key: 'type',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, direction.typeDirection),
                            React.createElement('td', {
                                key: 'responsable',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, direction.nomResponsable),
                            React.createElement('td', {
                                key: 'email',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, direction.emailResponsable),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'edit',
                                    onClick: () => handleEdit(direction),
                                    className: 'text-blue-600 hover:text-blue-900 mr-2'
                                }, React.createElement('i', { className: 'fas fa-edit' })),
                                React.createElement('button', {
                                    key: 'delete',
                                    onClick: () => handleDelete(direction.id),
                                    className: 'text-red-600 hover:text-red-900'
                                }, React.createElement('i', { className: 'fas fa-trash' }))
                            ])
                        ])
                    ))
                ])
            ]),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-lg max-h-screen overflow-y-auto'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, editMode ? 'Modifier la Direction' : 'Nouvelle Direction'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                    }, [
                        React.createElement('input', {
                            key: 'nom-input',
                            type: 'text',
                            placeholder: 'Nom de la direction',
                            value: formData.nomDirection,
                            onChange: (e) => setFormData(prev => ({ ...prev, nomDirection: e.target.value })),
                            className: 'col-span-2 px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('input', {
                            key: 'code-input',
                            type: 'text',
                            placeholder: 'Code (ex: DIR001)',
                            value: formData.code,
                            onChange: (e) => setFormData(prev => ({ ...prev, code: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('select', {
                            key: 'parent-select',
                            value: formData.directionParent,
                            onChange: (e) => setFormData(prev => ({ ...prev, directionParent: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default-parent', value: '' }, 'Direction Parent (optionnel)'),
                            ...directions.map(dir => 
                                React.createElement('option', { key: dir.id, value: dir.code }, `${dir.code} - ${dir.nomDirection}`)
                            )
                        ]),
                        React.createElement('select', {
                            key: 'type-select',
                            value: formData.typeDirection,
                            onChange: (e) => setFormData(prev => ({ ...prev, typeDirection: e.target.value })),
                            className: 'col-span-2 px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default-type', value: '' }, 'Type de Direction'),
                            ...typeDirections.map(type => 
                                React.createElement('option', { key: type.nom, value: type.nom }, type.nom)
                            )
                        ]),
                        React.createElement('input', {
                            key: 'responsable-input',
                            type: 'text',
                            placeholder: 'Nom du Responsable',
                            value: formData.nomResponsable,
                            onChange: (e) => setFormData(prev => ({ ...prev, nomResponsable: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('input', {
                            key: 'email-input',
                            type: 'email',
                            placeholder: 'Email Responsable',
                            value: formData.emailResponsable,
                            onChange: (e) => setFormData(prev => ({ ...prev, emailResponsable: e.target.value })),
                            className: 'px-3 py-2 border border-gray-300 rounded-md'
                        })
                    ]),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save-btn',
                            onClick: handleSave,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, editMode ? 'Modifier' : 'Créer'),
                        React.createElement('button', {
                            key: 'cancel-btn',
                            onClick: resetForm,
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Directions component error:', error);
        reportError(error);
    }
}

window.SuiviDemandeAgent = function SuiviDemandeAgent({ user }) {
    try {
        const [demandes, setDemandes] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [selectedDemande, setSelectedDemande] = React.useState(null);

        React.useEffect(() => {
            loadMesDemandes();
        }, []);

        const loadMesDemandes = async () => {
            try {
                const response = await trickleListObjects('demande_conge', 100, true);
                const mesDemandes = response.items.filter(item => 
                    item.objectData.agent_id === user.id
                );
                setDemandes(mesDemandes);
            } catch (error) {
                console.error('Erreur chargement demandes:', error);
            } finally {
                setLoading(false);
            }
        };

        const getStatutBadge = (statut) => {
            const styles = {
                'soumise': 'bg-blue-100 text-blue-800',
                'en_cours': 'bg-yellow-100 text-yellow-800',
                'approuvee': 'bg-green-100 text-green-800',
                'refusee': 'bg-red-100 text-red-800',
                'en_attente': 'bg-gray-100 text-gray-800'
            };
            return styles[statut] || styles['en_attente'];
        };

        const getEtapeValidation = (demande) => {
            const workflow = demande.objectData.workflow || [];
            const etapeActuelle = workflow.findIndex(etape => !etape.valide);
            return etapeActuelle === -1 ? workflow.length : etapeActuelle + 1;
        };

        if (loading) {
            return (
                <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
            );
        }

        return (
            <div className="p-6" data-name="suivi-demande-agent" data-file="components/SuiviDemandeAgent.js">
                <h1 className="text-2xl font-bold text-gray-900 mb-6">Suivi de mes demandes</h1>

                <div className="grid gap-6">
                    {demandes.length === 0 ? (
                        <div className="text-center py-12">
                            <i className="fas fa-calendar-times text-4xl text-gray-400 mb-4"></i>
                            <p className="text-gray-500">Aucune demande de congé</p>
                        </div>
                    ) : (
                        demandes.map((demande) => (
                            <div key={demande.objectId} className="bg-white shadow-md rounded-lg p-6">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 className="text-lg font-semibold">{demande.objectData.type_conge}</h3>
                                        <p className="text-gray-600">
                                            Du {new Date(demande.objectData.date_debut).toLocaleDateString()} 
                                            au {new Date(demande.objectData.date_fin).toLocaleDateString()}
                                        </p>
                                    </div>
                                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatutBadge(demande.objectData.statut)}`}>
                                        {demande.objectData.statut}
                                    </span>
                                </div>

                                <div className="mb-4">
                                    <div className="flex items-center space-x-2 mb-2">
                                        <span className="text-sm font-medium">Progression:</span>
                                        <span className="text-sm text-gray-600">
                                            Étape {getEtapeValidation(demande)} sur {(demande.objectData.workflow || []).length}
                                        </span>
                                    </div>
                                    
                                    <div className="w-full bg-gray-200 rounded-full h-2">
                                        <div 
                                            className="bg-blue-600 h-2 rounded-full"
                                            style={{
                                                width: `${((getEtapeValidation(demande) - 1) / Math.max((demande.objectData.workflow || []).length, 1)) * 100}%`
                                            }}
                                        ></div>
                                    </div>
                                </div>

                                {demande.objectData.workflow && (
                                    <div className="space-y-2">
                                        <h4 className="font-medium text-gray-900">Historique des validations:</h4>
                                        {demande.objectData.workflow.map((etape, index) => (
                                            <div key={index} className="flex items-center space-x-3 text-sm">
                                                <div className={`w-4 h-4 rounded-full ${etape.valide ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                                                <span className="font-medium">{etape.validateur_nom}</span>
                                                <span className="text-gray-600">{etape.poste}</span>
                                                {etape.valide && (
                                                    <span className="text-green-600">
                                                        ✓ {new Date(etape.date_validation).toLocaleDateString()}
                                                    </span>
                                                )}
                                                {etape.commentaire && (
                                                    <span className="text-gray-500 italic">"{etape.commentaire}"</span>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))
                    )}
                </div>
            </div>
        );
    } catch (error) {
        console.error('SuiviDemandeAgent error:', error);
        return <div className="p-6 text-red-600">Erreur lors du chargement</div>;
    }
};
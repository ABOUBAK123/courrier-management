function FTPUploadTest() {
    try {
        const [selectedFile, setSelectedFile] = React.useState(null);
        const [uploading, setUploading] = React.useState(false);
        const [uploadResult, setUploadResult] = React.useState(null);

        const handleFileSelect = (event) => {
            const file = event.target.files[0];
            setSelectedFile(file);
            setUploadResult(null);
        };

        const handleUpload = async () => {
            if (!selectedFile) return;

            setUploading(true);
            try {
                const result = await window.FTPManager.uploadFile(selectedFile);
                setUploadResult({
                    success: true,
                    data: result
                });
                console.log('Upload réussi:', result);
            } catch (error) {
                setUploadResult({
                    success: false,
                    error: error.message
                });
                console.error('Upload échoué:', error);
            }
            setUploading(false);
        };

        return React.createElement('div', {
            className: 'bg-white rounded-lg shadow p-6',
            'data-name': 'ftp-upload-test',
            'data-file': 'components/FTPUploadTest.js'
        }, [
            React.createElement('h3', { className: 'text-lg font-medium mb-4' }, 
                'Test Upload FTP'),

            React.createElement('div', { className: 'space-y-4' }, [
                React.createElement('div', {}, [
                    React.createElement('label', { className: 'block text-sm font-medium mb-2' }, 
                        'Sélectionner un fichier'),
                    React.createElement('input', {
                        type: 'file',
                        onChange: handleFileSelect,
                        className: 'w-full px-3 py-2 border rounded-md',
                        accept: '.pdf,.doc,.docx,.jpg,.png'
                    })
                ]),

                selectedFile && React.createElement('div', { 
                    className: 'bg-gray-50 p-3 rounded border' 
                }, [
                    React.createElement('p', { className: 'text-sm' }, [
                        React.createElement('strong', {}, 'Fichier: '),
                        selectedFile.name
                    ]),
                    React.createElement('p', { className: 'text-sm text-gray-600' }, [
                        React.createElement('strong', {}, 'Taille: '),
                        Math.round(selectedFile.size / 1024) + ' KB'
                    ])
                ]),

                React.createElement('button', {
                    onClick: handleUpload,
                    disabled: !selectedFile || uploading,
                    className: 'px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50'
                }, uploading ? 'Upload...' : 'Uploader vers FTP'),

                uploadResult && React.createElement('div', {
                    className: `p-3 rounded border ${
                        uploadResult.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                    }`
                }, [
                    uploadResult.success ? [
                        React.createElement('p', { className: 'text-green-800 font-medium' }, '✅ Upload réussi'),
                        React.createElement('p', { className: 'text-sm text-green-700' }, 
                            `Fichier: ${uploadResult.data.fileName}`),
                        React.createElement('p', { className: 'text-sm text-green-700' }, 
                            `Chemin FTP: ${uploadResult.data.ftpPath}`)
                    ] : [
                        React.createElement('p', { className: 'text-red-800 font-medium' }, '❌ Upload échoué'),
                        React.createElement('p', { className: 'text-sm text-red-700' }, uploadResult.error)
                    ]
                ])
            ])
        ]);

    } catch (error) {
        console.error('Erreur FTPUploadTest:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.FTPUploadTest = FTPUploadTest;
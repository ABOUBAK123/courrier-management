const GestionCongeManager = () => {
    const [activeTab, setActiveTab] = React.useState('notifications');
    const [selectedDepartment, setSelectedDepartment] = React.useState('');
    const [departments, setDepartments] = React.useState([]);

    React.useEffect(() => {
        loadDepartments();
    }, []);

    const loadDepartments = async () => {
        try {
            const response = await trickleListObjects('direction', 100, true);
            setDepartments(response.items || []);
        } catch (error) {
            console.error('Erreur chargement départements:', error);
        }
    };

    const tabs = [
        { id: 'notifications', label: 'Congés à valider', icon: 'fas fa-check-circle' },
        { id: 'stats', label: 'Statistiques', icon: 'fas fa-chart-bar' },
        { id: 'planning', label: 'Planification', icon: 'fas fa-calendar' },
        { id: 'remplacements', label: 'Remplacements', icon: 'fas fa-user-friends' }
    ];

    try {
        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'gestion-conge-manager',
            'data-file': 'components/GestionCongeManager.js'
        }, [
            // Header with department filter
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h1', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Gestion des Congés'),
                React.createElement('select', {
                    key: 'dept-filter',
                    value: selectedDepartment,
                    onChange: (e) => setSelectedDepartment(e.target.value),
                    className: 'border rounded px-3 py-2'
                }, [
                    React.createElement('option', { key: 'all', value: '' }, 'Tous les départements'),
                    ...departments.map(dept =>
                        React.createElement('option', {
                            key: dept.objectId,
                            value: dept.objectData.nom
                        }, dept.objectData.nom)
                    )
                ])
            ]),

            // Tab navigation
            React.createElement('div', {
                key: 'tabs',
                className: 'border-b border-gray-200'
            }, React.createElement('nav', {
                className: 'flex space-x-8'
            }, tabs.map(tab =>
                React.createElement('button', {
                    key: tab.id,
                    onClick: () => setActiveTab(tab.id),
                    className: `flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                        activeTab === tab.id
                            ? 'border-blue-500 text-blue-600'
                            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: tab.icon
                    }),
                    React.createElement('span', {
                        key: 'label'
                    }, tab.label)
                ])
            ))),

            // Tab content
            React.createElement('div', {
                key: 'content',
                className: 'mt-6'
            }, [
                activeTab === 'notifications' && React.createElement(window.ValidationHierarchique, {
                    key: 'validation',
                    user: { id: 'current_user_id', nom: 'Supérieur Hiérarchique' }
                }),
                activeTab === 'stats' && React.createElement(window.StatistiquesConges, {
                    key: 'stats'
                }),
                activeTab === 'planning' && React.createElement(window.PlanificationEquipe, {
                    key: 'planning'
                }),
                activeTab === 'remplacements' && React.createElement(window.GestionRemplacements, {
                    key: 'remplacements'
                })
            ])
        ]);

    } catch (error) {
        console.error('GestionCongeManager component error:', error);
        return React.createElement('div', {
            className: 'p-6 text-center text-red-600'
        }, 'Erreur lors du chargement de la gestion des congés');
    }
};

window.GestionCongeManager = GestionCongeManager;
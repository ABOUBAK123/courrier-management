function ValidationModal({ isOpen, onClose, demande, onValidate }) {
    try {
        const [decision, setDecision] = React.useState('');
        const [commentaire, setCommentaire] = React.useState('');

        const handleSubmit = (e) => {
            e.preventDefault();
            if (!decision) {
                window.toastManager?.error('Veuillez sélectionner une décision');
                return;
            }
            onValidate(decision, commentaire);
        };

        if (!isOpen || !demande) return null;

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50',
            'data-name': 'validation-modal',
            'data-file': 'components/ValidationModal.js'
        }, [
            React.createElement('div', {
                key: 'modal-content',
                className: 'bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold mb-6'
                }, 'Validation de Demande de Congé'),

                React.createElement('div', {
                    key: 'demande-details',
                    className: 'bg-gray-50 p-4 rounded-lg mb-6'
                }, [
                    React.createElement('h4', {
                        key: 'details-title',
                        className: 'font-medium mb-3'
                    }, 'Détails de la demande'),
                    React.createElement('div', {
                        key: 'details-grid',
                        className: 'grid grid-cols-2 gap-4'
                    }, [
                        React.createElement('p', { key: 'employe' }, [
                            React.createElement('strong', { key: 'label' }, 'Employé: '),
                            demande.demande.employe
                        ]),
                        React.createElement('p', { key: 'matricule' }, [
                            React.createElement('strong', { key: 'label' }, 'Matricule: '),
                            demande.demande.matricule
                        ]),
                        React.createElement('p', { key: 'type' }, [
                            React.createElement('strong', { key: 'label' }, 'Type: '),
                            demande.demande.typeConge
                        ]),
                        React.createElement('p', { key: 'duree' }, [
                            React.createElement('strong', { key: 'label' }, 'Durée: '),
                            `${window.WorkflowManager.calculateDuration(demande.demande.dateDebut, demande.demande.dateFin)} jours`
                        ]),
                        React.createElement('p', { key: 'debut' }, [
                            React.createElement('strong', { key: 'label' }, 'Date début: '),
                            new Date(demande.demande.dateDebut).toLocaleDateString()
                        ]),
                        React.createElement('p', { key: 'fin' }, [
                            React.createElement('strong', { key: 'label' }, 'Date fin: '),
                            new Date(demande.demande.dateFin).toLocaleDateString()
                        ])
                    ]),
                    demande.demande.motif && React.createElement('div', {
                        key: 'motif',
                        className: 'mt-4'
                    }, [
                        React.createElement('strong', { key: 'label' }, 'Motif: '),
                        React.createElement('p', {
                            key: 'value',
                            className: 'mt-1 text-gray-700'
                        }, demande.demande.motif)
                    ]),
                    demande.demande.pieceJustificative && React.createElement('div', {
                        key: 'piece',
                        className: 'mt-4'
                    }, [
                        React.createElement('strong', { key: 'label' }, 'Pièce justificative: '),
                        React.createElement('a', {
                            key: 'link',
                            href: demande.demande.pieceJustificative.ftpPath,
                            target: '_blank',
                            className: 'text-blue-600 hover:underline ml-2'
                        }, demande.demande.pieceJustificative.originalName)
                    ])
                ]),

                React.createElement('form', {
                    key: 'form',
                    onSubmit: handleSubmit,
                    className: 'space-y-4'
                }, [
                    React.createElement('div', { key: 'decision' }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Décision *'),
                        React.createElement('div', {
                            key: 'options',
                            className: 'space-y-2'
                        }, [
                            React.createElement('label', {
                                key: 'approve',
                                className: 'flex items-center'
                            }, [
                                React.createElement('input', {
                                    key: 'radio',
                                    type: 'radio',
                                    name: 'decision',
                                    value: 'approuve',
                                    checked: decision === 'approuve',
                                    onChange: (e) => setDecision(e.target.value),
                                    className: 'mr-2'
                                }),
                                React.createElement('span', {
                                    key: 'text',
                                    className: 'text-green-700'
                                }, 'Approuver')
                            ]),
                            React.createElement('label', {
                                key: 'reject',
                                className: 'flex items-center'
                            }, [
                                React.createElement('input', {
                                    key: 'radio',
                                    type: 'radio',
                                    name: 'decision',
                                    value: 'rejete',
                                    checked: decision === 'rejete',
                                    onChange: (e) => setDecision(e.target.value),
                                    className: 'mr-2'
                                }),
                                React.createElement('span', {
                                    key: 'text',
                                    className: 'text-red-700'
                                }, 'Rejeter')
                            ])
                        ])
                    ]),

                    React.createElement('div', { key: 'commentaire' }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Commentaire'),
                        React.createElement('textarea', {
                            key: 'textarea',
                            value: commentaire,
                            onChange: (e) => setCommentaire(e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            rows: 3,
                            placeholder: 'Commentaire optionnel...'
                        })
                    ])
                ]),

                React.createElement('div', {
                    key: 'actions',
                    className: 'flex justify-end space-x-4 mt-6'
                }, [
                    React.createElement('button', {
                        key: 'cancel',
                        type: 'button',
                        onClick: onClose,
                        className: 'px-4 py-2 text-gray-600 hover:text-gray-800'
                    }, 'Annuler'),
                    React.createElement('button', {
                        key: 'submit',
                        type: 'submit',
                        onClick: handleSubmit,
                        className: 'bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700'
                    }, 'Valider')
                ])
            ])
        ]);

    } catch (error) {
        console.error('ValidationModal component error:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.ValidationModal = ValidationModal;
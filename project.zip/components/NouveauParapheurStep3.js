function NouveauParapheurStep3({ 
    formData, 
    setFormData, 
    formatFileSize, 
    getFileIcon 
}) {
    try {
        const [showPDFViewer, setShowPDFViewer] = React.useState(false);
        const [selectedDocument, setSelectedDocument] = React.useState(null);

        const handleDocumentUpload = (e) => {
            const files = Array.from(e.target.files);
            const numSigners = formData.signatures?.length || 0;
            
            const newDocuments = files.map(file => ({
                id: Date.now() + Math.random(),
                name: file.name,
                size: file.size,
                type: file.type,
                url: URL.createObjectURL(file),
                uploadedAt: new Date().toISOString(),
                signatureZones: file.type.includes('pdf') && numSigners > 0 ? 
                    createInitialZones(numSigners) : []
            }));
            
            setFormData(prev => ({
                ...prev,
                documents: [...(prev.documents || []), ...newDocuments]
            }));
        };

        const handlePiecesJointesUpload = (e) => {
            const files = Array.from(e.target.files);
            
            const newPiecesJointes = files.map(file => ({
                id: Date.now() + Math.random(),
                name: file.name,
                size: file.size,
                type: file.type,
                url: URL.createObjectURL(file),
                uploadedAt: new Date().toISOString()
            }));
            
            setFormData(prev => ({
                ...prev,
                piecesJointes: [...(prev.piecesJointes || []), ...newPiecesJointes]
            }));
        };

        const createInitialZones = (numSigners) => {
            const zones = [];
            for (let i = 0; i < numSigners; i++) {
                const row = Math.floor(i / 3);
                const col = i % 3;
                
                zones.push({
                    id: i + 1,
                    x: 50 + (col * 250),
                    y: 100 + (row * 120),
                    width: 180,
                    height: 80,
                    label: `SIGNATURE ${i + 1}`,
                    signerIndex: i
                });
            }
            return zones;
        };

        const openDocumentForPositioning = (document) => {
            setSelectedDocument({
                ...document,
                signaturesCount: formData.signatures?.length || 0
            });
            setShowPDFViewer(true);
        };

        const handleSaveSignatureZones = (zones) => {
            if (!selectedDocument) return;
            
            setFormData(prev => ({
                ...prev,
                documents: (prev.documents || []).map(doc => 
                    doc.id === selectedDocument.id 
                        ? { ...doc, signatureZones: zones }
                        : doc
                )
            }));
        };

        const removeDocument = (docId) => {
            setFormData(prev => ({
                ...prev,
                documents: (prev.documents || []).filter(doc => doc.id !== docId)
            }));
        };

        const removePieceJointe = (pieceId) => {
            setFormData(prev => ({
                ...prev,
                piecesJointes: (prev.piecesJointes || []).filter(piece => piece.id !== pieceId)
            }));
        };

        const signaturesCount = formData.signatures?.length || 0;

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'nouveau-parapheur-step3',
            'data-file': 'components/NouveauParapheurStep3.js'
        }, [
            React.createElement('div', {
                key: 'documents-section',
                className: 'border p-4 rounded-lg bg-red-50'
            }, [
                React.createElement('h5', {
                    key: 'documents-title',
                    className: 'font-medium text-red-800 mb-3'
                }, '📄 Documents à signer'),
                React.createElement('input', {
                    key: 'documents-input',
                    type: 'file',
                    multiple: true,
                    accept: '.pdf,.doc,.docx',
                    onChange: handleDocumentUpload,
                    className: 'w-full px-3 py-2 border border-gray-300 rounded-md mb-3'
                }),
                formData.documents?.length > 0 && React.createElement('div', {
                    key: 'documents-list',
                    className: 'space-y-2'
                }, (formData.documents || []).map(doc =>
                    React.createElement('div', {
                        key: doc.id,
                        className: 'flex items-center justify-between bg-white p-3 rounded border'
                    }, [
                        React.createElement('div', {
                            key: 'doc-info',
                            className: 'flex items-center flex-1'
                        }, [
                            React.createElement('i', {
                                key: 'doc-icon',
                                className: `${getFileIcon(doc.type)} mr-3`
                            }),
                            React.createElement('div', {
                                key: 'doc-details'
                            }, [
                                React.createElement('p', {
                                    key: 'doc-name',
                                    className: 'text-sm font-medium'
                                }, doc.name),
                                React.createElement('p', {
                                    key: 'doc-size',
                                    className: 'text-xs text-gray-500'
                                }, `${formatFileSize(doc.size)} ${doc.signatureZones?.length ? `• ${doc.signatureZones.length} zone(s)` : ''}`)
                            ])
                        ]),
                        React.createElement('div', {
                            key: 'doc-actions',
                            className: 'flex space-x-2'
                        }, [
                            doc.type.includes('pdf') && signaturesCount > 0 && React.createElement('button', {
                                key: 'position-zones',
                                onClick: () => openDocumentForPositioning(doc),
                                className: 'bg-purple-600 text-white px-3 py-1 rounded text-xs hover:bg-purple-700'
                            }, 'Positionner'),
                            React.createElement('button', {
                                key: 'remove-doc',
                                onClick: () => removeDocument(doc.id),
                                className: 'text-red-600 hover:text-red-800'
                            }, [
                                React.createElement('i', { className: 'fas fa-trash' })
                            ])
                        ])
                    ])
                ))
            ]),
            React.createElement('div', {
                key: 'pieces-jointes-section',
                className: 'border p-4 rounded-lg bg-gray-50'
            }, [
                React.createElement('h5', {
                    key: 'pieces-title',
                    className: 'font-medium text-gray-800 mb-3'
                }, '📎 Pièces jointes'),
                React.createElement('input', {
                    key: 'pieces-input',
                    type: 'file',
                    multiple: true,
                    accept: '.pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png',
                    onChange: handlePiecesJointesUpload,
                    className: 'w-full px-3 py-2 border border-gray-300 rounded-md mb-3'
                }),
                formData.piecesJointes?.length > 0 && React.createElement('div', {
                    key: 'pieces-list',
                    className: 'space-y-2'
                }, (formData.piecesJointes || []).map(piece =>
                    React.createElement('div', {
                        key: piece.id,
                        className: 'flex items-center justify-between bg-white p-3 rounded border'
                    }, [
                        React.createElement('div', {
                            key: 'piece-info',
                            className: 'flex items-center flex-1'
                        }, [
                            React.createElement('i', {
                                key: 'piece-icon',
                                className: `${getFileIcon(piece.type)} mr-3`
                            }),
                            React.createElement('div', {
                                key: 'piece-details'
                            }, [
                                React.createElement('p', {
                                    key: 'piece-name',
                                    className: 'text-sm font-medium'
                                }, piece.name),
                                React.createElement('p', {
                                    key: 'piece-size',
                                    className: 'text-xs text-gray-500'
                                }, formatFileSize(piece.size))
                            ])
                        ]),
                        React.createElement('button', {
                            key: 'remove-piece',
                            onClick: () => removePieceJointe(piece.id),
                            className: 'text-red-600 hover:text-red-800'
                        }, [
                            React.createElement('i', { className: 'fas fa-trash' })
                        ])
                    ])
                ))
            ]),
            showPDFViewer && selectedDocument && React.createElement(PDFViewer, {
                key: 'pdf-viewer',
                documentUrl: selectedDocument.url,
                onClose: () => setShowPDFViewer(false),
                signaturesCount: selectedDocument.signaturesCount,
                showSignatureZones: true,
                onSaveSignatureZone: handleSaveSignatureZones
            })
        ]);
    } catch (error) {
        console.error('NouveauParapheurStep3 component error:', error);
        reportError(error);
    }
}

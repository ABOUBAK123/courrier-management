window.HistoriqueValidations = function HistoriqueValidations({ user, userRole = 'hierarchique' }) {
    try {
        const [historique, setHistorique] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [filtres, setFiltres] = React.useState({
            statut: 'tous',
            dateDebut: '',
            dateFin: '',
            agent: ''
        });

        React.useEffect(() => {
            loadHistorique();
        }, [user, userRole]);

        const loadHistorique = async () => {
            try {
                setLoading(true);
                const response = await trickleListObjects('demande_conge', 200, true);
                
                const demandesFiltered = response.items.filter(demande => {
                    const data = demande.objectData;
                    
                    // Filtrer selon le rôle
                    if (userRole === 'drh') {
                        // DRH voit toutes les demandes traitées
                        return data.statut === 'approuve' || data.statut === 'refuse';
                    } else {
                        // Supérieur hiérarchique voit ses validations
                        return (data.statut === 'approuve' || data.statut === 'refuse') &&
                               data.workflow && 
                               data.workflow.some(etape => 
                                   etape.validateur_id === user.id && etape.decision
                               );
                    }
                });

                // Trier par date de soumission (plus récent en premier)
                demandesFiltered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
                
                setHistorique(demandesFiltered);
            } catch (error) {
                console.error('Erreur chargement historique:', error);
            } finally {
                setLoading(false);
            }
        };

        const filtrerHistorique = () => {
            return historique.filter(demande => {
                const data = demande.objectData;
                
                // Filtre par statut
                if (filtres.statut !== 'tous' && data.statut !== filtres.statut) {
                    return false;
                }
                
                // Filtre par agent
                if (filtres.agent && !data.agent_nom.toLowerCase().includes(filtres.agent.toLowerCase())) {
                    return false;
                }
                
                // Filtre par date
                if (filtres.dateDebut) {
                    const dateDebut = new Date(filtres.dateDebut);
                    const dateDemande = new Date(data.date_debut);
                    if (dateDemande < dateDebut) return false;
                }
                
                if (filtres.dateFin) {
                    const dateFin = new Date(filtres.dateFin);
                    const dateDemande = new Date(data.date_fin);
                    if (dateDemande > dateFin) return false;
                }
                
                return true;
            });
        };

        const getStatutBadge = (statut) => {
            const badges = {
                'approuve': 'bg-green-100 text-green-800',
                'refuse': 'bg-red-100 text-red-800',
                'en_attente': 'bg-yellow-100 text-yellow-800'
            };
            
            const labels = {
                'approuve': 'Approuvé',
                'refuse': 'Refusé', 
                'en_attente': 'En attente'
            };
            
            return React.createElement('span', {
                className: `px-2 py-1 rounded-full text-sm font-medium ${badges[statut] || 'bg-gray-100 text-gray-800'}`
            }, labels[statut] || statut);
        };

        const getValidationInfo = (demande) => {
            const workflow = demande.objectData.workflow || [];
            const validations = workflow.filter(etape => etape.decision);
            
            if (userRole === 'hierarchique') {
                const maValidation = validations.find(v => v.validateur_id === user.id);
                if (maValidation) {
                    return {
                        date: new Date(maValidation.date_decision).toLocaleDateString(),
                        decision: maValidation.decision,
                        commentaire: maValidation.commentaire || 'Aucun commentaire'
                    };
                }
            }
            
            return validations.length > 0 ? {
                date: new Date(validations[validations.length - 1].date_decision).toLocaleDateString(),
                decision: validations[validations.length - 1].decision,
                commentaire: validations[validations.length - 1].commentaire || 'Aucun commentaire'
            } : null;
        };

        if (loading) {
            return React.createElement('div', { className: 'flex justify-center items-center h-64' },
                React.createElement('div', { className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600' })
            );
        }

        const historiqueFiltre = filtrerHistorique();

        return React.createElement('div', { className: 'p-6', 'data-name': 'historique-validations', 'data-file': 'components/HistoriqueValidations.js' },
            // En-tête
            React.createElement('div', { className: 'mb-6' },
                React.createElement('h2', { className: 'text-2xl font-bold text-gray-900 mb-2' },
                    React.createElement('i', { className: 'fas fa-history mr-3 text-blue-600' }),
                    userRole === 'drh' ? 'Historique des congés' : 'Mes validations de congés'
                ),
                React.createElement('p', { className: 'text-gray-600' },
                    userRole === 'drh' 
                        ? 'Historique complet de toutes les demandes de congés traitées'
                        : 'Historique des demandes que vous avez validées ou refusées'
                )
            ),

            // Filtres
            React.createElement('div', { className: 'bg-white p-4 rounded-lg shadow mb-6' },
                React.createElement('h3', { className: 'text-lg font-medium mb-4' }, 'Filtres'),
                React.createElement('div', { className: 'grid grid-cols-1 md:grid-cols-4 gap-4' },
                    // Filtre statut
                    React.createElement('div', null,
                        React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Statut'),
                        React.createElement('select', {
                            value: filtres.statut,
                            onChange: (e) => setFiltres({...filtres, statut: e.target.value}),
                            className: 'w-full border border-gray-300 rounded-md px-3 py-2'
                        },
                            React.createElement('option', { value: 'tous' }, 'Tous'),
                            React.createElement('option', { value: 'approuve' }, 'Approuvés'),
                            React.createElement('option', { value: 'refuse' }, 'Refusés')
                        )
                    ),
                    
                    // Filtre agent
                    React.createElement('div', null,
                        React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Agent'),
                        React.createElement('input', {
                            type: 'text',
                            value: filtres.agent,
                            onChange: (e) => setFiltres({...filtres, agent: e.target.value}),
                            placeholder: 'Nom de l\'agent...',
                            className: 'w-full border border-gray-300 rounded-md px-3 py-2'
                        })
                    ),
                    
                    // Date début
                    React.createElement('div', null,
                        React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Du'),
                        React.createElement('input', {
                            type: 'date',
                            value: filtres.dateDebut,
                            onChange: (e) => setFiltres({...filtres, dateDebut: e.target.value}),
                            className: 'w-full border border-gray-300 rounded-md px-3 py-2'
                        })
                    ),
                    
                    // Date fin
                    React.createElement('div', null,
                        React.createElement('label', { className: 'block text-sm font-medium text-gray-700 mb-1' }, 'Au'),
                        React.createElement('input', {
                            type: 'date',
                            value: filtres.dateFin,
                            onChange: (e) => setFiltres({...filtres, dateFin: e.target.value}),
                            className: 'w-full border border-gray-300 rounded-md px-3 py-2'
                        })
                    )
                ),
                
                React.createElement('div', { className: 'mt-4 flex justify-between items-center' },
                    React.createElement('button', {
                        onClick: () => setFiltres({ statut: 'tous', dateDebut: '', dateFin: '', agent: '' }),
                        className: 'text-blue-600 hover:text-blue-800'
                    }, 'Réinitialiser les filtres'),
                    React.createElement('span', { className: 'text-sm text-gray-600' },
                        `${historiqueFiltre.length} demande(s) trouvée(s)`
                    )
                )
            ),

            // Liste de l'historique
            historiqueFiltre.length === 0 ? 
                React.createElement('div', { className: 'text-center py-12 bg-white rounded-lg shadow' },
                    React.createElement('i', { className: 'fas fa-inbox text-4xl text-gray-400 mb-4' }),
                    React.createElement('p', { className: 'text-gray-500' }, 'Aucune demande trouvée avec ces critères')
                ) :
                React.createElement('div', { className: 'space-y-4' },
                    historiqueFiltre.map(demande => {
                        const validationInfo = getValidationInfo(demande);
                        return React.createElement('div', { 
                            key: demande.objectId, 
                            className: 'bg-white rounded-lg shadow border border-gray-200 p-6' 
                        },
                            React.createElement('div', { className: 'flex justify-between items-start mb-4' },
                                React.createElement('div', null,
                                    React.createElement('h4', { className: 'text-lg font-semibold text-gray-900' },
                                        demande.objectData.agent_nom
                                    ),
                                    React.createElement('p', { className: 'text-gray-600' },
                                        demande.objectData.agent_direction
                                    )
                                ),
                                React.createElement('div', { className: 'text-right' },
                                    getStatutBadge(demande.objectData.statut),
                                    React.createElement('p', { className: 'text-sm text-gray-500 mt-1' },
                                        `Soumis le ${new Date(demande.createdAt).toLocaleDateString()}`
                                    )
                                )
                            ),
                            
                            React.createElement('div', { className: 'grid grid-cols-1 md:grid-cols-3 gap-4 mb-4' },
                                React.createElement('div', null,
                                    React.createElement('span', { className: 'text-sm font-medium text-gray-700' }, 'Type: '),
                                    React.createElement('span', { className: 'text-sm text-gray-900' }, 
                                        demande.objectData.type_conge
                                    )
                                ),
                                React.createElement('div', null,
                                    React.createElement('span', { className: 'text-sm font-medium text-gray-700' }, 'Période: '),
                                    React.createElement('span', { className: 'text-sm text-gray-900' },
                                        `${new Date(demande.objectData.date_debut).toLocaleDateString()} - ${new Date(demande.objectData.date_fin).toLocaleDateString()}`
                                    )
                                ),
                                React.createElement('div', null,
                                    React.createElement('span', { className: 'text-sm font-medium text-gray-700' }, 'Durée: '),
                                    React.createElement('span', { className: 'text-sm text-gray-900' },
                                        `${demande.objectData.duree_jours} jour(s)`
                                    )
                                )
                            ),
                            
                            demande.objectData.motif && React.createElement('div', { className: 'mb-4' },
                                React.createElement('span', { className: 'text-sm font-medium text-gray-700' }, 'Motif: '),
                                React.createElement('span', { className: 'text-sm text-gray-900' }, demande.objectData.motif)
                            ),
                            
                            validationInfo && React.createElement('div', { className: 'border-t pt-4' },
                                React.createElement('h5', { className: 'text-sm font-medium text-gray-700 mb-2' },
                                    userRole === 'hierarchique' ? 'Ma validation:' : 'Dernière validation:'
                                ),
                                React.createElement('div', { className: 'text-sm text-gray-600' },
                                    React.createElement('p', null,
                                        React.createElement('span', { className: 'font-medium' }, 'Date: '),
                                        validationInfo.date
                                    ),
                                    React.createElement('p', null,
                                        React.createElement('span', { className: 'font-medium' }, 'Décision: '),
                                        React.createElement('span', {
                                            className: validationInfo.decision === 'approuver' ? 'text-green-600' : 'text-red-600'
                                        }, validationInfo.decision === 'approuver' ? 'Approuvé' : 'Refusé')
                                    ),
                                    React.createElement('p', null,
                                        React.createElement('span', { className: 'font-medium' }, 'Commentaire: '),
                                        validationInfo.commentaire
                                    )
                                )
                            )
                        );
                    })
                )
        );
    } catch (error) {
        console.error('HistoriqueValidations error:', error);
        return React.createElement('div', { className: 'p-6 text-red-600' }, 'Erreur lors du chargement');
    }
};
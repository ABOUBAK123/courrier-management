function FTPConfig() {
    try {
        const [config, setConfig] = React.useState(null);
        const [showModal, setShowModal] = React.useState(false);
        const [testing, setTesting] = React.useState(false);
        const [status, setStatus] = React.useState('unknown');

        React.useEffect(() => {
            loadConfig();
        }, []);

        const loadConfig = async () => {
            try {
                const settings = await trickleListObjects('ftp-config', 1, true);
                if (settings.items.length > 0) {
                    setConfig(settings.items[0].objectData);
                    setStatus('configured');
                }
            } catch (error) {
                console.error('Erreur chargement config:', error);
            }
        };

        const testConnection = async () => {
            if (!config) return;
            
            setTesting(true);
            try {
                const response = await fetch('/api/ftp-test.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(config)
                });

                const result = await response.json();
                
                if (result.success) {
                    setStatus('connected');
                    window.toastManager?.success('✓ Connexion FTP réussie');
                } else {
                    setStatus('error');
                    window.toastManager?.error(`✗ ${result.message}`);
                }
            } catch (error) {
                setStatus('error');
                window.toastManager?.error(`Erreur: ${error.message}`);
            }
            setTesting(false);
        };

        const handleSave = async (newConfig) => {
            setConfig(newConfig);
            setStatus('configured');
            setShowModal(false);
            await testConnection();
        };

        return React.createElement('div', {
            className: 'bg-white rounded-lg shadow p-6',
            'data-name': 'ftp-config',
            'data-file': 'components/FTPConfig.js'
        }, [
            React.createElement('div', { className: 'flex justify-between items-center mb-4' }, [
                React.createElement('h3', { className: 'text-lg font-medium' }, 
                    'Configuration Serveur FTP')
            ]),

            config ? React.createElement('div', { className: 'space-y-3' }, [
                React.createElement('div', { className: 'grid grid-cols-2 gap-4 text-sm' }, [
                    React.createElement('div', {}, [
                        React.createElement('span', { className: 'font-medium' }, 'Serveur: '),
                        React.createElement('span', {}, `${config.server}:${config.port}`)
                    ]),
                    React.createElement('div', {}, [
                        React.createElement('span', { className: 'font-medium' }, 'Utilisateur: '),
                        React.createElement('span', {}, config.username)
                    ]),
                    config.directory && React.createElement('div', {}, [
                        React.createElement('span', { className: 'font-medium' }, 'Répertoire: '),
                        React.createElement('span', {}, config.directory)
                    ])
                ]),

                React.createElement('div', { className: 'flex items-center gap-2' }, [
                    React.createElement('span', { 
                        className: `inline-flex items-center px-2 py-1 rounded text-xs ${
                            status === 'connected' ? 'bg-green-100 text-green-800' :
                            status === 'error' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                        }`
                    }, [
                        React.createElement('i', { 
                            className: `fas ${
                                status === 'connected' ? 'fa-check-circle' :
                                status === 'error' ? 'fa-exclamation-circle' :
                                'fa-question-circle'
                            } mr-1`
                        }),
                        status === 'connected' ? 'Connecté' :
                        status === 'error' ? 'Erreur' : 'Non testé'
                    ])
                ])
            ]) : React.createElement('div', { className: 'text-center py-8' }, [
                React.createElement('i', { className: 'fas fa-server text-4xl text-gray-300 mb-4' }),
                React.createElement('p', { className: 'text-gray-500 mb-4' }, 
                    'Aucune configuration FTP trouvée')
            ]),

            React.createElement('div', { className: 'flex gap-2 mt-4' }, [
                React.createElement('button', {
                    onClick: () => setShowModal(true),
                    className: 'px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
                }, config ? 'Modifier' : 'Configurer'),
                
                config && React.createElement('button', {
                    onClick: testConnection,
                    disabled: testing,
                    className: 'px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50'
                }, testing ? 'Test...' : 'Tester')
            ]),

            showModal && React.createElement(ConfigServerModal, {
                type: 'ftp',
                onClose: () => setShowModal(false),
                onSave: handleSave
            })
        ]);

    } catch (error) {
        console.error('Erreur FTPConfig:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.FTPConfig = FTPConfig;
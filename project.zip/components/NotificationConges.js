window.NotificationConges = function NotificationConges() {
    try {
        const [notifications, setNotifications] = React.useState([]);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadNotifications();
            const interval = setInterval(loadNotifications, 30000); // Refresh toutes les 30s
            return () => clearInterval(interval);
        }, []);

        const loadNotifications = async () => {
            try {
                const response = await trickleListObjects('notification_conge', 20, true);
                setNotifications(response.items);
            } catch (error) {
                console.error('Erreur chargement notifications:', error);
            } finally {
                setLoading(false);
            }
        };

        const marquerCommeLue = async (notificationId) => {
            try {
                const notification = notifications.find(n => n.objectId === notificationId);
                if (notification) {
                    await trickleUpdateObject('notification_conge', notificationId, {
                        ...notification.objectData,
                        lue: true,
                        date_lecture: new Date().toISOString()
                    });
                    loadNotifications();
                }
            } catch (error) {
                console.error('Erreur marquage notification:', error);
            }
        };

        const getNotificationIcon = (type) => {
            switch (type) {
                case 'nouvelle_demande': return 'fas fa-plus-circle text-blue-500';
                case 'demande_approuvee': return 'fas fa-check-circle text-green-500';
                case 'demande_refusee': return 'fas fa-times-circle text-red-500';
                case 'rappel_validation': return 'fas fa-bell text-yellow-500';
                default: return 'fas fa-info-circle text-gray-500';
            }
        };

        if (loading) {
            return (
                <div className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </div>
            );
        }

        return (
            <div className="space-y-2" data-name="notification-conges" data-file="components/NotificationConges.js">
                {notifications.length === 0 ? (
                    <p className="text-gray-500 text-sm">Aucune notification</p>
                ) : (
                    notifications.map((notification) => (
                        <div
                            key={notification.objectId}
                            className={`p-3 rounded-md cursor-pointer transition-colors ${
                                notification.objectData.lue 
                                    ? 'bg-gray-50 text-gray-600' 
                                    : 'bg-blue-50 text-blue-900 border border-blue-200'
                            }`}
                            onClick={() => marquerCommeLue(notification.objectId)}
                        >
                            <div className="flex items-start space-x-3">
                                <i className={getNotificationIcon(notification.objectData.type)}></i>
                                <div className="flex-1">
                                    <p className="text-sm font-medium">{notification.objectData.titre}</p>
                                    <p className="text-xs text-gray-500 mt-1">{notification.objectData.message}</p>
                                    <p className="text-xs text-gray-400 mt-1">
                                        {new Date(notification.createdAt).toLocaleString()}
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        );
    } catch (error) {
        console.error('NotificationConges error:', error);
        return <div className="text-red-500 text-sm">Erreur notifications</div>;
    }
};
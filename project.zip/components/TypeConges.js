function TypeConges() {
    const [types, setTypes] = React.useState([]);
    const [showForm, setShowForm] = React.useState(false);
    const [formData, setFormData] = React.useState({
        nom: '', code: '', couleur: '#3b82f6', soldeParAn: 0,
        reportable: false, justificatif: false, description: '',
        validationN1: true, validationN2: false, validationDRH: false, seuilValidationN2: 5
    });

    React.useEffect(() => {
        initialiserTypesDefaut();
    }, []);

    const typesDefaut = [
        { nom: 'Congés payés annuels', code: 'CP', couleur: '#3b82f6', soldeParAn: 25, reportable: true, justificatif: false },
        { nom: 'RTT', code: 'RTT', couleur: '#10b981', soldeParAn: 12, reportable: false, justificatif: false },
        { nom: 'Congés maladie', code: 'CM', couleur: '#ef4444', soldeParAn: 0, reportable: false, justificatif: true },
        { nom: 'Congés sans solde', code: 'CSS', couleur: '#f59e0b', soldeParAn: 0, reportable: false, justificatif: true },
        { nom: 'Congés maternité/paternité', code: 'CMP', couleur: '#ec4899', soldeParAn: 0, reportable: false, justificatif: true },
        { nom: 'Congés exceptionnels', code: 'CE', couleur: '#8b5cf6', soldeParAn: 5, reportable: false, justificatif: true },
        { nom: 'Congés événements familiaux', code: 'CEF', couleur: '#06b6d4', soldeParAn: 3, reportable: false, justificatif: true }
    ];

    const initialiserTypesDefaut = () => {
        setTypes(typesDefaut);
    };

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">Types de Congés</h2>
                <button onClick={() => setShowForm(true)} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    Ajouter un type
                </button>
            </div>

            <div className="grid gap-4">
                {types.map((type, index) => (
                    <div key={index} className="border rounded-lg p-4 flex justify-between items-center">
                        <div className="flex items-center">
                            <div className="w-4 h-4 rounded mr-3" style={{backgroundColor: type.couleur}}></div>
                            <div>
                                <div className="font-medium">{type.nom} ({type.code})</div>
                                <div className="text-sm text-gray-600">{type.soldeParAn} jours/an</div>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button className="text-blue-600 hover:bg-blue-50 p-2 rounded">
                                <i className="fas fa-edit"></i>
                            </button>
                            <button className="text-red-600 hover:bg-red-50 p-2 rounded">
                                <i className="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            {showForm && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg max-w-md w-full mx-4 p-6">
                        <h3 className="text-lg font-bold mb-4">Nouveau Type de Congé</h3>
                        <div className="space-y-4">
                            <input type="text" placeholder="Nom" className="w-full border rounded px-3 py-2" />
                            <input type="text" placeholder="Code" className="w-full border rounded px-3 py-2" />
                            <input type="number" placeholder="Solde par an" className="w-full border rounded px-3 py-2" />
                        </div>
                        <div className="flex gap-2 mt-6">
                            <button onClick={() => setShowForm(false)} className="flex-1 border rounded px-4 py-2">
                                Annuler
                            </button>
                            <button className="flex-1 bg-blue-600 text-white rounded px-4 py-2">
                                Enregistrer
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

window.TypeConges = TypeConges;
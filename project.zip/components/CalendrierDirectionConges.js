function CalendrierDirectionConges({ directionId }) {
    const [conges, setConges] = React.useState([]);
    const [currentMonth, setCurrentMonth] = React.useState(new Date());
    const [loading, setLoading] = React.useState(true);
    const [viewMode, setViewMode] = React.useState('month');

    React.useEffect(() => {
        chargerCongesDirection();
    }, [directionId, currentMonth]);

    const chargerCongesDirection = async () => {
        try {
            setLoading(true);
            
            // Récupérer employés de la direction
            const personnelResult = await trickleListObjects('personnel', 100, true);
            const employes = personnelResult.items.filter(p => 
                p.objectData.direction === directionId
            );

            // Récupérer congés
            const congesResult = await trickleListObjects('demande_conge', 200, true);
            const congesDirection = congesResult.items.filter(c => {
                const employe = employes.find(e => e.objectId === c.objectData.employeId);
                return employe && c.objectData.etat === 'approuve_final';
            });

            // Enrichir avec infos employé
            const congesEnrichis = congesDirection.map(conge => {
                const employe = employes.find(e => e.objectId === conge.objectData.employeId);
                return {
                    ...conge,
                    employeInfo: employe.objectData
                };
            });

            setConges(congesEnrichis);
        } catch (error) {
            console.error('Erreur chargement congés direction:', error);
        } finally {
            setLoading(false);
        }
    };

    const getDaysInMonth = (date) => {
        const year = date.getFullYear();
        const month = date.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const days = [];

        // Jours du mois précédent pour compléter la semaine
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());

        for (let i = 0; i < 42; i++) { // 6 semaines x 7 jours
            const currentDate = new Date(startDate);
            currentDate.setDate(startDate.getDate() + i);
            
            const congesJour = conges.filter(conge => {
                const debut = new Date(conge.objectData.dateDebut);
                const fin = new Date(conge.objectData.dateFin);
                return currentDate >= debut && currentDate <= fin;
            });

            days.push({
                date: currentDate,
                isCurrentMonth: currentDate.getMonth() === month,
                conges: congesJour
            });
        }

        return days;
    };

    const navigateMonth = (direction) => {
        const newDate = new Date(currentMonth);
        newDate.setMonth(newDate.getMonth() + direction);
        setCurrentMonth(newDate);
    };

    const getConflictLevel = (congesJour) => {
        const nombrePersonnes = congesJour.length;
        if (nombrePersonnes >= 4) return 'critique';
        if (nombrePersonnes >= 2) return 'moyen';
        return 'normal';
    };

    if (loading) {
        return React.createElement('div', {
            className: 'flex justify-center items-center h-48'
        }, 'Chargement du calendrier...');
    }

    const days = getDaysInMonth(currentMonth);
    const monthNames = [
        'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
        'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];

    return React.createElement('div', {
        className: 'bg-white rounded-lg shadow-md p-6',
        'data-name': 'calendrier-direction-conges',
        'data-file': 'components/CalendrierDirectionConges.js'
    }, [
        // En-tête du calendrier
        React.createElement('div', {
            key: 'header',
            className: 'flex justify-between items-center mb-6'
        }, [
            React.createElement('h3', {
                key: 'title',
                className: 'text-xl font-bold flex items-center'
            }, [
                React.createElement('i', {
                    key: 'icon',
                    className: 'fas fa-calendar mr-2 text-blue-600'
                }),
                'Calendrier des Congés'
            ]),
            React.createElement('div', {
                key: 'navigation',
                className: 'flex items-center space-x-4'
            }, [
                React.createElement('button', {
                    key: 'prev',
                    onClick: () => navigateMonth(-1),
                    className: 'p-2 hover:bg-gray-100 rounded'
                }, React.createElement('i', { className: 'fas fa-chevron-left' })),
                React.createElement('span', {
                    key: 'current-month',
                    className: 'text-lg font-semibold'
                }, `${monthNames[currentMonth.getMonth()]} ${currentMonth.getFullYear()}`),
                React.createElement('button', {
                    key: 'next',
                    onClick: () => navigateMonth(1),
                    className: 'p-2 hover:bg-gray-100 rounded'
                }, React.createElement('i', { className: 'fas fa-chevron-right' }))
            ])
        ]),

        // Légende
        React.createElement('div', {
            key: 'legend',
            className: 'flex justify-center space-x-6 mb-4 text-sm'
        }, [
            React.createElement('div', {
                key: 'normal',
                className: 'flex items-center'
            }, [
                React.createElement('div', {
                    key: 'color',
                    className: 'w-3 h-3 bg-green-200 rounded mr-2'
                }),
                '1 personne'
            ]),
            React.createElement('div', {
                key: 'medium',
                className: 'flex items-center'
            }, [
                React.createElement('div', {
                    key: 'color',
                    className: 'w-3 h-3 bg-orange-200 rounded mr-2'
                }),
                '2-3 personnes'
            ]),
            React.createElement('div', {
                key: 'critical',
                className: 'flex items-center'
            }, [
                React.createElement('div', {
                    key: 'color',
                    className: 'w-3 h-3 bg-red-200 rounded mr-2'
                }),
                '4+ personnes (Conflit)'
            ])
        ]),

        // Jours de la semaine
        React.createElement('div', {
            key: 'weekdays',
            className: 'grid grid-cols-7 gap-1 mb-2'
        }, ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'].map(day =>
            React.createElement('div', {
                key: day,
                className: 'text-center text-sm font-semibold text-gray-600 p-2'
            }, day)
        )),

        // Grille du calendrier
        React.createElement('div', {
            key: 'calendar-grid',
            className: 'grid grid-cols-7 gap-1'
        }, days.map((day, index) => {
            const conflictLevel = getConflictLevel(day.conges);
            const bgColor = day.conges.length > 0 ? 
                conflictLevel === 'critique' ? 'bg-red-100 border-red-300' :
                conflictLevel === 'moyen' ? 'bg-orange-100 border-orange-300' :
                'bg-green-100 border-green-300' : 'bg-white';

            return React.createElement('div', {
                key: index,
                className: `border p-2 h-20 ${bgColor} ${
                    day.isCurrentMonth ? 'text-gray-900' : 'text-gray-400'
                } hover:bg-gray-50 transition-colors`
            }, [
                React.createElement('div', {
                    key: 'date',
                    className: 'text-sm font-medium'
                }, day.date.getDate()),
                day.conges.length > 0 && React.createElement('div', {
                    key: 'conges-info',
                    className: 'text-xs mt-1'
                }, [
                    React.createElement('div', {
                        key: 'count',
                        className: 'font-semibold'
                    }, `${day.conges.length} congé${day.conges.length > 1 ? 's' : ''}`),
                    day.conges.slice(0, 2).map((conge, i) =>
                        React.createElement('div', {
                            key: i,
                            className: 'truncate'
                        }, `${conge.employeInfo.prenom} ${conge.employeInfo.nom}`)
                    ),
                    day.conges.length > 2 && React.createElement('div', {
                        key: 'more',
                        className: 'text-gray-500'
                    }, `+${day.conges.length - 2} autres`)
                ])
            ]);
        }))
    ]);
}

window.CalendrierDirectionConges = CalendrierDirectionConges;
function EnTraitementModals({ 
    showModal, 
    setShowModal, 
    selectedMail, 
    treatmentData, 
    setTreatmentData, 
    handleTreat 
}) {
    try {
        if (!showModal) return null;

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50',
            'data-name': 'treatment-modal',
            'data-file': 'components/EnTraitementModals.js'
        }, [
            React.createElement('div', {
                key: 'modal-content',
                className: 'bg-white rounded-lg p-6 w-full max-w-md'
            }, [
                React.createElement('h3', {
                    key: 'modal-title',
                    className: 'text-lg font-semibold mb-4'
                }, 'Formulaire de Traitement'),
                React.createElement('div', {
                    key: 'mail-info',
                    className: 'mb-4 p-3 bg-gray-50 rounded'
                }, [
                    React.createElement('p', { key: 'numero' }, `Numéro: ${selectedMail?.numero}`),
                    React.createElement('p', { key: 'objet' }, `Objet: ${selectedMail?.objet}`),
                    React.createElement('p', { key: 'expediteur' }, `Expéditeur: ${selectedMail?.expediteur}`)
                ]),
                React.createElement('div', {
                    key: 'form',
                    className: 'space-y-4'
                }, [
                    React.createElement('input', {
                        key: 'nom-traitement',
                        type: 'text',
                        placeholder: 'Nom du traitement...',
                        value: treatmentData.nomTraitement,
                        onChange: (e) => setTreatmentData(prev => ({ ...prev, nomTraitement: e.target.value })),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                        required: true
                    }),
                    React.createElement('input', {
                        key: 'fichier-reponse',
                        type: 'file',
                        accept: '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png',
                        onChange: (e) => setTreatmentData(prev => ({ ...prev, fichierReponse: e.target.files[0]?.name })),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                    })
                ]),
                React.createElement('div', {
                    key: 'modal-buttons',
                    className: 'flex space-x-2 mt-6'
                }, [
                    React.createElement('button', {
                        key: 'treat-btn',
                        onClick: handleTreat,
                        className: 'flex-1 btn-primary text-white py-2 rounded-md'
                    }, 'Traiter'),
                    React.createElement('button', {
                        key: 'cancel-btn',
                        onClick: () => setShowModal(false),
                        className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                    }, 'Annuler')
                ])
            ])
        ]);
    } catch (error) {
        console.error('EnTraitementModals component error:', error);
        reportError(error);
    }
}

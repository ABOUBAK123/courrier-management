const CongesAgent = ({ agent }) => {
    const [showDemandeModal, setShowDemandeModal] = React.useState(false);
    const [showDemandeAnnuelModal, setShowDemandeAnnuelModal] = React.useState(false);
    const [historiqueDemandes, setHistoriqueDemandes] = React.useState([]);
    const [loadingHistorique, setLoadingHistorique] = React.useState(false);
    const [soldesCalcules, setSoldesCalcules] = React.useState({
        congesAnnuelsRestants: 25,
        joursPrisValides: 0,
        demandesEnAttente: 0,
        totalAcquis: 25
    });

    React.useEffect(() => {
        if (agent?.matricule || agent?.id) {
            chargerHistoriqueDemandes();
        }
    }, [agent]);

    React.useEffect(() => {
        calculerSoldesReels();
    }, [historiqueDemandes]);

    const chargerHistoriqueDemandes = async () => {
        try {
            setLoadingHistorique(true);
            const agentId = agent?.objectId || agent?.id || agent?.matricule;
            if (!agentId) {
                console.warn('Agent ID non trouvé');
                return;
            }

            const response = await trickleListObjects('demande_conge', 50, true);
            
            // Filtrer les demandes pour cet agent
            const demandesAgent = response.items.filter(item => 
                item.objectData.agent_id === agentId || 
                item.objectData.matricule === agentId ||
                item.objectData.agent_id === agent?.matricule
            );
            
            setHistoriqueDemandes(demandesAgent);
        } catch (error) {
            console.error('Erreur chargement historique:', error);
        } finally {
            setLoadingHistorique(false);
        }
    };

    const calculerSoldesReels = () => {
        const anneeActuelle = new Date().getFullYear();
        let joursPrisValides = 0;
        let demandesEnAttente = 0;

        historiqueDemandes.forEach(demande => {
            const dateDebut = new Date(demande.objectData.date_debut || demande.objectData.dateDebut);
            
            // Ne compter que les demandes de l'année en cours
            if (dateDebut.getFullYear() === anneeActuelle) {
                const duree = parseInt(demande.objectData.duree_jours || demande.objectData.nombreJours || 0);
                
                if (demande.objectData.statut === 'approuve' || demande.objectData.statut === 'validee') {
                    // Ne compter que les congés annuels pour le solde
                    if (demande.objectData.type_conge === 'Congé annuel' || 
                        demande.objectData.type === 'Congé annuel' ||
                        demande.objectData.type_conge === 'CP') {
                        joursPrisValides += duree;
                    }
                } else if (demande.objectData.statut === 'en_attente') {
                    demandesEnAttente++;
                }
            }
        });

        const totalAcquis = agent?.solde_conges || 25; // Solde annuel par défaut
        const congesAnnuelsRestants = Math.max(0, totalAcquis - joursPrisValides);

        setSoldesCalcules({
            congesAnnuelsRestants,
            joursPrisValides,
            demandesEnAttente,
            totalAcquis
        });
    };

    const handleDemandeConge = async (demandeData) => {
        try {
            // Fermer les modales
            setShowDemandeModal(false);
            setShowDemandeAnnuelModal(false);
            
            // Recharger l'historique
            await chargerHistoriqueDemandes();
            
            // Afficher un message de succès
            alert('Demande de congé soumise avec succès');
        } catch (error) {
            console.error('Erreur création demande:', error);
            alert('Erreur lors de la création de la demande');
        }
    };

    const getStatutBadge = (statut) => {
        const styles = {
            'en_attente': 'bg-yellow-100 text-yellow-800',
            'approuve': 'bg-green-100 text-green-800',
            'refuse': 'bg-red-100 text-red-800',
            'en_cours': 'bg-blue-100 text-blue-800'
        };
        
        const labels = {
            'en_attente': 'En attente',
            'approuve': 'Approuvé',
            'refuse': 'Refusé',
            'en_cours': 'En cours'
        };
        
        return React.createElement('span', {
            className: `px-2 py-1 rounded-full text-xs font-medium ${styles[statut] || 'bg-gray-100 text-gray-800'}`
        }, labels[statut] || statut);
    };

    try {
        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'conges-agent',
            'data-file': 'components/CongesAgent.js'
        }, [
            // En-tête avec boutons
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-xl font-bold text-gray-800'
                }, 'Mes Congés'),
                React.createElement('div', {
                    key: 'buttons',
                    className: 'flex space-x-3'
                }, [
                    React.createElement('button', {
                        key: 'conge-annuel',
                        onClick: () => setShowDemandeAnnuelModal(true),
                        className: 'bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center'
                    }, [
                        React.createElement('i', { 
                            key: 'icon1',
                            className: 'fas fa-calendar-alt mr-2' 
                        }),
                        'Congé Annuel'
                    ]),
                    React.createElement('button', {
                        key: 'autre-conge',
                        onClick: () => setShowDemandeModal(true),
                        className: 'bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 flex items-center'
                    }, [
                        React.createElement('i', { 
                            key: 'icon2',
                            className: 'fas fa-plus mr-2' 
                        }),
                        'Autre congé'
                    ])
                ])
            ]),

            // Tableau de bord avec soldes calculés
            React.createElement('div', {
                key: 'tableau-bord-soldes',
                className: 'grid grid-cols-1 md:grid-cols-3 gap-4 mb-6'
            }, [
                React.createElement('div', {
                    key: 'conges-restants',
                    className: 'bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-lg shadow'
                }, [
                    React.createElement('div', {
                        key: 'content',
                        className: 'flex items-center justify-between'
                    }, [
                        React.createElement('div', { key: 'info' }, [
                            React.createElement('div', {
                                key: 'number',
                                className: 'text-3xl font-bold'
                            }, soldesCalcules.congesAnnuelsRestants),
                            React.createElement('div', {
                                key: 'label',
                                className: 'text-blue-100'
                            }, 'Jours Restants'),
                            React.createElement('div', {
                                key: 'detail',
                                className: 'text-xs text-blue-200 mt-1'
                            }, `Sur ${soldesCalcules.totalAcquis} jours acquis`)
                        ]),
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-calendar-check text-3xl text-blue-200'
                        })
                    ])
                ]),
                React.createElement('div', {
                    key: 'jours-pris',
                    className: 'bg-gradient-to-r from-green-500 to-green-600 text-white p-6 rounded-lg shadow'
                }, [
                    React.createElement('div', {
                        key: 'content',
                        className: 'flex items-center justify-between'
                    }, [
                        React.createElement('div', { key: 'info' }, [
                            React.createElement('div', {
                                key: 'number',
                                className: 'text-3xl font-bold'
                            }, soldesCalcules.joursPrisValides),
                            React.createElement('div', {
                                key: 'label',
                                className: 'text-green-100'
                            }, 'Jours Pris (Validés)'),
                            React.createElement('div', {
                                key: 'detail',
                                className: 'text-xs text-green-200 mt-1'
                            }, 'Congés annuels confirmés')
                        ]),
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-calendar-minus text-3xl text-green-200'
                        })
                    ])
                ]),
                React.createElement('div', {
                    key: 'en-attente',
                    className: 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-white p-6 rounded-lg shadow'
                }, [
                    React.createElement('div', {
                        key: 'content',
                        className: 'flex items-center justify-between'
                    }, [
                        React.createElement('div', { key: 'info' }, [
                            React.createElement('div', {
                                key: 'number',
                                className: 'text-3xl font-bold'
                            }, soldesCalcules.demandesEnAttente),
                            React.createElement('div', {
                                key: 'label',
                                className: 'text-yellow-100'
                            }, 'En Attente'),
                            React.createElement('div', {
                                key: 'detail',
                                className: 'text-xs text-yellow-200 mt-1'
                            }, 'Demandes à valider')
                        ]),
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-hourglass-half text-3xl text-yellow-200'
                        })
                    ])
                ])
            ]),

            // Section Historique des demandes
            React.createElement('div', {
                key: 'historique',
                className: 'bg-white p-6 rounded-lg shadow'
            }, [
                React.createElement('h3', { 
                    key: 'titre-historique',
                    className: 'text-lg font-semibold text-gray-900 mb-4' 
                }, 'Historique des Demandes'),
                
                loadingHistorique ? 
                    React.createElement('div', { 
                        key: 'loading',
                        className: 'text-center py-4' 
                    },
                        React.createElement('div', { 
                            className: 'animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto' 
                        })
                    ) :
                    
                historiqueDemandes.length === 0 ?
                    React.createElement('p', { 
                        key: 'no-data',
                        className: 'text-gray-500 text-center py-4' 
                    }, 'Aucune demande trouvée') :
                    
                    React.createElement('div', { 
                        key: 'liste-demandes',
                        className: 'space-y-4' 
                    },
                        historiqueDemandes.map(demande => 
                            React.createElement('div', { 
                                key: demande.objectId,
                                className: 'border rounded-lg p-4 hover:bg-gray-50'
                            }, [
                                React.createElement('div', { 
                                    key: 'header',
                                    className: 'flex justify-between items-start mb-2' 
                                }, [
                                    React.createElement('div', { key: 'info' }, [
                                        React.createElement('h4', { 
                                            key: 'type',
                                            className: 'font-medium text-gray-900' 
                                        }, 
                                            demande.objectData.type_conge || demande.objectData.type || 'Congé'
                                        ),
                                        React.createElement('p', { 
                                            key: 'periode',
                                            className: 'text-sm text-gray-600' 
                                        },
                                            `Du ${new Date(demande.objectData.date_debut || demande.objectData.dateDebut).toLocaleDateString('fr-FR')} au ${new Date(demande.objectData.date_fin || demande.objectData.dateFin).toLocaleDateString('fr-FR')}`
                                        )
                                    ]),
                                    getStatutBadge(demande.objectData.statut || demande.objectData.status || 'en_attente')
                                ]),
                                React.createElement('div', { 
                                    key: 'details',
                                    className: 'text-sm text-gray-500' 
                                }, [
                                    React.createElement('p', { key: 'duree' }, 
                                        `Durée: ${demande.objectData.duree_jours || demande.objectData.nombreJours || 'N/A'} jour(s)`
                                    ),
                                    demande.objectData.motif && React.createElement('p', { key: 'motif' }, 
                                        `Motif: ${demande.objectData.motif}`
                                    ),
                                    React.createElement('p', { key: 'date-creation' }, 
                                        `Demandé le: ${new Date(demande.createdAt).toLocaleDateString('fr-FR')}`
                                    )
                                ])
                            ])
                        )
                    )
            ]),

            showDemandeModal && React.createElement(window.DemandeCongeModal, {
                key: 'modal',
                agent: agent,
                isOpen: showDemandeModal,
                onClose: () => setShowDemandeModal(false),
                onSubmit: handleDemandeConge
            }),

            showDemandeAnnuelModal && React.createElement(window.DemandeCongeAnnuelModal, {
                key: 'modal-annuel',
                agent: agent,
                isOpen: showDemandeAnnuelModal,
                onClose: () => setShowDemandeAnnuelModal(false),
                onSubmit: handleDemandeConge
            })
        ]);

    } catch (error) {
        console.error('CongesAgent component error:', error);
        return React.createElement('div', {
            className: 'p-6 text-center text-red-600'
        }, 'Erreur lors du chargement des congés');
    }
};

window.CongesAgent = CongesAgent;
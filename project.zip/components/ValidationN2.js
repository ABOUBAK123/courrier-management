window.ValidationN2 = function({ user, onValidation }) {
    const { useState, useEffect } = React;
    
    const [demandes, setDemandes] = useState([]);
    const [historique, setHistorique] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('en_attente');
    const [processing, setProcessing] = useState(false);

    useEffect(() => {
        loadDemandes();
    }, []);

    const loadDemandes = async () => {
        try {
            const response = await trickleListObjects('demande_conge', 100, true);
            const personnelResponse = await trickleListObjects('personnel', 200, false);
            
            // Demandes en attente N+2 (validées par N+1 de mon périmètre)
            const demandesEnAttente = response.items.filter(demande => {
                const workflow = demande.objectData.workflow || [];
                const etapeActuelle = demande.objectData.etape_actuelle || 1;
                
                // Vérifier que c'est l'étape N+2
                if (workflow.length >= 2 && etapeActuelle === 2) {
                    const etapeN2 = workflow[1];
                    // Vérifier que je suis le validateur N+2 et que N+1 a approuvé
                    return etapeN2 && 
                           etapeN2.validateur_id === user.id &&
                           etapeN2.type === 'validation_n2' &&
                           etapeN2.statut === 'en_attente' &&
                           workflow[0].decision === 'approuver';
                }
                return false;
            });
            
            // Historique N+2
            const historiqueN2 = response.items.filter(demande => {
                const workflow = demande.objectData.workflow || [];
                return workflow.some(etape => 
                    etape.validateur_id === user.id && 
                    etape.type === 'validation_n2' && 
                    etape.decision
                );
            });
            
            setDemandes(demandesEnAttente);
            setHistorique(historiqueN2);
        } catch (error) {
            console.error('Erreur chargement demandes N+2:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleValidation = async (demandeId, decision, commentaire) => {
        setProcessing(true);
        try {
            await window.workflowCongesHierarchique.validerEtape(
                demandeId, user.id, decision, commentaire
            );
            await loadDemandes();
            if (onValidation) onValidation();
        } catch (error) {
            console.error('Erreur validation N+2:', error);
        } finally {
            setProcessing(false);
        }
    };

    if (loading) return React.createElement('div', { 
        className: 'flex justify-center py-12' 
    }, 'Chargement...');

    return React.createElement('div', { className: 'p-6' }, [
        React.createElement('h2', { 
            key: 'title',
            className: 'text-2xl font-bold mb-6 text-gray-800' 
        }, 'Validation N+2'),
        
        React.createElement('div', { key: 'tabs', className: 'border-b mb-6' },
            React.createElement('nav', { className: 'flex space-x-8' }, [
                React.createElement('button', {
                    key: 'tab1',
                    onClick: () => setActiveTab('en_attente'),
                    className: `py-2 px-1 border-b-2 ${activeTab === 'en_attente' ? 
                        'border-blue-500 text-blue-600' : 'border-transparent text-gray-500'}`
                }, `📋 En attente (${demandes.length})`),
                
                React.createElement('button', {
                    key: 'tab2',
                    onClick: () => setActiveTab('historique'),
                    className: `py-2 px-1 border-b-2 ${activeTab === 'historique' ? 
                        'border-blue-500 text-blue-600' : 'border-transparent text-gray-500'}`
                }, `📚 Historique (${historique.length})`)
            ])
        ),

        activeTab === 'en_attente' && React.createElement('div', { key: 'content1' },
            demandes.length === 0 ? 
                React.createElement('div', { 
                    className: 'text-center py-12 text-gray-500' 
                }, 'Aucune demande en attente N+2') :
                React.createElement('div', { className: 'space-y-4' },
                    demandes.map(demande => 
                        React.createElement(window.ValidationCongePanel, {
                            key: demande.objectId,
                            demande: demande,
                            onValidation: handleValidation,
                            currentUser: user,
                            processing: processing,
                            isN2: true
                        })
                    )
                )
        ),

        activeTab === 'historique' && React.createElement('div', { key: 'content2' },
            React.createElement('div', { className: 'space-y-4' },
                historique.map(demande => {
                    const etapeN2 = demande.objectData.workflow?.find(e => 
                        e.validateur_id === user.id && e.type === 'validation_n2'
                    );
                    
                    return React.createElement('div', { 
                        key: demande.objectId,
                        className: 'bg-white border rounded-lg p-4' 
                    }, [
                        React.createElement('div', { 
                            key: 'header',
                            className: 'flex justify-between mb-2' 
                        }, [
                            React.createElement('span', { 
                                key: 'nom',
                                className: 'font-semibold' 
                            }, demande.objectData.agent_nom),
                            React.createElement('span', { 
                                key: 'decision',
                                className: `px-2 py-1 rounded text-xs ${
                                    etapeN2?.decision === 'approuver' ? 
                                    'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                }` 
                            }, etapeN2?.decision === 'approuver' ? '✅ Approuvé N+2' : '❌ Refusé N+2')
                        ]),
                        React.createElement('div', { 
                            key: 'details',
                            className: 'text-sm text-gray-600' 
                        }, `${demande.objectData.type_conge} - ${demande.objectData.duree_jours} jour(s)`)
                    ]);
                })
            )
        )
    ]);
};
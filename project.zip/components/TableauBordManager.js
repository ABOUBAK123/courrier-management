function TableauBordManager({ user }) {
    const [demandesEnAttente, setDemandesEnAttente] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [stats, setStats] = React.useState({});

    React.useEffect(() => {
        loadDemandesEnAttente();
        const interval = setInterval(loadDemandesEnAttente, 30000); // Refresh toutes les 30s
        return () => clearInterval(interval);
    }, [user]);

    const loadDemandesEnAttente = async () => {
        try {
            const result = await trickleListObjects('conge', 100, true);
            const mesValidations = result.items.filter(demande => 
                demande.objectData.superieurId === user.id && 
                demande.objectData.status === 'en_attente'
            );
            
            setDemandesEnAttente(mesValidations);
            setStats({
                total: mesValidations.length,
                urgent: mesValidations.filter(d => isUrgent(d)).length,
                ancienne: mesValidations.filter(d => isAncienne(d)).length
            });
        } catch (error) {
            console.error('Erreur chargement demandes:', error);
        } finally {
            setLoading(false);
        }
    };

    const isUrgent = (demande) => {
        const dateDebut = new Date(demande.objectData.dateDebut);
        const maintenant = new Date();
        const joursAvantDebut = Math.ceil((dateDebut - maintenant) / (1000 * 60 * 60 * 24));
        return joursAvantDebut <= 7;
    };

    const isAncienne = (demande) => {
        const dateCreation = new Date(demande.objectData.dateCreation);
        const maintenant = new Date();
        const joursDepuisCreation = Math.ceil((maintenant - dateCreation) / (1000 * 60 * 60 * 24));
        return joursDepuisCreation > 3;
    };

    const handleValidation = async (demandeId, decision, commentaire) => {
        try {
            await window.WorkflowConges.validerParSuperieur(demandeId, decision, commentaire, user.id);
            await loadDemandesEnAttente();
        } catch (error) {
            console.error('Erreur validation:', error);
            alert('Erreur lors de la validation');
        }
    };

    if (loading) {
        return React.createElement('div', {
            className: 'flex items-center justify-center h-64'
        }, 'Chargement...');
    }

    return React.createElement('div', {
        className: 'space-y-6',
        'data-name': 'tableau-bord-manager',
        'data-file': 'components/TableauBordManager.js'
    }, [
        // Stats cards
        React.createElement('div', {
            key: 'stats',
            className: 'grid grid-cols-1 md:grid-cols-3 gap-4'
        }, [
            React.createElement('div', {
                key: 'total',
                className: 'bg-blue-50 p-4 rounded-lg border'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-sm font-medium text-blue-600'
                }, 'Demandes en attente'),
                React.createElement('p', {
                    key: 'value',
                    className: 'text-2xl font-bold text-blue-900'
                }, stats.total || 0)
            ]),
            React.createElement('div', {
                key: 'urgent',
                className: 'bg-red-50 p-4 rounded-lg border'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-sm font-medium text-red-600'
                }, 'Demandes urgentes'),
                React.createElement('p', {
                    key: 'value',
                    className: 'text-2xl font-bold text-red-900'
                }, stats.urgent || 0)
            ]),
            React.createElement('div', {
                key: 'ancien',
                className: 'bg-yellow-50 p-4 rounded-lg border'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-sm font-medium text-yellow-600'
                }, 'Demandes anciennes'),
                React.createElement('p', {
                    key: 'value',
                    className: 'text-2xl font-bold text-yellow-900'
                }, stats.ancienne || 0)
            ])
        ]),

        // Liste des demandes
        React.createElement('div', {
            key: 'demandes',
            className: 'bg-white rounded-lg shadow'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'px-6 py-4 border-b'
            }, React.createElement('h2', {
                className: 'text-lg font-semibold'
            }, 'Demandes en attente de validation')),

            demandesEnAttente.length === 0 ? 
                React.createElement('div', {
                    key: 'empty',
                    className: 'p-8 text-center text-gray-500'
                }, 'Aucune demande en attente') :
                React.createElement('div', {
                    key: 'list',
                    className: 'divide-y'
                }, demandesEnAttente.map(demande =>
                    React.createElement(window.ValidationPanel, {
                        key: demande.objectId,
                        demande,
                        onValidate: handleValidation,
                        onReject: handleValidation
                    })
                ))
        ])
    ]);
}

window.TableauBordManager = TableauBordManager;
function Dashboard({ user, setCurrentPage }) {
    try {
        const [stats, setStats] = React.useState({
            total: 0,
            arrives: 0,
            departs: 0,
            attente: 0,
            traites: 0
        });
        const [pendingValidations, setPendingValidations] = React.useState(0);
        const [showStatistiques, setShowStatistiques] = React.useState(false);
        const [showRappels, setShowRappels] = React.useState(false);

        React.useEffect(() => {
            loadStats();
            loadPendingValidations();
        }, [user]);

        const loadStats = async () => {
            try {
                const mails = await trickleListObjects('mail', 100, true);
                const courriers = mails.items || [];
                
                setStats({
                    total: courriers.length,
                    arrives: courriers.filter(m => m.objectData.type === 'arrive').length,
                    departs: courriers.filter(m => m.objectData.type === 'depart').length,
                    attente: courriers.filter(m => m.objectData.status === 'attente').length,
                    traites: courriers.filter(m => m.objectData.status === 'traite').length
                });
            } catch (error) {
                console.error('Erreur chargement stats:', error);
            }
        };

        const loadPendingValidations = async () => {
            try {
                if (!['CHEF_SERVICE', 'DIRECTEUR', 'RH'].includes(user?.role)) return;
                
                const workflows = await trickleListObjects('workflow-validation', 100, true);
                let count = 0;
                
                for (const workflow of workflows.items) {
                    if (workflow.objectData.status === 'en_validation') {
                        const currentLevel = workflow.objectData.levels[workflow.objectData.currentLevel];
                        const validators = await window.WorkflowManager.getValidators(currentLevel, user.direction);
                        
                        if (validators.some(v => v.id === user.id)) {
                            count++;
                        }
                    }
                }
                
                setPendingValidations(count);
            } catch (error) {
                console.error('Erreur chargement validations:', error);
            }
        };

        const statCards = [
            { title: 'Total Courriers', value: stats.total, icon: 'fas fa-envelope', color: 'bg-blue-600' },
            { title: 'Courriers Arrivés', value: stats.arrives, icon: 'fas fa-inbox', color: 'bg-green-600' },
            { title: 'Courriers Départs', value: stats.departs, icon: 'fas fa-paper-plane', color: 'bg-purple-600' },
            { title: 'En Attente', value: stats.attente, icon: 'fas fa-clock', color: 'bg-yellow-600' },
            { title: 'Traités', value: stats.traites, icon: 'fas fa-check', color: 'bg-emerald-600' }
        ];

        return React.createElement('div', {
            className: 'p-6 space-y-6',
            'data-name': 'dashboard',
            'data-file': 'components/Dashboard.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, `Tableau de Bord - ${user?.name || 'Utilisateur'}`),
                React.createElement('div', {
                    key: 'actions',
                    className: 'flex space-x-4'
                }, [
                    React.createElement('button', {
                        key: 'new-mail',
                        onClick: () => setCurrentPage('nouveau-courrier'),
                        className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center'
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-plus mr-2'
                        }),
                        'Nouveau Courrier'
                    ]),
                    (user.role === 'CHEF_SERVICE' || user.role === 'DIRECTEUR' || user.role === 'RH') && React.createElement('button', {
                        key: 'validations',
                        onClick: () => setCurrentPage('validations'),
                        className: `relative bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 flex items-center ${pendingValidations > 0 ? 'animate-pulse' : ''}`
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-check-circle mr-2'
                        }),
                        'Validations Congés',
                        pendingValidations > 0 && React.createElement('span', {
                            key: 'badge',
                            className: 'absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center'
                        }, pendingValidations)
                    ]),
                    React.createElement('button', {
                        key: 'statistiques',
                        onClick: () => setShowStatistiques(true),
                        className: 'bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 flex items-center'
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-chart-bar mr-2'
                        }),
                        'Statistiques'
                    ]),
                    React.createElement('button', {
                        key: 'rappels',
                        onClick: () => setShowRappels(true),
                        className: 'bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700 flex items-center'
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: 'fas fa-bell mr-2'
                        }),
                        'Rappels'
                    ])
                ])
            ]),

            React.createElement('div', {
                key: 'stats',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6'
            }, statCards.map((card, index) =>
                React.createElement('div', {
                    key: index,
                    className: 'bg-white p-6 rounded-lg shadow-md border'
                }, [
                    React.createElement('div', {
                        key: 'icon-container',
                        className: `w-12 h-12 ${card.color} rounded-lg flex items-center justify-center mb-4`
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: `${card.icon} text-white text-xl`
                        })
                    ]),
                    React.createElement('div', { key: 'content' }, [
                        React.createElement('p', {
                            key: 'title',
                            className: 'text-gray-600 text-sm mb-1'
                        }, card.title),
                        React.createElement('p', {
                            key: 'value',
                            className: 'text-2xl font-bold text-gray-800'
                        }, card.value)
                    ])
                ])
            )),

            // Modales
            showStatistiques && React.createElement(window.TableauBordStatistiques, {
                key: 'modal-stats',
                onClose: () => setShowStatistiques(false)
            }),

            showRappels && React.createElement(window.SystemeRappels, {
                key: 'modal-rappels', 
                onClose: () => setShowRappels(false)
            })
        ]);

    } catch (error) {
        console.error('Dashboard component error:', error);
        return React.createElement('div', { className: 'text-red-600' }, 'Erreur composant');
    }
}

window.Dashboard = Dashboard;
function Notifications({ user }) {
    try {
        const [notifications, setNotifications] = React.useState([]);
        const [showDropdown, setShowDropdown] = React.useState(false);
        const [unreadCount, setUnreadCount] = React.useState(0);

        React.useEffect(() => {
            loadNotifications();
            const interval = setInterval(loadNotifications, 30000); // Refresh every 30s
            return () => clearInterval(interval);
        }, [user]);

        const loadNotifications = async () => {
            try {
                if (!user?.email) {
                    console.warn('Utilisateur ou email non défini, notifications désactivées');
                    setNotifications([]);
                    setUnreadCount(0);
                    return;
                }

                if (user.isOfflineMode || typeof trickleListObjects !== 'function') {
                    // Mode hors ligne - notifications factices
                    const demoNotifications = [
                        {
                            id: 'demo1',
                            message: 'Nouveau courrier reçu (Mode démo)',
                            createdAt: new Date().toISOString(),
                            read: false
                        },
                        {
                            id: 'demo2',
                            message: 'Document signé (Mode démo)',
                            createdAt: new Date(Date.now() - 3600000).toISOString(),
                            read: true
                        }
                    ];
                    setNotifications(demoNotifications);
                    setUnreadCount(demoNotifications.filter(n => !n.read).length);
                    return;
                }

                const response = await trickleListObjects(`notification:${user.email}`, 20, true);
                const notifData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setNotifications(notifData);
                setUnreadCount(notifData.filter(n => !n.read).length);
            } catch (error) {
                console.error('Erreur notifications:', error);
                // Fallback en cas d'erreur
                setNotifications([]);
                setUnreadCount(0);
            }
        };

        const markAsRead = async (notificationId) => {
            try {
                if (!user?.email || user.isOfflineMode) {
                    // Mode hors ligne - mise à jour locale uniquement
                    setNotifications(prev => prev.map(n => 
                        n.id === notificationId ? { ...n, read: true } : n
                    ));
                    setUnreadCount(prev => Math.max(0, prev - 1));
                    return;
                }

                const notification = notifications.find(n => n.id === notificationId);
                if (notification && typeof trickleUpdateObject === 'function') {
                    await trickleUpdateObject(`notification:${user.email}`, notificationId, {
                        ...notification,
                        read: true
                    });
                    loadNotifications();
                }
            } catch (error) {
                console.error('Erreur marquage lu:', error);
            }
        };

        const markAllAsRead = async () => {
            try {
                if (!user?.email || user.isOfflineMode) {
                    // Mode hors ligne - mise à jour locale uniquement
                    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
                    setUnreadCount(0);
                    return;
                }

                const unreadNotifs = notifications.filter(n => !n.read);
                if (typeof trickleUpdateObject === 'function') {
                    for (const notif of unreadNotifs) {
                        await trickleUpdateObject(`notification:${user.email}`, notif.id, {
                            ...notif,
                            read: true
                        });
                    }
                    loadNotifications();
                }
            } catch (error) {
                console.error('Erreur marquage tout lu:', error);
            }
        };

        const getTimeAgo = (dateString) => {
            const now = new Date();
            const date = new Date(dateString);
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMins / 60);
            const diffDays = Math.floor(diffHours / 24);

            if (diffMins < 1) return 'À l\'instant';
            if (diffMins < 60) return `${diffMins}min`;
            if (diffHours < 24) return `${diffHours}h`;
            return `${diffDays}j`;
        };

        return React.createElement('div', {
            className: 'relative',
            'data-name': 'notifications',
            'data-file': 'components/Notifications.js'
        }, [
            React.createElement('button', {
                key: 'bell-button',
                onClick: () => setShowDropdown(!showDropdown),
                className: 'relative text-gray-600 hover:text-gray-800 transition-colors'
            }, [
                React.createElement('i', {
                    key: 'bell-icon',
                    className: 'fas fa-bell text-lg'
                }),
                unreadCount > 0 && React.createElement('span', {
                    key: 'badge',
                    className: 'notification-badge absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center'
                }, unreadCount > 9 ? '9+' : unreadCount)
            ]),
            showDropdown && React.createElement('div', {
                key: 'dropdown',
                className: 'absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50'
            }, [
                React.createElement('div', {
                    key: 'header',
                    className: 'flex justify-between items-center p-4 border-b'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'font-semibold text-gray-800'
                    }, 'Notifications'),
                    unreadCount > 0 && React.createElement('button', {
                        key: 'mark-all',
                        onClick: markAllAsRead,
                        className: 'text-blue-600 text-sm hover:text-blue-800'
                    }, 'Tout marquer comme lu')
                ]),
                React.createElement('div', {
                    key: 'list',
                    className: 'max-h-96 overflow-y-auto'
                }, notifications.length > 0 ? notifications.map(notif =>
                    React.createElement('div', {
                        key: notif.id,
                        onClick: () => !notif.read && markAsRead(notif.id),
                        className: `p-4 border-b hover:bg-gray-50 cursor-pointer ${!notif.read ? 'bg-blue-50' : ''}`
                    }, [
                        React.createElement('div', {
                            key: 'content',
                            className: 'flex justify-between items-start'
                        }, [
                            React.createElement('div', {
                                key: 'text',
                                className: 'flex-1'
                            }, [
                                React.createElement('p', {
                                    key: 'message',
                                    className: `text-sm ${!notif.read ? 'font-medium' : ''}`
                                }, notif.message),
                                React.createElement('p', {
                                    key: 'time',
                                    className: 'text-xs text-gray-500 mt-1'
                                }, getTimeAgo(notif.createdAt))
                            ]),
                            !notif.read && React.createElement('div', {
                                key: 'dot',
                                className: 'w-2 h-2 bg-blue-600 rounded-full ml-2 mt-1'
                            })
                        ])
                    ])
                ) : React.createElement('div', {
                    key: 'empty',
                    className: 'p-4 text-center text-gray-500 text-sm'
                }, 'Aucune notification'))
            ])
        ]);
    } catch (error) {
        console.error('Notifications component error:', error);
        reportError(error);
    }
}

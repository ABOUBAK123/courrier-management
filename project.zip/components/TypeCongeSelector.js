const TypeCongeSelector = ({ value, onChange, required = false }) => {
    const [typeConges, setTypeConges] = React.useState([]);
    const [loading, setLoading] = React.useState(false);

    const loadTypeConges = async () => {
        setLoading(true);
        try {
            const result = await trickleListObjects('type_conge', 100, true);
            setTypeConges(result.items || []);
        } catch (error) {
            console.error('Erreur chargement types de congé:', error);
            // Types par défaut si erreur de chargement
            setTypeConges([
                { objectData: { nom: 'Congé annuel' } },
                { objectData: { nom: 'Congé maladie' } },
                { objectData: { nom: 'Congé maternité' } },
                { objectData: { nom: 'Congé exceptionnel' } }
            ]);
        }
        setLoading(false);
    };

    React.useEffect(() => {
        loadTypeConges();
    }, []);

    try {
        return React.createElement('div', {
            'data-name': 'type-conge-selector',
            'data-file': 'components/TypeCongeSelector.js'
        }, [
            React.createElement('label', {
                key: 'label',
                className: 'block text-sm font-medium text-gray-700 mb-1'
            }, 'Type de congé' + (required ? ' *' : '')),
            
            React.createElement('select', {
                key: 'select',
                value: value,
                onChange: (e) => onChange(e.target.value),
                className: 'w-full border border-gray-300 rounded-md px-3 py-2',
                required: required,
                disabled: loading
            }, [
                React.createElement('option', { 
                    key: 'empty', 
                    value: '' 
                }, loading ? 'Chargement...' : 'Sélectionner...'),
                
                ...typeConges.map((type, index) => 
                    React.createElement('option', {
                        key: index,
                        value: type.objectData.nom
                    }, type.objectData.nom)
                )
            ])
        ]);

    } catch (error) {
        console.error('TypeCongeSelector component error:', error);
        return React.createElement('div', {
            className: 'text-red-600 text-sm'
        }, 'Erreur de chargement des types de congé');
    }
};

window.TypeCongeSelector = TypeCongeSelector;
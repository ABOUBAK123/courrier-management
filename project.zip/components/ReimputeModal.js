function ReimputeModal({ 
    showReimputeModal, 
    setShowReimputeModal, 
    selectedMail, 
    reimputationData, 
    setReimputationData, 
    handleReimpute, 
    directions, 
    instructions 
}) {
    try {
        if (!showReimputeModal) return null;

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50',
            'data-name': 'reimpute-modal',
            'data-file': 'components/ReimputeModal.js'
        }, [
            React.createElement('div', {
                key: 'modal-content',
                className: 'bg-white rounded-lg p-6 w-full max-w-md'
            }, [
                React.createElement('h3', {
                    key: 'modal-title',
                    className: 'text-lg font-semibold mb-4'
                }, 'Formulaire de Réimputation'),
                React.createElement('div', {
                    key: 'mail-info',
                    className: 'mb-4 p-3 bg-gray-50 rounded'
                }, [
                    React.createElement('p', { key: 'numero' }, `Numéro: ${selectedMail?.numero}`),
                    React.createElement('p', { key: 'objet' }, `Objet: ${selectedMail?.objet}`),
                    React.createElement('p', { key: 'expediteur' }, `Expéditeur: ${selectedMail?.expediteur}`)
                ]),
                React.createElement('div', {
                    key: 'form',
                    className: 'space-y-4'
                }, [
                    React.createElement('select', {
                        key: 'direction',
                        value: reimputationData.direction,
                        onChange: (e) => setReimputationData(prev => ({ ...prev, direction: e.target.value })),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                        required: true
                    }, [
                        React.createElement('option', { key: 'default', value: '' }, 'Choisir une direction'),
                        ...directions.map(dir => 
                            React.createElement('option', { key: dir.code, value: dir.code }, `${dir.code} - ${dir.nomDirection}`)
                        )
                    ]),
                    React.createElement('select', {
                        key: 'instruction',
                        value: reimputationData.instruction,
                        onChange: (e) => setReimputationData(prev => ({ ...prev, instruction: e.target.value })),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                    }, [
                        React.createElement('option', { key: 'default', value: '' }, 'Choisir une instruction'),
                        ...instructions.map(inst => 
                            React.createElement('option', { key: inst.nom, value: inst.nom }, inst.nom)
                        )
                    ]),
                    React.createElement('textarea', {
                        key: 'instruction-particuliere',
                        placeholder: 'Instruction particulière...',
                        value: reimputationData.instructionParticuliere,
                        onChange: (e) => setReimputationData(prev => ({ ...prev, instructionParticuliere: e.target.value })),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                        rows: 3
                    }),
                    React.createElement('input', {
                        key: 'delai',
                        type: 'date',
                        value: reimputationData.delai,
                        onChange: (e) => setReimputationData(prev => ({ ...prev, delai: e.target.value })),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                    })
                ]),
                React.createElement('div', {
                    key: 'modal-buttons',
                    className: 'flex space-x-4 mt-6'
                }, [
                    React.createElement('button', {
                        key: 'reimpute-btn',
                        onClick: handleReimpute,
                        className: 'flex-1 bg-orange-600 text-white py-2 rounded-md hover:bg-orange-700'
                    }, 'Réimputer'),
                    React.createElement('button', {
                        key: 'cancel-btn',
                        onClick: () => setShowReimputeModal(false),
                        className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                    }, 'Annuler')
                ])
            ])
        ]);
    } catch (error) {
        console.error('ReimputeModal component error:', error);
        reportError(error);
    }
}

-- ===============================================
-- TABLES PARAMÈTRES ET CONFIGURATION
-- ===============================================

-- Table des paramètres généraux
CREATE TABLE general_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_organisation VARCHAR(200),
    document_viewer ENUM('pdf', 'onlyoffice') DEFAULT 'pdf',
    smtp_server VARCHAR(100),
    smtp_port INT DEFAULT 587,
    smtp_username VARCHAR(100),
    smtp_password VARCHAR(255),
    sms_api_url VARCHAR(255),
    sms_api_key VARCHAR(255),
    onlyoffice_server VARCHAR(255),
    onlyoffice_secret VARCHAR(255),
    updated_by VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table des paramètres e-parapheur par direction
CREATE TABLE eparapheur_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    direction VARCHAR(10) UNIQUE NOT NULL,
    api_signature VARCHAR(255),
    email_notifications BOOLEAN DEFAULT TRUE,
    sms_notifications BOOLEAN DEFAULT FALSE,
    auto_archive BOOLEAN DEFAULT TRUE,
    delai_validation INT DEFAULT 7,
    updated_by VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_direction (direction)
);

-- Table des paramètres d'archivage par direction
CREATE TABLE archive_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    direction VARCHAR(10) UNIQUE NOT NULL,
    delai_archivage INT DEFAULT 365,
    archivage_auto BOOLEAN DEFAULT TRUE,
    updated_by VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_direction (direction)
);

-- Table des demandes de réinitialisation de mot de passe
CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    token VARCHAR(100) UNIQUE NOT NULL,
    expiry TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    used_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_token (token),
    INDEX idx_expiry (expiry)
);

-- ===============================================
-- DONNÉES D'EXEMPLE ET CONFIGURATION INITIALE
-- ===============================================

-- Insertion des paramètres généraux par défaut
INSERT INTO general_settings (nom_organisation, document_viewer) VALUES
('Administration Publique', 'pdf');

-- Insertion des types de directions par défaut
INSERT INTO type_directions (nom, description, created_by) VALUES
('Ministère', 'Direction ministérielle', 'system'),
('Direction Générale', 'Direction générale d\'un ministère', 'system'),
('Direction', 'Direction sectorielle', 'system'),
('Sous-Direction', 'Sous-direction spécialisée', 'system'),
('Service', 'Service opérationnel', 'system');

-- Insertion des instructions par défaut
INSERT INTO instructions (nom, description, created_by) VALUES
('Pour traitement', 'Traiter le dossier selon les procédures', 'system'),
('Pour information', 'Prendre connaissance du contenu', 'system'),
('Pour avis', 'Donner un avis technique ou juridique', 'system'),
('Pour suite à donner', 'Donner les suites appropriées', 'system'),
('Urgent', 'Traitement prioritaire requis', 'system');

-- Insertion des rôles par défaut avec permissions
INSERT INTO roles (nom, description, permissions, created_by) VALUES
('ADMIN', 'Administrateur système', '{"courrier": true, "dashboard": true, "nouveau": true, "liste": true, "recherche": true, "imputation": true, "traitement": true, "suivi": true, "traite": true, "eparapheur": true, "eparapheur-accueil": true, "parapheur": true, "model": true, "eparapheur-parametres": true, "personnel": true, "gestion-personnelle": true, "archives": true, "liste-archives": true, "parametres-archives": true, "parametres": true, "utilisateurs": true, "roles": true, "directions": true, "instructions": true, "type-directions": true, "general": true}', 'system'),
('MINISTRE', 'Ministre', '{"courrier": true, "dashboard": true, "liste": true, "recherche": true, "imputation": true, "suivi": true, "traite": true, "eparapheur": true, "eparapheur-accueil": true, "parapheur": true}', 'system'),
('DIRECTEUR GENERAL', 'Directeur Général', '{"courrier": true, "dashboard": true, "nouveau": true, "liste": true, "recherche": true, "imputation": true, "traitement": true, "suivi": true, "traite": true, "eparapheur": true, "eparapheur-accueil": true, "parapheur": true, "model": true}', 'system'),
('DIRECTEUR', 'Directeur', '{"courrier": true, "dashboard": true, "nouveau": true, "liste": true, "recherche": true, "imputation": true, "traitement": true, "suivi": true, "traite": true, "eparapheur": true, "eparapheur-accueil": true, "parapheur": true}', 'system'),
('ASSISTANT', 'Assistant', '{"courrier": true, "dashboard": true, "nouveau": true, "liste": true, "recherche": true, "traitement": true}', 'system');

-- Insertion des directions par défaut
INSERT INTO directions (code, nom_direction, type_direction, nom_responsable, email_responsable, created_by) VALUES
('MIN001', 'Cabinet du Ministre', 'Ministère', 'Ministre', 'ministre@gov.ma', 'system'),
('DIR001', 'Direction Générale', 'Direction Générale', 'Directeur Général', 'dg@gov.ma', 'system'),
('DIR002', 'Direction des Affaires Administratives', 'Direction', 'Directeur DAA', 'daa@gov.ma', 'system'),
('DIR003', 'Direction des Ressources Humaines', 'Direction', 'Directeur DRH', 'drh@gov.ma', 'system');

-- Insertion des utilisateurs par défaut
INSERT INTO users (name, email, password, role, direction) VALUES
('Administrateur Système', 'admin@gov.ma', 'admin123', 'ADMIN', 'DIR001'),
('Ministre', 'ministre@gov.ma', 'ministre123', 'MINISTRE', 'MIN001'),
('Directeur Général', 'dg@gov.ma', 'dg123', 'DIRECTEUR GENERAL', 'DIR001'),
('Directeur DAA', 'daa@gov.ma', 'daa123', 'DIRECTEUR', 'DIR002'),
('Assistant DAA', 'assistant@gov.ma', 'assistant123', 'ASSISTANT', 'DIR002');

-- Insertion des notifications de bienvenue
INSERT INTO notifications (user_email, message, type) VALUES
('admin@gov.ma', 'Bienvenue dans le système de gestion du courrier', 'welcome'),
('ministre@gov.ma', 'Bienvenue Monsieur le Ministre', 'welcome'),
('dg@gov.ma', 'Bienvenue dans votre espace de travail', 'welcome');

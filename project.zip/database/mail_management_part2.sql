-- ===============================================
-- TABLES SUIVI ET IMPUTATION
-- ===============================================

-- Table des imputations et suivi
CREATE TABLE imputations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mail_id INT NOT NULL,
    mail_number VARCHAR(50) NOT NULL,
    mail_object TEXT NOT NULL,
    imputed_to VARCHAR(10) NOT NULL,
    imputed_by VARCHAR(10) NOT NULL,
    instruction VARCHAR(100),
    instruction_particuliere TEXT,
    delai DATE,
    status ENUM('en_traitement', 'traite', 'rejete') DEFAULT 'en_traitement',
    treatment_name VARCHAR(100),
    response_file VARCHAR(255),
    treated_date TIMESTAMP NULL,
    rejected_by VARCHAR(10),
    rejection_date TIMESTAMP NULL,
    validated_by VARCHAR(10),
    validation_date TIMESTAMP NULL,
    original_direction VARCHAR(10),
    original_mail_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_mail_number (mail_number),
    INDEX idx_imputed_to (imputed_to),
    INDEX idx_imputed_by (imputed_by),
    INDEX idx_status (status),
    FOREIGN KEY (mail_id) REFERENCES mails(id) ON DELETE CASCADE
);

-- Table des archives
CREATE TABLE archives (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(50) NOT NULL,
    objet TEXT NOT NULL,
    type ENUM('arrive', 'depart') NOT NULL,
    direction VARCHAR(10) NOT NULL,
    date_archivage TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    archived_by VARCHAR(100),
    original_mail_id INT,
    files JSON,
    INDEX idx_numero (numero),
    INDEX idx_direction (direction),
    INDEX idx_date (date_archivage)
);

-- ===============================================
-- TABLES COMMUNICATION ET NOTIFICATIONS
-- ===============================================

-- Table des notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'general',
    parapheur_id VARCHAR(50),
    action VARCHAR(50),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_email (user_email),
    INDEX idx_type (type),
    INDEX idx_read (is_read),
    FOREIGN KEY (user_email) REFERENCES users(email) ON DELETE CASCADE
);

-- Table des messages chat
CREATE TABLE chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_email VARCHAR(100) NOT NULL,
    sender_name VARCHAR(100) NOT NULL,
    receiver_email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sender (sender_email),
    INDEX idx_receiver (receiver_email),
    INDEX idx_timestamp (timestamp),
    FOREIGN KEY (sender_email) REFERENCES users(email) ON DELETE CASCADE,
    FOREIGN KEY (receiver_email) REFERENCES users(email) ON DELETE CASCADE
);

-- Table de statut en ligne
CREATE TABLE online_status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_email VARCHAR(100) UNIQUE NOT NULL,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('online', 'offline') DEFAULT 'offline',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (user_email),
    INDEX idx_last_seen (last_seen),
    FOREIGN KEY (user_email) REFERENCES users(email) ON DELETE CASCADE
);

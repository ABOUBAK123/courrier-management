-- Table pour stocker tous les objets de l'application
CREATE TABLE IF NOT EXISTS objects (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    object_type VARCHAR(255) NOT NULL,
    object_data JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_object_type (object_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
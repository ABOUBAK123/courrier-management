-- Base de données pour le Système de Gestion du Courrier
-- MariaDB/MySQL Schema

CREATE DATABASE IF NOT EXISTS mail_management 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE mail_management;

-- ===============================================
-- TABLES DE CONFIGURATION ET UTILISATEURS
-- ===============================================

-- Table des utilisateurs
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    direction VARCHAR(10) NOT NULL,
    superieur_hierarchique VARCHAR(100),
    photo LONGTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_direction (direction),
    INDEX idx_role (role)
);

-- Table des rôles et permissions
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    url_connexion VARCHAR(255),
    permissions JSON,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table des directions
CREATE TABLE directions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) UNIQUE NOT NULL,
    nom_direction VARCHAR(200) NOT NULL,
    direction_parent VARCHAR(10),
    type_direction VARCHAR(100),
    nom_responsable VARCHAR(100),
    email_responsable VARCHAR(100),
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    INDEX idx_parent (direction_parent),
    FOREIGN KEY (direction_parent) REFERENCES directions(code) ON DELETE SET NULL
);

-- Table des types de directions
CREATE TABLE type_directions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des instructions de traitement
CREATE TABLE instructions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===============================================
-- TABLES GESTION COURRIER
-- ===============================================

-- Table des courriers
CREATE TABLE mails (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(50) UNIQUE NOT NULL,
    type ENUM('arrive', 'depart') NOT NULL,
    priority ENUM('faible', 'normale', 'elevee', 'urgente') DEFAULT 'normale',
    date_emission DATE NOT NULL,
    objet TEXT NOT NULL,
    expediteur VARCHAR(200),
    destinateur VARCHAR(200),
    numero_emission VARCHAR(50),
    numero_reference VARCHAR(50),
    status ENUM('attente', 'traitement', 'traite', 'valide', 'reimpute') DEFAULT 'attente',
    direction VARCHAR(10) NOT NULL,
    imputed_to VARCHAR(10),
    imputed_by VARCHAR(10),
    instruction VARCHAR(100),
    instruction_particuliere TEXT,
    delai DATE,
    treatment_name VARCHAR(100),
    response_file VARCHAR(255),
    treated_by VARCHAR(10),
    treatment_date TIMESTAMP NULL,
    created_by INT,
    created_by_name VARCHAR(100),
    files JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_numero (numero),
    INDEX idx_direction (direction),
    INDEX idx_status (status),
    INDEX idx_type (type),
    INDEX idx_date (date_emission),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Table des compteurs de numérotation
CREATE TABLE mail_counters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    counter_key VARCHAR(50) UNIQUE NOT NULL,
    type ENUM('arrive', 'depart') NOT NULL,
    direction_code VARCHAR(10) NOT NULL,
    year YEAR NOT NULL,
    current_number INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_key (counter_key),
    INDEX idx_direction_year (direction_code, year)
);

-- Tables pour le système d'alertes email

CREATE TABLE IF NOT EXISTS email_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    destinataire VARCHAR(255) NOT NULL,
    sujet VARCHAR(500) NOT NULL,
    contenu TEXT,
    date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP,
    statut ENUM('envoye', 'erreur', 'en_attente') DEFAULT 'en_attente',
    type_alerte ENUM('urgent', 'retard', 'rappel') DEFAULT 'rappel',
    demande_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notification (
    id INT AUTO_INCREMENT PRIMARY KEY,
    destinataire_id VARCHAR(50) NOT NULL,
    titre VARCHAR(255) NOT NULL,
    message TEXT,
    type ENUM('info', 'warning', 'error', 'success') DEFAULT 'info',
    statut ENUM('lue', 'non_lue') DEFAULT 'non_lue',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_lecture DATETIME NULL,
    lien VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Index pour optimiser les requêtes
CREATE INDEX idx_notification_destinataire ON notification(destinataire_id);
CREATE INDEX idx_notification_statut ON notification(statut);
CREATE INDEX idx_email_log_destinataire ON email_log(destinataire);
CREATE INDEX idx_email_log_date ON email_log(date_envoi);
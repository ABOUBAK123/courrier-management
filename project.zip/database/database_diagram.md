# Schéma de Base de Données - Système de Gestion du Courrier

## 📊 **Structure Générale**


📦 MAIL_MANAGEMENT_DB (MariaDB/MySQL)
├── 👥 UTILISATEURS & CONFIGURATION
│   ├── users (Utilisateurs)
│   ├── roles (Rôles et permissions)
│   ├── directions (Organigramme)
│   ├── type_directions (Types d'organisation)
│   └── instructions (Instructions de traitement)
│
├── 📧 GESTION COURRIER
│   ├── mails (Courriers principaux)
│   ├── mail_counters (Numérotation automatique)
│   ├── imputations (Suivi des imputations)
│   └── archives (Courriers archivés)
│
├── ✍️ E-PARAPHEUR
│   ├── parapheurs (Documents à signer)
│   └── parapheur_models (Modèles de workflow)
│
├── 👨‍💼 GESTION PERSONNEL
│   ├── personnel (Employés)
│   ├── conges (Demandes de congé)
│   └── formations (Formations organisées)
│
├── 💬 COMMUNICATION
│   ├── notifications (Alertes système)
│   ├── chat_messages (Messagerie interne)
│   └── online_status (Statut en ligne)
│
└── ⚙️ PARAMÈTRES
    ├── general_settings (Configuration globale)
    ├── eparapheur_settings (Config e-parapheur)
    ├── archive_settings (Config archivage)
    └── password_resets (Réinitialisation MDP)


## 🔗 **Relations Principales**

### **Users → Mails**
sql
users.id ← mails.created_by
users.direction ← mails.direction


### **Directions → Tout**
sql
directions.code ← mails.direction
directions.code ← users.direction
directions.code ← personnel.direction


### **Mails → Imputations**
sql
mails.id ← imputations.mail_id
mails.numero ← imputations.mail_number


### **Users → Communications**
sql
users.email ← notifications.user_email
users.email ← chat_messages.sender_email
users.email ← chat_messages.receiver_email


## 📋 **Tables Détaillées**

### **🏢 CONFIGURATION**
| Table | Lignes | Description |
|-------|--------|-------------|
| `users` | ~50 | Comptes utilisateurs |
| `roles` | ~10 | Rôles et permissions |
| `directions` | ~20 | Structure organisationnelle |
| `type_directions` | ~5 | Types d'organisation |
| `instructions` | ~10 | Instructions prédéfinies |

### **📧 COURRIER**
| Table | Lignes | Description |
|-------|--------|-------------|
| `mails` | ~10,000 | Courriers entrants/sortants |
| `mail_counters` | ~100 | Compteurs numérotation |
| `imputations` | ~5,000 | Suivi des traitements |
| `archives` | ~50,000 | Courriers archivés |

### **✍️ SIGNATURE**
| Table | Lignes | Description |
|-------|--------|-------------|
| `parapheurs` | ~1,000 | Documents en signature |
| `parapheur_models` | ~50 | Modèles de workflow |

### **👥 PERSONNEL**
| Table | Lignes | Description |
|-------|--------|-------------|
| `personnel` | ~200 | Base employés |
| `conges` | ~1,000 | Demandes congé |
| `formations` | ~100 | Sessions formation |

## 🚀 **Index Optimisés**

### **Performance Courrier**
sql
-- Recherche rapide courriers
INDEX idx_numero ON mails(numero)
INDEX idx_direction ON mails(direction) 
INDEX idx_status ON mails(status)
INDEX idx_date ON mails(date_emission)

-- Suivi imputation
INDEX idx_mail_number ON imputations(mail_number)
INDEX idx_imputed_to ON imputations(imputed_to)


### **Performance Communication**
sql
-- Notifications rapides
INDEX idx_user_email ON notifications(user_email)
INDEX idx_read ON notifications(is_read)

-- Chat temps réel
INDEX idx_sender ON chat_messages(sender_email)
INDEX idx_receiver ON chat_messages(receiver_email)


## 💾 **Stockage JSON**

### **Permissions Rôles**
json
{
  "courrier": true,
  "dashboard": true,
  "nouveau": true,
  "parametres": false
}


### **Workflow Parapheur**
json
{
  "validations": [
    {"ordre": 1, "utilisateur": "user@gov.ma", "completed": false}
  ],
  "signatures": [
    {"ordre": 1, "utilisateur": "chef@gov.ma", "completed": false}
  ]
}


### **Fichiers Courrier**
json
[
  {
    "name": "document.pdf",
    "size": 1024000,
    "type": "application/pdf",
    "content": "base64_encoded_content"
  }
]


## ⚡ **Commandes Utiles**

### **Installation**
sql
-- Créer la base
SOURCE database/mail_management.sql;
SOURCE database/mail_management_part2.sql;
SOURCE database/mail_management_part3.sql;
SOURCE database/mail_management_part4.sql;


### **Maintenance**
sql
-- Optimiser tables
OPTIMIZE TABLE mails, imputations, notifications;

-- Statistiques
SELECT COUNT(*) as total_courriers FROM mails;
SELECT direction, COUNT(*) as nb_courriers FROM mails GROUP BY direction;


Schéma complet pour 50 000+ courriers avec performance optimisée ! 🎯

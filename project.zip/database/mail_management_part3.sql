-- ===============================================
-- TABLES E-PARAPHEUR
-- ===============================================

-- Table des parapheurs
CREATE TABLE parapheurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(200) NOT NULL,
    description TEXT,
    model VARCHAR(100),
    proprietaire VARCHAR(100) NOT NULL,
    proprietaire_email VARCHAR(100),
    direction VARCHAR(10) NOT NULL,
    status ENUM('brouillon', 'demarre', 'validation', 'signature', 'signe', 'arrete', 'archive') DEFAULT 'brouillon',
    current_step INT DEFAULT 1,
    current_step_type ENUM('validation', 'signature'),
    progression INT DEFAULT 0,
    validations JSON,
    signatures JSON,
    documents JSON,
    pieces_jointes JSON,
    notifications JSON,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_proprietaire (proprietaire_email),
    INDEX idx_direction (direction),
    INDEX idx_status (status),
    INDEX idx_created_by (created_by)
);

-- Table des modèles de parapheur
CREATE TABLE parapheur_models (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_modele VARCHAR(100) NOT NULL,
    description TEXT,
    proprietaire VARCHAR(100) NOT NULL,
    groupe VARCHAR(10) NOT NULL,
    status ENUM('modele', 'archive') DEFAULT 'modele',
    validations JSON,
    signatures JSON,
    documents JSON,
    pieces_jointes JSON,
    notifications JSON,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100),
    INDEX idx_nom (nom_modele),
    INDEX idx_proprietaire (proprietaire),
    INDEX idx_groupe (groupe)
);

-- ===============================================
-- TABLES GESTION DU PERSONNEL
-- ===============================================

-- Table du personnel
CREATE TABLE personnel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    poste VARCHAR(100) NOT NULL,
    telephone VARCHAR(20),
    date_embauche DATE NOT NULL,
    direction VARCHAR(10) NOT NULL,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_direction (direction),
    INDEX idx_date_embauche (date_embauche)
);

-- Table des congés
CREATE TABLE conges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employe VARCHAR(100) NOT NULL,
    type_conge ENUM('annuel', 'maladie', 'maternite', 'formation', 'autre') NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    motif TEXT,
    status ENUM('attente', 'approuve', 'refuse') DEFAULT 'attente',
    demande_par VARCHAR(100),
    approuve_par VARCHAR(100),
    date_approbation TIMESTAMP NULL,
    direction VARCHAR(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_employe (employe),
    INDEX idx_direction (direction),
    INDEX idx_status (status),
    INDEX idx_dates (date_debut, date_fin)
);

-- Table des formations
CREATE TABLE formations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(200) NOT NULL,
    description TEXT,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    formateur VARCHAR(100) NOT NULL,
    participants VARCHAR(50),
    status ENUM('active', 'terminee', 'annulee') DEFAULT 'active',
    direction VARCHAR(10) NOT NULL,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_direction (direction),
    INDEX idx_status (status),
    INDEX idx_dates (date_debut, date_fin)
);

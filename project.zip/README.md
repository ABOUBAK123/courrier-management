# Système de Gestion du Courrier

## Installation sur WampServer

### Prérequis
- WampServer 3.2+ installé
- PHP 7.4+ avec extensions PDO et MySQL
- MySQL 5.7+ ou MariaDB 10.2+

### Étapes d'installation

1. **Télécharger et placer les fichiers**
   
   C:\wamp64\www\mail-management\
   ├── api/
   │   ├── auth.php
   │   ├── mails.php
   │   ├── notifications.php
   │   ├── chat.php
   │   ├── personnel.php
   │   ├── conges.php
   │   └── formations.php
   ├── config/
   │   └── database.php
   ├── database/
   │   └── mail_management.sql
   ├── install/
   │   └── install.php
   ├── components/
   ├── utils/
   ├── index.html
   └── styles.css
   

2. **Démarrer WampServer**
   - Lancer WampServer
   - Vérifier que l'icône est verte
   - Accéder à phpMyAdmin via http://localhost/phpmyadmin

3. **Installation automatique**
   - Ouvrir http://localhost/mail-management/install/install.php
   - Remplir les informations de connexion MySQL
   - Cliquer sur "Installer"

4. **Configuration manuelle (alternative)**
   - Importer le fichier `database/mail_management.sql` dans phpMyAdmin
   - Modifier `config/database.php` si nécessaire

5. **Accès à l'application**
   - URL: http://localhost/mail-management/
   - Login: admin@gov.com
   - Mot de passe: admin123

### Structure de la base de données

- **users**: Utilisateurs du système
- **mails**: Courriers entrants/sortants
- **imputations**: Suivi des imputations
- **notifications**: Notifications utilisateurs
- **chat_messages**: Messages entre utilisateurs
- **personnel**: Gestion du personnel
- **conges**: Demandes de congés
- **formations**: Formations organisées

### API Endpoints

- `api/auth.php`: Authentification et gestion des utilisateurs
- `api/mails.php`: Gestion des courriers
- `api/notifications.php`: Système de notifications
- `api/chat.php`: Messagerie interne
- `api/personnel.php`: Gestion du personnel
- `api/conges.php`: Gestion des congés
- `api/formations.php`: Gestion des formations

### Fonctionnalités

#### Gestion Courrier
- Création de courriers arrivés/départs
- Imputation et suivi
- Recherche avancée
- Workflow de traitement

#### Gestion Personnelle
- Liste du personnel
- Demandes de congés
- Formations
- Statistiques RH

#### Communication
- Notifications en temps réel
- Chat interne entre utilisateurs
- Système d'alertes

#### Administration
- Gestion des utilisateurs et rôles
- Configuration des directions
- Paramètres système

### Dépannage

1. **Erreur de connexion MySQL**
   - Vérifier que WampServer est démarré
   - Contrôler les paramètres dans `config/database.php`

2. **Erreur 404 sur les API**
   - Vérifier que les fichiers PHP sont dans le dossier `api/`
   - Contrôler les permissions de fichiers

3. **Problème de CORS**
   - Les headers CORS sont configurés dans `config/database.php`
   - Redémarrer Apache si nécessaire

### Support
Pour toute question technique, consulter les logs d'erreur PHP dans WampServer.

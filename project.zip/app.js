// Error Boundary Component
class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }

    componentDidCatch(error, errorInfo) {
        console.error('ErrorBoundary caught an error:', error, errorInfo);
        if (typeof reportError === 'function') {
            reportError(error);
        }
    }

    render() {
        if (this.state.hasError) {
            return React.createElement('div', {
                className: 'min-h-screen flex items-center justify-center bg-gray-50 p-4'
            }, [
                React.createElement('div', {
                    key: 'error-content',
                    className: 'text-center max-w-md'
                }, [
                    React.createElement('i', {
                        key: 'error-icon',
                        className: 'fas fa-exclamation-triangle text-6xl text-red-500 mb-4'
                    }),
                    React.createElement('h1', {
                        key: 'error-title',
                        className: 'text-2xl font-bold text-gray-800 mb-4'
                    }, 'Une erreur s\'est produite'),
                    React.createElement('p', {
                        key: 'error-message',
                        className: 'text-gray-600 mb-6'
                    }, 'L\'application a rencontré un problème. Veuillez recharger la page.'),
                    React.createElement('button', {
                        key: 'reload-button',
                        onClick: () => window.location.reload(),
                        className: 'bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700'
                    }, 'Recharger la page')
                ])
            ]);
        }

        return this.props.children;
    }
}

function App() {
    try {
        const [activeSection, setActiveSection] = React.useState('dashboard');
        const [showMobileSidebar, setShowMobileSidebar] = React.useState(false);

        const renderContent = (user) => {
            // Redirection automatique pour les AGENT vers leur espace
            if (user && user.role === 'AGENT' && activeSection === 'dashboard') {
                setActiveSection('gestion-personnelle');
            }

            switch (activeSection) {
                case 'dashboard':
                    return React.createElement(Dashboard, { user });
                case 'nouveau':
                    return React.createElement(NewMail, { user });
                case 'liste':
                    return React.createElement(MailList, { user });
                case 'recherche':
                    return React.createElement(AdvancedSearch, { user });
                case 'imputation':
                    return React.createElement(Imputation, { user });
                case 'traitement':
                    return React.createElement(EnTraitement, { user });
                case 'suivi':
                    return React.createElement(SuiviImputation, { user });
                case 'traite':
                    return React.createElement(CourrierTraite, { user });
                case 'eparapheur-accueil':
                    return React.createElement(EparapheurAccueil, { user });
                case 'parapheur':
                    return React.createElement(ParapheurList, { user });
                case 'model':
                    return React.createElement(ModelParapheur, { user });
                case 'eparapheur-parametres':
                    return React.createElement(ParametresEparapheur, { user });
                case 'gestion-personnelle':
                    return React.createElement(GestionPersonnelle, { user });
                case 'personnel-list':
                    return React.createElement(PersonnelList, { user });
                case 'espace-agent':
                    return React.createElement(EspaceAgent, { 
                        user,
                        embedded: true
                    });
                case 'suivi-demandes-agent':
                    return React.createElement(window.SuiviDemandeAgent, { user });
                case 'validation-hierarchique':
                    return React.createElement(window.ValidationHierarchique, { user });
                case 'tableau-bord-rh':
                    return React.createElement(window.TableauBordRH, { user });
                case 'calendrier-integre':
                    return React.createElement(window.CalendrierIntegre, { user });
                case 'liste-archives':
                    return React.createElement(ListeArchives, { user });
                case 'parametres-archives':
                    return React.createElement(ParametresArchives, { user });
                case 'utilisateurs':
                    return React.createElement(Utilisateurs, { user });
                case 'roles':
                    return React.createElement(Roles, { user });
                case 'directions':
                    return React.createElement(Directions, { user });
                case 'instructions':
                    return React.createElement(Instructions, { user });
                case 'type-directions':
                    return React.createElement(TypeDirections, { user });
                case 'general':
                    return React.createElement(ParametresGeneraux, { user });
                case 'stockage':
                    return React.createElement(ParametresStockage, { user });
                case 'profil':
                    return React.createElement(ProfilUtilisateur, { user });
                case 'validations':
                    return React.createElement(ValidationPanel, { user });
                case 'validation-drh':
                    return React.createElement(ValidationDRH, { user });
                case 'conges-a-valider':
                    return React.createElement(window.ValidationCongesPage, { user });
                case 'planification-conges':
                    return React.createElement(window.PlanificationCongesPage, { user });
                case 'rapports-conges':
                    return React.createElement(window.RapportsCongesPage, { user });
                case 'tableau-bord-manager':
                    return React.createElement(window.TableauBordManager, { user });
                case 'planification-equipe':
                    return React.createElement(window.PlanificationEquipe);
                case 'rapports-conges':
                    return React.createElement(window.RapportsConges);
                default:
                    return React.createElement('div', {
                        className: 'p-6 text-center text-gray-600'
                    }, 'Section en développement');
            }
        };

        const MainApp = () => {
            const { user, login, logout, loading } = useAuth();
            const [currentModal, setCurrentModal] = React.useState(null);

            React.useEffect(() => {
                // Redirection automatique pour les AGENT au chargement
                if (user && user.role === 'AGENT') {
                    setActiveSection('gestion-personnelle');
                }
                
                // Fonction globale pour afficher les modales
                window.showModal = (modalType) => {
                    setCurrentModal(modalType);
                };
            }, [user]);

            if (loading) {
                return React.createElement('div', {
                    className: 'min-h-screen flex items-center justify-center bg-gray-50'
                }, [
                    React.createElement('div', {
                        key: 'loading',
                        className: 'text-center'
                    }, [
                        React.createElement('i', {
                            key: 'spinner',
                            className: 'fas fa-spinner fa-spin text-4xl text-blue-600 mb-4'
                        }),
                        React.createElement('p', {
                            key: 'text',
                            className: 'text-gray-600'
                        }, 'Chargement...')
                    ])
                ]);
            }

            if (!user) {
                return React.createElement('div', {
                    className: 'min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4'
                }, [
                    React.createElement(Login, {
                        key: 'login',
                        onLogin: login
                    })
                ]);
            }

            return React.createElement('div', {
                className: 'min-h-screen bg-gray-50 flex',
                'data-name': 'main-app',
                'data-file': 'app.js'
            }, [
                // Mobile sidebar overlay
                showMobileSidebar && React.createElement('div', {
                    key: 'overlay',
                    className: 'sidebar-overlay md:hidden',
                    onClick: () => setShowMobileSidebar(false)
                }),
                // Sidebar
                React.createElement('div', {
                    key: 'sidebar-container',
                    className: `sidebar-mobile ${showMobileSidebar ? 'open' : ''} md:relative md:translate-x-0`
                }, [
                    React.createElement(Sidebar, {
                        key: 'sidebar',
                        activeSection,
                        onSectionChange: (section) => {
                            setActiveSection(section);
                            setShowMobileSidebar(false);
                        },
                        user
                    })
                ]),
                // Main content
                React.createElement('div', {
                    key: 'main-content',
                    className: 'flex-1 flex flex-col min-w-0'
                }, [
                    React.createElement(OfflineIndicator, {
                        key: 'offline-indicator',
                        user
                    }),
                    React.createElement(Header, {
                        key: 'header',
                        user,
                        onLogout: logout,
                        onSectionChange: setActiveSection,
                        onToggleSidebar: () => setShowMobileSidebar(!showMobileSidebar)
                    }),
                React.createElement('main', {
                    key: 'content',
                    className: 'flex-1 overflow-y-auto content-mobile'
                }, renderContent(user)),
                React.createElement(window.ToastContainer, { key: 'toast-container' })
                ]),
                // Chat box - responsive positioning
                React.createElement('div', {
                    key: 'chat-container',
                    className: 'chat-mobile'
                }, [
                    React.createElement(ChatBox, {
                        key: 'chat-box',
                        user
                    })
                ]),
                // Modales
                currentModal === 'scanner' && React.createElement(ScannerOCR, {
                    key: 'scanner-modal',
                    onClose: () => setCurrentModal(null),
                    onDocumentScanned: (doc) => {
                        console.log('Document scanné:', doc);
                        setCurrentModal(null);
                    }
                }),
                currentModal === 'new-mail' && React.createElement(NewMail, {
                    key: 'new-mail-modal',
                    user: user,
                    onClose: () => setCurrentModal(null),
                    modal: true
                }),
                currentModal === 'reminders' && React.createElement(ReminderSystem, {
                    key: 'reminders-modal',
                    onClose: () => setCurrentModal(null)
                }),
                currentModal === 'export' && React.createElement(MassExport, {
                    key: 'export-modal',
                    onClose: () => setCurrentModal(null)
                })
            ]);
        };

        return React.createElement(ErrorBoundary, null, 
            React.createElement(AuthProvider, null, React.createElement(MainApp))
        );
    } catch (error) {
        console.error('App component error:', error);
        reportError(error);
    }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App));

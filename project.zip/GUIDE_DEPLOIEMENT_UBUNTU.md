# Guide de Déploiement - Système de Gestion Administrative
## Ubuntu Server + Webmin + Apache + MariaDB

### Prérequis
- Serveur Ubuntu 20.04 LTS ou plus récent
- Accès root ou utilisateur avec privilèges sudo
- Connexion Internet stable
- Minimum 2GB RAM, 20GB espace disque

---

## 1. Mise à jour du système

```bash
sudo apt update && sudo apt upgrade -y
sudo reboot
```

## 2. Installation d'Apache

```bash
# Installation d'Apache
sudo apt install apache2 -y

# Activation et démarrage d'Apache
sudo systemctl enable apache2
sudo systemctl start apache2

# Vérification du statut
sudo systemctl status apache2

# Test : http://votre-ip-serveur
```

## 3. Installation de PHP

```bash
# Installation de PHP et modules nécessaires
sudo apt install php php-mysql php-mbstring php-xml php-curl php-zip php-gd php-json php-common -y

# Redémarrage d'Apache
sudo systemctl restart apache2

# Test PHP
echo "<?php phpinfo(); ?>" | sudo tee /var/www/html/info.php
# Visitez : http://votre-ip-serveur/info.php
```

## 4. Installation de MariaDB

```bash
# Installation de MariaDB
sudo apt install mariadb-server mariadb-client -y

# Sécurisation de MariaDB
sudo mysql_secure_installation
```

### Configuration MariaDB sécurisée :
- Mot de passe root : **OUI** (créer un mot de passe fort)
- Supprimer utilisateurs anonymes : **OUI**
- Désactiver connexion root distante : **OUI**
- Supprimer base test : **OUI**
- Recharger privilèges : **OUI**

## 5. Installation de Webmin

```bash
# Ajout du dépôt Webmin
curl -o setup-repos.sh https://raw.githubusercontent.com/webmin/webmin/master/setup-repos.sh
sudo sh setup-repos.sh

# Installation de Webmin
sudo apt install webmin -y

# Démarrage de Webmin
sudo systemctl enable webmin
sudo systemctl start webmin

# Accès Webmin : https://votre-ip-serveur:10000
```

## 6. Configuration du Firewall

```bash
# Installation et configuration UFW
sudo apt install ufw -y

# Règles de base
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Autoriser les services essentiels
sudo ufw allow ssh
sudo ufw allow 80/tcp     # HTTP
sudo ufw allow 443/tcp    # HTTPS
sudo ufw allow 10000/tcp  # Webmin

# Activation du firewall
sudo ufw enable

# Vérification
sudo ufw status
```

## 7. Création de la base de données

```bash
# Connexion à MariaDB
sudo mysql -u root -p

# Dans MariaDB, exécuter :
```

```sql
-- Création de la base de données
CREATE DATABASE gestion_administrative CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Création de l'utilisateur
CREATE USER 'admin_user'@'localhost' IDENTIFIED BY 'MotDePasseSecurise123!';

-- Attribution des privilèges
GRANT ALL PRIVILEGES ON gestion_administrative.* TO 'admin_user'@'localhost';
FLUSH PRIVILEGES;

-- Vérification
SHOW DATABASES;
SELECT User, Host FROM mysql.user WHERE User = 'admin_user';

EXIT;
```

## 8. Configuration Apache pour l'application

```bash
# Création du répertoire de l'application
sudo mkdir -p /var/www/gestion-admin
sudo chown -R www-data:www-data /var/www/gestion-admin
sudo chmod -R 755 /var/www/gestion-admin

# Création du Virtual Host
sudo nano /etc/apache2/sites-available/gestion-admin.conf
```

### Contenu du fichier `/etc/apache2/sites-available/gestion-admin.conf` :

```apache
<VirtualHost *:80>
    ServerName votre-domaine.com
    ServerAlias www.votre-domaine.com
    DocumentRoot /var/www/gestion-admin
    
    <Directory /var/www/gestion-admin>
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/gestion-admin_error.log
    CustomLog ${APACHE_LOG_DIR}/gestion-admin_access.log combined
</VirtualHost>
```

```bash
# Activation du site
sudo a2ensite gestion-admin.conf
sudo a2dissite 000-default.conf

# Activation des modules Apache
sudo a2enmod rewrite
sudo a2enmod headers

# Redémarrage d'Apache
sudo systemctl restart apache2
```

## 9. Déploiement de l'application

```bash
# Aller dans le répertoire de l'application
cd /var/www/gestion-admin

# Upload des fichiers (via SCP, FTP, ou Git)
# Option 1 : Upload direct
sudo chown -R www-data:www-data /var/www/gestion-admin

# Option 2 : Si utilisation de Git
# sudo apt install git -y
# git clone https://github.com/votre-repo/gestion-admin.git .
```

## 10. Configuration de la base de données

```bash
# Import du schéma de base de données
cd /var/www/gestion-admin

# Si vous avez des fichiers SQL
sudo mysql -u admin_user -p gestion_administrative < database/mail_management.sql
sudo mysql -u admin_user -p gestion_administrative < database/mail_management_part2.sql
sudo mysql -u admin_user -p gestion_administrative < database/mail_management_part3.sql
sudo mysql -u admin_user -p gestion_administrative < database/mail_management_part4.sql
```

## 11. Configuration PHP de l'application

```bash
# Édition du fichier de configuration
sudo nano /var/www/gestion-admin/config/database.php
```

### Contenu du fichier `config/database.php` :

```php
<?php
$host = 'localhost';
$dbname = 'gestion_administrative';
$username = 'admin_user';
$password = 'MotDePasseSecurise123!';
$charset = 'utf8mb4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=$charset", 
                   $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
?>
```

## 12. Configuration des permissions

```bash
# Permissions des fichiers
sudo chown -R www-data:www-data /var/www/gestion-admin
sudo find /var/www/gestion-admin -type d -exec chmod 755 {} \;
sudo find /var/www/gestion-admin -type f -exec chmod 644 {} \;

# Permissions spéciales pour les dossiers d'upload
sudo mkdir -p /var/www/gestion-admin/uploads
sudo mkdir -p /var/www/gestion-admin/temp
sudo chmod -R 777 /var/www/gestion-admin/uploads
sudo chmod -R 777 /var/www/gestion-admin/temp
```

## 13. Configuration SSL avec Let's Encrypt (Optionnel mais recommandé)

```bash
# Installation de Certbot
sudo apt install certbot python3-certbot-apache -y

# Obtention du certificat SSL
sudo certbot --apache -d votre-domaine.com -d www.votre-domaine.com

# Renouvellement automatique
sudo crontab -e
# Ajouter : 0 12 * * * /usr/bin/certbot renew --quiet
```

## 14. Optimisation et surveillance

### Configuration PHP pour production :

```bash
sudo nano /etc/php/8.1/apache2/php.ini
```

Modifications recommandées :
```ini
upload_max_filesize = 20M
post_max_size = 25M
max_execution_time = 300
memory_limit = 512M
max_input_vars = 3000
```

### Logs et surveillance :

```bash
# Surveillance des logs Apache
sudo tail -f /var/log/apache2/gestion-admin_error.log

# Surveillance des logs MariaDB
sudo tail -f /var/log/mysql/error.log

# Surveillance système avec Webmin
# Accéder à https://votre-ip:10000 > System Information
```

## 15. Sauvegarde automatique

```bash
# Création du script de sauvegarde
sudo nano /usr/local/bin/backup-gestion-admin.sh
```

### Contenu du script :

```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup/gestion-admin"
DB_NAME="gestion_administrative"
DB_USER="admin_user"
DB_PASS="MotDePasseSecurise123!"

# Création du répertoire de sauvegarde
mkdir -p $BACKUP_DIR

# Sauvegarde de la base de données
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/db_backup_$DATE.sql

# Sauvegarde des fichiers
tar -czf $BACKUP_DIR/files_backup_$DATE.tar.gz /var/www/gestion-admin

# Nettoyage des anciennes sauvegardes (garder 7 jours)
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Sauvegarde terminée : $DATE"
```

```bash
# Rendre le script exécutable
sudo chmod +x /usr/local/bin/backup-gestion-admin.sh

# Programmation automatique (tous les jours à 2h00)
sudo crontab -e
# Ajouter : 0 2 * * * /usr/local/bin/backup-gestion-admin.sh
```

## 16. Tests finaux

### Vérifications essentielles :

1. **Apache** : `sudo systemctl status apache2`
2. **MariaDB** : `sudo systemctl status mariadb`
3. **Webmin** : `sudo systemctl status webmin`
4. **Site web** : Accéder à http://votre-domaine.com
5. **Base de données** : Test de connexion via l'application

### URLs d'accès :
- **Application** : http://votre-domaine.com
- **Webmin** : https://votre-ip:10000
- **Logs Apache** : Webmin > Servers > Apache Webserver > Log Files

---

## Dépannage courant

### Problème de connexion base de données :
```bash
sudo systemctl status mariadb
sudo mysql -u admin_user -p gestion_administrative
```

### Erreurs Apache :
```bash
sudo apache2ctl configtest
sudo tail -f /var/log/apache2/error.log
```

### Permissions fichiers :
```bash
sudo chown -R www-data:www-data /var/www/gestion-admin
sudo chmod -R 755 /var/www/gestion-admin
```

---

## Sécurité supplémentaire

1. **Changer le port SSH** (recommandé)
2. **Installer Fail2Ban** pour protection contre les attaques
3. **Configurer un pare-feu applicatif** (ModSecurity)
4. **Surveillance avec Logwatch**
5. **Mises à jour automatiques de sécurité**

Ce guide vous permet de déployer complètement votre système de gestion administrative sur un serveur Ubuntu professionnel.
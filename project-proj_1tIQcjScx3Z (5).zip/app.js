function App() {
    try {
        const [activeSection, setActiveSection] = React.useState('dashboard');
        const [showMobileSidebar, setShowMobileSidebar] = React.useState(false);

        const renderContent = (user) => {
            // Redirection automatique pour les AGENT vers leur espace
            if (user && user.role === 'AGENT' && activeSection === 'dashboard') {
                setActiveSection('gestion-personnelle');
            }

            switch (activeSection) {
                case 'dashboard':
                    return React.createElement(Dashboard, { user });
                case 'nouveau':
                    return React.createElement(NewMail, { user });
                case 'liste':
                    return React.createElement(MailList, { user });
                case 'recherche':
                    return React.createElement(AdvancedSearch, { user });
                case 'imputation':
                    return React.createElement(Imputation, { user });
                case 'traitement':
                    return React.createElement(EnTraitement, { user });
                case 'suivi':
                    return React.createElement(SuiviImputation, { user });
                case 'traite':
                    return React.createElement(CourrierTraite, { user });
                case 'eparapheur-accueil':
                    return React.createElement(EparapheurAccueil, { user });
                case 'parapheur':
                    return React.createElement(ParapheurList, { user });
                case 'model':
                    return React.createElement(ModelParapheur, { user });
                case 'eparapheur-parametres':
                    return React.createElement(ParametresEparapheur, { user });
                case 'gestion-personnelle':
                    return React.createElement(GestionPersonnelle, { user });
                case 'espace-agent':
                    return React.createElement(EspaceAgent, { user, embedded: true });
                case 'liste-archives':
                    return React.createElement(ListeArchives, { user });
                case 'parametres-archives':
                    return React.createElement(ParametresArchives, { user });
                case 'utilisateurs':
                    return React.createElement(Utilisateurs, { user });
                case 'roles':
                    return React.createElement(Roles, { user });
                case 'directions':
                    return React.createElement(Directions, { user });
                case 'instructions':
                    return React.createElement(Instructions, { user });
                case 'type-directions':
                    return React.createElement(TypeDirections, { user });
                case 'general':
                    return React.createElement(ParametresGeneraux, { user });
                case 'profil':
                    return React.createElement(ProfilUtilisateur, { user });
                default:
                    return React.createElement('div', {
                        className: 'p-6 text-center text-gray-600'
                    }, 'Section en développement');
            }
        };

        const MainApp = () => {
            const { user, login, logout, loading } = useAuth();

            React.useEffect(() => {
                // Redirection automatique pour les AGENT au chargement
                if (user && user.role === 'AGENT') {
                    setActiveSection('gestion-personnelle');
                }
            }, [user]);

            if (loading) {
                return React.createElement('div', {
                    className: 'min-h-screen flex items-center justify-center bg-gray-50'
                }, [
                    React.createElement('div', {
                        key: 'loading',
                        className: 'text-center'
                    }, [
                        React.createElement('i', {
                            key: 'spinner',
                            className: 'fas fa-spinner fa-spin text-4xl text-blue-600 mb-4'
                        }),
                        React.createElement('p', {
                            key: 'text',
                            className: 'text-gray-600'
                        }, 'Chargement...')
                    ])
                ]);
            }

            if (!user) {
                return React.createElement('div', {
                    className: 'min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4'
                }, [
                    React.createElement(Login, {
                        key: 'login',
                        onLogin: login
                    })
                ]);
            }

            return React.createElement('div', {
                className: 'min-h-screen bg-gray-50 flex',
                'data-name': 'main-app',
                'data-file': 'app.js'
            }, [
                // Mobile sidebar overlay
                showMobileSidebar && React.createElement('div', {
                    key: 'overlay',
                    className: 'sidebar-overlay md:hidden',
                    onClick: () => setShowMobileSidebar(false)
                }),
                // Sidebar
                React.createElement('div', {
                    key: 'sidebar-container',
                    className: `sidebar-mobile ${showMobileSidebar ? 'open' : ''} md:relative md:translate-x-0`
                }, [
                    React.createElement(Sidebar, {
                        key: 'sidebar',
                        activeSection,
                        onSectionChange: (section) => {
                            setActiveSection(section);
                            setShowMobileSidebar(false);
                        },
                        user
                    })
                ]),
                // Main content
                React.createElement('div', {
                    key: 'main-content',
                    className: 'flex-1 flex flex-col min-w-0'
                }, [
                    React.createElement(Header, {
                        key: 'header',
                        user,
                        onLogout: logout,
                        onSectionChange: setActiveSection,
                        onToggleSidebar: () => setShowMobileSidebar(!showMobileSidebar)
                    }),
                    React.createElement('main', {
                        key: 'content',
                        className: 'flex-1 overflow-y-auto content-mobile'
                    }, renderContent(user))
                ]),
                // Chat box - responsive positioning
                React.createElement('div', {
                    key: 'chat-container',
                    className: 'chat-mobile'
                }, [
                    React.createElement(ChatBox, {
                        key: 'chat-box',
                        user
                    })
                ])
            ]);
        };

        return React.createElement(AuthProvider, null, React.createElement(MainApp));
    } catch (error) {
        console.error('App component error:', error);
        reportError(error);
    }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App));

function Sidebar({ activeSection, onSectionChange, user }) {
    try {
        const [openMenus, setOpenMenus] = React.useState({ 
            courrier: true, 
            eparapheur: false, 
            personnel: false,
            archives: false, 
            parametres: false 
        });
        const [userPermissions, setUserPermissions] = React.useState({});
        const [organizationName, setOrganizationName] = React.useState('Administration');

        React.useEffect(() => {
            loadUserPermissions();
            loadOrganizationName();
        }, [user]);

        const loadUserPermissions = async () => {
            try {
                if (!user?.role) return;
                
                const roles = await trickleListObjects('roles', 100, true);
                const userRole = roles.items.find(role => 
                    role.objectData.nom === user.role
                );
                
                if (userRole && userRole.objectData.permissions) {
                    setUserPermissions(userRole.objectData.permissions);
                } else {
                    const defaultPermissions = getDefaultPermissions(user.role);
                    setUserPermissions(defaultPermissions);
                }
            } catch (error) {
                console.error('Erreur chargement permissions:', error);
            }
        };

        const loadOrganizationName = async () => {
            try {
                const settings = await trickleListObjects('general-settings', 10, true);
                if (settings.items.length > 0 && settings.items[0].objectData.nomOrganisation) {
                    setOrganizationName(settings.items[0].objectData.nomOrganisation);
                }
            } catch (error) {
                console.error('Erreur chargement nom organisation:', error);
            }
        };

        const getDefaultPermissions = (role) => {
            const adminRoles = ['ADMIN', 'DIRECTEUR', 'DIRECTEUR GENERAL', 'MINISTRE'];
            if (adminRoles.includes(role)) {
                return {
                    courrier: true, dashboard: true, nouveau: true, liste: true, 
                    recherche: true, imputation: true, traitement: true, suivi: true, traite: true,
                    eparapheur: true, 'eparapheur-accueil': true, parapheur: true, model: true, 'eparapheur-parametres': true,
                    personnel: true, 'gestion-personnelle': true, 'personnel-list': true, 'espace-agent': true,
                    archives: true, 'liste-archives': true, 'parametres-archives': true,
                    parametres: true, utilisateurs: true, roles: true, directions: true, instructions: true, 'type-directions': true, general: true
                };
            }
            return {
                courrier: true, dashboard: true, nouveau: true, liste: true, recherche: true,
                personnel: true, 'espace-agent': true
            };
        };

        const toggleMenu = (menu) => {
            setOpenMenus(prev => ({
                ...prev,
                [menu]: !prev[menu]
            }));
        };

        const hasPermission = (key) => {
            return userPermissions[key] === true;
        };

        const menuItems = [
            {
                id: 'courrier',
                label: 'Gestion Courrier',
                icon: 'fas fa-envelope',
                subItems: [
                    { id: 'dashboard', label: 'Tableau de bord', icon: 'fas fa-chart-bar' },
                    { id: 'nouveau', label: 'Nouveau courrier', icon: 'fas fa-plus' },
                    { id: 'liste', label: 'Liste des courriers', icon: 'fas fa-list' },
                    { id: 'recherche', label: 'Recherche avancée', icon: 'fas fa-search' },
                    { id: 'imputation', label: 'Imputation', icon: 'fas fa-share' },
                    { id: 'traitement', label: 'En Traitement', icon: 'fas fa-cogs' },
                    { id: 'suivi', label: 'Suivi Imputation', icon: 'fas fa-eye' },
                    { id: 'traite', label: 'Courrier Traité', icon: 'fas fa-check' }
                ]
            },
            {
                id: 'eparapheur',
                label: 'E-parapheur',
                icon: 'fas fa-signature',
                subItems: [
                    { id: 'eparapheur-accueil', label: 'Accueil', icon: 'fas fa-home' },
                    { id: 'parapheur', label: 'Parapheur', icon: 'fas fa-pen' },
                    { id: 'model', label: 'Modèle', icon: 'fas fa-template' },
                    { id: 'eparapheur-parametres', label: 'Paramètres', icon: 'fas fa-cog' }
                ]
            },
            {
                id: 'personnel',
                label: 'Gestion Personnelle',
                icon: 'fas fa-users',
                subItems: [
                    { id: 'gestion-personnelle', label: 'Gestion Personnelle', icon: 'fas fa-user-friends' },
                    { id: 'espace-agent', label: 'Espace Agent', icon: 'fas fa-user-circle' }
                ]
            },
            {
                id: 'archives',
                label: 'Archives',
                icon: 'fas fa-archive',
                subItems: [
                    { id: 'liste-archives', label: 'Liste Archives', icon: 'fas fa-list' },
                    { id: 'parametres-archives', label: 'Paramètres', icon: 'fas fa-cog' }
                ]
            },
            {
                id: 'parametres',
                label: 'Paramètres',
                icon: 'fas fa-cogs',
                subItems: [
                    { id: 'utilisateurs', label: 'Utilisateurs', icon: 'fas fa-users' },
                    { id: 'roles', label: 'Rôles', icon: 'fas fa-user-tag' },
                    { id: 'directions', label: 'Directions', icon: 'fas fa-building' },
                    { id: 'instructions', label: 'Instructions', icon: 'fas fa-clipboard-list' },
                    { id: 'type-directions', label: 'Type Directions', icon: 'fas fa-tags' },
                    { id: 'general', label: 'Général', icon: 'fas fa-globe' }
                ]
            }
        ];

        const visibleMenus = menuItems.filter(item => hasPermission(item.id));

        return React.createElement('div', {
            className: 'bg-gray-900 text-white w-64 min-h-screen sidebar-transition',
            'data-name': 'sidebar',
            'data-file': 'components/Sidebar.js'
        }, [
            React.createElement('div', {
                key: 'sidebar-content',
                className: 'p-4'
            }, [
                React.createElement('div', {
                    key: 'logo',
                    className: 'flex items-center mb-8'
                }, [
                    React.createElement('i', {
                        key: 'logo-icon',
                        className: 'fas fa-building text-2xl text-blue-400 mr-3'
                    }),
                    React.createElement('span', {
                        key: 'logo-text',
                        className: 'text-lg font-bold',
                        title: organizationName
                    }, organizationName.length > 15 ? organizationName.substring(0, 15) + '...' : organizationName)
                ]),
                React.createElement('nav', {
                    key: 'navigation',
                    className: 'space-y-2'
                }, visibleMenus.map(item => 
                    React.createElement('div', {
                        key: item.id,
                        className: 'space-y-1'
                    }, [
                        React.createElement('button', {
                            key: 'menu-button',
                            onClick: () => toggleMenu(item.id),
                            className: 'w-full flex items-center justify-between px-3 py-2 rounded-lg text-gray-300 hover:bg-gray-800 hover:text-white transition-colors'
                        }, [
                            React.createElement('div', {
                                key: 'menu-label',
                                className: 'flex items-center'
                            }, [
                                React.createElement('i', {
                                    key: 'menu-icon',
                                    className: `${item.icon} mr-3`
                                }),
                                React.createElement('span', {
                                    key: 'menu-text'
                                }, item.label)
                            ]),
                            React.createElement('i', {
                                key: 'chevron',
                                className: `fas fa-chevron-${openMenus[item.id] ? 'up' : 'down'} text-sm`
                            })
                        ]),
                        openMenus[item.id] && React.createElement('div', {
                            key: 'submenu',
                            className: 'ml-6 space-y-1'
                        }, item.subItems.filter(subItem => hasPermission(subItem.id)).map(subItem =>
                            React.createElement('button', {
                                key: subItem.id,
                                onClick: () => onSectionChange(subItem.id),
                                className: `w-full flex items-center px-3 py-2 rounded-lg text-sm transition-colors ${
                                    activeSection === subItem.id 
                                        ? 'bg-blue-600 text-white' 
                                        : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                                }`
                            }, [
                                React.createElement('i', {
                                    key: 'sub-icon',
                                    className: `${subItem.icon} mr-3`
                                }),
                                React.createElement('span', {
                                    key: 'sub-text'
                                }, subItem.label)
                            ])
                        ))
                    ])
                ))
            ])
        ]);
    } catch (error) {
        console.error('Sidebar component error:', error);
        reportError(error);
    }
}

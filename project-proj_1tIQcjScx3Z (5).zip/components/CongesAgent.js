function CongesAgent({ agent }) {
    try {
        const [conges, setConges] = React.useState([]);
        const [showModal, setShowModal] = React.useState(false);
        const [stats, setStats] = React.useState({ total: 25, utilises: 5, attente: 2 });

        React.useEffect(() => {
            loadConges();
        }, [agent]);

        const loadConges = async () => {
            try {
                const agentConges = [
                    {
                        id: 1,
                        type: 'annuel',
                        dateDebut: '2024-02-15',
                        dateFin: '2024-02-20',
                        duree: 5,
                        motif: 'Vacances familiales',
                        status: 'approuve',
                        dateCreation: '2024-01-15'
                    },
                    {
                        id: 2,
                        type: 'maladie',
                        dateDebut: '2024-03-10',
                        dateFin: '2024-03-12',
                        duree: 2,
                        motif: 'Consultation médicale',
                        status: 'attente',
                        dateCreation: '2024-03-08'
                    }
                ];
                setConges(agentConges);
            } catch (error) {
                console.error('Erreur chargement congés:', error);
            }
        };

        const getStatusColor = (status) => {
            switch (status) {
                case 'attente': return 'bg-yellow-100 text-yellow-800';
                case 'approuve': return 'bg-green-100 text-green-800';
                case 'refuse': return 'bg-red-100 text-red-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        };

        const getStatusLabel = (status) => {
            switch (status) {
                case 'attente': return 'En attente';
                case 'approuve': return 'Approuvé';
                case 'refuse': return 'Refusé';
                default: return status;
            }
        };

        return React.createElement('div', {
            className: 'p-6 space-y-6',
            'data-name': 'conges-agent',
            'data-file': 'components/CongesAgent.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Mes Congés'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowModal(true),
                    className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: 'fas fa-plus mr-2'
                    }),
                    'Nouvelle Demande'
                ])
            ]),
            React.createElement('div', {
                key: 'stats',
                className: 'grid grid-cols-1 md:grid-cols-3 gap-6'
            }, [
                React.createElement('div', {
                    key: 'total-card',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('div', {
                        key: 'total-content',
                        className: 'flex items-center'
                    }, [
                        React.createElement('div', {
                            key: 'total-icon',
                            className: 'bg-blue-500 p-3 rounded-lg'
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: 'fas fa-calendar text-white text-xl'
                            })
                        ]),
                        React.createElement('div', {
                            key: 'total-info',
                            className: 'ml-4'
                        }, [
                            React.createElement('p', {
                                key: 'label',
                                className: 'text-sm font-medium text-gray-600'
                            }, 'Solde Total'),
                            React.createElement('p', {
                                key: 'value',
                                className: 'text-2xl font-bold text-gray-900'
                            }, `${stats.total} jours`)
                        ])
                    ])
                ]),
                React.createElement('div', {
                    key: 'utilises-card',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('div', {
                        key: 'utilises-content',
                        className: 'flex items-center'
                    }, [
                        React.createElement('div', {
                            key: 'utilises-icon',
                            className: 'bg-orange-500 p-3 rounded-lg'
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: 'fas fa-check text-white text-xl'
                            })
                        ]),
                        React.createElement('div', {
                            key: 'utilises-info',
                            className: 'ml-4'
                        }, [
                            React.createElement('p', {
                                key: 'label',
                                className: 'text-sm font-medium text-gray-600'
                            }, 'Utilisés'),
                            React.createElement('p', {
                                key: 'value',
                                className: 'text-2xl font-bold text-gray-900'
                            }, `${stats.utilises} jours`)
                        ])
                    ])
                ]),
                React.createElement('div', {
                    key: 'restants-card',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('div', {
                        key: 'restants-content',
                        className: 'flex items-center'
                    }, [
                        React.createElement('div', {
                            key: 'restants-icon',
                            className: 'bg-green-500 p-3 rounded-lg'
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: 'fas fa-clock text-white text-xl'
                            })
                        ]),
                        React.createElement('div', {
                            key: 'restants-info',
                            className: 'ml-4'
                        }, [
                            React.createElement('p', {
                                key: 'label',
                                className: 'text-sm font-medium text-gray-600'
                            }, 'Restants'),
                            React.createElement('p', {
                                key: 'value',
                                className: 'text-2xl font-bold text-gray-900'
                            }, `${stats.total - stats.utilises} jours`)
                        ])
                    ])
                ])
            ]),
            showModal && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Nouvelle Demande de Congé'),
                    React.createElement('form', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('div', { key: 'type' }, [
                            React.createElement('label', {
                                key: 'label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Type de congé'),
                            React.createElement('select', {
                                key: 'select',
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                            }, [
                                React.createElement('option', { key: 'default', value: '' }, 'Sélectionner'),
                                React.createElement('option', { key: 'annuel', value: 'annuel' }, 'Congé annuel'),
                                React.createElement('option', { key: 'maladie', value: 'maladie' }, 'Congé maladie'),
                                React.createElement('option', { key: 'maternite', value: 'maternite' }, 'Congé maternité')
                            ])
                        ]),
                        React.createElement('div', { key: 'dates' }, [
                            React.createElement('div', {
                                key: 'dates-grid',
                                className: 'grid grid-cols-2 gap-4'
                            }, [
                                React.createElement('div', { key: 'debut' }, [
                                    React.createElement('label', {
                                        key: 'label',
                                        className: 'block text-sm font-medium text-gray-700 mb-2'
                                    }, 'Date début'),
                                    React.createElement('input', {
                                        key: 'input',
                                        type: 'date',
                                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                                    })
                                ]),
                                React.createElement('div', { key: 'fin' }, [
                                    React.createElement('label', {
                                        key: 'label',
                                        className: 'block text-sm font-medium text-gray-700 mb-2'
                                    }, 'Date fin'),
                                    React.createElement('input', {
                                        key: 'input',
                                        type: 'date',
                                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                                    })
                                ])
                            ])
                        ]),
                        React.createElement('div', { key: 'motif' }, [
                            React.createElement('label', {
                                key: 'label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Motif'),
                            React.createElement('textarea', {
                                key: 'textarea',
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                                rows: 3
                            })
                        ])
                    ]),
                    React.createElement('div', {
                        key: 'actions',
                        className: 'flex justify-end space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'cancel',
                            onClick: () => setShowModal(false),
                            className: 'px-4 py-2 text-gray-600 hover:text-gray-800'
                        }, 'Annuler'),
                        React.createElement('button', {
                            key: 'submit',
                            className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700'
                        }, 'Soumettre')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('CongesAgent component error:', error);
        reportError(error);
    }
}

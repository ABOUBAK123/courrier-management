function ParametresGeneraux({ user }) {
    try {
        const [settings, setSettings] = React.useState({
            nomOrganisation: '',
            documentViewer: 'pdf',
            smtpServer: '',
            smtpPort: 587,
            smtpUsername: '',
            smtpPassword: '',
            smsApiUrl: '',
            smsApiKey: '',
            onlyofficeServer: '',
            onlyofficeSecret: '',
            loginBackgroundImage: ''
        });
        const [loading, setLoading] = React.useState(true);
        const [activeSection, setActiveSection] = React.useState('general');

        React.useEffect(() => {
            loadSettings();
        }, []);

        const loadSettings = async () => {
            try {
                const response = await trickleListObjects('general-settings', 10, true);
                if (response.items.length > 0) {
                    setSettings(response.items[0].objectData);
                }
            } catch (error) {
                console.error('Erreur lors du chargement des paramètres:', error);
            } finally {
                setLoading(false);
            }
        };

        const handleSave = async () => {
            try {
                const response = await trickleListObjects('general-settings', 10, true);
                
                if (response.items.length > 0) {
                    await trickleUpdateObject('general-settings', response.items[0].objectId, settings);
                } else {
                    await trickleCreateObject('general-settings', {
                        ...settings,
                        updatedBy: user.name,
                        updatedAt: new Date().toISOString()
                    });
                }
                
                alert('Paramètres généraux sauvegardés avec succès!');
            } catch (error) {
                alert('Erreur lors de la sauvegarde');
            }
        };

        const handleImageUpload = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    setSettings(prev => ({ ...prev, loginBackgroundImage: event.target.result }));
                };
                reader.readAsDataURL(file);
            }
        };

        const sections = [
            { id: 'general', label: 'Général', icon: 'fas fa-cog' },
            { id: 'personnalisation', label: 'Personnalisation', icon: 'fas fa-palette' }
        ];

        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center',
                'data-name': 'loading',
                'data-file': 'components/ParametresGeneraux.js'
            }, 'Chargement des paramètres...');
        }

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'parametres-generaux',
            'data-file': 'components/ParametresGeneraux.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Paramètres Généraux'),
            React.createElement('div', {
                key: 'tabs',
                className: 'flex border-b border-gray-200 mb-6'
            }, sections.map(section =>
                React.createElement('button', {
                    key: section.id,
                    onClick: () => setActiveSection(section.id),
                    className: `flex items-center px-6 py-3 text-sm font-medium transition-colors ${
                        activeSection === section.id
                            ? 'border-b-2 border-blue-600 text-blue-600'
                            : 'text-gray-600 hover:text-gray-800'
                    }`
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: `${section.icon} mr-2`
                    }),
                    section.label
                ])
            )),
            React.createElement('div', {
                key: 'content',
                className: 'bg-white rounded-lg shadow-md p-6'
            }, [
                activeSection === 'general' && [
                    React.createElement('div', {
                        key: 'org-section',
                        className: 'border-b pb-6 mb-6'
                    }, [
                        React.createElement('h3', {
                            key: 'org-title',
                            className: 'text-lg font-semibold text-gray-800 mb-4'
                        }, 'Organisation'),
                        React.createElement('input', {
                            key: 'org-input',
                            type: 'text',
                            placeholder: 'Nom de l\'organisation',
                            value: settings.nomOrganisation,
                            onChange: (e) => setSettings(prev => ({ ...prev, nomOrganisation: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        })
                    ]),
                    React.createElement('div', {
                        key: 'email-section',
                        className: 'border-b pb-6 mb-6'
                    }, [
                        React.createElement('h3', {
                            key: 'email-title',
                            className: 'text-lg font-semibold text-gray-800 mb-4'
                        }, 'Configuration Email (SMTP)'),
                        React.createElement('div', {
                            key: 'email-fields',
                            className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                        }, [
                            React.createElement('input', {
                                key: 'smtp-server',
                                type: 'text',
                                placeholder: 'Serveur SMTP',
                                value: settings.smtpServer,
                                onChange: (e) => setSettings(prev => ({ ...prev, smtpServer: e.target.value })),
                                className: 'px-3 py-2 border border-gray-300 rounded-md'
                            }),
                            React.createElement('input', {
                                key: 'smtp-port',
                                type: 'number',
                                placeholder: 'Port SMTP',
                                value: settings.smtpPort,
                                onChange: (e) => setSettings(prev => ({ ...prev, smtpPort: parseInt(e.target.value) })),
                                className: 'px-3 py-2 border border-gray-300 rounded-md'
                            })
                        ])
                    ])
                ],
                activeSection === 'personnalisation' && [
                    React.createElement('div', {
                        key: 'background-section',
                        className: 'space-y-6'
                    }, [
                        React.createElement('h3', {
                            key: 'bg-title',
                            className: 'text-lg font-semibold text-gray-800 mb-4'
                        }, 'Image de fond - Page d\'authentification'),
                        React.createElement('div', {
                            key: 'bg-preview',
                            className: 'border-2 border-dashed border-gray-300 rounded-lg p-6 text-center'
                        }, [
                            settings.loginBackgroundImage ? [
                                React.createElement('img', {
                                    key: 'preview-img',
                                    src: settings.loginBackgroundImage,
                                    alt: 'Aperçu image de fond',
                                    className: 'max-w-full h-48 object-cover mx-auto rounded-lg mb-4'
                                }),
                                React.createElement('p', {
                                    key: 'preview-text',
                                    className: 'text-sm text-gray-600'
                                }, 'Aperçu de l\'image de fond')
                            ] : [
                                React.createElement('i', {
                                    key: 'upload-icon',
                                    className: 'fas fa-image text-4xl text-gray-400 mb-4'
                                }),
                                React.createElement('p', {
                                    key: 'upload-text',
                                    className: 'text-gray-600'
                                }, 'Aucune image sélectionnée')
                            ]
                        ]),
                        React.createElement('div', {
                            key: 'upload-controls',
                            className: 'space-y-4'
                        }, [
                            React.createElement('input', {
                                key: 'file-input',
                                type: 'file',
                                accept: 'image/*',
                                onChange: handleImageUpload,
                                className: 'hidden',
                                id: 'background-upload'
                            }),
                            React.createElement('label', {
                                key: 'upload-btn',
                                htmlFor: 'background-upload',
                                className: 'inline-block bg-blue-600 text-white px-6 py-3 rounded-lg cursor-pointer hover:bg-blue-700 transition-colors'
                            }, 'Choisir une image'),
                            settings.loginBackgroundImage && React.createElement('button', {
                                key: 'remove-btn',
                                onClick: () => setSettings(prev => ({ ...prev, loginBackgroundImage: '' })),
                                className: 'ml-4 bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors'
                            }, 'Supprimer l\'image'),
                            React.createElement('p', {
                                key: 'info-text',
                                className: 'text-sm text-gray-500'
                            }, 'Formats acceptés: JPG, PNG, GIF. Taille recommandée: 1920x1080px')
                        ])
                    ])
                ]
            ]),
            React.createElement('div', {
                key: 'buttons',
                className: 'flex space-x-4 mt-6'
            }, [
                React.createElement('button', {
                    key: 'save-btn',
                    onClick: handleSave,
                    className: 'btn-primary text-white px-6 py-2 rounded-md'
                }, 'Sauvegarder'),
                React.createElement('button', {
                    key: 'test-btn',
                    className: 'bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700'
                }, 'Tester Connexions')
            ])
        ]);
    } catch (error) {
        console.error('ParametresGeneraux component error:', error);
        reportError(error);
    }
}

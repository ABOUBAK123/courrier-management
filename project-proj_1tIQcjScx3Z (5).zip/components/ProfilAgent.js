function ProfilAgent({ agent }) {
    try {
        const [profileData, setProfileData] = React.useState(null);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            loadProfileData();
        }, [agent]);

        const loadProfileData = async () => {
            try {
                // Simuler le chargement des données complètes de l'agent
                const fullProfile = {
                    ...agent,
                    matricule: 'AG-' + Math.floor(Math.random() * 10000),
                    direction: 'Direction des Ressources Humaines',
                    service: 'Service Gestion Personnel',
                    dateEmbauche: '2020-01-15',
                    telephone: '05 37 XX XX XX',
                    adresse: 'Rabat, Maroc',
                    situationFamiliale: 'Marié(e)',
                    nombreEnfants: 2,
                    grade: 'Catégorie B',
                    soldeConges: 25,
                    congesUtilises: 5
                };
                setProfileData(fullProfile);
            } catch (error) {
                console.error('Erreur chargement profil:', error);
            } finally {
                setLoading(false);
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'p-6 text-center'
            }, 'Chargement du profil...');
        }

        return React.createElement('div', {
            className: 'p-6 space-y-6',
            'data-name': 'profil-agent',
            'data-file': 'components/ProfilAgent.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-6'
            }, [
                React.createElement('div', {
                    key: 'header-content',
                    className: 'flex items-center'
                }, [
                    React.createElement('div', {
                        key: 'avatar',
                        className: 'w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-6'
                    }, [
                        React.createElement('i', {
                            key: 'avatar-icon',
                            className: 'fas fa-user text-3xl'
                        })
                    ]),
                    React.createElement('div', {
                        key: 'info'
                    }, [
                        React.createElement('h1', {
                            key: 'name',
                            className: 'text-2xl font-bold'
                        }, profileData.nom),
                        React.createElement('p', {
                            key: 'poste',
                            className: 'text-blue-100 text-lg'
                        }, profileData.poste),
                        React.createElement('p', {
                            key: 'matricule',
                            className: 'text-blue-200 text-sm'
                        }, `Matricule: ${profileData.matricule}`)
                    ])
                ])
            ]),
            React.createElement('div', {
                key: 'content',
                className: 'grid grid-cols-1 md:grid-cols-2 gap-6'
            }, [
                React.createElement('div', {
                    key: 'personal-info',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('h3', {
                        key: 'personal-title',
                        className: 'text-lg font-semibold text-gray-800 mb-4'
                    }, '👤 Informations Personnelles'),
                    React.createElement('div', {
                        key: 'personal-content',
                        className: 'space-y-3'
                    }, [
                        React.createElement('div', { key: 'email' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Email: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.email)
                        ]),
                        React.createElement('div', { key: 'telephone' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Téléphone: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.telephone)
                        ]),
                        React.createElement('div', { key: 'adresse' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Adresse: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.adresse)
                        ]),
                        React.createElement('div', { key: 'situation' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Situation: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.situationFamiliale)
                        ]),
                        React.createElement('div', { key: 'enfants' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Enfants: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.nombreEnfants)
                        ])
                    ])
                ]),
                React.createElement('div', {
                    key: 'professional-info',
                    className: 'bg-white rounded-lg shadow-md p-6'
                }, [
                    React.createElement('h3', {
                        key: 'professional-title',
                        className: 'text-lg font-semibold text-gray-800 mb-4'
                    }, '🏢 Informations Professionnelles'),
                    React.createElement('div', {
                        key: 'professional-content',
                        className: 'space-y-3'
                    }, [
                        React.createElement('div', { key: 'direction' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Direction: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.direction)
                        ]),
                        React.createElement('div', { key: 'service' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Service: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.service)
                        ]),
                        React.createElement('div', { key: 'embauche' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Date embauche: '),
                            React.createElement('span', { className: 'text-gray-800' }, new Date(profileData.dateEmbauche).toLocaleDateString())
                        ]),
                        React.createElement('div', { key: 'grade' }, [
                            React.createElement('span', { className: 'font-medium text-gray-600' }, 'Grade: '),
                            React.createElement('span', { className: 'text-gray-800' }, profileData.grade)
                        ])
                    ])
                ])
            ]),
            React.createElement('div', {
                key: 'conges-summary',
                className: 'bg-white rounded-lg shadow-md p-6'
            }, [
                React.createElement('h3', {
                    key: 'conges-title',
                    className: 'text-lg font-semibold text-gray-800 mb-4'
                }, '📅 Résumé Congés'),
                React.createElement('div', {
                    key: 'conges-stats',
                    className: 'grid grid-cols-3 gap-4'
                }, [
                    React.createElement('div', {
                        key: 'solde',
                        className: 'text-center p-4 bg-blue-50 rounded-lg'
                    }, [
                        React.createElement('div', {
                            key: 'solde-value',
                            className: 'text-2xl font-bold text-blue-600'
                        }, profileData.soldeConges),
                        React.createElement('div', {
                            key: 'solde-label',
                            className: 'text-sm text-gray-600'
                        }, 'Solde total')
                    ]),
                    React.createElement('div', {
                        key: 'utilises',
                        className: 'text-center p-4 bg-orange-50 rounded-lg'
                    }, [
                        React.createElement('div', {
                            key: 'utilises-value',
                            className: 'text-2xl font-bold text-orange-600'
                        }, profileData.congesUtilises),
                        React.createElement('div', {
                            key: 'utilises-label',
                            className: 'text-sm text-gray-600'
                        }, 'Utilisés')
                    ]),
                    React.createElement('div', {
                        key: 'restants',
                        className: 'text-center p-4 bg-green-50 rounded-lg'
                    }, [
                        React.createElement('div', {
                            key: 'restants-value',
                            className: 'text-2xl font-bold text-green-600'
                        }, profileData.soldeConges - profileData.congesUtilises),
                        React.createElement('div', {
                            key: 'restants-label',
                            className: 'text-sm text-gray-600'
                        }, 'Restants')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('ProfilAgent component error:', error);
        reportError(error);
    }
}

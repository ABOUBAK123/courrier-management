function EspaceAgent({ user, embedded = false, onBack }) {
    try {
        const [activeSection, setActiveSection] = React.useState('profil');
        const [agentUser, setAgentUser] = React.useState(null);
        const [loading, setLoading] = React.useState(true);
        const [matricule, setMatricule] = React.useState('');
        const [searchLoading, setSearchLoading] = React.useState(false);

        React.useEffect(() => {
            if (embedded && user && user.role === 'AGENT' && user.matricule) {
                // Auto-charger les données de l'agent connecté
                loadAgentData(user.matricule);
            } else if (embedded) {
                setLoading(false);
            } else {
                checkAgentAuth();
            }
        }, [embedded, user]);

        const loadAgentData = async (agentMatricule) => {
            setLoading(true);
            try {
                const agentsDemo = [
                    { matricule: 'AG-1001', nom: 'Marie Dupont', email: 'marie.dupont@gouv.fr', poste: 'Assistant' },
                    { matricule: 'AG-1002', nom: 'Jean Martin', email: 'jean.martin@gouv.fr', poste: 'Technicien' },
                    { matricule: 'AG-1003', nom: 'Sophie Bernard', email: 'sophie.bernard@gouv.fr', poste: 'Agent' },
                    { matricule: 'AG-1004', nom: 'Ahmed Alami', email: 'ahmed.alami@gouv.fr', poste: 'Secrétaire' }
                ];

                const foundAgent = agentsDemo.find(agent => 
                    agent.matricule.toLowerCase() === agentMatricule.toLowerCase()
                );

                if (foundAgent) {
                    setAgentUser(foundAgent);
                } else {
                    setAgentUser({
                        matricule: agentMatricule,
                        nom: user.name,
                        email: user.email,
                        poste: 'Agent'
                    });
                }
            } catch (error) {
                console.error('Erreur chargement agent:', error);
            } finally {
                setLoading(false);
            }
        };

        const checkAgentAuth = () => {
            const savedAgent = localStorage.getItem('agentUser');
            if (savedAgent) {
                setAgentUser(JSON.parse(savedAgent));
            }
            setLoading(false);
        };

        const searchAgent = async () => {
            if (!matricule.trim()) return;
            
            setSearchLoading(true);
            try {
                const agentsDemo = [
                    { matricule: 'AG-1001', nom: 'Marie Dupont', email: 'marie.dupont@gouv.fr', poste: 'Assistant' },
                    { matricule: 'AG-1002', nom: 'Jean Martin', email: 'jean.martin@gouv.fr', poste: 'Technicien' },
                    { matricule: 'AG-1003', nom: 'Sophie Bernard', email: 'sophie.bernard@gouv.fr', poste: 'Agent' },
                    { matricule: 'AG-1004', nom: 'Ahmed Alami', email: 'ahmed.alami@gouv.fr', poste: 'Secrétaire' }
                ];

                const foundAgent = agentsDemo.find(agent => 
                    agent.matricule.toLowerCase() === matricule.toLowerCase()
                );

                if (foundAgent) {
                    setAgentUser(foundAgent);
                    setActiveSection('profil');
                } else {
                    alert('Aucun agent trouvé avec ce matricule');
                }
            } catch (error) {
                alert('Erreur lors de la recherche');
            } finally {
                setSearchLoading(false);
            }
        };

        const menuItems = [
            { id: 'profil', label: 'Mon Profil', icon: 'fas fa-user' },
            { id: 'conges', label: 'Mes Congés', icon: 'fas fa-calendar-alt' },
            { id: 'formations', label: 'Mes Formations', icon: 'fas fa-graduation-cap' },
            { id: 'documents', label: 'Mes Documents', icon: 'fas fa-folder' }
        ];

        const renderContent = () => {
            if (!agentUser && embedded) {
                return React.createElement('div', {
                    className: 'p-6 text-center text-gray-600'
                }, user && user.role === 'AGENT' ? 'Aucun matricule configuré pour cet agent' : 'Veuillez rechercher un agent par son matricule');
            }

            switch (activeSection) {
                case 'profil':
                    return React.createElement(ProfilAgent, { agent: agentUser });
                case 'conges':
                    return React.createElement(CongesAgent, { agent: agentUser });
                case 'formations':
                    return React.createElement(FormationsAgent, { agent: agentUser });
                case 'documents':
                    return React.createElement(DocumentsAgent, { agent: agentUser });
                default:
                    return React.createElement('div', {
                        className: 'p-6 text-center'
                    }, 'Section en développement');
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'min-h-screen flex items-center justify-center'
            }, 'Chargement...');
        }

        if (embedded) {
            return React.createElement('div', {
                className: 'space-y-6',
                'data-name': 'espace-agent-embedded',
                'data-file': 'components/EspaceAgent.js'
            }, [
                // Barre de recherche seulement pour les non-AGENT
                (!user || user.role !== 'AGENT') && React.createElement('div', {
                    key: 'search-bar',
                    className: 'bg-blue-50 p-4 rounded-lg border border-blue-200'
                }, [
                    React.createElement('div', {
                        key: 'search-content',
                        className: 'flex items-center space-x-4'
                    }, [
                        React.createElement('div', {
                            key: 'search-field',
                            className: 'flex-1'
                        }, [
                            React.createElement('label', {
                                key: 'label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Matricule de l\'agent'),
                            React.createElement('input', {
                                key: 'input',
                                type: 'text',
                                value: matricule,
                                onChange: (e) => setMatricule(e.target.value),
                                placeholder: 'Ex: AG-1001',
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                                onKeyPress: (e) => e.key === 'Enter' && searchAgent()
                            })
                        ]),
                        React.createElement('button', {
                            key: 'search-btn',
                            onClick: searchAgent,
                            disabled: searchLoading || !matricule.trim(),
                            className: 'bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 mt-6'
                        }, searchLoading ? 'Recherche...' : 'Rechercher'),
                        agentUser && React.createElement('button', {
                            key: 'clear-btn',
                            onClick: () => {
                                setAgentUser(null);
                                setMatricule('');
                            },
                            className: 'bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 mt-6'
                        }, 'Effacer')
                    ])
                ]),
                agentUser && React.createElement('div', {
                    key: 'nav-tabs',
                    className: 'flex border-b border-gray-200 bg-gray-50 rounded-t-lg'
                }, menuItems.map(item =>
                    React.createElement('button', {
                        key: item.id,
                        onClick: () => setActiveSection(item.id),
                        className: `flex items-center px-6 py-3 text-sm font-medium transition-colors ${
                            activeSection === item.id
                                ? 'border-b-2 border-blue-600 text-blue-600 bg-white'
                                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                        }`
                    }, [
                        React.createElement('i', {
                            key: 'icon',
                            className: `${item.icon} mr-2`
                        }),
                        React.createElement('span', {
                            key: 'label'
                        }, item.label)
                    ])
                )),
                React.createElement('div', {
                    key: 'content',
                    className: 'bg-white rounded-b-lg'
                }, renderContent())
            ]);
        }

        // Mode standalone supprimé - plus d'authentification séparée pour les agents
        return React.createElement('div', {
            className: 'p-6 text-center text-gray-600'
        }, 'Mode standalone non disponible. Veuillez vous connecter via l\'interface principale.');
    } catch (error) {
        console.error('EspaceAgent component error:', error);
        reportError(error);
    }
}

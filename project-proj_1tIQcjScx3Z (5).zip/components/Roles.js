function Roles({ user }) {
    try {
        const [roles, setRoles] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [editMode, setEditMode] = React.useState(false);
        const [editingRoleId, setEditingRoleId] = React.useState(null);
        const [formData, setFormData] = React.useState({
            nom: '',
            description: '',
            urlConnexion: '',
            permissions: {}
        });

        const menuStructure = [
            {
                key: 'courrier',
                label: 'Gestion Courrier',
                icon: 'fas fa-envelope',
                subItems: [
                    { key: 'dashboard', label: 'Tableau de bord' },
                    { key: 'nouveau', label: 'Nouveau courrier' },
                    { key: 'liste', label: 'Liste des courriers' },
                    { key: 'recherche', label: 'Recherche avancée' },
                    { key: 'imputation', label: 'Imputation' },
                    { key: 'traitement', label: 'En Traitement' },
                    { key: 'suivi', label: 'Suivi Imputation' },
                    { key: 'traite', label: 'Courrier Traité' }
                ]
            },
            {
                key: 'eparapheur',
                label: 'E-parapheur',
                icon: 'fas fa-signature',
                subItems: [
                    { key: 'eparapheur-accueil', label: 'Accueil' },
                    { key: 'parapheur', label: 'Parapheur' },
                    { key: 'model', label: 'Modèle' },
                    { key: 'eparapheur-parametres', label: 'Paramètres' }
                ]
            },
            {
                key: 'personnel',
                label: 'Gestion du Personnel',
                icon: 'fas fa-users',
                subItems: [
                    { key: 'gestion-personnelle', label: 'Gestion Personnelle' },
                    { key: 'espace-agent', label: 'Espace Agent' }
                ]
            },
            {
                key: 'archives',
                label: 'Archives',
                icon: 'fas fa-archive',
                subItems: [
                    { key: 'liste-archives', label: 'Liste Archives' },
                    { key: 'parametres-archives', label: 'Paramètres' }
                ]
            },
            {
                key: 'parametres',
                label: 'Paramètres',
                icon: 'fas fa-cogs',
                subItems: [
                    { key: 'utilisateurs', label: 'Utilisateurs' },
                    { key: 'roles', label: 'Rôles' },
                    { key: 'directions', label: 'Directions' },
                    { key: 'instructions', label: 'Instructions' },
                    { key: 'type-directions', label: 'Type Directions' },
                    { key: 'general', label: 'Général' }
                ]
            }
        ];

        React.useEffect(() => {
            loadRoles();
            initializePermissions();
        }, []);

        const initializePermissions = () => {
            const defaultPermissions = {};
            menuStructure.forEach(menu => {
                defaultPermissions[menu.key] = false;
                menu.subItems.forEach(subItem => {
                    defaultPermissions[subItem.key] = false;
                });
            });
            setFormData(prev => ({ ...prev, permissions: defaultPermissions }));
        };

        const loadRoles = async () => {
            try {
                const response = await trickleListObjects('roles', 100, true);
                const roleData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setRoles(roleData);
            } catch (error) {
                console.error('Erreur lors du chargement des rôles:', error);
            }
        };

        const handleEdit = (role) => {
            setEditMode(true);
            setEditingRoleId(role.id);
            setFormData({
                nom: role.nom,
                description: role.description || '',
                urlConnexion: role.urlConnexion || '',
                permissions: role.permissions || {}
            });
            setShowForm(true);
        };

        const handleSave = async () => {
            try {
                if (editMode) {
                    await trickleUpdateObject('roles', editingRoleId, {
                        ...formData,
                        updatedBy: user.name,
                        updatedAt: new Date().toISOString()
                    });
                    alert('Rôle modifié avec succès!');
                } else {
                    await trickleCreateObject('roles', {
                        ...formData,
                        createdBy: user.name,
                        createdAt: new Date().toISOString()
                    });
                    alert('Rôle créé avec succès!');
                }
                
                resetForm();
                loadRoles();
            } catch (error) {
                alert('Erreur lors de la sauvegarde');
            }
        };

        const resetForm = () => {
            setFormData({ nom: '', description: '', urlConnexion: '', permissions: {} });
            initializePermissions();
            setShowForm(false);
            setEditMode(false);
            setEditingRoleId(null);
        };

        const handleDelete = async (roleId) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce rôle?')) {
                try {
                    await trickleDeleteObject('roles', roleId);
                    alert('Rôle supprimé avec succès');
                    loadRoles();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        const handlePermissionChange = (key) => {
            setFormData(prev => ({
                ...prev,
                permissions: {
                    ...prev.permissions,
                    [key]: !prev.permissions[key]
                }
            }));
        };

        const handleMenuToggle = (menuKey) => {
            const menu = menuStructure.find(m => m.key === menuKey);
            const allSubItemsChecked = menu.subItems.every(sub => formData.permissions[sub.key]);
            
            setFormData(prev => {
                const newPermissions = { ...prev.permissions };
                newPermissions[menuKey] = !allSubItemsChecked;
                menu.subItems.forEach(sub => {
                    newPermissions[sub.key] = !allSubItemsChecked;
                });
                return { ...prev, permissions: newPermissions };
            });
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'roles',
            'data-file': 'components/Roles.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Gestion des Rôles'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => {
                        resetForm();
                        setShowForm(true);
                    },
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouveau Rôle')
            ]),
            React.createElement('div', {
                key: 'roles-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            }, roles.map(role =>
                React.createElement('div', {
                    key: role.id,
                    className: 'bg-white rounded-lg shadow-md p-6 card-hover'
                }, [
                    React.createElement('div', {
                        key: 'role-header',
                        className: 'flex justify-between items-start mb-4'
                    }, [
                        React.createElement('h3', {
                            key: 'role-name',
                            className: 'text-lg font-semibold text-gray-800'
                        }, role.nom),
                        React.createElement('div', {
                            key: 'actions',
                            className: 'flex space-x-2'
                        }, [
                            React.createElement('button', {
                                key: 'edit-btn',
                                onClick: () => handleEdit(role),
                                className: 'text-blue-600 hover:text-blue-900'
                            }, React.createElement('i', { className: 'fas fa-edit' })),
                            React.createElement('button', {
                                key: 'delete-btn',
                                onClick: () => handleDelete(role.id),
                                className: 'text-red-600 hover:text-red-900'
                            }, React.createElement('i', { className: 'fas fa-trash' }))
                        ])
                    ]),
                    React.createElement('p', {
                        key: 'role-description',
                        className: 'text-gray-600 mb-2'
                    }, role.description || 'Aucune description'),
                    role.urlConnexion && React.createElement('p', {
                        key: 'role-url',
                        className: 'text-blue-600 text-sm mb-2'
                    }, `URL: ${role.urlConnexion}`),
                    React.createElement('div', {
                        key: 'role-info',
                        className: 'text-sm text-gray-500'
                    }, [
                        React.createElement('p', { key: 'created-by' }, `Créé par: ${role.createdBy}`),
                        React.createElement('p', { key: 'created-date' }, `Date: ${new Date(role.createdAt).toLocaleDateString()}`)
                    ])
                ])
            )),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-2xl max-h-screen overflow-y-auto'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, editMode ? 'Modifier le Rôle' : 'Nouveau Rôle'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('input', {
                            key: 'nom-input',
                            type: 'text',
                            placeholder: 'Nom du rôle',
                            value: formData.nom,
                            onChange: (e) => setFormData(prev => ({ ...prev, nom: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('textarea', {
                            key: 'description-textarea',
                            placeholder: 'Description du rôle',
                            value: formData.description,
                            onChange: (e) => setFormData(prev => ({ ...prev, description: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            rows: 3
                        }),
                        React.createElement('input', {
                            key: 'url-input',
                            type: 'url',
                            placeholder: 'URL de connexion (ex: /dashboard, /admin)',
                            value: formData.urlConnexion,
                            onChange: (e) => setFormData(prev => ({ ...prev, urlConnexion: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('div', {
                            key: 'permissions-section'
                        }, [
                            React.createElement('h4', {
                                key: 'permissions-title',
                                className: 'text-sm font-medium text-gray-700 mb-3'
                            }, 'Permissions d\'accès détaillées:'),
                            React.createElement('div', {
                                key: 'permissions-tree',
                                className: 'space-y-4'
                            }, menuStructure.map(menu =>
                                React.createElement('div', {
                                    key: menu.key,
                                    className: 'border rounded-lg p-3'
                                }, [
                                    React.createElement('label', {
                                        key: 'menu-label',
                                        className: 'flex items-center font-medium text-gray-800 mb-2'
                                    }, [
                                        React.createElement('input', {
                                            key: 'menu-checkbox',
                                            type: 'checkbox',
                                            checked: formData.permissions[menu.key] || false,
                                            onChange: () => handleMenuToggle(menu.key),
                                            className: 'mr-3'
                                        }),
                                        React.createElement('i', {
                                            key: 'menu-icon',
                                            className: `${menu.icon} mr-2 text-blue-600`
                                        }),
                                        React.createElement('span', { key: 'menu-text' }, menu.label)
                                    ]),
                                    React.createElement('div', {
                                        key: 'submenu-items',
                                        className: 'ml-8 space-y-2'
                                    }, menu.subItems.map(subItem =>
                                        React.createElement('label', {
                                            key: subItem.key,
                                            className: 'flex items-center text-sm text-gray-600'
                                        }, [
                                            React.createElement('input', {
                                                key: 'sub-checkbox',
                                                type: 'checkbox',
                                                checked: formData.permissions[subItem.key] || false,
                                                onChange: () => handlePermissionChange(subItem.key),
                                                className: 'mr-3'
                                            }),
                                            React.createElement('span', { key: 'sub-text' }, subItem.label)
                                        ])
                                    ))
                                ])
                            ))
                        ])
                    ]),
                    React.createElement('div', {
                        key: 'modal-buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save-btn',
                            onClick: handleSave,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, editMode ? 'Modifier' : 'Créer'),
                        React.createElement('button', {
                            key: 'cancel-btn',
                            onClick: resetForm,
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Roles component error:', error);
        reportError(error);
    }
}

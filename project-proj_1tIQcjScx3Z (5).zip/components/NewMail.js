function NewMail({ user }) {
    try {
        const [activeTab, setActiveTab] = React.useState('arrive');
        const [nextNumber, setNextNumber] = React.useState('');
        const [formData, setFormData] = React.useState({
            priority: 'normale',
            date: new Date().toISOString().split('T')[0],
            objet: '',
            expediteur: '',
            numeroEmission: '',
            destinateur: '',
            numeroReference: '',
            files: []
        });
        const [saving, setSaving] = React.useState(false);

        React.useEffect(() => {
            updateNextNumberPreview();
        }, [activeTab, user]);

        const updateNextNumberPreview = async () => {
            try {
                const preview = await previewNextNumber(activeTab, user.direction, new Date().getFullYear());
                setNextNumber(preview);
            } catch (error) {
                console.error('Erreur preview numéro:', error);
                setNextNumber(`${activeTab === 'arrive' ? 'A' : 'D'}-0001-${user.direction}-${new Date().getFullYear()}`);
            }
        };

        const handleSubmit = async (e) => {
            e.preventDefault();
            setSaving(true);
            
            try {
                // Générer le numéro définitif avec incrémentation
                const mailNumber = await getNextMailNumber(activeTab, user.direction, new Date().getFullYear());
                
                const mailData = {
                    numero: mailNumber,
                    type: activeTab,
                    priority: formData.priority,
                    date: formData.date,
                    objet: formData.objet,
                    expediteur: activeTab === 'arrive' ? formData.expediteur : user.name,
                    destinateur: activeTab === 'depart' ? formData.destinateur : '',
                    numeroEmission: formData.numeroEmission,
                    numeroReference: formData.numeroReference,
                    status: 'attente',
                    direction: user.direction,
                    createdBy: user.id,
                    createdByName: user.name,
                    files: formData.files,
                    createdAt: new Date().toISOString()
                };

                await trickleCreateObject(`mail:${user.direction}`, mailData);
                alert(`Courrier enregistré avec succès!\nNuméro: ${mailNumber}`);
                
                // Reset form et mettre à jour le preview
                setFormData({
                    priority: 'normale',
                    date: new Date().toISOString().split('T')[0],
                    objet: '',
                    expediteur: '',
                    numeroEmission: '',
                    destinateur: '',
                    numeroReference: '',
                    files: []
                });
                updateNextNumberPreview();
            } catch (error) {
                if (error.message.includes('Limite de numérotation atteinte')) {
                    alert('Limite de numérotation atteinte (9999) pour cette année. Contactez l\'administrateur.');
                } else {
                    alert('Erreur lors de l\'enregistrement');
                }
                console.error('Error saving mail:', error);
            } finally {
                setSaving(false);
            }
        };

        const handleChange = (field, value) => {
            setFormData(prev => ({ ...prev, [field]: value }));
        };

        const handleFileChange = (e) => {
            const files = Array.from(e.target.files).map(file => ({
                name: file.name,
                size: file.size,
                type: file.type
            }));
            setFormData(prev => ({ ...prev, files }));
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'new-mail',
            'data-file': 'components/NewMail.js'
        }, [
            React.createElement('h2', {
                key: 'title',
                className: 'text-2xl font-bold text-gray-800 mb-6'
            }, 'Nouveau Courrier'),
            React.createElement('div', {
                key: 'tabs',
                className: 'flex mb-6 bg-gray-100 rounded-lg p-1'
            }, [
                React.createElement('button', {
                    key: 'arrive-tab',
                    onClick: () => setActiveTab('arrive'),
                    className: `flex-1 py-2 px-4 rounded-md transition-colors ${
                        activeTab === 'arrive' ? 'bg-white text-blue-600 shadow' : 'text-gray-600'
                    }`
                }, 'Courrier Arrivé'),
                React.createElement('button', {
                    key: 'depart-tab',
                    onClick: () => setActiveTab('depart'),
                    className: `flex-1 py-2 px-4 rounded-md transition-colors ${
                        activeTab === 'depart' ? 'bg-white text-blue-600 shadow' : 'text-gray-600'
                    }`
                }, 'Courrier Départ')
            ]),
            React.createElement('form', {
                key: 'form',
                onSubmit: handleSubmit,
                className: 'bg-white rounded-lg shadow-md p-6 space-y-4'
            }, [
                React.createElement('div', {
                    key: 'info-banner',
                    className: 'bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4'
                }, [
                    React.createElement('p', {
                        key: 'numbering-info',
                        className: 'text-sm text-blue-700'
                    }, `📋 Prochain numéro: ${nextNumber}`)
                ]),
                React.createElement('div', {
                    key: 'priority-date',
                    className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                }, [
                    React.createElement('div', { key: 'priority-field' }, [
                        React.createElement('label', {
                            key: 'priority-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Priorité'),
                        React.createElement('select', {
                            key: 'priority-select',
                            value: formData.priority,
                            onChange: (e) => handleChange('priority', e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                        }, PRIORITIES.map(p => 
                            React.createElement('option', { key: p.value, value: p.value }, p.label)
                        ))
                    ]),
                    React.createElement('div', { key: 'date-field' }, [
                        React.createElement('label', {
                            key: 'date-label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, 'Date d\'émission'),
                        React.createElement('input', {
                            key: 'date-input',
                            type: 'date',
                            value: formData.date,
                            onChange: (e) => handleChange('date', e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                            required: true
                        })
                    ])
                ]),
                React.createElement('div', { key: 'objet-field' }, [
                    React.createElement('label', {
                        key: 'objet-label',
                        className: 'block text-sm font-medium text-gray-700 mb-2'
                    }, 'Objet'),
                    React.createElement('input', {
                        key: 'objet-input',
                        type: 'text',
                        value: formData.objet,
                        onChange: (e) => handleChange('objet', e.target.value),
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                        required: true
                    })
                ]),
                activeTab === 'arrive' ? [
                    React.createElement('div', {
                        key: 'arrive-fields',
                        className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                    }, [
                        React.createElement('div', { key: 'expediteur' }, [
                            React.createElement('label', {
                                key: 'expediteur-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Expéditeur'),
                            React.createElement('input', {
                                key: 'expediteur-input',
                                type: 'text',
                                value: formData.expediteur,
                                onChange: (e) => handleChange('expediteur', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                                required: true
                            })
                        ]),
                        React.createElement('div', { key: 'numero-emission' }, [
                            React.createElement('label', {
                                key: 'numero-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Numéro d\'émission'),
                            React.createElement('input', {
                                key: 'numero-input',
                                type: 'text',
                                value: formData.numeroEmission,
                                onChange: (e) => handleChange('numeroEmission', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                            })
                        ])
                    ])
                ] : [
                    React.createElement('div', {
                        key: 'depart-fields',
                        className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
                    }, [
                        React.createElement('div', { key: 'destinateur' }, [
                            React.createElement('label', {
                                key: 'destinateur-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Destinateur'),
                            React.createElement('input', {
                                key: 'destinateur-input',
                                type: 'text',
                                value: formData.destinateur,
                                onChange: (e) => handleChange('destinateur', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500',
                                required: true
                            })
                        ]),
                        React.createElement('div', { key: 'numero-reference' }, [
                            React.createElement('label', {
                                key: 'reference-label',
                                className: 'block text-sm font-medium text-gray-700 mb-2'
                            }, 'Numéro de référence'),
                            React.createElement('input', {
                                key: 'reference-input',
                                type: 'text',
                                value: formData.numeroReference,
                                onChange: (e) => handleChange('numeroReference', e.target.value),
                                className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                            })
                        ])
                    ])
                ],
                React.createElement('div', { key: 'files-field' }, [
                    React.createElement('label', {
                        key: 'files-label',
                        className: 'block text-sm font-medium text-gray-700 mb-2'
                    }, 'Fichiers joints'),
                    React.createElement('input', {
                        key: 'files-input',
                        type: 'file',
                        multiple: true,
                        accept: '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png',
                        onChange: handleFileChange,
                        className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                    }),
                    formData.files.length > 0 && React.createElement('div', {
                        key: 'files-list',
                        className: 'mt-2 text-sm text-gray-600'
                    }, `${formData.files.length} fichier(s) sélectionné(s)`)
                ]),
                React.createElement('button', {
                    key: 'submit',
                    type: 'submit',
                    disabled: saving,
                    className: 'btn-primary text-white px-6 py-2 rounded-md font-medium disabled:opacity-50'
                }, saving ? 'Enregistrement...' : 'Enregistrer')
            ])
        ]);
    } catch (error) {
        console.error('NewMail component error:', error);
        reportError(error);
    }
}

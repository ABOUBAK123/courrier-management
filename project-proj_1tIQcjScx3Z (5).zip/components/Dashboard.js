function Dashboard({ user }) {
    try {
        const [stats, setStats] = React.useState({
            total: 0,
            arrives: 0,
            departs: 0,
            attente: 0,
            traites: 0
        });

        React.useEffect(() => {
            loadStats();
        }, [user]);

        const loadStats = async () => {
            try {
                const mails = await trickleListObjects(`mail:${user.direction}`, 100, true);
                const mailData = mails.items.map(item => item.objectData);
                
                setStats({
                    total: mailData.length,
                    arrives: mailData.filter(m => m.type === 'arrive').length,
                    departs: mailData.filter(m => m.type === 'depart').length,
                    attente: mailData.filter(m => m.status === 'attente').length,
                    traites: mailData.filter(m => m.status === 'traite').length
                });
            } catch (error) {
                console.error('Erreur lors du chargement des statistiques:', error);
            }
        };

        const statCards = [
            { title: 'Total Courriers', value: stats.total, icon: 'fas fa-envelope', color: 'bg-blue-500' },
            { title: 'Courriers Arrivés', value: stats.arrives, icon: 'fas fa-inbox', color: 'bg-green-500' },
            { title: 'Courriers Départ', value: stats.departs, icon: 'fas fa-paper-plane', color: 'bg-purple-500' },
            { title: 'En Attente', value: stats.attente, icon: 'fas fa-clock', color: 'bg-yellow-500' },
            { title: 'Traités', value: stats.traites, icon: 'fas fa-check-circle', color: 'bg-emerald-500' }
        ];

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'dashboard',
            'data-file': 'components/Dashboard.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'mb-8'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800 mb-2'
                }, 'Tableau de Bord'),
                React.createElement('p', {
                    key: 'subtitle',
                    className: 'text-gray-600'
                }, `Direction: ${user?.direction || 'Non définie'}`)
            ]),
            React.createElement('div', {
                key: 'stats-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8'
            }, statCards.map((card, index) =>
                React.createElement('div', {
                    key: index,
                    className: 'bg-white rounded-xl shadow-md p-6 card-hover'
                }, [
                    React.createElement('div', {
                        key: 'card-content',
                        className: 'flex items-center'
                    }, [
                        React.createElement('div', {
                            key: 'icon-container',
                            className: `${card.color} p-3 rounded-lg`
                        }, [
                            React.createElement('i', {
                                key: 'icon',
                                className: `${card.icon} text-white text-xl`
                            })
                        ]),
                        React.createElement('div', {
                            key: 'card-info',
                            className: 'ml-4'
                        }, [
                            React.createElement('p', {
                                key: 'card-title',
                                className: 'text-sm font-medium text-gray-600'
                            }, card.title),
                            React.createElement('p', {
                                key: 'card-value',
                                className: 'text-2xl font-bold text-gray-900'
                            }, card.value)
                        ])
                    ])
                ])
            )),
            React.createElement('div', {
                key: 'quick-actions',
                className: 'bg-white rounded-xl shadow-md p-6'
            }, [
                React.createElement('h3', {
                    key: 'actions-title',
                    className: 'text-lg font-semibold text-gray-800 mb-4'
                }, 'Actions Rapides'),
                React.createElement('div', {
                    key: 'actions-grid',
                    className: 'grid grid-cols-1 md:grid-cols-3 gap-4'
                }, [
                    React.createElement('button', {
                        key: 'new-mail',
                        className: 'flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors'
                    }, [
                        React.createElement('i', {
                            key: 'new-icon',
                            className: 'fas fa-plus text-blue-600 mr-3'
                        }),
                        React.createElement('span', {
                            key: 'new-text',
                            className: 'text-blue-800 font-medium'
                        }, 'Nouveau Courrier')
                    ]),
                    React.createElement('button', {
                        key: 'search',
                        className: 'flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors'
                    }, [
                        React.createElement('i', {
                            key: 'search-icon',
                            className: 'fas fa-search text-green-600 mr-3'
                        }),
                        React.createElement('span', {
                            key: 'search-text',
                            className: 'text-green-800 font-medium'
                        }, 'Rechercher')
                    ]),
                    React.createElement('button', {
                        key: 'reports',
                        className: 'flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors'
                    }, [
                        React.createElement('i', {
                            key: 'reports-icon',
                            className: 'fas fa-chart-bar text-purple-600 mr-3'
                        }),
                        React.createElement('span', {
                            key: 'reports-text',
                            className: 'text-purple-800 font-medium'
                        }, 'Rapports')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('Dashboard component error:', error);
        reportError(error);
    }
}

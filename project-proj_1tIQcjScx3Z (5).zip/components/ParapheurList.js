function ParapheurList({ user }) {
    try {
        const [parapheurs, setParapheurs] = React.useState([]);
        const [showNewForm, setShowNewForm] = React.useState(false);
        const [showPDFViewer, setShowPDFViewer] = React.useState(false);
        const [selectedParapheur, setSelectedParapheur] = React.useState(null);

        React.useEffect(() => {
            loadParapheurs();
        }, [user]);

        const loadParapheurs = async () => {
            try {
                const response = await trickleListObjects('parapheurs', 100, true);
                const allParapheurs = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                
                const userParapheurs = allParapheurs.filter(parapheur => {
                    const isInitiator = parapheur.createdBy === user.email || 
                                       parapheur.proprietaire === user.name ||
                                       parapheur.proprietaireEmail === user.email;
                    
                    const isValidator = parapheur.validations?.some(v => 
                        v.utilisateur === user.email || v.utilisateur === user.name
                    );
                    
                    const isSigner = parapheur.signatures?.some(s => 
                        s.utilisateur === user.email || s.utilisateur === user.name
                    );
                    
                    return isInitiator || isValidator || isSigner;
                });
                
                setParapheurs(userParapheurs);
            } catch (error) {
                console.error('Erreur lors du chargement:', error);
            }
        };

        const calculateProgress = (parapheur) => {
            const totalSteps = (parapheur.validations?.length || 0) + (parapheur.signatures?.length || 0);
            if (totalSteps === 0) return 0;
            
            const completedValidations = parapheur.validations?.filter(v => v.completed).length || 0;
            const completedSignatures = parapheur.signatures?.filter(s => s.completed).length || 0;
            const completedSteps = completedValidations + completedSignatures;
            
            return Math.round((completedSteps / totalSteps) * 100);
        };

        const getCurrentWorkflowStep = (parapheur) => {
            if (parapheur.validations?.length > 0) {
                const sortedValidations = parapheur.validations.sort((a, b) => a.ordre - b.ordre);
                for (const validation of sortedValidations) {
                    if (!validation.completed) {
                        return { type: 'validation', ...validation };
                    }
                }
            }
            
            if (parapheur.signatures?.length > 0) {
                const sortedSignatures = parapheur.signatures.sort((a, b) => a.ordre - b.ordre);
                for (const signature of sortedSignatures) {
                    if (!signature.completed) {
                        return { type: 'signature', ...signature };
                    }
                }
            }
            
            return null;
        };

        const getUserAction = (parapheur) => {
            if (parapheur.status === 'signe' || parapheur.status === 'arrete') {
                return null;
            }
            
            const currentStep = getCurrentWorkflowStep(parapheur);
            
            if (currentStep && (currentStep.utilisateur === user.email || currentStep.utilisateur === user.name)) {
                return currentStep.type;
            }
            
            return null;
        };

        const getParapheurStatus = (parapheur) => {
            if (parapheur.status === 'signe') return 'Signé';
            
            const allValidationsCompleted = !parapheur.validations?.length || 
                                           parapheur.validations.every(v => v.completed);
            
            if (allValidationsCompleted && parapheur.signatures?.length > 0) {
                return 'Validé';
            }
            
            return 'Démarré';
        };

        const handleViewDocument = (parapheur) => {
            console.log('📄 Ouverture PDF avec zones de signature:', {
                nom: parapheur.nom,
                signataires: parapheur.signatures?.length || 0,
                showSignatureZones: true
            });
            
            setSelectedParapheur(parapheur);
            setShowPDFViewer(true);
        };

        const handleValidate = async (parapheur) => {
            try {
                const currentStep = getCurrentWorkflowStep(parapheur);
                if (!currentStep || currentStep.type !== 'validation') return;
                
                const updatedValidations = parapheur.validations.map(v => 
                    v.ordre === currentStep.ordre ? { 
                        ...v, 
                        completed: true, 
                        completedBy: user.email, 
                        completedAt: new Date().toISOString() 
                    } : v
                );
                
                await trickleUpdateObject('parapheurs', parapheur.id, {
                    ...parapheur,
                    validations: updatedValidations,
                    progression: calculateProgress({ ...parapheur, validations: updatedValidations })
                });
                
                alert('Validation effectuée avec succès');
                loadParapheurs();
            } catch (error) {
                alert('Erreur lors de la validation');
            }
        };

        const handleSign = async (parapheur) => {
            try {
                const currentStep = getCurrentWorkflowStep(parapheur);
                if (!currentStep || currentStep.type !== 'signature') return;
                
                const updatedSignatures = parapheur.signatures.map(s => 
                    s.ordre === currentStep.ordre ? { 
                        ...s, 
                        completed: true, 
                        completedBy: user.email, 
                        completedAt: new Date().toISOString() 
                    } : s
                );
                
                const allCompleted = updatedSignatures.every(s => s.completed) && 
                                   (parapheur.validations?.every(v => v.completed) || !parapheur.validations?.length);
                
                await trickleUpdateObject('parapheurs', parapheur.id, {
                    ...parapheur,
                    signatures: updatedSignatures,
                    status: allCompleted ? 'signe' : parapheur.status,
                    progression: allCompleted ? 100 : calculateProgress({ ...parapheur, signatures: updatedSignatures })
                });
                
                alert('Signature effectuée avec succès');
                loadParapheurs();
            } catch (error) {
                alert('Erreur lors de la signature');
            }
        };

        return React.createElement('div', {
            className: 'p-6 fade-in',
            'data-name': 'parapheur-list',
            'data-file': 'components/ParapheurList.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center mb-6'
            }, [
                React.createElement('h2', {
                    key: 'title',
                    className: 'text-2xl font-bold text-gray-800'
                }, 'Liste des Parapheurs'),
                React.createElement('button', {
                    key: 'new-btn',
                    onClick: () => setShowNewForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Nouveau Parapheur')
            ]),
            parapheurs.length === 0 ? React.createElement('div', {
                key: 'no-parapheurs',
                className: 'bg-white rounded-lg shadow-md p-8 text-center text-gray-500'
            }, 'Aucun parapheur trouvé') : React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Nom', 'Propriétaire', 'Signataires', 'Statut', 'Progression', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, parapheurs.map(parapheur => {
                        const progress = calculateProgress(parapheur);
                        const userAction = getUserAction(parapheur);
                        const status = getParapheurStatus(parapheur);
                        const signaturesCount = parapheur.signatures?.length || 0;
                        
                        return React.createElement('tr', {
                            key: parapheur.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'nom',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, parapheur.nom),
                            React.createElement('td', {
                                key: 'proprietaire',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, parapheur.proprietaire),
                            React.createElement('td', {
                                key: 'signataires',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, `${signaturesCount} zone(s)`),
                            React.createElement('td', {
                                key: 'status',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('span', {
                                    key: 'status-badge',
                                    className: `px-2 py-1 text-xs font-medium rounded-full ${
                                        status === 'Démarré' ? 'bg-blue-100 text-blue-800' :
                                        status === 'Validé' ? 'bg-yellow-100 text-yellow-800' :
                                        status === 'Signé' ? 'bg-green-100 text-green-800' :
                                        'bg-gray-100 text-gray-800'
                                    }`
                                }, status)
                            ]),
                            React.createElement('td', {
                                key: 'progress',
                                className: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900'
                            }, `${progress}%`),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'view',
                                    onClick: () => handleViewDocument(parapheur),
                                    className: 'text-blue-600 hover:text-blue-900 mr-2 font-bold'
                                }, '👁️ Voir PDF'),
                                userAction === 'validation' && React.createElement('button', {
                                    key: 'validate',
                                    onClick: () => handleValidate(parapheur),
                                    className: 'bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 mr-2'
                                }, 'Valider'),
                                userAction === 'signature' && React.createElement('button', {
                                    key: 'sign',
                                    onClick: () => handleSign(parapheur),
                                    className: 'bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700'
                                }, 'Signer')
                            ])
                        ]);
                    }))
                ])
            ]),
            showNewForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-4xl max-h-screen overflow-y-auto'
                }, [
                    React.createElement('div', {
                        key: 'modal-header',
                        className: 'flex justify-between items-center mb-4'
                    }, [
                        React.createElement('h3', {
                            key: 'modal-title',
                            className: 'text-lg font-semibold'
                        }, 'Nouveau Parapheur'),
                        React.createElement('button', {
                            key: 'close-btn',
                            onClick: () => setShowNewForm(false),
                            className: 'text-gray-500 hover:text-gray-700'
                        }, '✕')
                    ]),
                    React.createElement(NouveauParapheur, {
                        key: 'new-form',
                        user,
                        onClose: () => {
                            setShowNewForm(false);
                            loadParapheurs();
                        }
                    })
                ])
            ]),
            showPDFViewer && selectedParapheur && React.createElement(PDFViewer, {
                key: 'pdf-viewer',
                documentUrl: selectedParapheur.documents?.[0]?.url || 'data:application/pdf;base64,JVBERi0xLjQKJdPr6eEKMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovUGFnZXMgMiAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1R5cGUgL1BhZ2VzCi9LaWRzIFszIDAgUl0KL0NvdW50IDEKPD4KZW5kb2JqCjMgMCBvYmoKPDwKL1R5cGUgL1BhZ2UKL1BhcmVudCAyIDAgUgovTWVkaWFCb3ggWzAgMCA2MTIgNzkyXQo+PgplbmRvYmoKeHJlZgo=',
                onClose: () => setShowPDFViewer(false),
                signaturesCount: selectedParapheur.signatures?.length || 0,
                showSignatureZones: true,
                onSaveSignatureZone: (zone) => {
                    console.log('Zone sauvegardée:', zone);
                }
            })
        ]);
    } catch (error) {
        console.error('ParapheurList component error:', error);
        reportError(error);
    }
}

function EmployeeFormTab2({ formData, handleInputChange }) {
    try {
        const [directions, setDirections] = React.useState([]);

        React.useEffect(() => {
            loadDirections();
        }, []);

        const loadDirections = async () => {
            try {
                const response = await trickleListObjects('directions', 100, true);
                const directionData = response.items.map(item => item.objectData);
                setDirections(directionData);
            } catch (error) {
                console.error('Erreur lors du chargement des directions:', error);
            }
        };

        const getDirectionsByType = (type) => {
            return directions.filter(dir => dir.typeDirection === type);
        };

        const professionalSelects = [
            {
                key: 'directionGenerale',
                label: 'Direction Générale',
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('DIRECTION GENERAL').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            {
                key: 'directionCentrale',
                label: 'Direction Centrale',
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('DIRECTION').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            {
                key: 'sousDirection',
                label: 'Sous-Direction',
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('SOUS-DIRECTION').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            {
                key: 'service',
                label: 'Service',
                options: [
                    { value: '', label: 'Sélectionner' },
                    ...getDirectionsByType('SERVICES').map(dir => ({
                        value: dir.code,
                        label: `${dir.code} - ${dir.nomDirection}`
                    }))
                ]
            },
            {
                key: 'categorie',
                label: 'Catégorie',
                options: [
                    { value: '', label: 'Sélectionner' },
                    { value: 'A', label: 'Catégorie A' },
                    { value: 'B', label: 'Catégorie B' },
                    { value: 'C', label: 'Catégorie C' },
                    { value: 'D', label: 'Catégorie D' }
                ]
            },
            {
                key: 'grade',
                label: 'Grade',
                options: [
                    { value: '', label: 'Sélectionner' },
                    { value: 'DIRECTEUR', label: 'Directeur' },
                    { value: 'SOUS-DIRECTEUR', label: 'Sous-Directeur' },
                    { value: 'CHEF DE SERVICE', label: 'Chef de Service' },
                    { value: 'CHEF DE BUREAU', label: 'Chef de Bureau' },
                    { value: 'INGENIEUR', label: 'Ingénieur' },
                    { value: 'TECHNICIEN', label: 'Technicien' },
                    { value: 'ASSISTANT', label: 'Assistant' },
                    { value: 'AGENT', label: 'Agent' }
                ]
            }
        ];

        const textFields = [
            { key: 'emploi', label: 'Emploi', type: 'text' },
            { key: 'lieuTravail', label: 'Lieu de Travail', type: 'text' }
        ];

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'employee-form-tab2',
            'data-file': 'components/EmployeeFormTab2.js'
        }, [
            React.createElement('h4', {
                key: 'title',
                className: 'text-lg font-medium text-gray-800 border-b pb-2'
            }, '🏢 Informations Professionnelles'),
            React.createElement('div', {
                key: 'fields-grid',
                className: 'grid grid-cols-1 md:grid-cols-2 gap-4'
            }, [
                ...professionalSelects.map(field =>
                    React.createElement('div', {
                        key: field.key
                    }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, field.label),
                        React.createElement('select', {
                            key: 'select',
                            value: formData[field.key] || '',
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                        }, field.options.map(option =>
                            React.createElement('option', {
                                key: option.value,
                                value: option.value
                            }, option.label)
                        ))
                    ])
                ),
                ...textFields.map(field =>
                    React.createElement('div', {
                        key: field.key
                    }, [
                        React.createElement('label', {
                            key: 'label',
                            className: 'block text-sm font-medium text-gray-700 mb-2'
                        }, field.label),
                        React.createElement('input', {
                            key: 'input',
                            type: field.type,
                            value: formData[field.key] || '',
                            onChange: (e) => handleInputChange(field.key, e.target.value),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                        })
                    ])
                )
            ]),
            React.createElement('div', {
                key: 'summary',
                className: 'bg-green-50 border border-green-200 rounded-lg p-4'
            }, [
                React.createElement('h5', {
                    key: 'summary-title',
                    className: 'font-medium text-green-800 mb-2'
                }, '📋 Résumé du profil'),
                React.createElement('p', {
                    key: 'summary-text',
                    className: 'text-sm text-green-700'
                }, `${formData.nom || 'Nom'} ${formData.prenom || 'Prénom'} - ${formData.grade || 'Grade'} - ${formData.directionCentrale || 'Direction'}`)
            ])
        ]);
    } catch (error) {
        console.error('EmployeeFormTab2 component error:', error);
        reportError(error);
    }
}

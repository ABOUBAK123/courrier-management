function GestionConge({ user }) {
    try {
        const [conges, setConges] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);
        const [formData, setFormData] = React.useState({
            employe: '',
            typeConge: '',
            dateDebut: '',
            dateFin: '',
            motif: ''
        });

        React.useEffect(() => {
            loadConges();
        }, [user]);

        const loadConges = async () => {
            try {
                const response = await trickleListObjects(`conge:${user.direction}`, 100, true);
                const congeData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setConges(congeData);
            } catch (error) {
                console.error('Erreur chargement congés:', error);
            }
        };

        const handleSave = async () => {
            try {
                await trickleCreateObject(`conge:${user.direction}`, {
                    ...formData,
                    status: 'attente',
                    demandePar: user.name,
                    createdAt: new Date().toISOString()
                });
                
                alert('Demande de congé soumise avec succès!');
                setFormData({ employe: '', typeConge: '', dateDebut: '', dateFin: '', motif: '' });
                setShowForm(false);
                loadConges();
            } catch (error) {
                alert('Erreur lors de la soumission');
            }
        };

        const handleApprove = async (congeId) => {
            try {
                const conge = conges.find(c => c.id === congeId);
                await trickleUpdateObject(`conge:${user.direction}`, congeId, {
                    ...conge,
                    status: 'approuve',
                    approuvePar: user.name,
                    dateApprobation: new Date().toISOString()
                });
                alert('Congé approuvé');
                loadConges();
            } catch (error) {
                alert('Erreur lors de l\'approbation');
            }
        };

        const getStatusColor = (status) => {
            switch (status) {
                case 'attente': return 'bg-yellow-100 text-yellow-800';
                case 'approuve': return 'bg-green-100 text-green-800';
                case 'refuse': return 'bg-red-100 text-red-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        };

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'gestion-conge',
            'data-file': 'components/GestionConge.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold text-gray-800'
                }, 'Gestion des Congés'),
                React.createElement('button', {
                    key: 'add-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, 'Demander Congé')
            ]),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Employé', 'Type', 'Date Début', 'Date Fin', 'Statut', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, conges.map(conge =>
                        React.createElement('tr', {
                            key: conge.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'employe',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, conge.employe),
                            React.createElement('td', {
                                key: 'type',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, conge.typeConge),
                            React.createElement('td', {
                                key: 'debut',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, new Date(conge.dateDebut).toLocaleDateString()),
                            React.createElement('td', {
                                key: 'fin',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, new Date(conge.dateFin).toLocaleDateString()),
                            React.createElement('td', {
                                key: 'status',
                                className: 'px-6 py-4 whitespace-nowrap'
                            }, [
                                React.createElement('span', {
                                    key: 'status-badge',
                                    className: `px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(conge.status)}`
                                }, conge.status)
                            ]),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium'
                            }, conge.status === 'attente' && [
                                React.createElement('button', {
                                    key: 'approve',
                                    onClick: () => handleApprove(conge.id),
                                    className: 'text-green-600 hover:text-green-900 mr-2'
                                }, 'Approuver')
                            ])
                        ])
                    ))
                ])
            ]),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-md'
                }, [
                    React.createElement('h3', {
                        key: 'modal-title',
                        className: 'text-lg font-semibold mb-4'
                    }, 'Demande de Congé'),
                    React.createElement('div', {
                        key: 'form',
                        className: 'space-y-4'
                    }, [
                        React.createElement('input', {
                            key: 'employe',
                            type: 'text',
                            placeholder: 'Nom employé',
                            value: formData.employe,
                            onChange: (e) => setFormData(prev => ({ ...prev, employe: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('select', {
                            key: 'type',
                            value: formData.typeConge,
                            onChange: (e) => setFormData(prev => ({ ...prev, typeConge: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default', value: '' }, 'Type de congé'),
                            React.createElement('option', { key: 'annuel', value: 'annuel' }, 'Congé annuel'),
                            React.createElement('option', { key: 'maladie', value: 'maladie' }, 'Congé maladie'),
                            React.createElement('option', { key: 'maternite', value: 'maternite' }, 'Congé maternité')
                        ]),
                        React.createElement('input', {
                            key: 'debut',
                            type: 'date',
                            value: formData.dateDebut,
                            onChange: (e) => setFormData(prev => ({ ...prev, dateDebut: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('input', {
                            key: 'fin',
                            type: 'date',
                            value: formData.dateFin,
                            onChange: (e) => setFormData(prev => ({ ...prev, dateFin: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md'
                        }),
                        React.createElement('textarea', {
                            key: 'motif',
                            placeholder: 'Motif (optionnel)',
                            value: formData.motif,
                            onChange: (e) => setFormData(prev => ({ ...prev, motif: e.target.value })),
                            className: 'w-full px-3 py-2 border border-gray-300 rounded-md',
                            rows: 3
                        })
                    ]),
                    React.createElement('div', {
                        key: 'buttons',
                        className: 'flex space-x-4 mt-6'
                    }, [
                        React.createElement('button', {
                            key: 'save',
                            onClick: handleSave,
                            className: 'flex-1 btn-primary text-white py-2 rounded-md'
                        }, 'Soumettre'),
                        React.createElement('button', {
                            key: 'cancel',
                            onClick: () => setShowForm(false),
                            className: 'flex-1 bg-gray-500 text-white py-2 rounded-md hover:bg-gray-600'
                        }, 'Annuler')
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('GestionConge component error:', error);
        reportError(error);
    }
}

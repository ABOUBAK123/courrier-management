function PersonnelList({ user }) {
    try {
        const [personnel, setPersonnel] = React.useState([]);
        const [showForm, setShowForm] = React.useState(false);

        React.useEffect(() => {
            loadPersonnel();
        }, [user]);

        const loadPersonnel = async () => {
            try {
                const response = await trickleListObjects(`personnel:${user.direction}`, 100, true);
                const personnelData = response.items.map(item => ({
                    ...item.objectData,
                    id: item.objectId
                }));
                setPersonnel(personnelData);
            } catch (error) {
                console.error('Erreur chargement personnel:', error);
            }
        };

        const handleDelete = async (id) => {
            if (confirm('Êtes-vous sûr de vouloir supprimer cet employé?')) {
                try {
                    await trickleDeleteObject(`personnel:${user.direction}`, id);
                    alert('Employé supprimé avec succès');
                    loadPersonnel();
                } catch (error) {
                    alert('Erreur lors de la suppression');
                }
            }
        };

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'personnel-list',
            'data-file': 'components/PersonnelList.js'
        }, [
            React.createElement('div', {
                key: 'header',
                className: 'flex justify-between items-center'
            }, [
                React.createElement('h3', {
                    key: 'title',
                    className: 'text-lg font-semibold text-gray-800'
                }, 'Liste du Personnel'),
                React.createElement('button', {
                    key: 'add-btn',
                    onClick: () => setShowForm(true),
                    className: 'btn-primary text-white px-4 py-2 rounded-lg'
                }, [
                    React.createElement('i', {
                        key: 'icon',
                        className: 'fas fa-user-plus mr-2'
                    }),
                    'Nouvel Employé'
                ])
            ]),
            React.createElement('div', {
                key: 'table-container',
                className: 'bg-white rounded-lg shadow-md overflow-hidden'
            }, [
                React.createElement('table', {
                    key: 'table',
                    className: 'w-full'
                }, [
                    React.createElement('thead', {
                        key: 'thead',
                        className: 'bg-gray-50'
                    }, [
                        React.createElement('tr', { key: 'header-row' }, [
                            'Matricule', 'Nom & Prénoms', 'Email', 'Poste', 'Grade', 'Actions'
                        ].map(header => 
                            React.createElement('th', {
                                key: header,
                                className: 'px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase'
                            }, header)
                        ))
                    ]),
                    React.createElement('tbody', {
                        key: 'tbody',
                        className: 'bg-white divide-y divide-gray-200'
                    }, personnel.map(person =>
                        React.createElement('tr', {
                            key: person.id,
                            className: 'hover:bg-gray-50'
                        }, [
                            React.createElement('td', {
                                key: 'matricule',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'
                            }, person.matricule || '-'),
                            React.createElement('td', {
                                key: 'nom',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, `${person.nom} ${person.prenom}`),
                            React.createElement('td', {
                                key: 'email',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, person.email),
                            React.createElement('td', {
                                key: 'poste',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, person.emploi || person.poste || '-'),
                            React.createElement('td', {
                                key: 'grade',
                                className: 'px-6 py-4 text-sm text-gray-900'
                            }, person.grade || '-'),
                            React.createElement('td', {
                                key: 'actions',
                                className: 'px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2'
                            }, [
                                React.createElement('button', {
                                    key: 'edit',
                                    className: 'text-blue-600 hover:text-blue-900 mr-2'
                                }, [
                                    React.createElement('i', {
                                        key: 'edit-icon',
                                        className: 'fas fa-edit'
                                    })
                                ]),
                                React.createElement('button', {
                                    key: 'delete',
                                    onClick: () => handleDelete(person.id),
                                    className: 'text-red-600 hover:text-red-900'
                                }, [
                                    React.createElement('i', {
                                        key: 'delete-icon',
                                        className: 'fas fa-trash'
                                    })
                                ])
                            ])
                        ])
                    ))
                ])
            ]),
            showForm && React.createElement('div', {
                key: 'modal',
                className: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'modal-content',
                    className: 'bg-white rounded-lg p-6 w-full max-w-4xl max-h-screen overflow-y-auto'
                }, [
                    React.createElement('div', {
                        key: 'modal-header',
                        className: 'flex justify-between items-center mb-4'
                    }, [
                        React.createElement('h3', {
                            key: 'modal-title',
                            className: 'text-lg font-semibold'
                        }, 'Nouvel Employé'),
                        React.createElement('button', {
                            key: 'close-btn',
                            onClick: () => setShowForm(false),
                            className: 'text-gray-500 hover:text-gray-700'
                        }, [
                            React.createElement('i', {
                                key: 'close-icon',
                                className: 'fas fa-times'
                            })
                        ])
                    ]),
                    React.createElement(EmployeeForm, {
                        key: 'employee-form',
                        user,
                        onClose: () => {
                            setShowForm(false);
                            loadPersonnel();
                        }
                    })
                ])
            ])
        ]);
    } catch (error) {
        console.error('PersonnelList component error:', error);
        reportError(error);
    }
}

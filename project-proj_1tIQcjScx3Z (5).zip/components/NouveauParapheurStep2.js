function NouveauParapheurStep2({ formData, users }) {
    try {
        const addValidationStep = () => {
            const newValidation = {
                id: Date.now(),
                utilisateur: '',
                ordre: formData.validations.length + 1,
                obligatoire: true
            };
            
            // Utiliser setFormData du parent pour synchroniser
            if (window.updateFormData) {
                window.updateFormData(prev => ({
                    ...prev,
                    validations: [...prev.validations, newValidation]
                }));
            }
        };

        const addSignatureStep = () => {
            const newSignature = {
                id: Date.now(),
                utilisateur: '',
                ordre: formData.signatures.length + 1,
                obligatoire: true
            };
            
            if (window.updateFormData) {
                window.updateFormData(prev => ({
                    ...prev,
                    signatures: [...prev.signatures, newSignature]
                }));
            }
        };

        const updateValidationStep = (id, field, value) => {
            if (window.updateFormData) {
                window.updateFormData(prev => ({
                    ...prev,
                    validations: prev.validations.map(v => 
                        v.id === id ? { ...v, [field]: value } : v
                    )
                }));
            }
        };

        const updateSignatureStep = (id, field, value) => {
            if (window.updateFormData) {
                window.updateFormData(prev => ({
                    ...prev,
                    signatures: prev.signatures.map(s => 
                        s.id === id ? { ...s, [field]: value } : s
                    )
                }));
            }
        };

        const removeValidationStep = (id) => {
            if (window.updateFormData) {
                window.updateFormData(prev => ({
                    ...prev,
                    validations: prev.validations.filter(v => v.id !== id)
                }));
            }
        };

        const removeSignatureStep = (id) => {
            if (window.updateFormData) {
                window.updateFormData(prev => ({
                    ...prev,
                    signatures: prev.signatures.filter(s => s.id !== id)
                }));
            }
        };

        return React.createElement('div', {
            className: 'space-y-6',
            'data-name': 'nouveau-parapheur-step2',
            'data-file': 'components/NouveauParapheurStep2.js'
        }, [
            React.createElement('div', {
                key: 'validation-section',
                className: 'border p-4 rounded-lg bg-green-50'
            }, [
                React.createElement('div', {
                    key: 'validation-header',
                    className: 'flex justify-between items-center mb-4'
                }, [
                    React.createElement('h5', {
                        key: 'validation-title',
                        className: 'font-medium text-green-800'
                    }, '✅ Étapes de validation'),
                    React.createElement('button', {
                        key: 'add-validation',
                        onClick: addValidationStep,
                        className: 'bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700'
                    }, 'Ajouter')
                ]),
                React.createElement('div', {
                    key: 'validation-list',
                    className: 'space-y-3'
                }, formData.validations?.map(validation =>
                    React.createElement('div', {
                        key: validation.id,
                        className: 'flex items-center space-x-3 bg-white p-3 rounded border'
                    }, [
                        React.createElement('span', {
                            key: 'ordre',
                            className: 'w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold'
                        }, validation.ordre),
                        React.createElement('select', {
                            key: 'user-select',
                            value: validation.utilisateur,
                            onChange: (e) => updateValidationStep(validation.id, 'utilisateur', e.target.value),
                            className: 'flex-1 px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default', value: '' }, 'Choisir un validateur'),
                            ...users.map(u => 
                                React.createElement('option', { key: u.email, value: u.email }, `${u.name} - ${u.role}`)
                            )
                        ]),
                        React.createElement('button', {
                            key: 'remove',
                            onClick: () => removeValidationStep(validation.id),
                            className: 'text-red-600 hover:text-red-800'
                        }, [
                            React.createElement('i', { className: 'fas fa-trash' })
                        ])
                    ])
                ) || [])
            ]),
            React.createElement('div', {
                key: 'signature-section',
                className: 'border p-4 rounded-lg bg-blue-50'
            }, [
                React.createElement('div', {
                    key: 'signature-header',
                    className: 'flex justify-between items-center mb-4'
                }, [
                    React.createElement('h5', {
                        key: 'signature-title',
                        className: 'font-medium text-blue-800'
                    }, '✍️ Étapes de signature'),
                    React.createElement('button', {
                        key: 'add-signature',
                        onClick: addSignatureStep,
                        className: 'bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700'
                    }, 'Ajouter')
                ]),
                React.createElement('div', {
                    key: 'signature-list',
                    className: 'space-y-3'
                }, formData.signatures?.map(signature =>
                    React.createElement('div', {
                        key: signature.id,
                        className: 'flex items-center space-x-3 bg-white p-3 rounded border'
                    }, [
                        React.createElement('span', {
                            key: 'ordre',
                            className: 'w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold'
                        }, signature.ordre),
                        React.createElement('select', {
                            key: 'user-select',
                            value: signature.utilisateur,
                            onChange: (e) => updateSignatureStep(signature.id, 'utilisateur', e.target.value),
                            className: 'flex-1 px-3 py-2 border border-gray-300 rounded-md'
                        }, [
                            React.createElement('option', { key: 'default', value: '' }, 'Choisir un signataire'),
                            ...users.map(u => 
                                React.createElement('option', { key: u.email, value: u.email }, `${u.name} - ${u.role}`)
                            )
                        ]),
                        React.createElement('button', {
                            key: 'remove',
                            onClick: () => removeSignatureStep(signature.id),
                            className: 'text-red-600 hover:text-red-800'
                        }, [
                            React.createElement('i', { className: 'fas fa-trash' })
                        ])
                    ])
                ) || [])
            ])
        ]);
    } catch (error) {
        console.error('NouveauParapheurStep2 component error:', error);
        reportError(error);
    }
}

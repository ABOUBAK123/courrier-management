function PDFViewer({ documentUrl, onClose, onSaveSignatureZone, signaturesCount = 0, showSignatureZones = false }) {
    try {
        const [loading, setLoading] = React.useState(true);
        const [signatureZones, setSignatureZones] = React.useState([]);
        const [activeZone, setActiveZone] = React.useState(null);
        const [isDragging, setIsDragging] = React.useState(false);
        const [isResizing, setIsResizing] = React.useState(false);
        const [dragStart, setDragStart] = React.useState({ x: 0, y: 0 });
        const [editMode, setEditMode] = React.useState(true);
        const viewerRef = React.useRef(null);

        React.useEffect(() => {
            if (showSignatureZones && signaturesCount > 0) {
                const zones = [];
                const containerWidth = 800;
                const containerHeight = 600;
                
                for (let i = 0; i < signaturesCount; i++) {
                    const row = Math.floor(i / 3);
                    const col = i % 3;
                    
                    zones.push({
                        id: i + 1,
                        x: 50 + (col * 250),
                        y: 100 + (row * 120),
                        width: 180,
                        height: 80,
                        label: `SIGNATURE ${i + 1}`,
                        signerIndex: i
                    });
                }
                setSignatureZones(zones);
            }
            
            setTimeout(() => setLoading(false), 800);
        }, [signaturesCount, showSignatureZones]);

        const handleZoneMouseDown = (e, zoneId) => {
            if (!editMode) return;
            e.preventDefault();
            e.stopPropagation();
            
            const rect = e.currentTarget.getBoundingClientRect();
            const containerRect = viewerRef.current?.getBoundingClientRect();
            
            if (!containerRect) return;
            
            setActiveZone(zoneId);
            setIsDragging(true);
            setDragStart({
                x: e.clientX - rect.left,
                y: e.clientY - rect.top
            });
        };

        const handleResizeMouseDown = (e, zoneId) => {
            if (!editMode) return;
            e.preventDefault();
            e.stopPropagation();
            
            setActiveZone(zoneId);
            setIsResizing(true);
            setDragStart({
                x: e.clientX,
                y: e.clientY
            });
        };

        const handleMouseMove = (e) => {
            if (!editMode || (!isDragging && !isResizing)) return;
            
            const containerRect = viewerRef.current?.getBoundingClientRect();
            if (!containerRect) return;
            
            if (isDragging && activeZone) {
                const newX = e.clientX - containerRect.left - dragStart.x;
                const newY = e.clientY - containerRect.top - dragStart.y;
                
                setSignatureZones(prev => prev.map(zone => 
                    zone.id === activeZone ? {
                        ...zone,
                        x: Math.max(5, Math.min(newX, containerRect.width - zone.width - 5)),
                        y: Math.max(5, Math.min(newY, containerRect.height - zone.height - 5))
                    } : zone
                ));
            }
            
            if (isResizing && activeZone) {
                const zone = signatureZones.find(z => z.id === activeZone);
                if (!zone) return;
                
                const deltaX = e.clientX - dragStart.x;
                const deltaY = e.clientY - dragStart.y;
                
                const newWidth = Math.max(100, Math.min(zone.width + deltaX, 350));
                const newHeight = Math.max(50, Math.min(zone.height + deltaY, 150));
                
                setSignatureZones(prev => prev.map(z => 
                    z.id === activeZone ? { ...z, width: newWidth, height: newHeight } : z
                ));
                
                setDragStart({ x: e.clientX, y: e.clientY });
            }
        };

        const handleMouseUp = () => {
            setIsDragging(false);
            setIsResizing(false);
            setActiveZone(null);
        };

        React.useEffect(() => {
            if (isDragging || isResizing) {
                document.addEventListener('mousemove', handleMouseMove);
                document.addEventListener('mouseup', handleMouseUp);
                
                return () => {
                    document.removeEventListener('mousemove', handleMouseMove);
                    document.removeEventListener('mouseup', handleMouseUp);
                };
            }
        }, [isDragging, isResizing, activeZone, dragStart]);

        const saveZonesPositions = () => {
            if (onSaveSignatureZone) {
                onSaveSignatureZone(signatureZones);
            }
            
            const positions = signatureZones.map(zone => 
                `${zone.label}: (${Math.round(zone.x)}, ${Math.round(zone.y)}) ${Math.round(zone.width)}×${Math.round(zone.height)}px`
            ).join('\n');
            
            alert(`✅ Zones sauvegardées:\n${positions}`);
            onClose();
        };

        const resetZones = () => {
            if (confirm('Remettre les zones à leur position initiale ?')) {
                const zones = [];
                for (let i = 0; i < signaturesCount; i++) {
                    const row = Math.floor(i / 3);
                    const col = i % 3;
                    
                    zones.push({
                        id: i + 1,
                        x: 50 + (col * 250),
                        y: 100 + (row * 120),
                        width: 180,
                        height: 80,
                        label: `SIGNATURE ${i + 1}`,
                        signerIndex: i
                    });
                }
                setSignatureZones(zones);
            }
        };

        if (loading) {
            return React.createElement('div', {
                className: 'fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50'
            }, [
                React.createElement('div', {
                    key: 'loading',
                    className: 'bg-white rounded-lg p-8 text-center'
                }, [
                    React.createElement('div', {
                        key: 'spinner',
                        className: 'animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4'
                    }),
                    React.createElement('p', {
                        key: 'text',
                        className: 'text-gray-700'
                    }, 'Chargement du document PDF...')
                ])
            ]);
        }

        return React.createElement('div', {
            className: 'fixed inset-0 bg-black bg-opacity-90 flex flex-col z-50'
        }, [
            React.createElement('div', {
                key: 'toolbar',
                className: 'bg-gray-900 text-white p-4 flex justify-between items-center border-b border-gray-700'
            }, [
                React.createElement('div', {
                    key: 'title-section',
                    className: 'flex items-center space-x-4'
                }, [
                    React.createElement('h3', {
                        key: 'title',
                        className: 'text-lg font-bold'
                    }, `Positionnement des zones de signature (${signaturesCount} zone${signaturesCount > 1 ? 's' : ''})`),
                    React.createElement('span', {
                        key: 'mode-indicator',
                        className: `px-3 py-1 rounded-full text-xs font-medium ${
                            editMode ? 'bg-green-600 text-white' : 'bg-gray-600 text-gray-300'
                        }`
                    }, editMode ? '✏️ MODE ÉDITION' : '🔒 LECTURE SEULE')
                ]),
                React.createElement('div', {
                    key: 'buttons',
                    className: 'flex space-x-3'
                }, [
                    React.createElement('button', {
                        key: 'reset-btn',
                        onClick: resetZones,
                        className: 'bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded text-sm font-medium transition-colors'
                    }, [
                        React.createElement('i', { key: 'icon', className: 'fas fa-undo mr-2' }),
                        'Reset'
                    ]),
                    React.createElement('button', {
                        key: 'save-btn',
                        onClick: saveZonesPositions,
                        className: 'bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-sm font-medium transition-colors'
                    }, [
                        React.createElement('i', { key: 'icon', className: 'fas fa-save mr-2' }),
                        'Sauvegarder & Fermer'
                    ]),
                    React.createElement('button', {
                        key: 'close-btn',
                        onClick: onClose,
                        className: 'bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-sm font-medium transition-colors'
                    }, [
                        React.createElement('i', { key: 'icon', className: 'fas fa-times mr-2' }),
                        'Fermer'
                    ])
                ])
            ]),
            React.createElement('div', {
                key: 'viewer-container',
                ref: viewerRef,
                className: 'flex-1 relative bg-gray-200 overflow-hidden'
            }, [
                React.createElement('iframe', {
                    key: 'pdf-iframe',
                    src: documentUrl,
                    className: 'w-full h-full border-0',
                    title: 'Document PDF'
                }),
                showSignatureZones && signatureZones.map(zone =>
                    React.createElement('div', {
                        key: `signature-zone-${zone.id}`,
                        className: `absolute border-2 ${
                            activeZone === zone.id 
                                ? 'border-red-500 bg-red-100 shadow-2xl' 
                                : 'border-blue-500 bg-blue-100 hover:border-blue-700'
                        } bg-opacity-80 cursor-move select-none transition-all`,
                        style: {
                            left: `${zone.x}px`,
                            top: `${zone.y}px`,
                            width: `${zone.width}px`,
                            height: `${zone.height}px`,
                            zIndex: activeZone === zone.id ? 1000 : 100
                        },
                        onMouseDown: (e) => handleZoneMouseDown(e, zone.id),
                        title: `Zone ${zone.id} - Cliquer et glisser pour déplacer`
                    }, [
                        React.createElement('div', {
                            key: 'zone-content',
                            className: 'h-full flex flex-col items-center justify-center text-center p-2'
                        }, [
                            React.createElement('i', {
                                key: 'signature-icon',
                                className: `fas fa-signature text-xl ${
                                    activeZone === zone.id ? 'text-red-700' : 'text-blue-700'
                                } mb-1`
                            }),
                            React.createElement('div', {
                                key: 'zone-label',
                                className: `text-xs font-bold ${
                                    activeZone === zone.id ? 'text-red-800' : 'text-blue-800'
                                }`
                            }, zone.label),
                            React.createElement('div', {
                                key: 'zone-size',
                                className: `text-xs ${
                                    activeZone === zone.id ? 'text-red-600' : 'text-blue-600'
                                } mt-1`
                            }, `${Math.round(zone.width)}×${Math.round(zone.height)}`)
                        ]),
                        React.createElement('div', {
                            key: 'resize-handle',
                            className: `absolute bottom-0 right-0 w-4 h-4 ${
                                activeZone === zone.id ? 'bg-red-600' : 'bg-blue-600'
                            } cursor-se-resize opacity-80 hover:opacity-100`,
                            style: { 
                                transform: 'translate(50%, 50%)',
                                borderRadius: '50%'
                            },
                            onMouseDown: (e) => handleResizeMouseDown(e, zone.id),
                            title: 'Glisser pour redimensionner'
                        }, [
                            React.createElement('i', {
                                key: 'resize-icon',
                                className: 'fas fa-expand-arrows-alt text-white text-xs absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2'
                            })
                        ])
                    ])
                )
            ]),
            React.createElement('div', {
                key: 'help-bar',
                className: 'bg-blue-900 text-white p-3 text-center'
            }, [
                React.createElement('div', {
                    key: 'help-content',
                    className: 'flex items-center justify-center space-x-6 text-sm'
                }, [
                    React.createElement('span', {
                        key: 'drag-help',
                        className: 'flex items-center'
                    }, [
                        React.createElement('i', { key: 'icon1', className: 'fas fa-arrows-alt mr-2' }),
                        'Glisser pour déplacer'
                    ]),
                    React.createElement('span', {
                        key: 'resize-help',
                        className: 'flex items-center'
                    }, [
                        React.createElement('i', { key: 'icon2', className: 'fas fa-expand-arrows-alt mr-2' }),
                        'Coin pour redimensionner'
                    ]),
                    React.createElement('span', {
                        key: 'save-help',
                        className: 'flex items-center'
                    }, [
                        React.createElement('i', { key: 'icon3', className: 'fas fa-save mr-2' }),
                        'Sauvegarder pour valider'
                    ])
                ])
            ])
        ]);
    } catch (error) {
        console.error('PDFViewer component error:', error);
        reportError(error);
    }
}

// Système de numérotation auto-incrémentée pour chaque direction
const getNextMailNumber = async (type, directionCode, year) => {
    try {
        // Clé unique pour chaque combinaison type-direction-année
        const counterKey = `${type}-${directionCode}-${year}`;
        
        // Récupérer le compteur actuel pour cette combinaison
        const counters = await trickleListObjects('mail-counters', 100, true);
        const existingCounter = counters.items.find(item => 
            item.objectData.key === counterKey
        );
        
        let nextNumber = 1; // Commence à 1 pour le premier courrier (devient 0001)
        
        if (existingCounter) {
            // Incrémenter le compteur existant
            nextNumber = existingCounter.objectData.currentNumber + 1;
            
            // Vérifier la limite de 9999
            if (nextNumber > 9999) {
                throw new Error(`Limite de numérotation atteinte (9999) pour ${counterKey}`);
            }
            
            // Mettre à jour le compteur
            await trickleUpdateObject('mail-counters', existingCounter.objectId, {
                ...existingCounter.objectData,
                currentNumber: nextNumber,
                lastUpdated: new Date().toISOString()
            });
        } else {
            // Créer un nouveau compteur pour cette direction/type/année
            await trickleCreateObject('mail-counters', {
                key: counterKey,
                type: type,
                directionCode: directionCode,
                year: year,
                currentNumber: nextNumber,
                createdAt: new Date().toISOString(),
                lastUpdated: new Date().toISOString()
            });
        }
        
        // Générer le numéro final avec padding à 4 chiffres
        const prefix = type === 'arrive' ? 'A' : 'D';
        return `${prefix}-${nextNumber.toString().padStart(4, '0')}-${directionCode}-${year}`;
        
    } catch (error) {
        console.error('Erreur système numérotation:', error);
        throw error;
    }
};

// Fonction pour obtenir le prochain numéro sans l'incrémenter (preview)
const previewNextNumber = async (type, directionCode, year) => {
    try {
        const counterKey = `${type}-${directionCode}-${year}`;
        const counters = await trickleListObjects('mail-counters', 100, true);
        const existingCounter = counters.items.find(item => 
            item.objectData.key === counterKey
        );
        
        const nextNumber = existingCounter ? existingCounter.objectData.currentNumber + 1 : 1;
        const prefix = type === 'arrive' ? 'A' : 'D';
        return `${prefix}-${nextNumber.toString().padStart(4, '0')}-${directionCode}-${year}`;
    } catch (error) {
        console.error('Erreur preview numéro:', error);
        return `${type === 'arrive' ? 'A' : 'D'}-0001-${directionCode}-${year}`;
    }
};

// Fonction pour obtenir les statistiques de numérotation par direction
const getNumberingStats = async (directionCode, year) => {
    try {
        const counters = await trickleListObjects('mail-counters', 100, true);
        const directionCounters = counters.items
            .map(item => item.objectData)
            .filter(counter => 
                counter.directionCode === directionCode && 
                counter.year === year
            );
        
        return {
            arrive: directionCounters.find(c => c.type === 'arrive')?.currentNumber || 0,
            depart: directionCounters.find(c => c.type === 'depart')?.currentNumber || 0,
            total: directionCounters.reduce((sum, c) => sum + c.currentNumber, 0)
        };
    } catch (error) {
        console.error('Erreur stats numérotation:', error);
        return { arrive: 0, depart: 0, total: 0 };
    }
};

// Fonction pour réinitialiser les compteurs (admin seulement)
const resetCountersForYear = async (year) => {
    try {
        const counters = await trickleListObjects('mail-counters', 1000, true);
        const yearCounters = counters.items.filter(item => 
            item.objectData.year === year
        );
        
        for (const counter of yearCounters) {
            await trickleUpdateObject('mail-counters', counter.objectId, {
                ...counter.objectData,
                currentNumber: 0,
                lastUpdated: new Date().toISOString()
            });
        }
        
        return `${yearCounters.length} compteurs réinitialisés pour l'année ${year}`;
    } catch (error) {
        console.error('Erreur réinitialisation compteurs:', error);
        throw error;
    }
};

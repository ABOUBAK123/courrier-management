const generateMailNumber = async (type, directionCode, year) => {
    try {
        // Récupérer tous les courriers de cette direction pour ce type et cette année
        const existingMails = await trickleListObjects(`mail:${directionCode}`, 1000, true);
        
        // Filtrer par type et année pour cette direction spécifique
        const sameTypeMails = existingMails.items
            .map(item => item.objectData)
            .filter(mail => 
                mail.type === type && 
                mail.numero && 
                mail.numero.includes(`-${directionCode}-${year}`)
            );
        
        // Extraire les numéros séquentiels et trouver le plus grand
        let maxNumber = 0;
        sameTypeMails.forEach(mail => {
            // Pattern: A-0001-DIR001-2024 ou D-0001-DIR001-2024
            const prefix = type === 'arrive' ? 'A' : 'D';
            const pattern = new RegExp(`${prefix}-(\\d{4})-${directionCode}-${year}`);
            const match = mail.numero.match(pattern);
            if (match) {
                const num = parseInt(match[1]);
                if (num > maxNumber) {
                    maxNumber = num;
                }
            }
        });
        
        // Générer le prochain numéro (commence à 0001)
        const nextNumber = maxNumber + 1;
        const prefix = type === 'arrive' ? 'A' : 'D';
        
        // Format: A-0001-DIR001-2024 (toujours 4 chiffres)
        return `${prefix}-${nextNumber.toString().padStart(4, '0')}-${directionCode}-${year}`;
        
    } catch (error) {
        console.error('Erreur génération numéro:', error);
        // Fallback sécurisé qui commence aussi par 0001
        const prefix = type === 'arrive' ? 'A' : 'D';
        return `${prefix}-0001-${directionCode}-${year}`;
    }
};

const generateFileNumber = () => {
    const now = new Date();
    const counter = Math.floor(Math.random() * 9999) + 1;
    const timestamp = now.toISOString().replace(/[-:T.]/g, '').slice(0, 14);
    return `J-${counter.toString().padStart(4, '0')}-${timestamp}`;
};

const PRIORITIES = [
    { value: 'faible', label: 'Faible', color: 'text-green-600' },
    { value: 'normale', label: 'Normale', color: 'text-blue-600' },
    { value: 'elevee', label: 'Élevée', color: 'text-orange-600' },
    { value: 'urgente', label: 'Urgente', color: 'text-red-600' }
];

const STATUSES = [
    { value: 'attente', label: 'En attente', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'traitement', label: 'En traitement', color: 'bg-blue-100 text-blue-800' },
    { value: 'traite', label: 'Traité', color: 'bg-green-100 text-green-800' },
    { value: 'valide', label: 'Validé', color: 'bg-purple-100 text-purple-800' }
];

const ROLES = {
    ADMIN: 'ADMIN',
    MINISTRE: 'MINISTRE',
    DIR_CAB: 'DIR CAB',
    DIRECTEUR_GENERAL: 'DIRECTEUR GENERAL',
    DIRECTEUR: 'DIRECTEUR',
    SOUS_DIRECTEUR: 'SOUS-DIRECTEUR',
    ASSISTANT: 'ASSISTANT',
    CHEF_SERVICE: 'CHEF DE SERVICE',
    AGENT: 'AGENT'
};

const canViewImputation = (role) => {
    return ['ADMIN', 'MINISTRE', 'DIR CAB', 'DIRECTEUR GENERAL', 'DIRECTEUR'].includes(role);
};

const canReimpute = (role) => {
    return ['DIR CAB', 'DIRECTEUR GENERAL', 'DIRECTEUR', 'SOUS-DIRECTEUR'].includes(role);
};

const AuthContext = React.createContext();

function useAuth() {
    const context = React.useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within AuthProvider');
    }
    return context;
}

function AuthProvider({ children }) {
    try {
        const [user, setUser] = React.useState(null);
        const [loading, setLoading] = React.useState(true);

        React.useEffect(() => {
            const initializeAuth = async () => {
                try {
                    // Create default user if none exists
                    const users = await trickleListObjects('user', 10, true);
                    if (users.items.length === 0) {
                        await trickleCreateObject('user', {
                            name: 'Administrateur',
                            email: 'admin@gov.com',
                            password: 'admin123',
                            role: 'ADMIN',
                            direction: 'DIR001'
                        });
                    }

                    // Check for saved user
                    const savedUser = localStorage.getItem('currentUser');
                    if (savedUser) {
                        setUser(JSON.parse(savedUser));
                    }
                } catch (error) {
                    console.error('Erreur d\'initialisation:', error);
                } finally {
                    setLoading(false);
                }
            };

            initializeAuth();
        }, []);

        const login = async (email, password) => {
            try {
                const users = await trickleListObjects('user', 100, true);
                const foundUser = users.items.find(u => 
                    u.objectData.email === email && u.objectData.password === password
                );
                
                if (foundUser) {
                    const userData = foundUser.objectData;
                    
                    // Get role URL if exists
                    const roles = await trickleListObjects('roles', 100, true);
                    const userRole = roles.items.find(r => r.objectData.nom === userData.role);
                    
                    if (userRole && userRole.objectData.urlConnexion) {
                        userData.urlConnexion = userRole.objectData.urlConnexion;
                    }
                    
                    setUser(userData);
                    localStorage.setItem('currentUser', JSON.stringify(userData));
                    return { success: true, user: userData };
                }
                return { success: false, error: 'Email ou mot de passe incorrect' };
            } catch (error) {
                console.error('Erreur de connexion:', error);
                return { success: false, error: 'Erreur de connexion au serveur' };
            }
        };

        const logout = () => {
            setUser(null);
            localStorage.removeItem('currentUser');
        };

        const value = { user, login, logout, loading };

        return React.createElement(AuthContext.Provider, { value }, children);
    } catch (error) {
        console.error('AuthProvider error:', error);
        reportError(error);
    }
}
